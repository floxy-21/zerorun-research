'''
Language parser for Apple Swift
'''

from .code_reader import CodeReader, CodeStateMachine
from .clike import CCppCommentsMixin


class SwiftReader(CodeReader, CCppCommentsMixin):
    # pylint: disable=R0903

    ext = ['swift']
    language_names = ['swift']

    def __init__(self, context):
        super(SwiftReader, self).__init__(context)
        self.parallel_states = [SwiftStates(context)]

    @staticmethod
    def generate_tokens(source_code, addition='', token_class=None):
        return CodeReader.generate_tokens(
            source_code,
            r"|`\w+`" +
            r"|\w+\?" +
            r"|\w+\!" +
            r"|\?\?" +
            addition)


class SwiftStates(CodeStateMachine):  # pylint: disable=R0903
    def _state_global(self, token):
        if token == 'func':
            self._state = self._function_name
        if token in ('init', 'subscript'):
            self._function_name(token)
        if token in ('get', 'set', 'willSet', 'didSet', 'deinit'):
            self._previous_function = self.context.current_function
            self.context.try_new_function(token)
            self._state = self._expect_accessor
        if token == 'protocol':
            self._state = self._protocol

    def _function_name(self, token):
        self.context.start_new_function(token.strip('`'))
        self._state = self._expect_function_dec

    def _expect_accessor(self, token):
        # Accessor names are also valid identifiers. Only start a function
        # when the name is immediately followed by a body or parameter list.
        if token in ('{', '('):
            self.context.confirm_new_function()
            self._state = (self._function_impl if token == '{'
                           else self._function_dec)
            if token == '{':
                self._state(token)
        else:
            self.context.current_function = self._previous_function
            self.next(self._state_global, token)

    def _expect_function_dec(self, token):
        if token == '(':
            self._state = self._function_dec

    def _function_dec(self, token):
        if token == ')':
            self._state = self._expect_function_impl
        else:
            self.context.parameter(token)

    def _expect_function_impl(self, token):
        if token == '{':
            self._state = self._function_impl
            self._state(token)

    @CodeStateMachine.read_inside_brackets_then("{}")
    def _function_impl(self, _):
        self._state = self._state_global
        self.context.end_of_function()

    @CodeStateMachine.read_inside_brackets_then("{}")
    def _protocol(self, end_token):
        if end_token == "}":
            self._state = self._state_global
