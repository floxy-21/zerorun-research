"""\
Test the fake fastnumbers module.
"""

from __future__ import annotations

import unicodedata
from decimal import Decimal
from math import isinf
from typing import cast

from hypothesis import given
from hypothesis.strategies import floats, integers, text

from natsort.compat.fake_fastnumbers import fast_float, fast_int


def is_float(x: str) -> bool:
    try:
        float(x)
    except ValueError:
        try:
            unicodedata.numeric(x)
        except (ValueError, TypeError):
            return False
        else:
            return True
    else:
        return True


def not_a_float(x: str) -> bool:
    return not is_float(x)


def is_int(x: str | float) -> bool:
    try:
        return cast("float", x).is_integer()
    except AttributeError:
        try:
            int(x)
        except ValueError:
            try:
                unicodedata.digit(cast("str", x))
            except (ValueError, TypeError):
                return False
            else:
                return True
        else:
            return True


def not_an_int(x: str | float) -> bool:
    return not is_int(x)


# Each test has an "example" version for demonstrative purposes,
# and a test that uses the hypothesis module.


def test_fast_float_returns_nan_alternate_if_nan_option_is_given() -> None:
    assert fast_float("nan", nan=7) == 7


def test_fast_float_converts_float_string_to_float_example() -> None:
    assert fast_float("45.8") == 45.8
    assert fast_float("-45") == -45.0
    assert fast_float("45.8e-2", key=lambda x: x.upper()) == 45.8e-2
    assert isinf(cast("float", fast_float("nan")))
    assert isinf(cast("float", fast_float("+nan")))
    assert isinf(cast("float", fast_float("-NaN")))
    assert fast_float("۱۲.۱۲") == 12.12
    assert fast_float("-۱۲.۱۲") == -12.12


@given(floats(allow_nan=False))
def test_fast_float_converts_float_string_to_float(x: float) -> None:
    assert fast_float(repr(x)) == x


def test_fast_float_widens_overflowing_magnitude_to_decimal_example() -> None:
    # "1e400" and "1e500" both overflow float()'s range to inf, so on
    # their own they would compare equal and lose their real order.
    # Widening the result to Decimal keeps them distinguishable.
    small = fast_float("1e400")
    large = fast_float("1e500")
    assert isinstance(small, Decimal)
    assert isinstance(large, Decimal)
    assert small != large
    assert small < large


def test_fast_float_still_returns_a_plain_float_for_literal_infinity() -> None:
    # A string that spells out infinity is not the result of an overflow,
    # so it should still come back as a plain float, same as before.
    assert fast_float("inf") == float("inf")
    assert fast_float("-inf") == float("-inf")
    assert isinstance(fast_float("inf"), float)


def test_fast_float_leaves_string_as_is_example() -> None:
    assert fast_float("invalid") == "invalid"
    assert fast_float("") == ""


@given(text().filter(not_a_float))
def test_fast_float_leaves_string_as_is(x: str) -> None:
    assert fast_float(x) == x


def test_fast_float_with_key_applies_to_string_example() -> None:
    assert fast_float("invalid", key=lambda x: x.upper()) == "INVALID"
    assert fast_float("", key=lambda x: x.upper()) == ""


@given(text().filter(not_a_float))
def test_fast_float_with_key_applies_to_string(x: str) -> None:
    assert fast_float(x, key=lambda x: x.upper()) == x.upper()


def test_fast_int_leaves_float_string_as_is_example() -> None:
    assert fast_int("45.8") == "45.8"
    assert fast_int("nan") == "nan"
    assert fast_int("inf") == "inf"


@given(floats().filter(not_an_int))
def test_fast_int_leaves_float_string_as_is(x: float) -> None:
    assert fast_int(repr(x)) == repr(x)


def test_fast_int_converts_int_string_to_int_example() -> None:
    assert fast_int("-45") == -45
    assert fast_int("+45") == 45
    assert fast_int("۱۲") == 12
    assert fast_int("-۱۲") == -12


@given(integers())
def test_fast_int_converts_int_string_to_int(x: int) -> None:
    assert fast_int(repr(x)) == x


def test_fast_int_leaves_string_as_is_example() -> None:
    assert fast_int("invalid") == "invalid"
    assert fast_int("") == ""


@given(text().filter(not_an_int))
def test_fast_int_leaves_string_as_is(x: str) -> None:
    assert fast_int(x) == x


def test_fast_int_with_key_applies_to_string_example() -> None:
    assert fast_int("invalid", key=lambda x: x.upper()) == "INVALID"
    assert fast_int("", key=lambda x: x.upper()) == ""


@given(text().filter(not_an_int))
def test_fast_int_with_key_applies_to_string(x: str) -> None:
    assert fast_int(x, key=lambda x: x.upper()) == x.upper()
