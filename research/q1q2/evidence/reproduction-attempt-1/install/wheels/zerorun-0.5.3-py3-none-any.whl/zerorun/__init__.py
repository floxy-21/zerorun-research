"""ZeroRun validation MVP."""

__version__ = "0.5.3"
