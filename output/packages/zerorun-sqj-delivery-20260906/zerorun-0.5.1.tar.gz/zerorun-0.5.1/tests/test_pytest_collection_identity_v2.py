from __future__ import annotations

import operator

from tools.pytest_collection_identity_v2 import canonical_parameter


class Option:
    def __init__(self, verbosity: int) -> None:
        self.verbosity = verbosity


def _named(value: object) -> object:
    return value


def test_plain_project_object_identity_tracks_exact_state() -> None:
    default = canonical_parameter(Option(0))
    verbose = canonical_parameter(Option(1))

    assert default["supported"] is True
    assert default["value"][:3] == [
        "plain-object",
        __name__,
        "Option",
    ]
    assert default != verbose


def test_python_function_identity_distinguishes_lambdas_and_named_functions() -> None:
    first = lambda value: None
    second = lambda value: False

    first_identity = canonical_parameter(first)
    second_identity = canonical_parameter(second)
    named_identity = canonical_parameter(_named)

    assert first_identity["supported"] is True
    assert second_identity["supported"] is True
    assert named_identity["supported"] is True
    assert first_identity["value"][0] == "python-function"
    assert first_identity != second_identity
    assert named_identity != first_identity


def test_python_function_identity_tracks_defaults_and_closure_values() -> None:
    def make(value: int):
        def inner(arg: int = 2) -> int:
            return value + arg

        return inner

    one = canonical_parameter(make(1))
    two = canonical_parameter(make(2))

    assert one["supported"] is True
    assert two["supported"] is True
    assert one != two


def test_builtin_operator_identity_is_structural_and_distinct() -> None:
    lt = canonical_parameter(operator.lt)
    gt = canonical_parameter(operator.gt)

    assert lt["supported"] is True
    assert gt["supported"] is True
    assert lt["value"][0] == "builtin-callable"
    assert lt != gt


def test_cycles_and_opaque_values_stay_fail_closed() -> None:
    cyclic: list[object] = []
    cyclic.append(cyclic)
    cycle = canonical_parameter(cyclic)
    opaque = canonical_parameter({1, 2})

    assert cycle["supported"] is False
    assert opaque["supported"] is False
