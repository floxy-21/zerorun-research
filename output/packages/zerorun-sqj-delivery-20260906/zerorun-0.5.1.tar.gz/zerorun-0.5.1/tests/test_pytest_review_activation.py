from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from zerorun.model import ConfigurationError
from zerorun.pytest_review import (
    activate_reviewed_candidate,
    write_review_template,
)


def _candidate(path: Path) -> dict:
    payload = {
        "schema": "zerorun-pytest-candidate-v1",
        "authorizes_reuse": False,
        "candidate_only": True,
        "generated_from_observation": True,
        "task": "tests",
        "base_args": [],
        "targets": ["tests"],
        "static_inputs": ["pyproject.toml"],
        "session_closure": {
            "selectors": ["pkg/session.py::setup"],
            "fallback_files": [],
        },
        "nodes": {
            "tests/test_a.py::test_a": {
                "reviewable": True,
                "fresh_required": False,
                "selectors": ["pkg/a.py::run"],
                "fallback_files": [],
            },
            "tests/test_b.py::test_b": {
                "reviewable": False,
                "fresh_required": True,
                "reason": "unsupported parameter identity",
                "selectors": [],
                "fallback_files": [],
            },
        },
        "review": {
            "required": True,
            "independence_review_sha256": None,
            "reason": "candidate only",
        },
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    payload["candidate_sha256"] = hashlib.sha256(encoded).hexdigest()
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload


def test_review_template_is_non_authorizing(tmp_path: Path):
    candidate = tmp_path / ".zerorun-pytest.candidate.json"
    payload = _candidate(candidate)
    review = tmp_path / ".zerorun-pytest.review.json"
    result = write_review_template(candidate, output=review, reviewer="operator")
    assert result["candidate_sha256"] == payload["candidate_sha256"]
    assert result["closure_completeness_reviewed"] is False
    assert result["node_independence_reviewed"] is False
    assert result["all_candidate_reviewable_nodes_covered"] is False
    assert result["authorizes_activation"] is False
    assert result["candidate_reviewable_nodes"] == 1
    assert result["fresh_required_nodes"] == 1


def test_activation_refuses_incomplete_review(tmp_path: Path):
    candidate = tmp_path / ".zerorun-pytest.candidate.json"
    _candidate(candidate)
    review = tmp_path / ".zerorun-pytest.review.json"
    write_review_template(candidate, output=review, reviewer="operator")
    with pytest.raises(ConfigurationError, match="does not authorize activation"):
        activate_reviewed_candidate(
            candidate,
            review_path=review,
            output=tmp_path / ".zerorun-pytest.json",
        )


def test_activation_binds_exact_completed_review(tmp_path: Path):
    candidate = tmp_path / ".zerorun-pytest.candidate.json"
    payload = _candidate(candidate)
    review_path = tmp_path / ".zerorun-pytest.review.json"
    review = write_review_template(candidate, output=review_path, reviewer="operator")
    review.update(
        {
            "closure_completeness_reviewed": True,
            "node_independence_reviewed": True,
            "all_candidate_reviewable_nodes_covered": True,
            "authorizes_activation": True,
            "notes": "reviewed exact candidate evidence",
        }
    )
    review_path.write_text(json.dumps(review, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    profile_path = tmp_path / ".zerorun-pytest.json"
    result = activate_reviewed_candidate(
        candidate,
        review_path=review_path,
        output=profile_path,
    )
    profile = json.loads(profile_path.read_text())
    expected_review_sha = hashlib.sha256(
        json.dumps(review, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()

    assert result["reuse_activated"] is True
    assert result["candidate_sha256"] == payload["candidate_sha256"]
    assert result["review_record_sha256"] == expected_review_sha
    assert profile["candidate_sha256"] == payload["candidate_sha256"]
    assert profile["review_record_sha256"] == expected_review_sha
    assert profile["independence_review_sha256"] == expected_review_sha
    assert profile["nodes"]["tests/test_b.py::test_b"]["fresh_required"] is True


def test_activation_refuses_review_for_different_candidate(tmp_path: Path):
    candidate = tmp_path / ".zerorun-pytest.candidate.json"
    _candidate(candidate)
    review_path = tmp_path / ".zerorun-pytest.review.json"
    review = write_review_template(candidate, output=review_path, reviewer="operator")
    review["candidate_sha256"] = "0" * 64
    review.update(
        {
            "closure_completeness_reviewed": True,
            "node_independence_reviewed": True,
            "all_candidate_reviewable_nodes_covered": True,
            "authorizes_activation": True,
        }
    )
    review_path.write_text(json.dumps(review, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with pytest.raises(ConfigurationError, match="different candidate"):
        activate_reviewed_candidate(
            candidate,
            review_path=review_path,
            output=tmp_path / ".zerorun-pytest.json",
        )
