from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from tools import pytest_result_dependency_probe as result_probe
from tools import pytest_session_scoped_result_probe as scoped


def test_consumer_filtered_sources_exclude_reporter_hooks_from_shared_session() -> None:
    plugin = scoped.plugin_source()
    site = scoped.sitecustomize_source()

    assert "ZERORUN_PROFILE_RESULT_CONSUMER" in plugin
    assert "def pytest_runtest_logstart" in plugin
    assert "def pytest_runtest_logreport" in plugin
    assert "def pytest_runtest_logfinish" in plugin
    assert "def pytest_terminal_summary" in plugin
    assert "def _sync_profile_context():" in plugin
    assert "def zerorun_set_profile_context(nodeid, consumer, collection_active):" in site
    assert "_CONSUMER_ACTIVE = bool(consumer) and nodeid is None" in site
    assert "if _CONSUMER_ACTIVE:" in site
    assert "nodeid = _CURRENT_NODEID" in site
    assert "nodeid = os.environ.get(_NODE_ENV)" not in site
    assert "def _receiver_mro(frame, name):" in site
    assert "receiver_mro = _receiver_mro(frame, name)" in site


def test_pre_collection_calls_are_retained_separately_from_shared_result_session() -> None:
    plugin = scoped.plugin_source()
    site = scoped.sitecustomize_source()

    assert "ZERORUN_PROFILE_COLLECTION_ACTIVE" in plugin
    assert '@pytest.hookimpl(hookwrapper=True, trylast=True)\ndef pytest_collection_finish' in plugin
    collection_finish = plugin.split("def pytest_collection_finish(session):", 1)[1].split(
        "def pytest_sessionfinish", 1
    )[0]
    assert "yield" in collection_finish
    assert 'os.environ[_COLLECTION_ENV] = "0"' in collection_finish
    assert collection_finish.index("yield") < collection_finish.index(
        'os.environ[_COLLECTION_ENV] = "0"'
    )
    assert "_sync_profile_context()" in collection_finish
    assert 'os.environ.get(_COLLECTION_ENV, "1") == "1"' in plugin
    assert '__collection__' in site
    assert "_COLLECTION_ACTIVE = os.environ.get(_COLLECTION_ENV, \"1\") == \"1\"" in site
    assert "nodeid = _COLLECTION_NODE if _COLLECTION_ACTIVE else _SESSION_NODE" in site


def test_top_level_consumer_filter_preserves_nested_test_dependencies() -> None:
    site = scoped.sitecustomize_source()

    assert (
        "_CONSUMER_ACTIVE = bool(os.environ.get(_CONSUMER_ENV)) "
        "and _CURRENT_NODEID is None"
    ) in site
    assert "_CONSUMER_ACTIVE = bool(consumer) and nodeid is None" in site
    assert '("src/_pytest/terminal.py", "report_collect")' in site
    assert (
        "if nodeid is None and (relative, name) in "
        "_TOP_LEVEL_RESULT_CONSUMER_CALLS:"
    ) in site


def test_session_profile_deduplicates_only_import_class_body_frames() -> None:
    site = scoped.sitecustomize_source()

    assert "def _is_redundant_import_class_body(frame, relative):" in site
    assert 'if code.co_name == "<module>" or (code.co_flags & 0x1):' in site
    assert 'if parent_code.co_name == "<module>":' in site
    assert "if parent_code.co_flags & 0x1:" in site
    assert "if nodeid is None and _is_redundant_import_class_body(frame, relative):" in site

    assert "nodeid = _COLLECTION_NODE if _COLLECTION_ACTIVE else _SESSION_NODE" in site


def test_scoped_profile_temporarily_swaps_and_restores_sources(monkeypatch) -> None:
    original_plugin = result_probe._RESULT_PLUGIN_SOURCE
    original_site = result_probe._RESULT_SITE_CUSTOMIZE
    observed = {}
    partition = SimpleNamespace(name="example")
    collection_row = ("src/_pytest/main.py", 1, "<module>", tuple(), False)

    def fake_run(root: Path, partition, environment):
        observed["plugin"] = result_probe._RESULT_PLUGIN_SOURCE
        observed["site"] = result_probe._RESULT_SITE_CUSTOMIZE
        return ["testing/test_example.py::test_one"], {"__collection__": {collection_row}}, 1.0

    monkeypatch.setattr(result_probe, "_run_result_profile", fake_run)
    scoped._COLLECTION_CALLS_BY_PARTITION.clear()
    result = scoped.run_result_profile(Path("."), partition, {})

    assert result[0] == ["testing/test_example.py::test_one"]
    assert "__collection__" not in result[1]
    assert scoped._COLLECTION_CALLS_BY_PARTITION["example"] == {collection_row}
    assert observed["plugin"] == scoped.plugin_source()
    assert observed["site"] == scoped.sitecustomize_source()
    assert result_probe._RESULT_PLUGIN_SOURCE == original_plugin
    assert result_probe._RESULT_SITE_CUSTOMIZE == original_site


def test_profiler_identity_keeps_independence_and_collection_gates() -> None:
    identity = scoped.profiler_identity()
    assert identity["excluded_result_consumers"] == [
        *result_probe._RESULT_CONSUMER_HOOKS,
        "pytest_terminal_summary",
    ]
    assert identity["consumer_profiler_paused"] is True
    assert identity["consumer_profiler_paused_only_without_node_context"] is True
    assert identity["audited_top_level_result_consumer_calls"] == [
        "src/_pytest/terminal.py::TerminalReporter.report_collect"
    ]
    assert identity["pre_collection_bucket"] == "__collection__"
    assert identity["pre_collection_excluded_from_shared_result_session"] is True
    assert identity["pre_collection_evidence_retained_out_of_band"] is True
    assert identity["collection_finish_transition"] == "after-all-hooks"
    assert identity["collection_gate_still_required"] is True
    assert identity["hot_path_environment_lookups"] is False
    assert "obj/_getobj" in identity["receiver_mro_evidence"]
    assert "@module-state" in identity["redundant_import_class_body_policy"]
    assert identity["node_independence_review_still_required"] is True
    assert len(identity["plugin_sha256"]) == 64
    assert len(identity["sitecustomize_sha256"]) == 64
