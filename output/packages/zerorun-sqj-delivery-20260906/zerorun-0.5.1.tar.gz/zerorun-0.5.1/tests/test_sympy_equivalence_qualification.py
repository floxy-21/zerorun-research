from __future__ import annotations

from tools.sympy_equivalence_qualification import _REVIEWS


def test_candidate_reviews_are_exact_source_pair_bound() -> None:
    assert set(_REVIEWS) == {20250, 20590}
    identities = set()
    for pr, review in _REVIEWS.items():
        assert review.pr == pr
        assert len(review.pre_merge_sha) == 40
        assert len(review.merge_sha) == 40
        assert len(review.identity_sha256) == 64
        identities.add(review.identity_sha256)
        assert review.reusable_partitions
        assert review.excluded_paths
    assert len(identities) == len(_REVIEWS)


def test_core_slots_candidate_never_reuses_core_partition() -> None:
    review = _REVIEWS[20590]
    assert review.pre_merge_sha == "cffd4e0f86fefd4802349a9f9b19ed70934ea354"
    assert review.merge_sha == "c0600593360b2bbba4595ccc5e171cb729cf6051"
    assert "core" not in review.reusable_partitions
    assert "sympy/core/_print_helpers.py" in review.excluded_paths


def test_doctest_blacklist_candidate_keeps_printing_fresh() -> None:
    review = _REVIEWS[20250]
    assert review.pre_merge_sha == "7f189265b46a0295a60f8cfe2ed449193e630852"
    assert review.merge_sha == "99701a55707a8cf9261e6e798998c6db4e987bd0"
    assert "printing" not in review.reusable_partitions
    assert review.excluded_paths == ("sympy/testing/runtests.py",)
