from __future__ import annotations

import base64
import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

import pytest

from tools import codex_agent_integration_smoke as smoke


FIXED_TIME = datetime(2026, 9, 5, 12, 0, tzinfo=timezone.utc)


def _git(*arguments: str, cwd: Path) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(
        [shutil.which("git") or "git", *arguments],
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


def _repository(tmp_path: Path) -> Path:
    root = tmp_path / "repository"
    root.mkdir()
    assert _git("init", "-q", cwd=root).returncode == 0
    assert _git("config", "user.email", "smoke@example.invalid", cwd=root).returncode == 0
    assert _git("config", "user.name", "Smoke Fixture", cwd=root).returncode == 0
    (root / ".zerorun.json").write_text(
        json.dumps(
            {
                "version": 2,
                "tasks": {
                    "tests": {
                        "command": ["python", "-m", "pytest"],
                        "inputs": ["tests"],
                        "outputs": [],
                        "env": [],
                        "cacheable": True,
                        "unsafe_effects": [],
                        "cache_streams": False,
                        "result_only": True,
                        "closure_reviewed": True,
                        "image": "python@sha256:" + "1" * 64,
                        "platform": "linux/amd64",
                    }
                },
            }
        )
        + "\n",
        encoding="utf-8",
    )
    (root / "tracked.txt").write_text("unchanged\n", encoding="utf-8")
    assert _git("add", ".zerorun.json", "tracked.txt", cwd=root).returncode == 0
    assert _git("commit", "-q", "-m", "fixture", cwd=root).returncode == 0
    return root.resolve()


def _doctor(root: Path, *, ok: bool = True) -> dict[str, Any]:
    ready = ok
    return {
        "root": str(root),
        "manifest": str(root / ".zerorun.json"),
        "manifest_present": True,
        "manifest_version": 2,
        "mcp_manifest_supported": True,
        "manifest_authorized": ready,
        "pytest_profile": {"present": False, "valid": False},
        "pytest_profile_present": False,
        "mode": "task-reuse" if ready else "observe-only",
        "reuse_ready": ready,
        "task_reuse_ready": ready,
        "pytest_reuse_ready": False,
        "platform": "fixture",
        "contract": "fixture",
        "tasks": [],
        "ok": ok,
    }


def _events(
    root: Path,
    *,
    ok: bool = True,
    extra_items: Sequence[dict[str, Any]] = (),
    second_call: bool = False,
    invalid_state: bool = False,
    failed_call: bool = False,
) -> bytes:
    payload = _doctor(root, ok=ok)
    if invalid_state:
        payload["reuse_ready"] = not payload["reuse_ready"]
    result = {
        "content": [
            {
                "type": "text",
                "text": json.dumps(payload, indent=2, sort_keys=True),
            }
        ],
        "structured_content": payload,
    }
    completed_item: dict[str, Any] = {
        "id": "item-doctor",
        "type": "mcp_tool_call",
        "server": "zerorun",
        "tool": "doctor",
        "arguments": {"root": str(root)},
        "status": "failed" if failed_call else "completed",
    }
    if failed_call:
        completed_item["error"] = {"message": "fixture MCP isError"}
    else:
        completed_item["result"] = result
    values: list[dict[str, Any]] = [
        {"type": "thread.started", "thread_id": "thread-fixture"},
        {"type": "turn.started"},
        {
            "type": "item.started",
            "item": {
                "id": "item-doctor",
                "type": "mcp_tool_call",
                "server": "zerorun",
                "tool": "doctor",
                "arguments": {"root": str(root)},
                "status": "in_progress",
            },
        },
        {
            "type": "item.completed",
            "item": completed_item,
        },
    ]
    values.extend(extra_items)
    if second_call:
        values.extend(
            [
                {
                    "type": "item.started",
                    "item": {
                        "id": "item-doctor-2",
                        "type": "mcp_tool_call",
                        "server": "zerorun",
                        "tool": "doctor",
                        "arguments": {"root": str(root)},
                        "status": "in_progress",
                    },
                },
                {
                    "type": "item.completed",
                    "item": {
                        "id": "item-doctor-2",
                        "type": "mcp_tool_call",
                        "server": "zerorun",
                        "tool": "doctor",
                        "arguments": {"root": str(root)},
                        "result": result,
                        "status": "completed",
                    },
                },
            ]
        )
    values.extend(
        [
            {
                "type": "item.completed",
                "item": {
                    "id": "item-message",
                    "type": "agent_message",
                    "text": smoke.FINAL_MARKER,
                },
            },
            {
                "type": "turn.completed",
                "usage": {
                    "input_tokens": 100,
                    "cached_input_tokens": 0,
                    "cache_write_input_tokens": 0,
                    "output_tokens": 10,
                    "reasoning_output_tokens": 0,
                },
            },
        ]
    )
    return b"".join(
        json.dumps(value, separators=(",", ":"), sort_keys=True).encode() + b"\n"
        for value in values
    )


class FixtureRunner:
    def __init__(
        self,
        root: Path,
        codex: Path,
        zerorun: Path,
        stdout: bytes,
        *,
        registration_overrides: dict[str, Any] | None = None,
        codex_returncode: int = 0,
        timed_out: bool = False,
        stdout_truncated: bool = False,
        mutate: bool = False,
        zerorun_version: str | None = None,
    ) -> None:
        self.root = root
        self.codex = codex
        self.zerorun = zerorun
        self.stdout = stdout
        self.registration_overrides = registration_overrides or {}
        self.codex_returncode = codex_returncode
        self.timed_out = timed_out
        self.stdout_truncated = stdout_truncated
        self.mutate = mutate
        self.zerorun_version = zerorun_version or smoke.SOURCE_ZERORUN_VERSION
        self.calls: list[dict[str, Any]] = []
        self.exec_calls = 0

    def __call__(
        self,
        command: Sequence[str],
        *,
        cwd: Path | None,
        environment: dict[str, str],
        timeout_seconds: float,
        output_limit_bytes: int,
        input_bytes: bytes | None = None,
    ) -> smoke.CommandResult:
        argv = [str(value) for value in command]
        self.calls.append(
            {
                "command": argv,
                "cwd": cwd,
                "environment": dict(environment),
                "timeout_seconds": timeout_seconds,
                "output_limit_bytes": output_limit_bytes,
                "input_bytes": input_bytes,
            }
        )
        if Path(argv[0]) == self.codex and argv[1:] == ["--version"]:
            return smoke.CommandResult(tuple(argv), 0, b"codex-cli 0.fixture\n", b"")
        if Path(argv[0]) == self.codex and argv[1:] == [
            "mcp",
            "get",
            "zerorun",
            "--json",
        ]:
            registration: dict[str, Any] = {
                "name": "zerorun",
                "enabled": True,
                "disabled_reason": None,
                "transport": {
                    "type": "stdio",
                    "command": str(self.zerorun),
                    "args": ["mcp-server"],
                    "env": None,
                    "env_vars": [],
                    "cwd": None,
                },
                "enabled_tools": None,
                "disabled_tools": None,
            }
            registration.update(self.registration_overrides)
            return smoke.CommandResult(
                tuple(argv),
                0,
                json.dumps(registration).encode(),
                b"",
            )
        if Path(argv[0]) == self.zerorun and argv[1:] == ["--version"]:
            return smoke.CommandResult(
                tuple(argv),
                0,
                f"zerorun {self.zerorun_version}\n".encode(),
                b"",
            )
        if Path(argv[0]) == self.codex and "exec" in argv[1:]:
            self.exec_calls += 1
            if self.mutate:
                (self.root / "tracked.txt").write_text("mutated\n", encoding="utf-8")
            return smoke.CommandResult(
                tuple(argv),
                self.codex_returncode,
                self.stdout,
                b"fixture stderr\n",
                timed_out=self.timed_out,
                stdout_truncated=self.stdout_truncated,
            )
        completed = subprocess.run(
            argv,
            cwd=cwd,
            env=environment,
            input=input_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_seconds,
            check=False,
        )
        return smoke.CommandResult(
            tuple(argv),
            completed.returncode,
            completed.stdout,
            completed.stderr,
        )


def _runner(
    tmp_path: Path,
    *,
    events: bytes | None = None,
    **kwargs: Any,
) -> tuple[Path, FixtureRunner]:
    root = _repository(tmp_path)
    tools = tmp_path / "installed-tools"
    tools.mkdir()
    codex = (tools / ("codex.exe" if os.name == "nt" else "codex")).resolve()
    zerorun = (tools / ("zerorun.exe" if os.name == "nt" else "zerorun")).resolve()
    codex.write_bytes(b"fixture codex executable\n")
    zerorun.write_bytes(b"fixture zerorun executable\n")
    if os.name != "nt":
        codex.chmod(0o700)
        zerorun.chmod(0o700)
    runner = FixtureRunner(
        root,
        codex,
        zerorun,
        events if events is not None else _events(root),
        **kwargs,
    )
    return root, runner


def _run(root: Path, runner: FixtureRunner, tmp_path: Path) -> dict[str, Any]:
    return smoke.run_smoke(
        root,
        approve_remote_metadata=True,
        codex_command=str(runner.codex),
        git_command=shutil.which("git"),
        work_root=tmp_path,
        runner=runner,
        clock=lambda: FIXED_TIME,
        environment={
            **os.environ,
            "OPENAI_API_KEY": "must-not-leak",
            "PYTHONPATH": "must-not-leak",
        },
    )


def test_pass_is_one_read_only_doctor_call_with_immutable_sources(tmp_path: Path) -> None:
    root, runner = _runner(tmp_path)

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "pass"
    assert receipt["evidence_valid"] is True
    assert receipt["functional_integration_pass"] is True
    assert receipt["upstream_repository_code_executed"] is False
    assert receipt["workspace"]["unchanged_before_receipt"] is True
    assert receipt["isolated_execution_root"]["unchanged"] is True
    assert receipt["event_analysis"]["mcp_call_count"] == 1
    assert receipt["event_analysis"]["server"] == "zerorun"
    assert receipt["event_analysis"]["tool"] == "doctor"
    assert receipt["event_analysis"]["doctor"]["manifest_version"] == 2
    assert receipt["event_analysis"]["doctor"]["mode"] == "task-reuse"
    assert receipt["event_analysis"]["doctor"]["reuse_ready"] is True
    assert runner.exec_calls == 1
    invocation = next(call for call in runner.calls if "exec" in call["command"][1:])
    command = invocation["command"]
    assert "--ephemeral" in command
    assert "--ignore-user-config" in command
    assert "--ignore-rules" in command
    assert command[command.index("--sandbox") + 1] == "read-only"
    assert 'mcp_servers.zerorun.enabled_tools=["doctor"]' in command
    assert "mcp_servers.zerorun.required=true" in command
    assert command[-1] == "-"
    assert invocation["cwd"] != root
    assert invocation["input_bytes"].decode().endswith(
        f"{smoke.FINAL_MARKER} and nothing else."
    )
    assert "OPENAI_API_KEY" not in invocation["environment"]
    assert "PYTHONPATH" not in invocation["environment"]
    assert set(receipt["environment"]["removed_sensitive_variable_names"]) >= {
        "OPENAI_API_KEY",
        "PYTHONPATH",
    }
    captured = base64.b64decode(receipt["codex_jsonl"]["stdout_base64"])
    assert captured == _events(root)


def test_adverse_doctor_result_is_preserved_without_retry(tmp_path: Path) -> None:
    root = _repository(tmp_path)
    tools = tmp_path / "installed-tools"
    tools.mkdir()
    codex = (tools / ("codex.exe" if os.name == "nt" else "codex")).resolve()
    zerorun = (tools / ("zerorun.exe" if os.name == "nt" else "zerorun")).resolve()
    codex.write_bytes(b"codex")
    zerorun.write_bytes(b"zerorun")
    runner = FixtureRunner(root, codex, zerorun, _events(root, ok=False))

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["evidence_valid"] is True
    assert receipt["functional_integration_pass"] is False
    assert receipt["event_analysis"]["server_is_error"] is True
    assert receipt["event_analysis"]["doctor"]["ok"] is False
    assert receipt["event_analysis"]["doctor"]["mode"] == "observe-only"
    assert receipt["event_analysis"]["doctor"]["reuse_ready"] is False
    assert runner.exec_calls == 1
    assert receipt["failure"]["phase"] == "doctor"


def test_failed_mcp_item_is_valid_adverse_evidence_without_retry(tmp_path: Path) -> None:
    root = _repository(tmp_path)
    tools = tmp_path / "installed-tools"
    tools.mkdir()
    codex = (tools / ("codex.exe" if os.name == "nt" else "codex")).resolve()
    zerorun = (tools / ("zerorun.exe" if os.name == "nt" else "zerorun")).resolve()
    codex.write_bytes(b"codex")
    zerorun.write_bytes(b"zerorun")
    runner = FixtureRunner(root, codex, zerorun, _events(root, failed_call=True))

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["evidence_valid"] is True
    assert receipt["functional_integration_pass"] is False
    assert receipt["event_analysis"]["server_is_error"] is True
    assert receipt["event_analysis"]["doctor"] is None
    assert receipt["event_analysis"]["error"] == {"message": "fixture MCP isError"}
    assert runner.exec_calls == 1


def test_forbidden_shell_item_invalidates_evidence(tmp_path: Path) -> None:
    root = _repository(tmp_path)
    shell_item = {
        "type": "item.completed",
        "item": {
            "id": "shell",
            "type": "command_execution",
            "command": "git status",
            "aggregated_output": "",
            "exit_code": 0,
            "status": "completed",
        },
    }
    tools = tmp_path / "tools"
    tools.mkdir()
    codex = (tools / "codex.exe").resolve()
    zerorun = (tools / "zerorun.exe").resolve()
    codex.write_bytes(b"codex")
    zerorun.write_bytes(b"zerorun")
    runner = FixtureRunner(root, codex, zerorun, _events(root, extra_items=[shell_item]))

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["evidence_valid"] is False
    assert "forbidden tool or item" in receipt["failure"]["message"]
    assert receipt["codex_jsonl"]["stdout_base64"]


def test_second_doctor_call_is_rejected(tmp_path: Path) -> None:
    root = _repository(tmp_path)
    tools = tmp_path / "tools"
    tools.mkdir()
    codex = (tools / "codex.exe").resolve()
    zerorun = (tools / "zerorun.exe").resolve()
    codex.write_bytes(b"codex")
    zerorun.write_bytes(b"zerorun")
    runner = FixtureRunner(root, codex, zerorun, _events(root, second_call=True))

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["evidence_valid"] is False
    assert "2 distinct MCP calls" in receipt["failure"]["message"]


def test_workspace_mutation_invalidates_otherwise_successful_trace(tmp_path: Path) -> None:
    root, runner = _runner(tmp_path, mutate=True)

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["workspace"]["unchanged_before_receipt"] is False
    assert "source/worktree identity changed" in receipt["failure"]["message"]


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"timed_out": True}, "time limit"),
        ({"stdout_truncated": True}, "output limit"),
        ({"codex_returncode": 7}, "exited 7"),
    ],
)
def test_process_adversity_is_receipted_fail_closed(
    tmp_path: Path, kwargs: dict[str, Any], message: str
) -> None:
    root, runner = _runner(tmp_path, **kwargs)

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["evidence_valid"] is False
    assert message in receipt["failure"]["message"]
    assert receipt["codex_jsonl"]["stdout_base64"]


def test_registration_environment_forwarding_refuses_before_agent_run(tmp_path: Path) -> None:
    root = _repository(tmp_path)
    tools = tmp_path / "tools"
    tools.mkdir()
    codex = (tools / "codex.exe").resolve()
    zerorun = (tools / "zerorun.exe").resolve()
    codex.write_bytes(b"codex")
    zerorun.write_bytes(b"zerorun")
    runner = FixtureRunner(
        root,
        codex,
        zerorun,
        _events(root),
        registration_overrides={
            "transport": {
                "type": "stdio",
                "command": str(zerorun),
                "args": ["mcp-server"],
                "env": {"SECRET": "not-allowed"},
                "env_vars": [],
                "cwd": None,
            }
        },
    )

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["failure"]["phase"] == "registration_identity"
    assert "forwards environment" in receipt["failure"]["message"]
    assert runner.exec_calls == 0


def test_installed_zerorun_version_must_match_checkout(tmp_path: Path) -> None:
    root, runner = _runner(tmp_path, zerorun_version="99.0.0")

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert "does not match the source checkout" in receipt["failure"]["message"]
    assert runner.exec_calls == 0


def test_incoherent_doctor_state_is_not_accepted(tmp_path: Path) -> None:
    root = _repository(tmp_path)
    tools = tmp_path / "tools"
    tools.mkdir()
    codex = (tools / "codex.exe").resolve()
    zerorun = (tools / "zerorun.exe").resolve()
    codex.write_bytes(b"codex")
    zerorun.write_bytes(b"zerorun")
    runner = FixtureRunner(root, codex, zerorun, _events(root, invalid_state=True))

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["evidence_valid"] is False
    assert "incoherent" in receipt["failure"]["message"]


def test_duplicate_json_member_is_rejected(tmp_path: Path) -> None:
    root, runner = _runner(tmp_path, events=b'{"type":"turn.started","type":"error"}\n')

    receipt = _run(root, runner, tmp_path)

    assert receipt["status"] == "fail_closed"
    assert receipt["evidence_valid"] is False
    assert "duplicate JSON member" in receipt["failure"]["message"]


def test_atomic_receipt_is_canonical_and_never_overwrites(tmp_path: Path) -> None:
    output = tmp_path / "receipt.json"
    receipt = {"z": 2, "a": {"value": True}}

    smoke.write_receipt_atomic(output, receipt)

    raw = output.read_bytes()
    assert raw == b'{"a":{"value":true},"z":2}\n'
    with pytest.raises(smoke.SmokeError, match="refusing overwrite"):
        smoke.write_receipt_atomic(output, {"replacement": True})
    assert output.read_bytes() == raw


def test_atomic_receipt_refuses_a_symlink_destination(tmp_path: Path) -> None:
    outside = tmp_path / "outside.json"
    outside.write_text("preserve\n", encoding="utf-8")
    output = tmp_path / "receipt.json"
    try:
        output.symlink_to(outside)
    except OSError as exc:
        pytest.skip(f"file symlinks are unavailable: {exc}")

    with pytest.raises(smoke.SmokeError, match="refusing overwrite"):
        smoke.write_receipt_atomic(output, {"must": "not write"})

    assert outside.read_text(encoding="utf-8") == "preserve\n"


def test_parser_requires_complete_bounded_jsonl() -> None:
    with pytest.raises(smoke.SmokeError, match="ended without a newline"):
        smoke._parse_jsonl(b'{"type":"turn.started"}')
    with pytest.raises(smoke.SmokeError, match="truncated"):
        smoke._parse_jsonl(smoke._TRUNCATION_MARKER + b'{}\n')


def test_remote_metadata_disclosure_requires_explicit_consent(tmp_path: Path) -> None:
    root, runner = _runner(tmp_path)

    receipt = smoke.run_smoke(
        root,
        codex_command=str(runner.codex),
        git_command=shutil.which("git"),
        work_root=tmp_path,
        runner=runner,
        clock=lambda: FIXED_TIME,
        environment=dict(os.environ),
    )

    assert receipt["status"] == "fail_closed"
    assert receipt["failure"]["phase"] == "input_validation"
    assert "--approve-remote-metadata" in receipt["failure"]["message"]
    assert runner.exec_calls == 0
