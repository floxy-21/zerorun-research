from __future__ import annotations

import hashlib
import os
import stat
from pathlib import Path

import pytest

import tools.publish_pilot_assets as publisher
from zerorun.path_safety import create_private_directory
from tools.publish_pilot_assets import PublicationError, publish_pilot_assets


ASSETS = (
    "zerorun-pilot-linux-amd64.tar.gz",
    "zerorun-pilot-linux-amd64.tar.gz.sha256",
)


def _publication_dirs(tmp_path: Path) -> tuple[Path, Path]:
    dist = tmp_path / "dist"
    dist.mkdir()
    staging = dist / ".zerorun-publish.fixture"
    create_private_directory(staging)
    return dist, staging


def _stage_valid_assets(staging: Path, payload: bytes) -> dict[str, bytes]:
    digest = hashlib.sha256(payload).hexdigest()
    expected = {
        ASSETS[0]: payload,
        ASSETS[1]: f"{digest}  {ASSETS[0]}\n".encode("ascii"),
    }
    for name, contents in expected.items():
        (staging / name).write_bytes(contents)
    return expected


def test_pilot_assets_replace_regular_files_from_private_same_fs_staging(
    tmp_path: Path,
) -> None:
    dist, staging = _publication_dirs(tmp_path)
    expected = _stage_valid_assets(staging, b"new deterministic archive\n")
    for name in expected:
        (dist / name).write_bytes(b"old\n")

    publish_pilot_assets(
        dist_dir=dist,
        staging_dir=staging,
        asset_names=ASSETS,
    )

    assert {name: (dist / name).read_bytes() for name in ASSETS} == expected
    assert list(staging.iterdir()) == []
    assert list(dist.glob(".zerorun-publish-copy.*")) == []
    if os.name == "posix":
        assert all(
            stat.S_IMODE((dist / name).stat().st_mode) == 0o644 for name in ASSETS
        )


def test_pilot_asset_preflight_refuses_special_destination_before_any_replace(
    tmp_path: Path,
) -> None:
    dist, staging = _publication_dirs(tmp_path)
    _stage_valid_assets(staging, b"new archive\n")
    (dist / ASSETS[0]).write_bytes(b"preserve old archive\n")
    (dist / ASSETS[1]).mkdir()

    with pytest.raises(PublicationError, match="symlink or special"):
        publish_pilot_assets(
            dist_dir=dist,
            staging_dir=staging,
            asset_names=ASSETS,
        )

    assert (dist / ASSETS[0]).read_bytes() == b"preserve old archive\n"
    assert (dist / ASSETS[1]).is_dir()
    assert all((staging / name).is_file() for name in ASSETS)


def test_pilot_asset_preflight_never_follows_destination_symlink(
    tmp_path: Path,
) -> None:
    dist, staging = _publication_dirs(tmp_path)
    _stage_valid_assets(staging, b"new archive\n")
    outside = tmp_path / "outside.txt"
    outside.write_bytes(b"do not overwrite\n")
    try:
        (dist / ASSETS[1]).symlink_to(outside)
    except OSError as exc:
        pytest.skip(f"file symlinks are unavailable: {exc}")

    with pytest.raises(PublicationError, match="symlink or special"):
        publish_pilot_assets(
            dist_dir=dist,
            staging_dir=staging,
            asset_names=ASSETS,
        )

    assert outside.read_bytes() == b"do not overwrite\n"
    assert (dist / ASSETS[1]).is_symlink()
    assert all((staging / name).is_file() for name in ASSETS)


def test_pilot_asset_checksum_failure_preserves_all_destinations_and_cleans_copies(
    tmp_path: Path,
) -> None:
    dist, staging = _publication_dirs(tmp_path)
    _stage_valid_assets(staging, b"new archive\n")
    (staging / ASSETS[1]).write_text(f"{'0' * 64}  {ASSETS[0]}\n", encoding="ascii")
    previous = {name: ("old " + name).encode() for name in ASSETS}
    for name, payload in previous.items():
        (dist / name).write_bytes(payload)

    with pytest.raises(PublicationError, match="does not bind"):
        publish_pilot_assets(
            dist_dir=dist,
            staging_dir=staging,
            asset_names=ASSETS,
        )

    assert {name: (dist / name).read_bytes() for name in ASSETS} == previous
    assert list(dist.glob(".zerorun-publish-copy.*")) == []


def test_pilot_asset_source_swap_after_copy_fails_before_destination_commit(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    dist, staging = _publication_dirs(tmp_path)
    _stage_valid_assets(staging, b"trusted archive\n")
    previous = {name: ("old " + name).encode() for name in ASSETS}
    for name, payload in previous.items():
        (dist / name).write_bytes(payload)

    original_validate = publisher._validate_checksum_sidecars

    def swap_after_integrity_check(*args, **kwargs) -> None:
        original_validate(*args, **kwargs)
        replacement = staging / "replacement"
        replacement.write_bytes(b"attacker-swapped archive\n")
        os.replace(replacement, staging / ASSETS[0])

    monkeypatch.setattr(
        publisher, "_validate_checksum_sidecars", swap_after_integrity_check
    )

    with pytest.raises(PublicationError, match="changed before commit"):
        publish_pilot_assets(
            dist_dir=dist,
            staging_dir=staging,
            asset_names=ASSETS,
        )

    assert {name: (dist / name).read_bytes() for name in ASSETS} == previous
    assert list(dist.glob(".zerorun-publish-copy.*")) == []


def test_pilot_asset_publisher_refuses_staging_outside_dist(tmp_path: Path) -> None:
    dist = tmp_path / "dist"
    dist.mkdir()
    staging = tmp_path / ".zerorun-publish.fixture"
    create_private_directory(staging)
    for name in ASSETS:
        (staging / name).write_bytes(b"payload")

    with pytest.raises(PublicationError, match="private direct child"):
        publish_pilot_assets(
            dist_dir=dist,
            staging_dir=staging,
            asset_names=ASSETS,
        )


def test_pilot_build_routes_final_assets_through_atomic_publisher() -> None:
    root = Path(__file__).resolve().parents[1]
    script = (root / "tools" / "build_pilot_package.sh").read_text(
        encoding="utf-8"
    )
    assert 'mktemp -d "$DIST_DIR/.zerorun-publish.XXXXXXXXXX"' in script
    assert 'gzip -n > "$STAGED_ARCHIVE"' in script
    assert 'python "$ROOT/tools/publish_pilot_assets.py"' in script
    assert 'gzip -n > "$ARCHIVE"' not in script


def test_publisher_uses_open_descriptors_and_private_exclusive_copies() -> None:
    source = (Path(__file__).resolve().parents[1] / "tools" / "publish_pilot_assets.py").read_text(
        encoding="utf-8"
    )
    assert "os.O_EXCL" in source
    assert "_copy_fd(source_fd, copy_fd)" in source
    assert "os.fsync(copy_fd)" in source
    assert "_verify_copied_fd(" in source
    assert "_validate_checksum_sidecars(" in source
    assert "os.replace(staging / name, destination)" not in source
