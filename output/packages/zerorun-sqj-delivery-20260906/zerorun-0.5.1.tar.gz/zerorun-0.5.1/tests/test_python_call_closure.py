from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest

from tools.python_call_closure import CallSite, resolve_reviewed_symbol_closure
from zerorun.hermetic_key import task_fingerprint_v2
from zerorun.manifest import load_manifest
from zerorun.model import ConfigurationError
from zerorun.oci import hermetic_environment


IMAGE = "example.invalid/python@sha256:" + "a" * 64
RUNTIME = {
    "runtime": "docker",
    "requested_image": IMAGE,
    "requested_digest": "sha256:" + "a" * 64,
    "platform": "linux/amd64",
    "image_id": "sha256:" + "b" * 64,
    "repo_digests": [IMAGE],
    "rootfs": {"type": "layers", "layers": ["sha256:" + "c" * 64]},
    "config_sha256": "d" * 64,
}


class PythonCallClosureTests(unittest.TestCase):
    def make_source(self):
        temporary = tempfile.TemporaryDirectory()
        root = Path(temporary.name)
        source = (
            "import math\n"
            "VALUE = 1\n\n"
            "def helper():\n"
            "    return VALUE + math.floor(1.2)\n\n"
            "class Box:\n"
            "    TOKEN = 2\n\n"
            "    def chosen(self):\n"
            "        return helper()\n\n"
            "    def unrelated(self):\n"
            "        return 99\n"
        )
        (root / "module.py").write_text(source, encoding="utf-8")
        return temporary, root

    def test_resolves_state_bindings_class_method_and_function(self):
        temporary, root = self.make_source()
        self.addCleanup(temporary.cleanup)
        closure = resolve_reviewed_symbol_closure(
            root,
            [
                CallSite("module.py", 1, "<module>"),
                CallSite("module.py", 4, "helper", ("VALUE", "math")),
                CallSite("module.py", 7, "Box"),
                CallSite("module.py", 10, "chosen", ("helper",)),
            ],
        )
        self.assertEqual(closure.fallback_files, ())
        self.assertEqual(
            set(closure.selectors),
            {
                "module.py::@module-state",
                "module.py::@binding:VALUE",
                "module.py::@binding:math",
                "module.py::@binding:helper",
                "module.py::helper",
                "module.py::Box.@class-state",
                "module.py::Box.chosen",
            },
        )
        self.assertNotIn("module.py::Box.unrelated", closure.selectors)

    def test_unknown_profiled_global_falls_back_to_whole_file(self):
        temporary, root = self.make_source()
        self.addCleanup(temporary.cleanup)
        closure = resolve_reviewed_symbol_closure(
            root,
            [CallSite("module.py", 4, "helper", ("runtime_injected_name",))],
        )
        self.assertEqual(closure.fallback_files, ("module.py",))
        self.assertEqual(closure.selectors, ())

    def test_dynamic_globals_fall_back_to_whole_file(self):
        temporary, root = self.make_source()
        self.addCleanup(temporary.cleanup)
        closure = resolve_reviewed_symbol_closure(
            root,
            [CallSite("module.py", 4, "helper", (), True)],
        )
        self.assertEqual(closure.fallback_files, ("module.py",))
        self.assertEqual(closure.selectors, ())

    def test_unresolved_named_frame_falls_back_to_whole_file(self):
        temporary, root = self.make_source()
        self.addCleanup(temporary.cleanup)
        closure = resolve_reviewed_symbol_closure(root, [CallSite("module.py", 5, "does_not_exist")])
        self.assertEqual(closure.fallback_files, ("module.py",))
        self.assertEqual(closure.selectors, ())

    def test_missing_source_falls_back_to_whole_file(self):
        temporary, root = self.make_source()
        self.addCleanup(temporary.cleanup)
        closure = resolve_reviewed_symbol_closure(root, [CallSite("missing.py", 1, "<module>")])
        self.assertEqual(closure.fallback_files, ("missing.py",))
        self.assertEqual(closure.selectors, ())

    def test_synthetic_frame_inside_function_does_not_force_fallback(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "module.py").write_text(
            "def work():\n"
            "    return [x + 1 for x in range(3)]\n",
            encoding="utf-8",
        )
        closure = resolve_reviewed_symbol_closure(
            root,
            [
                CallSite("module.py", 1, "<module>"),
                CallSite("module.py", 1, "work"),
                CallSite("module.py", 2, "<listcomp>"),
            ],
        )
        self.assertEqual(closure.fallback_files, ())
        self.assertIn("module.py::work", closure.selectors)

    def test_interpreter_metadata_global_does_not_require_source_binding(self):
        temporary, root = self.make_source()
        self.addCleanup(temporary.cleanup)
        closure = resolve_reviewed_symbol_closure(
            root,
            [CallSite("module.py", 4, "helper", ("__name__", "VALUE"))],
        )
        self.assertEqual(closure.fallback_files, ())
        self.assertIn("module.py::@binding:VALUE", closure.selectors)
        self.assertFalse(any("__name__" in selector for selector in closure.selectors))


class SymbolStateFingerprintTests(unittest.TestCase):
    def make_project(self, selectors: list[str]):
        temporary = tempfile.TemporaryDirectory()
        root = Path(temporary.name)
        (root / "bootstrap.txt").write_text("stable\n", encoding="utf-8")
        (root / "module.py").write_text(
            "import math\n"
            "from collections import deque\n"
            "FLAG = 1\n\n"
            "def selected():\n"
            "    return FLAG + math.floor(1.2)\n\n"
            "def unrelated():\n"
            "    return deque([10])[0]\n\n"
            "class Box:\n"
            "    TOKEN = 5\n\n"
            "    def chosen(self):\n"
            "        return 20\n\n"
            "    def other(self):\n"
            "        return 30\n",
            encoding="utf-8",
        )
        raw = {
            "version": 2,
            "tasks": {
                "work": {
                    "command": ["python", "-c", "pass"],
                    "inputs": ["bootstrap.txt"],
                    "input_symbols": selectors,
                    "outputs": [],
                    "cacheable": True,
                    "unsafe_effects": [],
                    "env": [],
                    "cache_streams": False,
                    "result_only": True,
                    "closure_reviewed": True,
                    "image": IMAGE,
                    "platform": "linux/amd64",
                }
            },
        }
        path = root / ".zerorun.json"
        path.write_text(json.dumps(raw), encoding="utf-8")
        return temporary, path

    def fingerprint(self, path: Path):
        manifest = load_manifest(path)
        task = manifest.tasks["work"]
        _, env_fp = hermetic_environment(task)
        return task_fingerprint_v2(manifest, task, RUNTIME, environment_fingerprint=env_fp)[0]

    def test_module_state_tracks_import_and_assignment_changes(self):
        temporary, path = self.make_project(["module.py::@module-state", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        key1 = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text("import statistics\n" + source.read_text(), encoding="utf-8")
        self.assertNotEqual(key1, self.fingerprint(path))

        temporary2, path2 = self.make_project(["module.py::@module-state", "module.py::selected"])
        self.addCleanup(temporary2.cleanup)
        key2 = self.fingerprint(path2)
        source2 = path2.parent / "module.py"
        source2.write_text(source2.read_text().replace("FLAG = 1", "FLAG = 2"), encoding="utf-8")
        self.assertNotEqual(key2, self.fingerprint(path2))

    def test_binding_selector_tracks_named_import(self):
        temporary, path = self.make_project(
            ["module.py::@module-state", "module.py::@binding:math", "module.py::selected"]
        )
        self.addCleanup(temporary.cleanup)
        key1 = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(source.read_text().replace("import math", "import math as math"), encoding="utf-8")
        self.assertNotEqual(key1, self.fingerprint(path))

    def test_module_state_ignores_unrelated_function_body(self):
        temporary, path = self.make_project(["module.py::@module-state", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        key1 = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(source.read_text().replace("return deque([10])[0]", "return deque([11])[0]"), encoding="utf-8")
        self.assertEqual(key1, self.fingerprint(path))

    def test_class_state_ignores_other_method_body_but_tracks_attribute(self):
        temporary, path = self.make_project(
            ["module.py::@module-state", "module.py::Box.@class-state", "module.py::Box.chosen"]
        )
        self.addCleanup(temporary.cleanup)
        key1 = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(source.read_text().replace("return 30", "return 31"), encoding="utf-8")
        self.assertEqual(key1, self.fingerprint(path))
        source.write_text(source.read_text().replace("TOKEN = 5", "TOKEN = 6"), encoding="utf-8")
        self.assertNotEqual(key1, self.fingerprint(path))

    def test_missing_binding_rejects(self):
        temporary, path = self.make_project(["module.py::@binding:not_there"])
        self.addCleanup(temporary.cleanup)
        with self.assertRaisesRegex(ConfigurationError, "reviewed module binding not found"):
            self.fingerprint(path)


if __name__ == "__main__":
    unittest.main()
