from __future__ import annotations

import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

import pytest

from tools import codex_agent_lifecycle as lifecycle


FIXED_TIME = datetime(2026, 9, 5, 16, 0, tzinfo=timezone.utc)
RUNTIME_IMAGE = "python@sha256:" + "1" * 64
CACHE_KEY = "a" * 64


def _git(*arguments: str, cwd: Path) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(
        [shutil.which("git") or "git", *arguments],
        cwd=cwd,
        env=lifecycle.smoke._git_environment(dict(os.environ)),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


def _source_repository(tmp_path: Path) -> Path:
    root = tmp_path / "source"
    package = root / "zerorun"
    tools = root / "tools"
    package.mkdir(parents=True)
    tools.mkdir()
    (package / "__init__.py").write_text(
        f'__version__ = "{lifecycle.SOURCE_ZERORUN_VERSION}"\n',
        encoding="utf-8",
    )
    (package / "feature.py").write_text("VALUE = 1\n", encoding="utf-8")
    (root / "pyproject.toml").write_text(
        "[project]\nname='zerorun'\nversion='"
        + lifecycle.SOURCE_ZERORUN_VERSION
        + "'\n",
        encoding="utf-8",
    )
    (tools / "codex_agent_lifecycle.py").write_bytes(Path(lifecycle.__file__).read_bytes())
    assert _git("init", "-q", cwd=root).returncode == 0
    assert _git("config", "user.name", "Lifecycle Fixture", cwd=root).returncode == 0
    assert _git("config", "user.email", "fixture@example.invalid", cwd=root).returncode == 0
    assert _git("add", ".", cwd=root).returncode == 0
    assert _git("commit", "-q", "-m", "source fixture", cwd=root).returncode == 0
    return root.resolve()


def _doctor(root: Path, *, ok: bool = True) -> dict[str, Any]:
    return {
        "root": str(root),
        "manifest": str(root / ".zerorun.json"),
        "manifest_present": True,
        "manifest_version": 2,
        "mcp_manifest_supported": True,
        "manifest_authorized": ok,
        "pytest_profile": {"present": False, "valid": False},
        "pytest_profile_present": False,
        "mode": "task-reuse" if ok else "observe-only",
        "reuse_ready": ok,
        "task_reuse_ready": ok,
        "pytest_reuse_ready": False,
        "platform": "fixture",
        "contract": "fixture",
        "tasks": [
            {
                "task": lifecycle.TASK_NAME,
                "status": "CACHEABLE" if ok else "UNTRUSTED",
                "reason": None if ok else "fixture",
                "cache_key": CACHE_KEY if ok else None,
            }
        ],
        "ok": ok,
    }


def _run_payload(status: str) -> dict[str, Any]:
    return {
        "task": lifecycle.TASK_NAME,
        "status": status,
        "exit_code": 0,
        "wall_ms": 10.0,
        "execution_ms": 20.0,
        "saved_ms": 10.0 if status == "HIT_REUSED" else 0.0,
        "saved_seconds": 0.01 if status == "HIT_REUSED" else 0.0,
        "cache_key": CACHE_KEY,
        "reason": "fixture",
        "restored_outputs": [],
        "verified": status == "VERIFY_MATCH",
        "phase_ms": {},
        "mode": "reuse",
        "stdout_tail": "",
        "stderr_tail": "",
    }


def _events(
    *,
    root: Path,
    tool: str,
    arguments: dict[str, Any],
    marker: str,
    payload: dict[str, Any],
    forbidden_item: str | None = None,
    extra_call: bool = False,
) -> bytes:
    result = {
        "content": [
            {
                "type": "text",
                "text": json.dumps(payload, indent=2, sort_keys=True),
            }
        ],
        "structured_content": payload,
        "is_error": False,
    }
    values: list[dict[str, Any]] = [
        {"type": "thread.started", "thread_id": f"thread-{tool}"},
        {"type": "turn.started"},
        {
            "type": "item.started",
            "item": {
                "id": f"item-{tool}",
                "type": "mcp_tool_call",
                "server": "zerorun",
                "tool": tool,
                "arguments": arguments,
                "status": "in_progress",
            },
        },
        {
            "type": "item.completed",
            "item": {
                "id": f"item-{tool}",
                "type": "mcp_tool_call",
                "server": "zerorun",
                "tool": tool,
                "arguments": arguments,
                "status": "completed",
                "result": result,
            },
        },
    ]
    if forbidden_item:
        values.append(
            {
                "type": "item.completed",
                "item": {
                    "id": "forbidden",
                    "type": forbidden_item,
                    "status": "completed",
                },
            }
        )
    if extra_call:
        values.extend(
            [
                {
                    "type": "item.started",
                    "item": {
                        "id": "retry",
                        "type": "mcp_tool_call",
                        "server": "zerorun",
                        "tool": tool,
                        "arguments": arguments,
                        "status": "in_progress",
                    },
                },
                {
                    "type": "item.completed",
                    "item": {
                        "id": "retry",
                        "type": "mcp_tool_call",
                        "server": "zerorun",
                        "tool": tool,
                        "arguments": arguments,
                        "status": "completed",
                        "result": result,
                    },
                },
            ]
        )
    values.extend(
        [
            {
                "type": "item.completed",
                "item": {
                    "id": "message",
                    "type": "agent_message",
                    "text": marker,
                },
            },
            {
                "type": "turn.completed",
                "usage": {
                    "input_tokens": 100,
                    "cached_input_tokens": 0,
                    "output_tokens": 10,
                },
            },
        ]
    )
    return b"".join(
        json.dumps(value, separators=(",", ":"), sort_keys=True).encode("utf-8")
        + b"\n"
        for value in values
    )


@pytest.mark.parametrize(
    "raw",
    [
        (b"[" * 40) + b"0" + (b"]" * 40),
        b'{"evidence_id":"first","evidence_id":"second"}',
    ],
)
def test_codex_installation_rejects_unbounded_or_ambiguous_receipt_json(
    tmp_path: Path,
    raw: bytes,
) -> None:
    receipt = tmp_path / "receipt.json"
    receipt.write_bytes(raw)

    with pytest.raises(lifecycle.SmokeError, match="failed validation"):
        lifecycle._validated_codex_installation(
            codex_resolved=tmp_path / "codex.js",
            install_receipt=receipt,
            expected_source_commit="1" * 40,
            version="0.0.0",
            main_integrity="sha512-" + ("A" * 88),
            platform_integrity="sha512-" + ("A" * 88),
        )


class FixtureRunner:
    def __init__(
        self,
        source: Path,
        codex: Path,
        zerorun: Path,
        *,
        doctor_ok: bool = True,
        statuses: Sequence[str] = ("MISS_EXECUTED", "HIT_REUSED", "VERIFY_MATCH"),
        forbidden_stage: int | None = None,
        forbidden_item: str = "command_execution",
        extra_call_stage: int | None = None,
        malformed_stage: int | None = None,
        truncate_stage: int | None = None,
        timed_out_stage: int | None = None,
        stdout_truncated_stage: int | None = None,
        nonzero_stage: int | None = None,
        mutate_source_stage: int | None = None,
        mutate_synthetic_stage: int | None = None,
        mutate_codex_stage: int | None = None,
        mutate_zerorun_stage: int | None = None,
    ) -> None:
        self.source = source
        self.codex = codex
        self.zerorun = zerorun
        self.doctor_ok = doctor_ok
        self.statuses = list(statuses)
        self.forbidden_stage = forbidden_stage
        self.forbidden_item = forbidden_item
        self.extra_call_stage = extra_call_stage
        self.malformed_stage = malformed_stage
        self.truncate_stage = truncate_stage
        self.timed_out_stage = timed_out_stage
        self.stdout_truncated_stage = stdout_truncated_stage
        self.nonzero_stage = nonzero_stage
        self.mutate_source_stage = mutate_source_stage
        self.mutate_synthetic_stage = mutate_synthetic_stage
        self.mutate_codex_stage = mutate_codex_stage
        self.mutate_zerorun_stage = mutate_zerorun_stage
        self.calls: list[dict[str, Any]] = []
        self.exec_calls = 0
        self.authorization_manifest: Path | None = None

    @staticmethod
    def _config_value(argv: list[str], prefix: str) -> str:
        value = next(item for item in argv if item.startswith(prefix))
        return value[len(prefix) :]

    def __call__(
        self,
        command: Sequence[str],
        *,
        cwd: Path | None,
        environment: dict[str, str],
        timeout_seconds: float,
        output_limit_bytes: int,
        input_bytes: bytes | None = None,
    ) -> lifecycle.CommandResult:
        argv = [str(value) for value in command]
        self.calls.append(
            {
                "command": argv,
                "cwd": cwd,
                "environment": dict(environment),
                "input_bytes": input_bytes,
                "timeout_seconds": timeout_seconds,
                "output_limit_bytes": output_limit_bytes,
            }
        )
        if Path(argv[0]) == self.codex and argv[1:] == ["--version"]:
            return lifecycle.CommandResult(tuple(argv), 0, b"codex-cli 0.fixture\n", b"")
        if Path(argv[0]) == self.codex and argv[1:] == [
            "mcp",
            "get",
            "zerorun",
            "--json",
        ]:
            registration = {
                "name": "zerorun",
                "enabled": True,
                "disabled_reason": None,
                "transport": {
                    "type": "stdio",
                    "command": str(self.zerorun),
                    "args": ["mcp-server"],
                    "env": None,
                    "env_vars": [],
                    "cwd": None,
                },
                "enabled_tools": None,
                "disabled_tools": None,
            }
            return lifecycle.CommandResult(
                tuple(argv), 0, json.dumps(registration).encode("utf-8"), b""
            )
        if Path(argv[0]) == self.zerorun and argv[1:] == ["--version"]:
            return lifecycle.CommandResult(
                tuple(argv),
                0,
                f"zerorun {lifecycle.SOURCE_ZERORUN_VERSION}\n".encode("utf-8"),
                b"",
            )
        if Path(argv[0]) == self.zerorun and "authorize" in argv:
            manifest = Path(argv[argv.index("--manifest") + 1]).resolve()
            digest = argv[argv.index("--manifest-sha256") + 1]
            self.authorization_manifest = manifest
            trust = Path(environment["ZERORUN_TRUST_ROOT"])
            (trust / "repositories" / "fixture" / "authorities").mkdir(parents=True)
            (trust / "authority.key").write_bytes(b"fixture-secret-not-receipted")
            (trust / "repositories" / "fixture" / "authorities" / "receipt.json").write_text(
                "{}\n", encoding="utf-8"
            )
            payload = {
                "status": "AUTHORIZED",
                "manifest_sha256": digest,
                "pytest_profile_sha256": None,
                "authority_location": "external-per-user",
            }
            return lifecycle.CommandResult(
                tuple(argv), 0, json.dumps(payload).encode("utf-8"), b""
            )
        if Path(argv[0]) == self.codex and "exec" in argv[1:]:
            stage = self.exec_calls
            self.exec_calls += 1
            root = Path(
                json.loads(
                    self._config_value(argv, "mcp_servers.zerorun.cwd=")
                )
            ).resolve()
            allowed = json.loads(
                self._config_value(argv, "mcp_servers.zerorun.enabled_tools=")
            )
            assert len(allowed) == 1
            tool = allowed[0]
            if stage == self.mutate_source_stage:
                (self.source / "zerorun" / "feature.py").write_text(
                    "VALUE = 2\n", encoding="utf-8"
                )
            if stage == self.mutate_synthetic_stage:
                (root / "fixture.txt").write_text("changed\n", encoding="utf-8")
            if stage == self.mutate_codex_stage:
                self.codex.write_bytes(b"changed codex executable")
            if stage == self.mutate_zerorun_stage:
                self.zerorun.write_bytes(b"changed zerorun executable")
            managed = root / ".zerorun"
            managed.mkdir(exist_ok=True)
            (managed / "events.jsonl").write_text(
                f'{{"fixture_stage":{stage}}}\n', encoding="utf-8"
            )
            if tool == "doctor":
                arguments = {"root": str(root)}
                marker = lifecycle.DOCTOR_MARKER
                payload = _doctor(root, ok=self.doctor_ok)
            else:
                verify = stage == 3
                arguments = {
                    "task": lifecycle.TASK_NAME,
                    "root": str(root),
                    "verify": verify,
                }
                marker = (
                    lifecycle.MISS_MARKER
                    if stage == 1
                    else lifecycle.HIT_MARKER
                    if stage == 2
                    else lifecycle.VERIFY_MARKER
                )
                payload = _run_payload(self.statuses[stage - 1])
            stdout = _events(
                root=root,
                tool=tool,
                arguments=arguments,
                marker=marker,
                payload=payload,
                forbidden_item=self.forbidden_item if stage == self.forbidden_stage else None,
                extra_call=stage == self.extra_call_stage,
            )
            if stage == self.malformed_stage:
                stdout = b'{"type":"thread.started"}\nnot-json\n'
            if stage == self.truncate_stage:
                stdout = lifecycle.smoke._TRUNCATION_MARKER + stdout
            return lifecycle.CommandResult(
                tuple(argv),
                9 if stage == self.nonzero_stage else 124 if stage == self.timed_out_stage else 0,
                stdout,
                b"fixture stderr\n",
                timed_out=stage == self.timed_out_stage,
                stdout_truncated=stage == self.stdout_truncated_stage,
            )
        completed = subprocess.run(
            argv,
            cwd=cwd,
            env=environment,
            input=input_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_seconds,
            check=False,
        )
        return lifecycle.CommandResult(
            tuple(argv), completed.returncode, completed.stdout, completed.stderr
        )


def _fake_installed_identity(
    _runner: lifecycle.Runner,
    *,
    zerorun: Path,
    python_command: str | None,
    source_root: Path,
    environment: dict[str, str],
) -> dict[str, Any]:
    del zerorun, python_command, environment
    source = lifecycle._source_package_identity(source_root)
    return {
        "version": lifecycle.SOURCE_ZERORUN_VERSION,
        "module_root": "/fixture/site-packages/zerorun",
        "module": {
            "identity_sha256": source["identity_sha256"],
            "file_count": source["file_count"],
            "bytes": source["bytes"],
            "files": source["files"],
        },
        "distribution_metadata_root": "/fixture/site-packages/zerorun.dist-info",
        "distribution_metadata": {"identity_sha256": "b" * 64},
        "python": {"executable": {"sha256": "c" * 64}, "version": "fixture"},
        "package_identity_sha256": "d" * 64,
    }


def _fixture(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    **runner_options: Any,
) -> tuple[Path, FixtureRunner, Path]:
    source = _source_repository(tmp_path)
    monkeypatch.setattr(
        lifecycle,
        "__file__",
        str(source / "tools" / "codex_agent_lifecycle.py"),
    )
    installed = tmp_path / "installed"
    installed.mkdir()
    codex = (installed / ("codex.exe" if os.name == "nt" else "codex")).resolve()
    zerorun = (installed / ("zerorun.exe" if os.name == "nt" else "zerorun")).resolve()
    codex.write_bytes(b"fixture codex executable")
    zerorun.write_bytes(b"fixture zerorun executable")
    if os.name != "nt":
        codex.chmod(0o700)
        zerorun.chmod(0o700)
    runner = FixtureRunner(source, codex, zerorun, **runner_options)
    monkeypatch.setattr(lifecycle, "_installed_package_identity", _fake_installed_identity)
    work = tmp_path / "work"
    work.mkdir()
    return source, runner, work


def _run(
    source: Path,
    runner: FixtureRunner,
    work: Path,
    **overrides: Any,
) -> dict[str, Any]:
    values: dict[str, Any] = {
        "runtime_image": RUNTIME_IMAGE,
        "approve_remote_metadata": True,
        "approve_synthetic_formative_authority": True,
        "codex_command": str(runner.codex),
        "git_command": shutil.which("git"),
        "work_root": work,
        "runner": runner,
        "clock": lambda: FIXED_TIME,
        "environment": {
            **os.environ,
            "OPENAI_API_KEY": "must-not-leak",
            "CODEX_API_KEY": "must-not-leak",
            "PYTHONPATH": "must-not-leak",
        },
    }
    values.update(overrides)
    return lifecycle.run_synthetic_lifecycle(source, **values)


def test_exact_synthetic_agent_lifecycle_passes_and_binds_identities(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch)

    receipt = _run(source, runner, work)

    assert receipt["status"] == "pass", json.dumps(
        receipt.get("failure"), sort_keys=True
    )
    assert receipt["evidence_payload_sha256"] == lifecycle._canonical_sha256(
        {
            key: value
            for key, value in receipt.items()
            if key != "evidence_payload_sha256"
        }
    )
    assert receipt["evidence_valid"] is True
    assert receipt["functional_lifecycle_pass"] is True
    assert receipt["real_repository_authorized"] is False
    assert receipt["synthetic_repository_code_executed"] is True
    assert receipt["runtime_acquisition_attempted"] is False
    assert receipt["lifecycle"]["statuses"] == [
        "MISS_EXECUTED",
        "HIT_REUSED",
        "VERIFY_MATCH",
    ]
    assert receipt["lifecycle"]["cache_key"] == CACHE_KEY
    assert receipt["lifecycle"]["total_retries"] == 0
    assert receipt["source"]["commit"] == _git("rev-parse", "HEAD", cwd=source).stdout.decode().strip()
    assert receipt["zerorun"]["installed_matches_source_package"] is True
    assert len(receipt["zerorun"]["installed_package"]["package_identity_sha256"]) == 64
    assert len(receipt["codex"]["package_identity_sha256"]) == 64
    for stage in receipt["agent_stages"]:
        assert stage["analysis"]["response_sha256"] == lifecycle._canonical_sha256(
            stage["analysis"]["response"]
        )
    assert all(receipt["identity_unchanged"].values())
    assert runner.exec_calls == 4
    assert runner.authorization_manifest is not None
    assert source not in runner.authorization_manifest.parents
    assert runner.authorization_manifest.name == ".zerorun.json"
    assert not (source / ".zerorun").exists()
    for index, stage in enumerate(receipt["agent_stages"]):
        assert stage["analysis"]["mcp_call_count"] == 1
        assert stage["analysis"]["retry_count"] == 0
        enabled = [
            value
            for value in stage["command"]
            if value.startswith("mcp_servers.zerorun.enabled_tools=")
        ]
        assert enabled == [
            'mcp_servers.zerorun.enabled_tools=["doctor"]'
            if index == 0
            else 'mcp_servers.zerorun.enabled_tools=["run_tests"]'
        ]
        assert "--ignore-user-config" in stage["command"]
        assert "--ignore-rules" in stage["command"]
        assert stage["command"][stage["command"].index("--sandbox") + 1] == "read-only"
    assert set(receipt["environment"]["removed_sensitive_variable_names"]) >= {
        "OPENAI_API_KEY",
        "CODEX_API_KEY",
        "PYTHONPATH",
    }
    assert "must-not-leak" not in json.dumps(receipt)
    assert receipt["external_authority"]["synthetic_only"] is True
    assert receipt["external_authority"]["secret_values_recorded"] is False


@pytest.mark.parametrize(
    ("approval", "value", "message"),
    [
        ("approve_remote_metadata", False, "approve-remote-metadata"),
        (
            "approve_synthetic_formative_authority",
            False,
            "approve-synthetic-formative-authority",
        ),
    ],
)
def test_both_explicit_approvals_are_mandatory_before_authority_or_agent(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    approval: str,
    value: bool,
    message: str,
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch)

    receipt = _run(source, runner, work, **{approval: value})

    assert receipt["status"] == "fail_closed"
    assert message in receipt["failure"]["message"]
    assert runner.authorization_manifest is None
    assert runner.exec_calls == 0


def test_doctor_adversity_is_final_and_never_retried(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch, doctor_ok=False)

    receipt = _run(source, runner, work)

    assert receipt["status"] == "fail_closed"
    assert receipt["functional_lifecycle_pass"] is False
    assert receipt["failure"]["phase"] == "agent_doctor"
    assert runner.exec_calls == 1


def test_wrong_lifecycle_status_fails_at_the_first_mismatch_without_retry(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source, runner, work = _fixture(
        tmp_path,
        monkeypatch,
        statuses=("MISS_EXECUTED", "MISS_EXECUTED", "VERIFY_MATCH"),
    )

    receipt = _run(source, runner, work)

    assert receipt["status"] == "fail_closed"
    assert receipt["failure"]["phase"] == "agent_hit"
    assert "HIT_REUSED" in receipt["failure"]["message"]
    assert runner.exec_calls == 3


@pytest.mark.parametrize("item_type", ["command_execution", "file_change", "web_search"])
def test_shell_file_and_other_tools_are_rejected(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    item_type: str,
) -> None:
    source, runner, work = _fixture(
        tmp_path,
        monkeypatch,
        forbidden_stage=1,
        forbidden_item=item_type,
    )

    receipt = _run(source, runner, work)

    assert receipt["status"] == "fail_closed"
    assert "forbidden" in receipt["failure"]["message"]
    assert runner.exec_calls == 2


def test_an_agent_retry_or_extra_mcp_call_is_rejected(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch, extra_call_stage=2)

    receipt = _run(source, runner, work)

    assert receipt["status"] == "fail_closed"
    assert "2 distinct MCP calls" in receipt["failure"]["message"]
    assert runner.exec_calls == 3


@pytest.mark.parametrize(
    ("option", "message"),
    [
        ({"malformed_stage": 1}, "could not parse"),
        ({"truncate_stage": 1}, "truncated"),
    ],
)
def test_malformed_and_truncated_jsonl_fail_closed(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    option: dict[str, Any],
    message: str,
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch, **option)

    receipt = _run(source, runner, work)

    assert receipt["status"] == "fail_closed"
    assert message in receipt["failure"]["message"]
    assert runner.exec_calls == 2


def test_jsonl_event_overflow_is_rejected() -> None:
    event = json.dumps({"type": "turn.started"}).encode("utf-8") + b"\n"
    with pytest.raises(lifecycle.SmokeError, match="invalid event count"):
        lifecycle.smoke._parse_jsonl(event * (lifecycle.smoke.MAX_JSONL_LINES + 1))


@pytest.mark.parametrize(
    ("option", "message"),
    [
        ({"timed_out_stage": 1}, "time limit"),
        ({"stdout_truncated_stage": 1}, "output limit"),
        ({"nonzero_stage": 1}, "exited 9"),
    ],
)
def test_timeout_output_overflow_and_nonzero_agent_exit_are_receipted(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    option: dict[str, Any],
    message: str,
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch, **option)

    receipt = _run(source, runner, work)

    assert receipt["status"] == "fail_closed"
    assert message in receipt["failure"]["message"]
    assert len(receipt["agent_stages"]) == 2
    assert "validation_error" in receipt["agent_stages"][-1]
    assert runner.exec_calls == 2


@pytest.mark.parametrize(
    ("mutation", "message"),
    [
        ("mutate_source_stage", "identity drifted"),
        ("mutate_synthetic_stage", "synthetic reviewed file drifted"),
        ("mutate_codex_stage", "identity drifted"),
        ("mutate_zerorun_stage", "identity drifted"),
    ],
)
def test_source_synthetic_and_executable_drift_are_rejected(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    mutation: str,
    message: str,
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch, **{mutation: 1})

    receipt = _run(source, runner, work)

    assert receipt["status"] == "fail_closed"
    assert message in receipt["failure"]["message"]


def test_installed_package_drift_is_rejected(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch)
    calls = 0

    def drifting(*args: Any, **kwargs: Any) -> dict[str, Any]:
        nonlocal calls
        value = _fake_installed_identity(*args, **kwargs)
        calls += 1
        if calls == 2:
            value = {**value, "package_identity_sha256": "e" * 64}
        return value

    monkeypatch.setattr(lifecycle, "_installed_package_identity", drifting)

    receipt = _run(source, runner, work)

    assert receipt["status"] == "fail_closed"
    assert "identity drifted" in receipt["failure"]["message"]


@pytest.mark.parametrize(
    "image",
    [
        "python:latest",
        "python@sha256:" + "0" * 64,
        "python@sha256:" + "A" * 64,
        "python@sha256:1234",
    ],
)
def test_runtime_image_must_be_a_real_lowercase_digest(image: str) -> None:
    receipt = lifecycle.run_synthetic_lifecycle(
        Path.cwd(),
        runtime_image=image,
        approve_remote_metadata=True,
        approve_synthetic_formative_authority=True,
    )
    assert receipt["status"] == "fail_closed"
    assert receipt["failure"]["phase"] == "input_validation"
    assert "digest-pinned" in receipt["failure"]["message"]


def test_exact_main_mode_binds_clean_main_and_expected_commit(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch)
    assert _git("branch", "-M", "main", cwd=source).returncode == 0
    commit = _git("rev-parse", "HEAD", cwd=source).stdout.decode().strip()

    receipt = _run(source, runner, work, expected_main_commit=commit)

    assert receipt["status"] == "pass", json.dumps(
        receipt.get("failure"), sort_keys=True
    )
    assert receipt["release_binding"] == {
        "requested": True,
        "expected_commit": commit,
        "head_commit": commit,
        "local_main_commit": commit,
        "branch": "main",
        "worktree_clean": True,
    }


@pytest.mark.parametrize("adversity", ["wrong_branch", "dirty", "wrong_commit"])
def test_exact_main_mode_rejects_branch_dirt_and_commit_drift(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    adversity: str,
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch)
    if adversity != "wrong_branch":
        assert _git("branch", "-M", "main", cwd=source).returncode == 0
    commit = _git("rev-parse", "HEAD", cwd=source).stdout.decode().strip()
    if adversity == "dirty":
        (source / "untracked.txt").write_text("dirty\n", encoding="utf-8")
    expected = "f" * 40 if adversity == "wrong_commit" else commit

    receipt = _run(source, runner, work, expected_main_commit=expected)

    assert receipt["status"] == "fail_closed"
    assert receipt["failure"]["phase"] == "source_and_executable_identity"
    assert "exact-main" in receipt["failure"]["message"]
    assert runner.exec_calls == 0


def test_authenticated_install_arguments_are_all_or_nothing(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source, runner, work = _fixture(tmp_path, monkeypatch)

    receipt = _run(
        source,
        runner,
        work,
        codex_install_receipt=tmp_path / "receipt.json",
    )

    assert receipt["status"] == "fail_closed"
    assert receipt["failure"]["phase"] == "input_validation"
    assert "both frozen SRI values" in receipt["failure"]["message"]
    assert runner.exec_calls == 0
