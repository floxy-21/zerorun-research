import hashlib
import json
from pathlib import Path
import sys

import pytest

from research.novelty_checks import function_boundary_probe as probe


@pytest.mark.parametrize("scenario_name,classification", [
    ("function-fixture-pure-call", "independent_control_match"),
    ("shared-global-negative-pollution", "false_green"),
])
def test_boundary_comparison_preserves_positive_and_negative_results(tmp_path, monkeypatch, scenario_name, classification):
    scenario = next(s for s in probe.harness.SCENARIOS if s.name == scenario_name)
    monkeypatch.setattr(probe.harness, "SCENARIOS", (scenario,))
    before_plugin = probe.harness.CALL_OMISSION_PLUGIN_SOURCE
    output = tmp_path / "evidence"
    result = probe.run(output, Path(sys.executable))
    assert result["case_count"] == 1
    assert result["pytest_invocations"] == 5
    assert result["status"] == "NO_DISTINCTION_IN_FIXED_EXAMPLES"
    assert result["all_seed_oracles_stable"]
    assert result["producer_bytes_stable"]
    assert not result["authorizes_reuse"]
    assert not result["evidence_eligible"]
    assert not result["pidc_implemented"]
    assert result["manual_prior_success_stub"]
    assert result["cases"][0]["generic_wrapper_classification"] == classification
    assert probe.harness.CALL_OMISSION_PLUGIN_SOURCE == before_plugin
    protocol = output / "protocol.pre-run.json"
    assert hashlib.sha256(protocol.read_bytes()).hexdigest() == result["protocol_sha256"]
    captures = list(output.glob("*/*.capture.json"))
    assert len(captures) == 5
    assert sum(json.loads(p.read_text())["oracle_complete"] for p in captures) == 2
    assert not list(output.rglob(".zerorun*"))


def test_probe_cannot_overwrite_prior_evidence(tmp_path):
    with pytest.raises(ValueError, match="output already exists"):
        probe.run(tmp_path, Path(sys.executable))
