from __future__ import annotations

from pathlib import Path
import tempfile

from tools.pytest_node_closure_audit import (
    resolve_node_framework_closure,
    resolve_session_result_closure,
)


def _source_root() -> tuple[tempfile.TemporaryDirectory, Path]:
    temporary = tempfile.TemporaryDirectory()
    root = Path(temporary.name)
    package = root / "src" / "_pytest"
    package.mkdir(parents=True)
    (package / "example.py").write_text(
        "VALUE = 1\n\n"
        "def helper():\n"
        "    return VALUE\n\n"
        "def dynamic_helper():\n"
        "    return globals().get('VALUE')\n",
        encoding="utf-8",
    )
    assertion = package / "assertion"
    assertion.mkdir()
    (assertion / "rewrite.py").write_text(
        "def rewrite_asserts():\n"
        "    return None\n",
        encoding="utf-8",
    )
    return temporary, root


def _successful_outcome() -> dict[str, object]:
    return {"cache_candidate_success": True}


def test_node_framework_closure_resolves_exact_symbol_and_binding() -> None:
    temporary, root = _source_root()
    try:
        row = resolve_node_framework_closure(
            root,
            {
                "nodeid": "testing/test_example.py::test_helper",
                "result_outcome": _successful_outcome(),
                "runtime_text_encoding": {
                    "preferred_encoding": "UTF-8",
                    "locale_encoding": "UTF-8",
                    "filesystem_encoding": "utf-8",
                    "utf8_mode": 1,
                    "default_text_sample": "é",
                    "default_text_bytes_hex": "c3a9",
                    "default_text_write_utf8": True,
                },
                "implementation_call_sites": [
                    {
                        "path": "src/_pytest/example.py",
                        "firstlineno": 3,
                        "qualname": "helper",
                        "globals": ["VALUE"],
                        "dynamic_globals": False,
                        "receiver_mro": [
                            "_pytest.python.Function",
                            "_pytest.python.PyobjMixin",
                        ],
                    }
                ],
            },
        )
    finally:
        temporary.cleanup()

    assert row["reviewable"] is True
    assert row["fresh_required"] is False
    assert row["cache_candidate_success"] is True
    assert row["fallback_files"] == []
    assert "src/_pytest/example.py::helper" in row["selectors"]
    assert "src/_pytest/example.py::@binding:VALUE" in row["selectors"]
    assert "src/_pytest/example.py::@module-state" in row["selectors"]
    assert row["receiver_mro_profiled"] is True
    assert row["observed_receiver_mro"] == [
        "_pytest.python.Function",
        "_pytest.python.PyobjMixin",
    ]
    assert row["runtime_text_encoding"]["default_text_write_utf8"] is True
    assert isinstance(row["closure_sha256"], str)
    assert len(row["closure_sha256"]) == 64


def test_node_framework_closure_falls_back_on_dynamic_globals() -> None:
    temporary, root = _source_root()
    try:
        row = resolve_node_framework_closure(
            root,
            {
                "nodeid": "testing/test_example.py::test_dynamic",
                "result_outcome": _successful_outcome(),
                "implementation_call_sites": [
                    {
                        "path": "src/_pytest/example.py",
                        "firstlineno": 6,
                        "qualname": "dynamic_helper",
                        "globals": ["globals"],
                        "dynamic_globals": True,
                    }
                ],
            },
        )
    finally:
        temporary.cleanup()

    assert row["reviewable"] is True
    assert row["fresh_required"] is False
    assert row["selectors"] == []
    assert row["fallback_files"] == ["src/_pytest/example.py"]


def test_node_framework_closure_keeps_assertion_rewriter_as_explicit_fallback() -> None:
    temporary, root = _source_root()
    try:
        row = resolve_node_framework_closure(
            root,
            {
                "nodeid": "testing/test_example.py::test_rewritten_assertion",
                "result_outcome": _successful_outcome(),
                "project_python_call_sites": [
                    {
                        "path": "src/_pytest/example.py",
                        "firstlineno": 3,
                        "qualname": "helper",
                        "globals": ["VALUE", "@py_builtins", "@pytest_ar"],
                        "dynamic_globals": False,
                    }
                ],
            },
        )
    finally:
        temporary.cleanup()

    assert row["reviewable"] is True
    assert row["fresh_required"] is False
    assert row["ignored_assertion_rewrite_globals"] == ["@py_builtins", "@pytest_ar"]
    assert row["assertion_rewrite_fallback_added"] is True
    assert row["fallback_files"] == ["src/_pytest/assertion/rewrite.py"]
    assert "src/_pytest/example.py::helper" in row["selectors"]
    assert "src/_pytest/example.py::@binding:VALUE" in row["selectors"]
    assert isinstance(row["closure_sha256"], str)


def test_session_closure_is_separate_and_reviewed_like_node_code() -> None:
    temporary, root = _source_root()
    try:
        row = resolve_session_result_closure(
            root,
            {
                "session_project_python_call_sites": [
                    {
                        "path": "src/_pytest/example.py",
                        "firstlineno": 3,
                        "qualname": "helper",
                        "globals": ["VALUE"],
                        "dynamic_globals": False,
                    }
                ]
            },
        )
    finally:
        temporary.cleanup()

    assert row["reviewable"] is True
    assert row["fresh_required"] is False
    assert "src/_pytest/example.py::helper" in row["selectors"]
    assert "src/_pytest/example.py::@binding:VALUE" in row["selectors"]
    assert isinstance(row["closure_sha256"], str)


def test_node_framework_closure_does_not_claim_complete_node_reuse() -> None:
    temporary, root = _source_root()
    try:
        row = resolve_node_framework_closure(
            root,
            {
                "nodeid": "testing/test_example.py::test_no_framework_calls",
                "result_outcome": _successful_outcome(),
                "implementation_call_sites": [],
            },
        )
    finally:
        temporary.cleanup()

    assert row["reviewable"] is True
    assert row["fresh_required"] is False
    assert row["selectors"] == []
    assert row["fallback_files"] == []
    assert row["call_site_count"] == 0


def test_node_framework_closure_requires_successful_baseline_outcome() -> None:
    temporary, root = _source_root()
    try:
        row = resolve_node_framework_closure(
            root,
            {
                "nodeid": "testing/test_example.py::test_incomplete",
                "result_outcome": {"cache_candidate_success": False},
                "implementation_call_sites": [
                    {
                        "path": "src/_pytest/example.py",
                        "firstlineno": 3,
                        "qualname": "helper",
                        "globals": ["VALUE"],
                        "dynamic_globals": False,
                    }
                ],
            },
        )
    finally:
        temporary.cleanup()

    assert row["reviewable"] is True
    assert row["fresh_required"] is True
    assert row["cache_candidate_success"] is False
    assert "baseline node outcome" in str(row["reason"])
    assert row["selectors"] == []
    assert row["fallback_files"] == []
    assert row["closure_sha256"] is None


def test_node_framework_closure_missing_outcome_fails_closed() -> None:
    temporary, root = _source_root()
    try:
        row = resolve_node_framework_closure(
            root,
            {
                "nodeid": "testing/test_example.py::test_missing_outcome",
                "implementation_call_sites": [],
            },
        )
    finally:
        temporary.cleanup()

    assert row["fresh_required"] is True
    assert row["cache_candidate_success"] is False
