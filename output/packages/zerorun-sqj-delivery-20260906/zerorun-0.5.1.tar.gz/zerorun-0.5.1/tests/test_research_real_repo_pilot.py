from __future__ import annotations

from copy import deepcopy
import hashlib
from io import BytesIO
import json
from pathlib import Path
import shutil
import sqlite3
import tarfile

import pytest

from research.artifact.pytest_capture import canonicalize_events
from research.phases import real_repo_pilot as pilot


IMAGE = "example.invalid/python@sha256:" + "a" * 64


def _manifest(tmp_path: Path) -> dict[str, object]:
    return {
        "schema": "zerorun.development-pilot-manifest.v1",
        "status": "DEVELOPMENT_PILOT_ONLY",
        "evidence_eligible": False,
        "authorizes_reuse": False,
        "study_status_mutated": False,
        "selection_rule": "fixed before outcomes",
        "image": IMAGE,
        "timeout_seconds": 180,
        "repositories": [
            {
                "id": "packaging",
                "upstream": "pypa/packaging",
                "path": str(tmp_path.resolve()),
                "head": "1" * 40,
                "first_parent": "2" * 40,
                "targets": ["tests/test_tags.py"],
            }
        ],
    }


def _report(sequence: int, node_id: str, phase: str, outcome: str) -> dict[str, object]:
    return {
        "sequence": sequence,
        "kind": "report",
        "node_id": node_id,
        "phase": phase,
        "outcome": outcome,
        "was_xfail": False,
        "xfail_reason": None,
        "strict_xpass": False,
        "longrepr": None,
        "longrepr_truncated": False,
    }


def _capture(
    rows: list[tuple[str, str]],
    *,
    selector: bool = False,
    exit_code: int = 0,
) -> dict[str, object]:
    events: list[dict[str, object]] = [
        {"sequence": 0, "kind": "collection", "node_ids": [row[0] for row in rows]}
    ]
    sequence = 1
    for node_id, outcome in rows:
        if outcome == "skipped":
            events.append(_report(sequence, node_id, "setup", "skipped"))
            sequence += 1
            events.append(_report(sequence, node_id, "teardown", "passed"))
            sequence += 1
            continue
        events.append(_report(sequence, node_id, "setup", "passed"))
        sequence += 1
        call_outcome = "failed" if outcome == "failed" else "passed"
        events.append(_report(sequence, node_id, "call", call_outcome))
        sequence += 1
        events.append(_report(sequence, node_id, "teardown", "passed"))
        sequence += 1
    events.append(
        {"sequence": sequence, "kind": "session_finish", "exit_code": exit_code}
    )
    canonical, oracle_complete, notes = canonicalize_events(events, exit_code)
    if selector:
        oracle_complete = False
        notes = [*notes, pilot.SELECTOR_INCOMPLETENESS_NOTE]
    raw_bytes = json.dumps(
        events,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return {
        "schema": "zerorun.pytest-event-capture.v1",
        "authorizes_reuse": False,
        "evidence_eligible": False,
        "study_status_mutated": False,
        "synthetic_validation": False,
        "selector_observation": selector,
        "normalizer_id": "zerorun-canonical-pytest-outcome-v1",
        "pytest_version": "9.1.1",
        "pytest_exit_code": exit_code,
        "invocation_args": [],
        "observed_module_origins": {},
        "raw_events": events,
        "raw_events_sha256": hashlib.sha256(
            pilot.RAW_EVENT_DOMAIN + raw_bytes
        ).hexdigest(),
        "capture_valid": True,
        "oracle_complete": oracle_complete,
        "incompleteness_notes": notes,
        "refusal_reasons": [],
        "canonical_outcome": canonical,
    }


def test_manifest_is_strict_and_pinned(tmp_path: Path) -> None:
    manifest = _manifest(tmp_path)
    assert pilot.validate_manifest(manifest)["image"] == IMAGE

    unpinned = deepcopy(manifest)
    unpinned["image"] = "python:3.12"
    with pytest.raises(pilot.PilotRefused, match="pinned"):
        pilot.validate_manifest(unpinned)

    unsafe = deepcopy(manifest)
    unsafe["repositories"][0]["targets"] = ["../outside.py"]
    with pytest.raises(pilot.PilotRefused, match="safe repository-relative"):
        pilot.validate_manifest(unsafe)


def test_docker_command_is_networkless_readonly_and_mode_exact(tmp_path: Path) -> None:
    paths = [tmp_path / name for name in ("work", "receipt", "runtime", "harness")]
    for path in paths:
        path.mkdir()
    common = dict(
        image=IMAGE,
        work=paths[0],
        receipt=paths[1],
        runtime_site=paths[2],
        engine_root=paths[3],
        targets=["tests/test_tags.py"],
        observed_module="packaging",
        container_name="pilot-test",
        uid=1000,
        gid=1000,
        testmon=True,
    )

    seed = pilot.build_docker_command(**common, testmon_seed=True)
    head = pilot.build_docker_command(**common, selector_observation=True)

    assert seed[:5] == ["docker", "run", "--rm", "--pull", "never"]
    assert ["--network", "none"] == seed[seed.index("--network") : seed.index("--network") + 2]
    assert "--read-only" in seed
    assert ["--cap-drop", "ALL"] == seed[seed.index("--cap-drop") : seed.index("--cap-drop") + 2]
    assert "PYTHONPATH=/harness:/work/src:/work:/runtime" in seed
    assert "PYTEST_DISABLE_PLUGIN_AUTOLOAD=1" in seed
    assert "no:cacheprovider" not in seed
    cache_option = seed.index("cache_dir=/tmp/pytest-cache")
    assert seed[cache_option - 1] == "-o"
    assert seed.count("--observe-module") == 1
    assert seed[seed.index("--observe-module") + 1] == "packaging"
    assert "--testmon-noselect" in seed
    assert "--selector-observation" not in seed
    assert "--selector-observation" in head
    assert "--testmon-noselect" not in head


def _write_tar(path: Path, members: list[tuple[tarfile.TarInfo, bytes]]) -> None:
    with tarfile.open(path, "w") as archive:
        for info, payload in members:
            archive.addfile(info, BytesIO(payload) if info.isfile() else None)


def test_archive_extraction_accepts_regular_tree_and_existing_implicit_directory(
    tmp_path: Path,
) -> None:
    archive = tmp_path / "source.tar"
    file_info = tarfile.TarInfo("pkg/value.py")
    file_info.size = 6
    directory_info = tarfile.TarInfo("pkg/")
    directory_info.type = tarfile.DIRTYPE
    _write_tar(archive, [(file_info, b"x = 1\n"), (directory_info, b"")])

    identity = pilot.safe_extract_archive(archive, tmp_path / "out")

    assert identity["file_count"] == 1
    assert (tmp_path / "out" / "pkg" / "value.py").read_bytes() == b"x = 1\n"


@pytest.mark.parametrize("kind", ["traversal", "symlink", "hardlink", "drive"])
def test_archive_extraction_refuses_unsafe_members(tmp_path: Path, kind: str) -> None:
    archive = tmp_path / f"{kind}.tar"
    if kind == "traversal":
        info = tarfile.TarInfo("../outside")
        info.size = 1
        payload = b"x"
    elif kind == "drive":
        info = tarfile.TarInfo("C:/outside")
        info.size = 1
        payload = b"x"
    else:
        info = tarfile.TarInfo("link")
        info.type = tarfile.SYMTYPE if kind == "symlink" else tarfile.LNKTYPE
        info.linkname = "target"
        payload = b""
    _write_tar(archive, [(info, payload)])

    with pytest.raises(pilot.PilotRefused):
        pilot.safe_extract_archive(archive, tmp_path / "out")
    assert not (tmp_path / "outside").exists()


def test_capture_view_reduces_raw_events_and_rejects_tampering() -> None:
    capture = _capture([("test_a.py::test_a", "passed")])
    view = pilot._capture_view(capture, require_oracle=True)
    assert view["outcomes"] == {"test_a.py::test_a": "passed"}

    tampered = deepcopy(capture)
    tampered["raw_events"][1]["outcome"] = "failed"
    with pytest.raises(pilot.PilotRefused, match="raw-event digest"):
        pilot._capture_view(tampered, require_oracle=True)

    forged = deepcopy(capture)
    forged["canonical_outcome"]["overall_status"] = "failed"
    with pytest.raises(pilot.PilotRefused, match="canonical outcome"):
        pilot._capture_view(forged, require_oracle=True)


def test_exit_zero_internal_error_is_always_terminal() -> None:
    events: list[dict[str, object]] = [
        {"sequence": 0, "kind": "collection", "node_ids": []},
        {
            "sequence": 1,
            "kind": "internal_error",
            "longrepr": "Testmon configure failed",
            "longrepr_truncated": False,
        },
        {"sequence": 2, "kind": "session_finish", "exit_code": 0},
    ]
    canonical, oracle_complete, notes = canonicalize_events(events, 0)
    raw_bytes = json.dumps(
        events,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    capture = _capture([], selector=True)
    capture.update(
        {
            "raw_events": events,
            "raw_events_sha256": hashlib.sha256(
                pilot.RAW_EVENT_DOMAIN + raw_bytes
            ).hexdigest(),
            "canonical_outcome": canonical,
            "oracle_complete": oracle_complete,
            "incompleteness_notes": [*notes, pilot.SELECTOR_INCOMPLETENESS_NOTE],
        }
    )

    view = pilot._capture_view(capture, require_oracle=False)

    assert view["overall_status"] == "internal_error"
    with pytest.raises(pilot.PilotRefused, match="terminal status internal_error"):
        pilot._require_nonterminal_capture(view)


def test_parent_seed_accepts_native_reordering_but_not_outcome_change() -> None:
    direct = _capture([("a", "passed"), ("b", "passed")])
    reordered = _capture([("b", "passed"), ("a", "passed")])

    comparison = pilot.compare_parent_seed(direct, reordered)

    assert comparison["native_collection_order_equal"] is False
    changed = _capture([("b", "failed"), ("a", "passed")], exit_code=1)
    with pytest.raises(pilot.PilotRefused):
        pilot.compare_parent_seed(direct, changed)


def test_testmon_cache_moves_from_retained_parent_to_exact_head_path(
    tmp_path: Path,
) -> None:
    work = tmp_path / "work"
    parent = work / "testmon"
    head = work / "testmon-head-template"
    parent.mkdir(parents=True)
    head.mkdir()
    (parent / "parent.py").write_text("parent = True\n", encoding="utf-8")
    (head / "head.py").write_text("head = True\n", encoding="utf-8")
    database = sqlite3.connect(parent / ".testmondata")
    database.execute("CREATE TABLE state (value TEXT NOT NULL)")
    database.execute("INSERT INTO state VALUES ('sealed-cache')")
    database.commit()
    database.close()

    promotion = pilot._promote_testmon_head(work)

    assert (work / "testmon" / "head.py").is_file()
    assert not (work / "testmon" / "parent.py").exists()
    copied = sqlite3.connect(work / "testmon" / ".testmondata")
    try:
        assert copied.execute("SELECT value FROM state").fetchall() == [
            ("sealed-cache",)
        ]
    finally:
        copied.close()
    assert (work / "testmon-parent-after-seed" / "parent.py").is_file()
    assert promotion["backup"]["integrity_check"] == "ok"


def test_testmon_sqlite_backup_preserves_uncheckpointed_wal_rows(
    tmp_path: Path,
) -> None:
    live = tmp_path / "live"
    live.mkdir()
    live_database = live / ".testmondata"
    writer = sqlite3.connect(live_database)
    assert writer.execute("PRAGMA journal_mode=WAL").fetchone() == ("wal",)
    writer.execute("PRAGMA wal_autocheckpoint=0")
    writer.execute("CREATE TABLE state (value TEXT NOT NULL)")
    writer.commit()
    writer.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    writer.execute("INSERT INTO state VALUES ('wal-only-row')")
    writer.commit()

    work = tmp_path / "work"
    parent = work / "testmon"
    head = work / "testmon-head-template"
    parent.mkdir(parents=True)
    head.mkdir()
    for name in pilot.TESTMON_STATE_PATHS:
        source = live / name
        if source.exists():
            shutil.copyfile(source, parent / name)
    writer.close()
    assert (parent / ".testmondata-wal").is_file()

    promotion = pilot._promote_testmon_head(work)

    backed_up = sqlite3.connect(work / "testmon" / ".testmondata")
    try:
        assert backed_up.execute("SELECT value FROM state").fetchall() == [
            ("wal-only-row",)
        ]
    finally:
        backed_up.close()
    assert ".testmondata-wal" in promotion["seed_state"]


def test_claims_match_by_node_id_and_preserve_overall_status() -> None:
    parent = _capture([("a", "passed"), ("b", "passed")])
    selected = _capture([("b", "passed")], selector=True)
    claims = pilot.derive_testmon_claims(parent, selected)
    oracle = _capture([("a", "passed"), ("b", "passed")])

    comparison = pilot.compare_with_head_oracles(claims, [oracle, deepcopy(oracle)])

    assert comparison["status"] == "PASSED"
    assert claims["claimed_node_ids"] == ["a"]

    session_failure_selector = _capture(
        [("b", "passed")], selector=True, exit_code=1
    )
    failed_claims = pilot.derive_testmon_claims(parent, session_failure_selector)
    mismatch = pilot.compare_with_head_oracles(
        failed_claims, [oracle, deepcopy(oracle)]
    )
    assert mismatch["status"] == "FAILED"
    assert mismatch["selector_overall_status_matches_head_oracle"] is False


def test_prior_nonpass_is_explicitly_uncomparable_not_a_false_green() -> None:
    parent = _capture([("a", "passed"), ("b", "skipped")])
    selected = _capture([], selector=True)
    claims = pilot.derive_testmon_claims(parent, selected)
    oracle = _capture([("a", "passed"), ("b", "skipped")])

    comparison = pilot.compare_with_head_oracles(claims, [oracle, deepcopy(oracle)])

    assert comparison["status"] == "FAILED"
    assert comparison["passed_claim_consistency_status"] == "PASSED"
    assert comparison["full_canonical_coverage_status"] == "UNCOMPARABLE_PRIOR_NONPASS"
    assert comparison["uncomparable_prior_nonpass_node_ids"] == ["b"]
    assert comparison["unexpected_missing_node_ids"] == []


def test_package_origin_must_be_same_regular_file_under_work(tmp_path: Path) -> None:
    work = tmp_path / "work"
    package = work / "src" / "packaging"
    package.mkdir(parents=True)
    module = package / "__init__.py"
    module.write_text("__version__ = 'test'\n", encoding="utf-8")
    capture = _capture([("a", "passed")])
    capture["observed_module_origins"] = {
        "packaging": {
            "loaded": True,
            "file": "/work/src/packaging/__init__.py",
            "spec_origin": "/work/src/packaging/__init__.py",
        }
    }

    identity = pilot._validate_observed_module_origin(
        capture, module_name="packaging", work=work
    )

    assert identity["sha256"] == hashlib.sha256(module.read_bytes()).hexdigest()
    outside = deepcopy(capture)
    outside["observed_module_origins"]["packaging"]["file"] = (
        "/runtime/packaging/__init__.py"
    )
    outside["observed_module_origins"]["packaging"]["spec_origin"] = (
        "/runtime/packaging/__init__.py"
    )
    with pytest.raises(pilot.PilotRefused, match="outside /work"):
        pilot._validate_observed_module_origin(
            outside, module_name="packaging", work=work
        )


@pytest.mark.parametrize("drift", ["source_edit", "new_file"])
def test_source_tree_integrity_rejects_every_noncache_drift(
    tmp_path: Path, drift: str
) -> None:
    source = tmp_path / "source"
    source.mkdir()
    tracked = source / "module.py"
    tracked.write_text("value = 1\n", encoding="utf-8")
    expected = pilot.stable_tree_identity(source)
    if drift == "source_edit":
        tracked.write_text("value = 2\n", encoding="utf-8")
    else:
        (source / ".unexpected").write_text("drift\n", encoding="utf-8")

    with pytest.raises(pilot.PilotRefused, match="pinned archive identity"):
        pilot._verified_source_tree(source, expected)


def test_only_exact_testmon_state_files_may_change(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    (source / "module.py").write_text("value = 1\n", encoding="utf-8")
    expected = pilot.stable_tree_identity(source)
    for name in pilot.TESTMON_STATE_PATHS:
        (source / name).write_bytes(("state:" + name).encode("ascii"))

    assert (
        pilot._verified_source_tree(
            source,
            expected,
            excluded_relative_paths=pilot.TESTMON_STATE_PATHS,
        )
        == expected
    )
    with pytest.raises(pilot.PilotRefused, match="pinned archive identity"):
        pilot._verified_source_tree(source, expected)
    (source / ".testmondata.extra").write_bytes(b"not allowed")
    with pytest.raises(pilot.PilotRefused, match="pinned archive identity"):
        pilot._verified_source_tree(
            source,
            expected,
            excluded_relative_paths=pilot.TESTMON_STATE_PATHS,
        )


def test_exclusive_output_never_overwrites(tmp_path: Path) -> None:
    target = tmp_path / "receipt.json"
    pilot._exclusive_write(target, b"first")
    with pytest.raises(pilot.PilotRefused, match="overwrite"):
        pilot._exclusive_write(target, b"second")
    assert target.read_bytes() == b"first"
