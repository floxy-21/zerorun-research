from __future__ import annotations

from pathlib import Path
import tempfile

import pytest

from tools.pytest_collection_cache import (
    collection_action_fingerprint,
    load_collection_contract,
    save_collection_contract,
)
from zerorun.model import ConfigurationError, TaskSpec


_HEX_A = "a" * 64
_HEX_B = "b" * 64


def _project() -> tuple[tempfile.TemporaryDirectory, Path]:
    temporary = tempfile.TemporaryDirectory()
    root = Path(temporary.name)
    (root / "testing").mkdir(parents=True)
    (root / "testing" / "test_example.py").write_text(
        "def test_one():\n    assert True\n",
        encoding="utf-8",
    )
    (root / "testing" / "conftest.py").write_text("STATIC = 1\n", encoding="utf-8")
    package = root / "src" / "_pytest"
    package.mkdir(parents=True)
    (package / "session.py").write_text(
        "STATE = 1\n\ndef session_helper():\n    return STATE\n",
        encoding="utf-8",
    )
    (package / "logging.py").write_text("UNRELATED = 1\n", encoding="utf-8")
    return temporary, root


def _task() -> TaskSpec:
    return TaskSpec(
        name="terminal-core",
        command=("bash", "-c", "python -m pytest testing/test_example.py"),
        inputs=("testing/test_example.py", "testing/conftest.py"),
        outputs=(),
        env=(),
        cacheable=True,
        unsafe_effects=(),
        cache_streams=False,
        image="example.invalid/pytest@sha256:" + "d" * 64,
        platform="linux/amd64",
        result_only=True,
        closure_reviewed=True,
    )


def _contract() -> dict[str, object]:
    # Match the compact contract produced by pytest_collection_contract_probe:
    # path is intentionally absent and must be recovered safely from nodeid.
    return {
        "contract_sha256": _HEX_A,
        "nodeids": ["testing/test_example.py::test_one"],
        "items": [
            {
                "nodeid": "testing/test_example.py::test_one",
                "identity_sha256": "c" * 64,
                "parameter_identity_supported": True,
            }
        ],
    }


def _session_closure() -> dict[str, object]:
    return {
        "reviewable": True,
        "fresh_required": False,
        "selectors": [
            "src/_pytest/session.py::@binding:STATE",
            "src/_pytest/session.py::session_helper",
        ],
        "fallback_files": [],
    }


def _fingerprint(root: Path) -> tuple[str, dict[str, object]]:
    return collection_action_fingerprint(
        root,
        _task(),
        expected_contract=_contract(),
        session_closure=_session_closure(),
        runtime_identity={"resolved_image": "sha256:" + "e" * 64},
        environment_fingerprint={},
        collection_review_sha256=_HEX_B,
    )


def test_compact_contract_recovers_test_source_and_tracks_changes() -> None:
    temporary, root = _project()
    try:
        key1, fingerprint1 = _fingerprint(root)
        tracked = {
            str(record.get("path"))
            for record in fingerprint1["collection_source_records"]
            if isinstance(record, dict)
        }
        assert "testing/test_example.py" in tracked

        unrelated = root / "src" / "_pytest" / "logging.py"
        unrelated.write_text("UNRELATED = 2\n", encoding="utf-8")
        key2, _ = _fingerprint(root)
        assert key2 == key1

        test_source = root / "testing" / "test_example.py"
        test_source.write_text("def test_one():\n    assert 1 == 1\n", encoding="utf-8")
        key3, _ = _fingerprint(root)
        assert key3 != key2
    finally:
        temporary.cleanup()


def test_collection_key_tracks_config_and_reviewed_session_closure() -> None:
    temporary, root = _project()
    try:
        key1, _ = _fingerprint(root)

        conftest = root / "testing" / "conftest.py"
        conftest.write_text("STATIC = 2\n", encoding="utf-8")
        key2, _ = _fingerprint(root)
        assert key2 != key1

        session_source = root / "src" / "_pytest" / "session.py"
        session_source.write_text(
            session_source.read_text(encoding="utf-8").replace("STATE = 1", "STATE = 2"),
            encoding="utf-8",
        )
        key3, _ = _fingerprint(root)
        assert key3 != key2
    finally:
        temporary.cleanup()


def test_compact_contract_missing_node_source_fails_closed() -> None:
    temporary, root = _project()
    try:
        contract = {
            "contract_sha256": _HEX_A,
            "nodeids": ["virtual-item::test_one"],
            "items": [
                {
                    "nodeid": "virtual-item::test_one",
                    "identity_sha256": "c" * 64,
                    "parameter_identity_supported": True,
                }
            ],
        }
        with pytest.raises(ConfigurationError, match="missing or outside the project"):
            collection_action_fingerprint(
                root,
                _task(),
                expected_contract=contract,
                session_closure=_session_closure(),
                runtime_identity={"resolved_image": "sha256:" + "e" * 64},
                environment_fingerprint={},
                collection_review_sha256=_HEX_B,
            )
    finally:
        temporary.cleanup()


def test_collection_contract_store_requires_exact_key_and_fingerprint() -> None:
    temporary, root = _project()
    try:
        key, fingerprint = _fingerprint(root)
        assert load_collection_contract(root, key, fingerprint) is None
        save_collection_contract(root, key, fingerprint, _contract())
        assert load_collection_contract(root, key, fingerprint) == _contract()

        changed = dict(fingerprint)
        changed["collection_review_sha256"] = "f" * 64
        assert load_collection_contract(root, key, changed) is None
    finally:
        temporary.cleanup()


def test_collection_cache_requires_immutable_review() -> None:
    temporary, root = _project()
    try:
        with pytest.raises(ConfigurationError, match="collection_review_sha256"):
            collection_action_fingerprint(
                root,
                _task(),
                expected_contract=_contract(),
                session_closure=_session_closure(),
                runtime_identity={"resolved_image": "sha256:" + "e" * 64},
                environment_fingerprint={},
                collection_review_sha256="",
            )
    finally:
        temporary.cleanup()
