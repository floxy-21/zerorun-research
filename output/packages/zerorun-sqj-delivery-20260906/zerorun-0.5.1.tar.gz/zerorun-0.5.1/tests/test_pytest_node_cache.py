from __future__ import annotations

import json
from pathlib import Path
import tempfile

from tools.pytest_node_cache import (
    NodeCacheContext,
    fresh_nodeids,
    prepare_node_cache,
    publish_verified_successes,
    verify_node_cache_snapshot,
)
from zerorun.model import TaskSpec


_HEX_A = "a" * 64
_HEX_B = "b" * 64
_HEX_C = "c" * 64
_PROFILE_SHA256 = "9" * 64


def _project() -> tuple[tempfile.TemporaryDirectory, Path]:
    temporary = tempfile.TemporaryDirectory()
    root = Path(temporary.name)
    package = root / "src" / "_pytest"
    package.mkdir(parents=True)
    (package / "example.py").write_text(
        "VALUE = 1\nSESSION = 1\n\n"
        "def node_helper():\n"
        "    return VALUE\n\n"
        "def session_helper():\n"
        "    return SESSION\n",
        encoding="utf-8",
    )
    testing = root / "testing"
    testing.mkdir()
    (testing / "conftest.py").write_text("STATIC = 1\n", encoding="utf-8")
    _write_manifest(root)
    return temporary, root


def _task() -> TaskSpec:
    return TaskSpec(
        name="terminal-core",
        command=("bash", "-c", "python -m pytest testing/test_terminal.py"),
        inputs=("testing/conftest.py",),
        outputs=(),
        env=(),
        cacheable=True,
        unsafe_effects=(),
        cache_streams=False,
        image="example.invalid/pytest@sha256:" + "d" * 64,
        platform="linux/amd64",
        result_only=True,
        closure_reviewed=True,
    )


def _write_manifest(root: Path) -> None:
    task = _task()
    payload = {
        "version": 2,
        "tasks": {
            task.name: {
                "command": list(task.command),
                "inputs": list(task.inputs),
                "outputs": list(task.outputs),
                "env": list(task.env),
                "cacheable": task.cacheable,
                "unsafe_effects": list(task.unsafe_effects),
                "cache_streams": task.cache_streams,
                "image": task.image,
                "platform": task.platform,
                "result_only": task.result_only,
                "closure_reviewed": task.closure_reviewed,
            }
        },
    }
    (root / ".zerorun.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _node_row() -> dict[str, object]:
    return {
        "nodeid": "testing/test_terminal.py::test_one",
        "reviewable": True,
        "fresh_required": False,
        "selectors": [
            "src/_pytest/example.py::@binding:VALUE",
            "src/_pytest/example.py::node_helper",
        ],
        "fallback_files": [],
    }


def _session_closure() -> dict[str, object]:
    return {
        "reviewable": True,
        "fresh_required": False,
        "selectors": [
            "src/_pytest/example.py::@binding:SESSION",
            "src/_pytest/example.py::session_helper",
        ],
        "fallback_files": [],
    }


def _collection() -> list[dict[str, object]]:
    return [
        {
            "nodeid": "testing/test_terminal.py::test_one",
            "identity_sha256": _HEX_A,
            "parameter_identity_supported": True,
        }
    ]


def _context(
    *,
    collection_contract_sha256: str = _HEX_B,
    independence_review_sha256: str = _HEX_C,
) -> NodeCacheContext:
    return NodeCacheContext(
        runtime_identity={"resolved_image": "sha256:" + "e" * 64},
        environment_fingerprint={},
        collection_contract_sha256=collection_contract_sha256,
        independence_review_sha256=independence_review_sha256,
        profile_sha256=_PROFILE_SHA256,
    )


def _seed_success(root: Path, *, collection_contract_sha256: str = _HEX_B) -> None:
    initial = prepare_node_cache(
        root,
        _task(),
        node_rows=[_node_row()],
        session_closure=_session_closure(),
        collection_items=_collection(),
        context=_context(collection_contract_sha256=collection_contract_sha256),
    )
    assert [decision.status for decision in initial] == ["MISS_KEYED"]
    verified = verify_node_cache_snapshot(
        root,
        _task(),
        decisions=initial,
        node_rows=[_node_row()],
        session_closure=_session_closure(),
        collection_items=_collection(),
        final_context=_context(collection_contract_sha256=collection_contract_sha256),
    )
    assert [decision.status for decision in verified] == ["MISS_VERIFIED"]
    assert publish_verified_successes(
        root,
        verified,
        successful_nodeids={"testing/test_terminal.py::test_one"},
        execution_ms_by_node={"testing/test_terminal.py::test_one": 12.5},
    ) == 1


def test_two_snapshot_hit_is_rejected_when_selected_source_changes() -> None:
    temporary, root = _project()
    try:
        _seed_success(root)
        hit = prepare_node_cache(
            root,
            _task(),
            node_rows=[_node_row()],
            session_closure=_session_closure(),
            collection_items=_collection(),
            context=_context(),
        )
        assert [decision.status for decision in hit] == ["HIT_PROVISIONAL"]
        assert fresh_nodeids(hit) == []

        source = root / "src" / "_pytest" / "example.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace("VALUE = 1", "VALUE = 2"),
            encoding="utf-8",
        )
        rejected = verify_node_cache_snapshot(
            root,
            _task(),
            decisions=hit,
            node_rows=[_node_row()],
            session_closure=_session_closure(),
            collection_items=_collection(),
            final_context=_context(),
        )
        assert [decision.status for decision in rejected] == ["REJECTED_INPUT_RACE"]
        assert "identity changed" in str(rejected[0].reason)
    finally:
        temporary.cleanup()


def test_collection_contract_drift_during_one_request_rejects_provisional_node() -> None:
    temporary, root = _project()
    try:
        initial = prepare_node_cache(
            root,
            _task(),
            node_rows=[_node_row()],
            session_closure=_session_closure(),
            collection_items=_collection(),
            context=_context(collection_contract_sha256="b" * 64),
        )
        rejected = verify_node_cache_snapshot(
            root,
            _task(),
            decisions=initial,
            node_rows=[_node_row()],
            session_closure=_session_closure(),
            collection_items=_collection(),
            final_context=_context(collection_contract_sha256="f" * 64),
        )
        assert [decision.status for decision in rejected] == ["REJECTED_INPUT_RACE"]
        assert "collection snapshot changed during request" in str(rejected[0].reason)
    finally:
        temporary.cleanup()


def test_cross_request_collection_set_change_can_reuse_same_node_identity() -> None:
    temporary, root = _project()
    try:
        _seed_success(root, collection_contract_sha256="b" * 64)
        # A later request may have a different complete collection contract
        # because a sibling node was added/removed. The same current node item,
        # source/session/runtime and independence review should still hit.
        later = prepare_node_cache(
            root,
            _task(),
            node_rows=[_node_row()],
            session_closure=_session_closure(),
            collection_items=_collection(),
            context=_context(collection_contract_sha256="f" * 64),
        )
        assert [decision.status for decision in later] == ["HIT_PROVISIONAL"]
        verified = verify_node_cache_snapshot(
            root,
            _task(),
            decisions=later,
            node_rows=[_node_row()],
            session_closure=_session_closure(),
            collection_items=_collection(),
            final_context=_context(collection_contract_sha256="f" * 64),
        )
        assert [decision.status for decision in verified] == ["HIT_REUSED"]
    finally:
        temporary.cleanup()


def test_missing_independence_review_stays_unkeyed_and_fresh() -> None:
    temporary, root = _project()
    try:
        decisions = prepare_node_cache(
            root,
            _task(),
            node_rows=[_node_row()],
            session_closure=_session_closure(),
            collection_items=_collection(),
            context=_context(independence_review_sha256=""),
        )
        assert [decision.status for decision in decisions] == ["MISS_UNCERTAIN"]
        assert decisions[0].key is None
        assert fresh_nodeids(decisions) == ["testing/test_terminal.py::test_one"]
    finally:
        temporary.cleanup()


def test_only_final_snapshot_verified_fresh_successes_are_published() -> None:
    temporary, root = _project()
    try:
        uncertain_row = {
            **_node_row(),
            "fresh_required": True,
            "reason": "review uncertainty",
        }
        decisions = prepare_node_cache(
            root,
            _task(),
            node_rows=[uncertain_row],
            session_closure=_session_closure(),
            collection_items=_collection(),
            context=_context(),
        )
        assert [decision.status for decision in decisions] == ["MISS_UNCERTAIN"]
        assert publish_verified_successes(
            root,
            decisions,
            successful_nodeids={"testing/test_terminal.py::test_one"},
        ) == 0
    finally:
        temporary.cleanup()
