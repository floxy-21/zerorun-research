from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from research.artifact import validation
from tools import research_candidate_selector as selector


ROOT = Path(__file__).resolve().parents[1]
GIT40 = "a" * 40
SHA64 = "b" * 64


def _sha(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _write_json(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, allow_nan=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def _fixture(
    tmp_path: Path, *, per_stratum: int = 30
) -> tuple[Path, Path, dict[str, object]]:
    tmp_path.mkdir(parents=True, exist_ok=True)
    exclusions = tmp_path / "development-contact-exclusions.txt"
    exclusions.write_text(
        "# frozen before ranking\nowner-s1-00/repo\n",
        encoding="utf-8",
        newline="\n",
    )
    exclusion_sha = validation.sha256_file(exclusions)
    candidates: list[dict[str, object]] = []
    strata = {
        "S1": 100,
        "S2": 500,
        "S3": 2_000,
        "S4": 10_000,
    }
    repository_id = 1
    for stratum, minimum_stars in strata.items():
        for index in range(per_stratum):
            name = f"owner-{stratum.casefold()}-{index:02d}/repo"
            candidates.append(
                {
                    "github_repository_id": repository_id,
                    "canonical_full_name": name,
                    "observed_aliases": [name],
                    "html_url": f"https://github.com/{name}",
                    "stratum": stratum,
                    "stars_at_sampling": minimum_stars + index,
                    "primary_language": "Python",
                    "is_fork": False,
                    "is_archived": False,
                    "is_private": False,
                    "pushed_at_utc": "2026-08-01T00:00:00Z",
                    "license_spdx": "MIT",
                    "size_kib": 100 + index,
                    "default_branch": "main",
                    "frozen_head_sha": _sha(f"commit-{repository_id}")[:40],
                    "metadata_status": "complete",
                    "metadata_sha256": _sha(f"metadata-{repository_id}"),
                    "frame_position": repository_id,
                }
            )
            repository_id += 1
    frame: dict[str, object] = {
        "schema": selector.FRAME_SCHEMA,
        "artifact_role": "candidate_frame_only",
        "protocol_commit": GIT40,
        "retrieval_client_commit": "c" * 40,
        "created_at_utc": "2026-09-01T01:00:00Z",
        "sampling": {
            "seed": "public-future-seed-0001",
            "seed_source": "synthetic test beacon",
            "seed_source_payload_sha256": _sha("beacon"),
            "window_start_utc": "2026-09-01T00:00:00Z",
            "window_end_utc": "2026-09-01T00:30:00Z",
            "maintenance_cutoff_utc": "2024-09-01T00:00:00Z",
            "github_api_version": "2022-11-28",
            "query_cells": [
                {
                    "cell_id": f"cell-{stratum}",
                    "stratum": stratum,
                    "query": f"language:Python stars:{stratum}",
                    "reported_total_count": per_stratum,
                    "pages_fetched": 1,
                    "retrieved_count": per_stratum,
                    "first_request_at_utc": "2026-09-01T00:00:00Z",
                    "last_request_at_utc": "2026-09-01T00:10:00Z",
                    "response_index_sha256": _sha(f"responses-{stratum}"),
                    "completeness_status": "complete",
                }
                for stratum in strata
            ],
        },
        "collection": {
            "algorithm": selector.FRAME_COLLECTION_ALGORITHM,
            "collector_source_sha256": _sha("frame collector source"),
            "created_partition_start_date": "2008-01-01",
            "created_partition_end_date": "2026-09-01",
            "terminal_cell_max_results": 900,
            "snapshot_count": 2,
            "selected_snapshot": 2,
            "snapshot_stability_max_symmetric_difference_ratio": 0.01,
            "snapshot_1_distinct_repositories": per_stratum * 4,
            "snapshot_2_distinct_repositories": per_stratum * 4,
            "overall_symmetric_difference_repositories": 0,
            "overall_symmetric_difference_ratio": 0.0,
            "snapshot_comparisons": [
                {
                    "stratum": stratum,
                    "snapshot_1_distinct_repositories": per_stratum,
                    "snapshot_2_distinct_repositories": per_stratum,
                    "symmetric_difference_repositories": 0,
                    "symmetric_difference_ratio": 0.0,
                }
                for stratum in strata
            ],
            "snapshot_1_search_index_sha256": _sha("snapshot-1"),
            "snapshot_2_search_index_sha256": _sha("snapshot-2"),
            "stable": True,
        },
        "raw_response_index_sha256": SHA64,
        "raw_response_aggregate_sha256": "d" * 64,
        "development_contact_exclusion_sha256": exclusion_sha,
        "candidates": candidates,
    }
    frame_path = tmp_path / "candidate-frame.json"
    _write_json(frame_path, frame)
    return frame_path, exclusions, frame


def _build(frame_path: Path, exclusions: Path) -> tuple[dict, dict]:
    return selector.build_candidate_selection(
        research_root=ROOT / "research",
        candidate_frame=frame_path,
        exclusion_file=exclusions,
        created_at_utc="2026-09-01T02:00:00Z",
    )


def test_selector_is_deterministic_schema_valid_and_non_authorizing(
    tmp_path: Path,
) -> None:
    frame_path, exclusions, _ = _fixture(tmp_path)
    first, first_receipt = _build(frame_path, exclusions)
    second, second_receipt = _build(frame_path, exclusions)

    assert first == second
    assert first_receipt == second_receipt
    assert len(first["candidates"]) == 120
    assert first["candidate_frame_sha256"] == validation.sha256_file(frame_path)
    assert first_receipt["confirmatory_execution_authorized"] is False
    assert first_receipt["final_corpus_created"] is False
    assert first_receipt["counts"]["S1"] == {
        "frame": 30,
        "preliminary_metadata_pass": 30,
        "development_contact_excluded": 1,
        "proposed_for_screening": 29,
    }

    by_stratum: dict[str, list[dict]] = {stratum: [] for stratum in selector.STRATA}
    for row in first["candidates"]:
        by_stratum[row["stratum"]].append(row)
        expected = selector._rank_key(first["seed"], row["github_repository_id"])
        assert row["rank_key"] == expected
    for rows in by_stratum.values():
        assert [row["rank_position"] for row in rows] == list(range(1, 31))
        assert [row["rank_key"] for row in rows] == sorted(
            row["rank_key"] for row in rows
        )

    report = validation.ValidationReport()
    catalog = validation.load_schema_catalog(ROOT / "research/schemas", report)
    assert validation.validate_instance(
        first,
        selector.SELECTION_SCHEMA,
        catalog,
        report,
        "generated selection",
    )
    assert report.errors == []


def test_selector_preserves_preliminary_failures_in_ranked_denominator(
    tmp_path: Path,
) -> None:
    frame_path, exclusions, frame = _fixture(tmp_path)
    frame["candidates"][1]["license_spdx"] = None
    frame["candidates"][2]["size_kib"] = selector.MAX_SIZE_KIB + 1
    _write_json(frame_path, frame)

    selection, receipt = _build(frame_path, exclusions)
    by_id = {row["github_repository_id"]: row for row in selection["candidates"]}
    assert len(by_id) == 120
    assert by_id[2]["preliminary_reason_codes"] == ["missing_license_metadata"]
    assert by_id[3]["preliminary_reason_codes"] == [
        "repository_size_cap_exceeded"
    ]
    assert by_id[2]["proposed_for_screening"] is False
    assert by_id[3]["proposed_for_screening"] is False
    assert receipt["counts"]["S1"]["frame"] == 30
    assert receipt["counts"]["S1"]["proposed_for_screening"] == 27


def test_selector_preserves_metadata_drift_as_screening_failures(
    tmp_path: Path,
) -> None:
    frame_path, exclusions, frame = _fixture(tmp_path)
    changed = frame["candidates"][1]
    changed["metadata_status"] = "head_unavailable"
    changed["frozen_head_sha"] = None
    changed["is_archived"] = True
    changed["primary_language"] = "Rust"
    changed["stars_at_sampling"] = 99
    changed["pushed_at_utc"] = "2024-01-01T00:00:00Z"
    _write_json(frame_path, frame)

    selection, receipt = _build(frame_path, exclusions)
    row = next(item for item in selection["candidates"] if item["github_repository_id"] == 2)
    assert row["preliminary_metadata_pass"] is False
    assert row["proposed_for_screening"] is False
    assert row["preliminary_reason_codes"] == [
        "metadata_freeze_incomplete",
        "archived_at_metadata_freeze",
        "primary_language_not_python",
        "star_stratum_drift",
        "maintenance_window_drift",
    ]
    assert receipt["counts"]["S1"]["frame"] == 30


def test_selector_cli_writes_receipt_and_refuses_different_overwrite(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    frame_path, exclusions, _ = _fixture(tmp_path)
    output = tmp_path / "candidate-selection.json"
    receipt = tmp_path / "candidate-selection-receipt.json"
    argv = [
        "--research-root",
        str(ROOT / "research"),
        "--candidate-frame",
        str(frame_path),
        "--development-contact-exclusions",
        str(exclusions),
        "--created-at-utc",
        "2026-09-01T02:00:00Z",
        "--output",
        str(output),
        "--receipt",
        str(receipt),
    ]
    assert selector.main(argv) == 0
    assert selector.main(argv) == 0
    assert json.loads(output.read_text(encoding="utf-8"))["artifact_role"] == (
        "candidate_selection_only"
    )
    assert json.loads(receipt.read_text(encoding="utf-8"))[
        "confirmatory_execution_authorized"
    ] is False
    capsys.readouterr()

    output.write_text("{}\n", encoding="utf-8", newline="\n")
    assert selector.main(argv) == 2
    assert "refusing to overwrite" in capsys.readouterr().err


@pytest.mark.parametrize("attack", ["duplicate_key", "nonfinite", "duplicate_id"])
def test_selector_rejects_malformed_or_ambiguous_frames(
    tmp_path: Path, attack: str
) -> None:
    frame_path, exclusions, frame = _fixture(tmp_path)
    if attack == "duplicate_key":
        source = frame_path.read_text(encoding="utf-8")
        frame_path.write_text(
            source.replace("{\n", '{\n  "schema": "wrong",\n', 1),
            encoding="utf-8",
            newline="\n",
        )
    elif attack == "nonfinite":
        source = frame_path.read_text(encoding="utf-8")
        frame_path.write_text(
            source.replace('"size_kib": 100', '"size_kib": NaN', 1),
            encoding="utf-8",
            newline="\n",
        )
    else:
        malformed = deepcopy(frame)
        malformed["candidates"][1]["github_repository_id"] = malformed["candidates"][0][
            "github_repository_id"
        ]
        _write_json(frame_path, malformed)

    with pytest.raises(selector.SelectionRefused):
        _build(frame_path, exclusions)


def test_selector_binds_exact_exclusions_and_requires_screening_depth(
    tmp_path: Path,
) -> None:
    frame_path, exclusions, _ = _fixture(tmp_path, per_stratum=25)
    with pytest.raises(selector.SelectionRefused, match="only 24 candidates"):
        _build(frame_path, exclusions)

    frame_path, exclusions, _ = _fixture(tmp_path / "digest", per_stratum=30)
    exclusions.write_text(
        exclusions.read_text(encoding="utf-8") + "unbound-owner/repo\n",
        encoding="utf-8",
        newline="\n",
    )
    with pytest.raises(selector.SelectionRefused, match="does not bind"):
        _build(frame_path, exclusions)


def test_selector_rejects_unresolved_or_unreconciled_collection_evidence(
    tmp_path: Path,
) -> None:
    frame_path, exclusions, frame = _fixture(tmp_path)
    frame["sampling"]["query_cells"][0]["completeness_status"] = "audited_overflow"
    _write_json(frame_path, frame)
    with pytest.raises(selector.SelectionRefused, match="unresolved search cell"):
        _build(frame_path, exclusions)

    frame_path, exclusions, frame = _fixture(tmp_path / "count")
    frame["collection"]["snapshot_2_distinct_repositories"] = 119
    _write_json(frame_path, frame)
    with pytest.raises(selector.SelectionRefused, match="candidate count differs"):
        _build(frame_path, exclusions)
