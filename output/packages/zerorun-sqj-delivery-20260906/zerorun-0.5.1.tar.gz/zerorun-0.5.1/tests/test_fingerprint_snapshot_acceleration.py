from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import glob
import json
import os
from pathlib import Path

import pytest

from zerorun import fingerprint
from zerorun.hermetic_batch_key import FingerprintSession
from zerorun.model import ConfigurationError


def _records_by_path(records: list[dict[str, object]]) -> dict[str, dict[str, object]]:
    return {
        str(record["path"]): record
        for record in records
        if isinstance(record.get("path"), str)
    }


def test_snapshot_pattern_cache_is_immutable_and_final_session_rehashes(
    tmp_path: Path,
) -> None:
    source = tmp_path / "source.py"
    source.write_text("VALUE = 1\n", encoding="utf-8")
    first_session = FingerprintSession(tmp_path)
    before = first_session.expand_inputs(tmp_path, ("source.py",))
    before_sha = before[0]["sha256"]

    # A caller cannot mutate the frozen expansion retained by the session.
    before[0]["sha256"] = "forged"
    assert first_session.expand_inputs(tmp_path, ("source.py",))[0]["sha256"] == before_sha

    source.write_text("VALUE = 2\n", encoding="utf-8")
    # One session is one explicit point-in-time snapshot.
    assert first_session.expand_inputs(tmp_path, ("source.py",))[0]["sha256"] == before_sha
    # Final verification always uses a new session and must observe the edit.
    after = FingerprintSession(tmp_path).expand_inputs(tmp_path, ("source.py",))
    assert after[0]["sha256"] != before_sha


def test_absent_becomes_present_only_new_snapshot_can_authorize_it(tmp_path: Path) -> None:
    first_session = FingerprintSession(tmp_path)
    missing = first_session.expand_inputs(tmp_path, ("shadow.py",))
    assert missing == [{"pattern": "shadow.py", "type": "missing"}]

    (tmp_path / "shadow.py").write_text("SHADOW = True\n", encoding="utf-8")
    assert first_session.expand_inputs(tmp_path, ("shadow.py",)) == missing
    present = FingerprintSession(tmp_path).expand_inputs(tmp_path, ("shadow.py",))
    assert present[0]["path"] == "shadow.py"
    assert present[0]["type"] == "file"


def test_expected_absence_expansion_preserves_exact_records(tmp_path: Path) -> None:
    native = tmp_path / "native"
    native.mkdir()
    patterns = (
        "missing.py",
        "native/missing.py",
        "native/module*.so",
    )
    canonical = fingerprint.expand_inputs(tmp_path, patterns)
    optimized = FingerprintSession(tmp_path).expand_expected_absent_inputs(
        tmp_path,
        patterns,
    )
    assert json.dumps(optimized, sort_keys=True, separators=(",", ":")) == json.dumps(
        canonical,
        sort_keys=True,
        separators=(",", ":"),
    )


@pytest.mark.parametrize(
    "pattern",
    (
        "",
        "nul\x00path.py",
        "/absolute.py",
        "../escape.py",
        "./relative.py",
        "nested//missing.py",
        "nested/../missing.py",
        ".zerorun/secret",
        "ancestor*/missing.py",
        "nested/",
        "windows\\separator.py",
        "C:/drive.py",
    ),
)
def test_expected_absence_parser_rejects_unsupported_safety_domains(
    pattern: str,
) -> None:
    assert fingerprint._canonical_expected_absence_parts(pattern) is None


def test_expected_missing_record_commit_is_exact_and_atomic() -> None:
    patterns = ("z.py", "a*.so", "z.py")
    cache: dict[str, fingerprint._FrozenExpansion] = {}
    assert fingerprint._commit_expected_missing_expansions(patterns, cache) == [
        {"pattern": "a*.so", "type": "missing"},
        {"pattern": "z.py", "type": "missing"},
        {"pattern": "z.py", "type": "missing"},
    ]
    assert list(cache) == ["z.py", "a*.so"]
    assert fingerprint._thaw_expansion(cache["z.py"]) == [
        {"pattern": "z.py", "type": "missing"}
    ]

    forged = fingerprint._freeze_expansion(
        [{"path": "conflict.py", "type": "unsupported"}]
    )
    conflicting = {"conflict.py": forged}
    with pytest.raises(ConfigurationError, match="pattern expansion changed"):
        fingerprint._commit_expected_missing_expansions(
            ("would-be-added.py", "conflict.py"),
            conflicting,
        )
    assert conflicting == {"conflict.py": forged}


@pytest.mark.skipif(os.name != "posix", reason="nofollow directory descriptors are POSIX")
def test_hierarchical_absence_direct_result_and_cache_match_generic_exactly(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    native = tmp_path / "native"
    native.mkdir()
    patterns = (
        "native/z*.so",
        "missing.py",
        "native/a?.so",
        "missing.py",
        "native/module[0-9].so",
    )
    generic = fingerprint.expand_inputs(tmp_path, patterns)
    expansion_cache: dict[str, fingerprint._FrozenExpansion] = {}

    def forbidden_replay(*_args, **_kwargs):
        raise AssertionError("proved expected absences must not use generic replay")

    monkeypatch.setattr(fingerprint, "expand_inputs", forbidden_replay)
    optimized = fingerprint.expand_expected_absent_inputs(
        tmp_path,
        patterns,
        pattern_expansion_cache=expansion_cache,
    )

    assert json.dumps(optimized, separators=(",", ":")) == json.dumps(
        generic,
        separators=(",", ":"),
    )
    assert list(expansion_cache) == list(dict.fromkeys(patterns))
    for pattern in dict.fromkeys(patterns):
        assert fingerprint._thaw_expansion(expansion_cache[pattern]) == [
            {"pattern": pattern, "type": "missing"}
        ]


@pytest.mark.skipif(os.name != "posix", reason="nofollow directory descriptors are POSIX")
def test_hierarchical_absence_refuses_conflicting_pattern_cache_commit(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    pattern = "shadow.py"
    cache: dict[str, fingerprint._FrozenExpansion] = {}
    forged = fingerprint._freeze_expansion(
        [{"path": pattern, "type": "unsupported"}]
    )
    calls = 0
    original = fingerprint._stable_nofollow_directory_inventory

    def inject_conflict(path: Path, *, required_names: frozenset[str]):
        nonlocal calls
        result = original(path, required_names=required_names)
        calls += 1
        if calls == 1:
            cache[pattern] = forged
        return result

    monkeypatch.setattr(
        fingerprint,
        "_stable_nofollow_directory_inventory",
        inject_conflict,
    )
    with pytest.raises(ConfigurationError, match="pattern expansion changed"):
        fingerprint.expand_expected_absent_inputs(
            tmp_path,
            (pattern,),
            pattern_expansion_cache=cache,
        )
    assert cache == {pattern: forged}


@pytest.mark.skipif(os.name != "posix", reason="nofollow directory descriptors are POSIX")
def test_hierarchical_absence_uses_bounded_stable_inventories(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "src"
    source.mkdir()
    patterns = tuple(f"src/shadow_{index:04d}.py" for index in range(3_521))
    observed: list[Path] = []
    original = fingerprint._stable_nofollow_directory_inventory

    def counted(path: Path, *, required_names: frozenset[str]):
        observed.append(path)
        return original(path, required_names=required_names)

    monkeypatch.setattr(
        fingerprint,
        "_stable_nofollow_directory_inventory",
        counted,
    )
    session = FingerprintSession(tmp_path)
    assert session.expand_expected_absent_inputs(tmp_path, ()) == []
    assert observed == []
    records = session.expand_expected_absent_inputs(
        tmp_path,
        patterns,
    )

    assert records == [
        {"pattern": pattern, "type": "missing"} for pattern in patterns
    ]
    assert observed.count(tmp_path) == 2
    assert observed.count(source) == 2
    assert len(observed) == 4


@pytest.mark.skipif(os.name != "posix", reason="nofollow directory descriptors are POSIX")
def test_hierarchical_absence_rejects_creation_between_inventory_passes(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    package = tmp_path / "package"
    package.mkdir()
    target = package / "shadow.py"
    calls = 0
    original = fingerprint._stable_nofollow_directory_inventory

    def mutate(path: Path, *, required_names: frozenset[str]):
        nonlocal calls
        if path == package:
            calls += 1
            if calls == 2:
                target.write_text("SHADOW = True\n", encoding="utf-8")
        return original(path, required_names=required_names)

    monkeypatch.setattr(
        fingerprint,
        "_stable_nofollow_directory_inventory",
        mutate,
    )
    with pytest.raises(ConfigurationError, match="changed between inventory passes"):
        FingerprintSession(tmp_path).expand_expected_absent_inputs(
            tmp_path,
            ("package/shadow.py",),
        )


@pytest.mark.skipif(os.name != "posix", reason="nofollow directory descriptors are POSIX")
def test_hierarchical_absence_rejects_directory_replacement(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    package = tmp_path / "package"
    package.mkdir()
    displaced = tmp_path / "displaced-package"
    calls = 0
    original = fingerprint._stable_nofollow_directory_inventory

    def replace(path: Path, *, required_names: frozenset[str]):
        nonlocal calls
        if path == package:
            calls += 1
            if calls == 2:
                package.rename(displaced)
                package.mkdir()
        return original(path, required_names=required_names)

    monkeypatch.setattr(
        fingerprint,
        "_stable_nofollow_directory_inventory",
        replace,
    )
    with pytest.raises(ConfigurationError, match="changed between inventory passes"):
        FingerprintSession(tmp_path).expand_expected_absent_inputs(
            tmp_path,
            ("package/shadow.py",),
        )


@pytest.mark.skipif(os.name != "posix", reason="nofollow directory descriptors are POSIX")
def test_hierarchical_absence_rejects_linked_parent(tmp_path: Path) -> None:
    real_parent = tmp_path / "real-parent"
    real_parent.mkdir()
    linked = tmp_path / "linked-parent"
    linked.symlink_to(real_parent, target_is_directory=True)

    with pytest.raises(ConfigurationError, match="linked or non-directory component"):
        FingerprintSession(tmp_path).expand_expected_absent_inputs(
            tmp_path,
            ("linked-parent/shadow.py",),
        )


@pytest.mark.skipif(os.name != "posix", reason="nofollow directory descriptors are POSIX")
def test_hierarchical_absence_new_session_observes_creation(tmp_path: Path) -> None:
    first = FingerprintSession(tmp_path)
    missing = first.expand_expected_absent_inputs(tmp_path, ("shadow.py",))
    assert missing == [{"pattern": "shadow.py", "type": "missing"}]

    (tmp_path / "shadow.py").write_text("SHADOW = True\n", encoding="utf-8")
    assert first.expand_expected_absent_inputs(tmp_path, ("shadow.py",)) == missing
    assert FingerprintSession(tmp_path).expand_expected_absent_inputs(
        tmp_path,
        ("shadow.py",),
    ) == [{"pattern": "shadow.py", "type": "present"}]


def test_glob_membership_order_duplicates_and_missing_semantics(tmp_path: Path) -> None:
    native = tmp_path / "native"
    native.mkdir()
    for name in ("z.so", "a.so", "m.txt"):
        (native / name).write_text(name, encoding="utf-8")
    patterns = (
        "native/*.so",
        "native/a.so",
        "native/*.so",
        "missing.py",
        "missing.py",
    )
    session = FingerprintSession(tmp_path)
    records = session.expand_inputs(tmp_path, patterns)

    assert [record.get("path") for record in records if "path" in record] == [
        "native/a.so",
        "native/z.so",
    ]
    # Existing paths are deduplicated across overlapping/duplicate patterns;
    # missing declarations remain one record per declaration, as before.
    assert [record for record in records if record.get("type") == "missing"] == [
        {"pattern": "missing.py", "type": "missing"},
        {"pattern": "missing.py", "type": "missing"},
    ]

    (native / "b.so").write_text("b.so", encoding="utf-8")
    assert "native/b.so" not in _records_by_path(session.expand_inputs(tmp_path, patterns))
    final_paths = _records_by_path(
        FingerprintSession(tmp_path).expand_inputs(tmp_path, patterns)
    )
    assert list(final_paths) == ["native/a.so", "native/b.so", "native/z.so"]


def test_snapshot_cache_preserves_exact_serialized_records(tmp_path: Path) -> None:
    package = tmp_path / "package"
    package.mkdir()
    (package / "b.py").write_text("B = 2\n", encoding="utf-8")
    (package / "a.py").write_text("A = 1\n", encoding="utf-8")
    patterns = ("package/*.py", "package/a.py", "missing*.so")
    direct = fingerprint.expand_inputs(tmp_path, patterns, path_record_cache={})
    snapshot = FingerprintSession(tmp_path).expand_inputs(tmp_path, patterns)
    assert json.dumps(snapshot, sort_keys=True, separators=(",", ":")) == json.dumps(
        direct,
        sort_keys=True,
        separators=(",", ":"),
    )


def test_basename_globs_share_one_directory_scan_in_snapshot(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    native = tmp_path / "native"
    native.mkdir()
    (native / "module.cpython-312-x86_64-linux-gnu.so").write_bytes(b"elf")
    (native / "module.pyd").write_bytes(b"pyd")
    calls = 0
    original = fingerprint.os.scandir

    def counted(path):
        nonlocal calls
        calls += 1
        return original(path)

    monkeypatch.setattr(fingerprint.os, "scandir", counted)
    session = FingerprintSession(tmp_path)
    records = session.expand_inputs(
        tmp_path,
        ("native/module*.so", "native/*.pyd", "native/module*.so"),
    )
    assert calls == 1
    assert sorted(_records_by_path(records)) == [
        "native/module.cpython-312-x86_64-linux-gnu.so",
        "native/module.pyd",
    ]


@pytest.mark.parametrize(
    "pattern",
    (
        "native/*.so",
        "native/module?.so",
        "native/[am]*.so",
        "native/.hidden*.so",
        "native/a*a.so",
    ),
)
def test_shared_directory_scan_matches_canonical_glob_exactly(
    tmp_path: Path,
    pattern: str,
) -> None:
    native = tmp_path / "native"
    native.mkdir()
    for name in (
        "a.so",
        "aa.so",
        "ama.so",
        "module1.so",
        "modulex.so",
        "z.txt",
        ".hidden-module.so",
    ):
        (native / name).write_text(name, encoding="utf-8")
    expected = sorted(glob.glob(str(tmp_path / pattern), recursive=True))
    observed = fingerprint._simple_basename_glob(
        str(tmp_path),
        pattern,
        directory_entries_cache={},
        lstat_cache={},
    )
    assert observed is not None
    assert sorted(observed) == expected


def test_independent_sessions_repeat_stable_hash_read(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    (tmp_path / "source.py").write_text("VALUE = 1\n", encoding="utf-8")
    calls = 0
    original = fingerprint.sha256_file

    def counted(path: Path) -> str:
        nonlocal calls
        calls += 1
        return original(path)

    monkeypatch.setattr(fingerprint, "sha256_file", counted)
    first = FingerprintSession(tmp_path)
    first.expand_inputs(tmp_path, ("source.py", "source.py"))
    first.expand_inputs(tmp_path, ("source.py",))
    assert calls == 1
    FingerprintSession(tmp_path).expand_inputs(tmp_path, ("source.py",))
    assert calls == 2


def test_concurrent_shared_session_has_one_coherent_expansion(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    native = tmp_path / "native"
    native.mkdir()
    for index in range(8):
        (native / f"module{index}.so").write_bytes(str(index).encode("ascii"))
    calls = 0
    original = fingerprint.os.scandir

    def counted(path):
        nonlocal calls
        calls += 1
        return original(path)

    monkeypatch.setattr(fingerprint.os, "scandir", counted)
    session = FingerprintSession(tmp_path)
    with ThreadPoolExecutor(max_workers=12) as executor:
        results = list(
            executor.map(
                lambda _: session.expand_inputs(tmp_path, ("native/*.so",)),
                range(48),
            )
        )
    assert calls == 1
    assert all(result == results[0] for result in results)
    assert len(results[0]) == 8


def test_fast_absence_rejects_symlink_or_junction_ancestor_escape(
    tmp_path: Path,
) -> None:
    outside = tmp_path.parent / f"{tmp_path.name}-outside"
    outside.mkdir()
    linked = tmp_path / "linked"
    try:
        os.symlink(outside, linked, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("directory links require unavailable host privileges")
    try:
        session = FingerprintSession(tmp_path)
        with pytest.raises(ConfigurationError, match="escapes the project root"):
            session.expand_inputs(tmp_path, ("linked/not-created.py",))
        with pytest.raises(ConfigurationError, match="escapes the project root"):
            session.expand_inputs(tmp_path, ("linked/native*.so",))
    finally:
        # Remove only the link itself, never its external target.
        linked.unlink(missing_ok=True)
        outside.rmdir()


def test_fast_validation_rejects_resolved_zerorun_alias(tmp_path: Path) -> None:
    state = tmp_path / ".zerorun"
    state.mkdir()
    alias = tmp_path / "state-alias"
    try:
        os.symlink(state, alias, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("directory links require unavailable host privileges")
    try:
        with pytest.raises(ConfigurationError, match="cannot point inside .zerorun"):
            FingerprintSession(tmp_path).expand_inputs(
                tmp_path,
                ("state-alias/missing.json",),
            )
    finally:
        alias.unlink(missing_ok=True)
