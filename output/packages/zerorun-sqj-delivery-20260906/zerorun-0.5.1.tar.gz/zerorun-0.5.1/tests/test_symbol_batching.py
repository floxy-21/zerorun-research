from __future__ import annotations

import ast
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from zerorun import fingerprint as fingerprint_module
from zerorun import hermetic_key
from zerorun.hermetic_key import FingerprintSession, task_fingerprint_v2
from zerorun.manifest import load_manifest
from zerorun.oci import hermetic_environment


IMAGE = "example.invalid/python@sha256:" + "a" * 64
RUNTIME = {
    "runtime": "docker",
    "requested_image": IMAGE,
    "requested_digest": "sha256:" + "a" * 64,
    "platform": "linux/amd64",
    "image_id": "sha256:" + "b" * 64,
    "repo_digests": [IMAGE],
    "rootfs": {"type": "layers", "layers": ["sha256:" + "c" * 64]},
    "config_sha256": "d" * 64,
}


class SymbolBatchingTests(unittest.TestCase):
    def _make_manifest(self, source: str, selectors: list[str]):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "bootstrap.txt").write_text("stable\n", encoding="utf-8")
        (root / "module.py").write_text(source, encoding="utf-8")
        manifest_path = root / ".zerorun.json"
        manifest_path.write_text(
            json.dumps(
                {
                    "version": 2,
                    "tasks": {
                        "work": {
                            "command": ["python", "-c", "pass"],
                            "inputs": ["bootstrap.txt"],
                            "input_symbols": selectors,
                            "outputs": [],
                            "cacheable": True,
                            "unsafe_effects": [],
                            "env": [],
                            "cache_streams": False,
                            "result_only": True,
                            "closure_reviewed": True,
                            "image": IMAGE,
                            "platform": "linux/amd64",
                        }
                    },
                }
            ),
            encoding="utf-8",
        )
        return root, load_manifest(manifest_path)

    def _fingerprint(self, manifest) -> str:
        task = manifest.tasks["work"]
        _, env_fp = hermetic_environment(task)
        return task_fingerprint_v2(
            manifest,
            task,
            RUNTIME,
            environment_fingerprint=env_fp,
        )[0]

    def test_multiple_selectors_parse_and_index_each_file_once(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "bootstrap.txt").write_text("stable\n", encoding="utf-8")
        (root / "module.py").write_text(
            "VALUE = 1\n\n"
            "def first():\n"
            "    return VALUE\n\n"
            "def second():\n"
            "    return VALUE + 1\n",
            encoding="utf-8",
        )
        manifest_path = root / ".zerorun.json"
        manifest_path.write_text(
            json.dumps(
                {
                    "version": 2,
                    "tasks": {
                        "work": {
                            "command": ["python", "-c", "pass"],
                            "inputs": ["bootstrap.txt"],
                            "input_symbols": [
                                "module.py::@module-state",
                                "module.py::@binding:VALUE",
                                "module.py::first",
                                "module.py::second",
                            ],
                            "outputs": [],
                            "cacheable": True,
                            "unsafe_effects": [],
                            "env": [],
                            "cache_streams": False,
                            "result_only": True,
                            "closure_reviewed": True,
                            "image": IMAGE,
                            "platform": "linux/amd64",
                        }
                    },
                }
            ),
            encoding="utf-8",
        )
        manifest = load_manifest(manifest_path)
        task = manifest.tasks["work"]
        _, env_fp = hermetic_environment(task)

        real_parse = ast.parse
        real_binding_index = hermetic_key._binding_index
        with patch("zerorun.hermetic_key.ast.parse", wraps=real_parse) as parse, patch(
            "zerorun.hermetic_key._binding_index", wraps=real_binding_index
        ) as binding_index:
            _, fingerprint = task_fingerprint_v2(
                manifest,
                task,
                RUNTIME,
                environment_fingerprint=env_fp,
            )

        self.assertEqual(parse.call_count, 1)
        self.assertEqual(binding_index.call_count, 1)
        self.assertEqual(len(fingerprint["input_symbols"]), 4)
        self.assertEqual({row["path"] for row in fingerprint["input_symbols"]}, {"module.py"})
        self.assertFalse(any("start_line" in row for row in fingerprint["input_symbols"]))
        self.assertFalse(any("end_line" in row for row in fingerprint["input_symbols"]))

    def test_unrelated_line_shift_does_not_change_symbol_action_key(self) -> None:
        root, manifest = self._make_manifest(
            "def chosen():\n"
            "    return 1\n\n"
            "def unrelated():\n"
            "    return 2\n",
            ["module.py::chosen"],
        )
        before = self._fingerprint(manifest)
        source = root / "module.py"
        source.write_text(
            "# unrelated leading comment\n\n" + source.read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        self.assertEqual(before, self._fingerprint(manifest))
        source.write_text(
            source.read_text(encoding="utf-8").replace("return 1", "return 3"),
            encoding="utf-8",
        )
        self.assertNotEqual(before, self._fingerprint(manifest))

    def test_multidefinition_key_uses_ordered_content_not_source_lines(self) -> None:
        source_text = (
            "from typing import overload\n\n"
            "@overload\n"
            "def chosen(value: int) -> int: ...\n\n"
            "def chosen(value):\n"
            "    return value\n"
        )
        root, manifest = self._make_manifest(source_text, ["module.py::chosen"])
        before = self._fingerprint(manifest)
        source = root / "module.py"
        source.write_text(
            "# shift every definition\n\n" + source.read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        self.assertEqual(before, self._fingerprint(manifest))
        source.write_text(
            source.read_text(encoding="utf-8").replace("value: int", "value: str"),
            encoding="utf-8",
        )
        self.assertNotEqual(before, self._fingerprint(manifest))

    def test_snapshot_session_reuses_file_hashes_and_symbol_parses_across_tasks(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "bootstrap.txt").write_text("stable\n", encoding="utf-8")
        (root / "module.py").write_text(
            "VALUE = 1\n\n"
            "def work():\n"
            "    return VALUE\n",
            encoding="utf-8",
        )
        common = {
            "inputs": ["bootstrap.txt"],
            "input_symbols": ["module.py::@binding:VALUE", "module.py::work"],
            "outputs": [],
            "cacheable": True,
            "unsafe_effects": [],
            "env": [],
            "cache_streams": False,
            "result_only": True,
            "closure_reviewed": True,
            "image": IMAGE,
            "platform": "linux/amd64",
        }
        manifest_path = root / ".zerorun.json"
        manifest_path.write_text(
            json.dumps(
                {
                    "version": 2,
                    "tasks": {
                        "first": {"command": ["python", "-c", "pass"], **common},
                        "second": {"command": ["python", "-c", "pass # two"], **common},
                    },
                }
            ),
            encoding="utf-8",
        )
        manifest = load_manifest(manifest_path)
        session = FingerprintSession(root)
        real_parse = ast.parse

        with patch("zerorun.hermetic_key.ast.parse", wraps=real_parse) as parse, patch(
            "zerorun.fingerprint.sha256_file", wraps=fingerprint_module.sha256_file
        ) as sha256:
            for task in manifest.tasks.values():
                _, env_fp = hermetic_environment(task)
                task_fingerprint_v2(
                    manifest,
                    task,
                    RUNTIME,
                    environment_fingerprint=env_fp,
                    session=session,
                )

        self.assertEqual(parse.call_count, 1)
        self.assertEqual(sha256.call_count, 1)


if __name__ == "__main__":
    unittest.main()
