from __future__ import annotations

from tools.pytest_incremental_collection import classify_incremental_collection


def _row(nodeid: str, identity: str, *, supported: bool = True):
    return {
        "nodeid": nodeid,
        "identity_sha256": identity * 64,
        "parameter_identity_supported": supported,
    }


def _payload(*rows):
    return {
        "nodeids": [row["nodeid"] for row in rows],
        "items": list(rows),
    }


def test_additive_collection_runs_only_new_node_fresh() -> None:
    baseline = _payload(_row("a", "a"), _row("b", "b"))
    current = _payload(_row("a", "a"), _row("b", "b"), _row("c", "c"))
    result = classify_incremental_collection(baseline, current)
    assert result["safe_incremental"] is True
    assert result["fresh_current_nodes"] == ["c"]
    assert result["reusable_existing_nodes"] == ["a", "b"]


def test_changed_identity_runs_only_changed_node_fresh() -> None:
    baseline = _payload(_row("a", "a"), _row("b", "b"))
    current = _payload(_row("a", "c"), _row("b", "b"))
    result = classify_incremental_collection(baseline, current)
    assert result["safe_incremental"] is True
    assert result["fresh_current_nodes"] == ["a"]
    assert result["reusable_existing_nodes"] == ["b"]


def test_removed_node_is_not_requested_and_retained_nodes_can_match() -> None:
    baseline = _payload(_row("a", "a"), _row("b", "b"), _row("c", "c"))
    current = _payload(_row("a", "a"), _row("c", "c"))
    result = classify_incremental_collection(baseline, current)
    assert result["safe_incremental"] is True
    assert result["removed_nodes"] == ["b"]
    assert result["fresh_current_nodes"] == []
    assert result["reusable_existing_nodes"] == ["a", "c"]


def test_unsupported_parameter_identity_runs_fresh() -> None:
    baseline = _payload(_row("a", "a"))
    current = _payload(_row("a", "a", supported=False))
    result = classify_incremental_collection(baseline, current)
    assert result["safe_incremental"] is True
    assert result["fresh_current_nodes"] == ["a"]
    assert result["reusable_existing_nodes"] == []


def test_relative_reorder_fails_closed() -> None:
    baseline = _payload(_row("a", "a"), _row("b", "b"), _row("c", "c"))
    current = _payload(_row("b", "b"), _row("a", "a"), _row("c", "c"))
    result = classify_incremental_collection(baseline, current)
    assert result["safe_incremental"] is False
    assert result["retained_order_equal"] is False
    assert result["reason"] == "retained node order changed"
