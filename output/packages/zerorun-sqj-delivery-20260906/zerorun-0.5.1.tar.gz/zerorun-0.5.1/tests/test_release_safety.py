import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import textwrap
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import pytest


ROOT = Path(__file__).resolve().parents[1]
WORKFLOWS = ROOT / ".github" / "workflows"
HISTORICAL_WORKFLOWS = ROOT / "docs" / "history" / "workflows"

LIVE_WORKFLOWS = {
    "codex-full-product-retest.yml",
    "commercial-100-repo-smoke.yml",
    "pilot-package.yml",
}

DELETED_OPERATIONAL_WORKFLOWS = {
    "actions-cleanup-v2.yml",
    "force-clear-actions-once.yml",
    "launch-external-after-gate-recovery.yml",
    "zerorun-v040-fastpath-branch-validation.yml",
    "zerorun-v040-postfix-closure-review.yml",
}

PINNED_ACTIONS = {
    "actions/checkout": ("de0fac2e4500dabe0009e67214ff5f5447ce83dd", "v6.0.2"),
    "actions/setup-python": ("a309ff8b426b58ec0e2a45f0f869d46889d02405", "v6.2.0"),
    "actions/upload-artifact": ("043fb46d1a93c77aae656e7c1c64a875d1fc6a0a", "v7.0.1"),
    "actions/download-artifact": ("3e5f45b2cfb9172054b4087a40e8e0b5a5461e7c", "v8.0.1"),
}


def _automatic_events(path: Path) -> set[str]:
    lines = path.read_text(encoding="utf-8").splitlines()
    start = lines.index("on:") + 1
    events: set[str] = set()
    for line in lines[start:]:
        if line and not line[0].isspace():
            break
        match = re.fullmatch(r"  ([a-z_]+):", line)
        if match and match.group(1) != "workflow_dispatch":
            events.add(match.group(1))
    return events


def test_only_current_gates_and_exact_tag_publisher_run_automatically() -> None:
    automatic = {
        path.name: _automatic_events(path)
        for path in sorted(WORKFLOWS.glob("*.y*ml"))
        if _automatic_events(path)
    }
    assert automatic == {
        "codex-full-product-retest.yml": {"push"},
        "commercial-100-repo-smoke.yml": {"push"},
        "pilot-package.yml": {"push"},
    }
    for name in (
        "codex-full-product-retest.yml",
        "commercial-100-repo-smoke.yml",
    ):
        text = (WORKFLOWS / name).read_text(encoding="utf-8")
        assert "branches: [main]" in text
        assert "\n    paths:" not in text
        assert "pull_request:" not in text
        assert "workflow_run:" not in text
    pilot = (WORKFLOWS / "pilot-package.yml").read_text(encoding="utf-8")
    assert 'tags:\n      - "v*"' in pilot
    assert "branches:" not in pilot
    assert "pull_request:" not in pilot
    assert "workflow_run:" not in pilot


def test_live_workflow_surface_is_minimal_and_least_privilege() -> None:
    live = {path.name for path in WORKFLOWS.glob("*.y*ml")}
    assert live == LIVE_WORKFLOWS

    for name in sorted(LIVE_WORKFLOWS):
        text = (WORKFLOWS / name).read_text(encoding="utf-8")
        jobs = text.index("\njobs:")
        top_level = text[:jobs]
        assert "permissions:\n  contents: read" in top_level, name
        assert "contents: write" not in top_level, name
        assert "actions: write" not in text, name
        assert "id-token: write" not in text, name
        assert "pull-requests: write" not in text, name

        if name == "pilot-package.yml":
            assert text.count("contents: write") == 1
        else:
            assert "contents: write" not in text, name

    archived = {
        path.name for path in HISTORICAL_WORKFLOWS.glob("*.y*ml")
    }
    assert len(archived) == 42
    assert live.isdisjoint(archived)
    assert DELETED_OPERATIONAL_WORKFLOWS.isdisjoint(archived)
    assert all(not (WORKFLOWS / name).exists() for name in DELETED_OPERATIONAL_WORKFLOWS)


def test_controlled_release_operations_are_explicit_and_non_deceptive() -> None:
    operations = (ROOT / "commercial" / "OPERATIONS.md").read_text(encoding="utf-8")
    assert "Jishan Kapoor" in operations
    assert "best effort" in operations
    assert "No response-time" in operations
    assert "no product telemetry" in operations
    assert "## Backup, rollback, and uninstall" in operations
    assert "## Incident response" in operations
    assert "do not use broad recursive deletion commands" in operations
    assert "current `LICENSE.txt` grants MIT open-source rights" in operations
    assert "Commercial demand remains unproven" in operations


def test_handoff_tracks_the_current_candidate_and_live_workflow_surface() -> None:
    handoff = (ROOT / "HANDOFF.md").read_text(encoding="utf-8")
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    match = re.search(r'(?m)^version = "([^"]+)"$', pyproject)
    assert match is not None
    version = match.group(1)

    assert f"Declared package and module version: `{version}`." in handoff
    assert (
        f"live actions surface contains exactly {len(LIVE_WORKFLOWS)} workflows"
        in handoff.lower()
    )
    assert "33947883320" not in handoff
    assert "1c678bbc2333e3d72870efd1a1d4b6560b6d7834" not in handoff
    assert "the other 46 are manual-only" not in handoff
    assert "matching CLI/import/MCP version `0.5.0`" not in handoff


def test_no_release_workflow_can_clobber_an_existing_asset() -> None:
    offenders = [
        path.relative_to(ROOT).as_posix()
        for path in sorted(WORKFLOWS.glob("*.y*ml"))
        if "--clobber" in path.read_text(encoding="utf-8")
    ]
    assert offenders == []


def test_candidate_release_publish_is_exact_tag_automatic_and_non_clobbering() -> None:
    workflow = WORKFLOWS / "pilot-package.yml"
    text = workflow.read_text(encoding="utf-8")
    assert "workflow_dispatch:" in text
    assert "push:" in text
    assert 'tags:\n      - "v*"' in text
    assert 'test "$GITHUB_REF_TYPE" = "tag"' in text
    assert 'test "$GITHUB_REF_NAME" = "v$version"' in text
    assert 'git cat-file -t "refs/tags/$GITHUB_REF_NAME"' in text
    assert "fetch-depth: 0" in text
    assert 'git rev-parse refs/remotes/origin/main' in text
    assert text.count("environment: zerorun-release") == 2
    assert "import zerorun" not in text
    assert "gh release upload" in text
    assert "gh release create" in text
    assert "gh release download" in text
    assert "gh release edit" in text
    assert "repos/$GITHUB_REPOSITORY/releases/tags/$GITHUB_REF_NAME" in text
    assert 'cmp --silent "$asset" "$verify_dir/$asset"' in text
    assert "--verify-tag" in text
    assert "--draft" in text
    assert "--notes-file" in text
    assert "--target \"$EXPECTED_SHA\"" in text
    assert "--draft=false" in text
    assert "--latest=false" in text
    assert "--clobber" not in text
    assert "permissions:\n  contents: read" in text
    assert "persist-credentials: false" in text
    assert "publish-release:" in text
    assert "needs: verify-qualified-candidate" in text
    assert "github.event_name == 'push' || inputs.publish_release" in text
    assert "cancel-in-progress: false" in text
    publish = text.index("  publish-release:")
    assert text.index("contents: write") > publish
    assert text.count("contents: write") == 1
    assert "actions: read" in text
    assert 'FULL_PRODUCT_WORKFLOW_ID: "349726112"' in text
    assert 'COMMERCIAL_WORKFLOW_ID: "350720517"' in text
    assert "head_sha=\"$RELEASE_SHA\"" in text
    assert 'run.get("event") != "push"' in text
    assert 'run.get("conclusion") != "success"' in text
    assert "expected exactly one logical push run" in text
    assert "product-generalization-five-repo-receipt" in text
    assert "commercial-100-repository-result" in text
    assert "zerorun-commercial-candidate-$RELEASE_SHA" in text
    assert "python -m tools.validate_release_prerequisites" in text
    assert "build_pilot_package.sh" not in text
    assert "smoke_pilot_package.sh" not in text
    assert "release-prerequisites.json" in text
    assert "SHA256SUMS.txt" in text
    assert "qualified release bundle has missing or unexpected entries" in text
    assert "release contains duplicate or unexpected assets" in text
    assert "release metadata differs from the qualified release declaration" in text
    assert "release is missing a required qualified asset" in text
    assert "SHA256SUMS.txt does not name every exact release asset" in text
    assert "release must remain a draft until asset verification completes" in text
    assert "release was not published after verification" in text
    assert "published release is not immutable" in text


def test_release_prerequisite_validator_uses_package_safe_module_invocation() -> None:
    text = (WORKFLOWS / "pilot-package.yml").read_text(encoding="utf-8")
    assert "python -m tools.validate_release_prerequisites" in text
    assert "python tools/validate_release_prerequisites.py" not in text
    assert 'grep -Fq "HTTP 404" "$release_error"' in text
    assert "revalidate_remote_identity immediately-before-draft-create" in text
    assert "revalidate_remote_identity immediately-after-draft-create" in text
    assert "revalidate_remote_identity immediately-before-asset-upload" in text
    assert "revalidate_remote_identity immediately-after-asset-upload" in text
    assert "revalidate_remote_identity immediately-before-publish" in text
    assert "revalidate_remote_identity immediately-after-publish" in text
    assert "revalidate_remote_identity final-post-verification" in text
    assert 'tag_ref.get("object", {}).get("type") != "tag"' in text
    assert 'tag_object.get("object", {}).get("type") != "commit"' in text
    assert 'tag_object.get("object", {}).get("sha") != expected_sha' in text
    assert 'main_ref.get("object", {}).get("sha") != expected_sha' in text
    assert "if digest != expected_digest:" in text
    assert text.count("verify_downloaded_assets") == 3


def test_full_product_workflow_does_not_persist_checkout_credentials_and_requires_evidence() -> None:
    text = (WORKFLOWS / "codex-full-product-retest.yml").read_text(
        encoding="utf-8"
    )
    checkout_count = text.count("uses: actions/checkout@")
    assert checkout_count == 4
    assert text.count("persist-credentials: false") == checkout_count
    assert "timeout-minutes: 90" in text
    assert "Require every transport evidence file before upload" in text
    assert '"codex_exec_invoked": False' in text
    assert '"real_codex_agent_executed": False' in text
    for path in (
        "$RUNNER_TEMP/codex-install-receipt.json",
        "$RUNNER_TEMP/codex-install-aggregate.json",
        "$RUNNER_TEMP/developer-repo/prepare-result.json",
        "$RUNNER_TEMP/unauthorized-lifecycle.json",
        "$RUNNER_TEMP/direct-pytest.txt",
    ):
        assert path in text
    assert 'test -f "$evidence"' in text
    assert 'test -s "$evidence"' in text
    assert text.count("if-no-files-found: error") == 3


def _embedded_python_after(marker: str) -> str:
    text = (WORKFLOWS / "pilot-package.yml").read_text(encoding="utf-8")
    start = text.index("<<'PY'", text.index(marker)) + len("<<'PY'")
    start = text.index("\n", start) + 1
    end = text.index("\n          PY\n", start)
    lines = text[start:end].splitlines()
    assert lines and all(not line or line.startswith("          ") for line in lines)
    return "\n".join(line[10:] if line else "" for line in lines) + "\n"


def _embedded_release_validator() -> str:
    return _embedded_python_after(
        'release_validator="$RUNNER_TEMP/validate-release.py"'
    )


def test_embedded_remote_identity_validator_requires_annotated_tag_and_exact_main(
    tmp_path: Path,
) -> None:
    expected_sha = "a" * 40
    tag_object_sha = "b" * 40
    payloads = {
        "tag-ref.json": {
            "ref": "refs/tags/v0.5.1",
            "object": {"type": "tag", "sha": tag_object_sha},
        },
        "main-ref.json": {
            "ref": "refs/heads/main",
            "object": {"type": "commit", "sha": expected_sha},
        },
        "tag-object.json": {
            "sha": tag_object_sha,
            "tag": "v0.5.1",
            "object": {"type": "commit", "sha": expected_sha},
        },
    }
    for name, payload in payloads.items():
        (tmp_path / name).write_text(
            json.dumps(payload, sort_keys=True) + "\n", encoding="utf-8"
        )
    validator = tmp_path / "validate-remote-identity.py"
    validator.write_text(
        _embedded_python_after('"$identity_dir/tag-object.json" <<\'PY\''),
        encoding="utf-8",
    )
    environment = {
        **os.environ,
        "GITHUB_REF_NAME": "v0.5.1",
        "EXPECTED_SHA": expected_sha,
    }

    def validate() -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [
                sys.executable,
                str(validator),
                str(tmp_path / "tag-ref.json"),
                str(tmp_path / "main-ref.json"),
                str(tmp_path / "tag-object.json"),
            ],
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=20,
            check=False,
        )

    assert validate().returncode == 0

    payloads["tag-ref.json"]["object"]["type"] = "commit"
    (tmp_path / "tag-ref.json").write_text(
        json.dumps(payloads["tag-ref.json"]) + "\n", encoding="utf-8"
    )
    result = validate()
    assert result.returncode != 0
    assert "not the expected annotated tag" in result.stderr

    payloads["tag-ref.json"]["object"]["type"] = "tag"
    (tmp_path / "tag-ref.json").write_text(
        json.dumps(payloads["tag-ref.json"]) + "\n", encoding="utf-8"
    )
    payloads["main-ref.json"]["object"]["sha"] = "c" * 40
    (tmp_path / "main-ref.json").write_text(
        json.dumps(payloads["main-ref.json"]) + "\n", encoding="utf-8"
    )
    result = validate()
    assert result.returncode != 0
    assert "remote main no longer names" in result.stderr


def test_embedded_release_validator_accepts_only_exact_metadata_and_assets(
    tmp_path: Path,
) -> None:
    version = "0.5.1"
    names = {
        f"zerorun-{version}-py3-none-any.whl",
        f"zerorun-{version}.tar.gz",
        "package-receipt.json",
        "product-generalization-five-repo-receipt.json",
        "commercial-100-repository-result.json",
        "release-prerequisites.json",
        "SHA256SUMS.txt",
    }
    local = tmp_path / "bundle"
    local.mkdir()
    for index, name in enumerate(sorted(names), start=1):
        (local / name).write_bytes(f"qualified-{index}-{name}\n".encode())
    notes = tmp_path / "notes.txt"
    notes.write_text("bounded release evidence\n", encoding="utf-8")
    expected_sha = "a" * 40
    release = {
        "id": 42,
        "tag_name": f"v{version}",
        "target_commitish": expected_sha,
        "name": f"ZeroRun v{version}",
        "body": notes.read_text(encoding="utf-8"),
        "draft": True,
        "prerelease": False,
        "immutable": False,
        "created_at": "2026-09-05T00:00:00Z",
        "published_at": None,
        "assets": [
            {
                "id": index,
                "name": name,
                "label": None,
                "state": "uploaded",
                "size": (local / name).stat().st_size,
                "digest": "sha256:" + hashlib.sha256((local / name).read_bytes()).hexdigest(),
            }
            for index, name in enumerate(sorted(names), start=1)
        ],
    }
    receipt = tmp_path / "release.json"
    validator = tmp_path / "validate-release.py"
    validator.write_text(_embedded_release_validator(), encoding="utf-8")
    environment = {
        **os.environ,
        "GITHUB_REF_NAME": f"v{version}",
        "EXPECTED_SHA": expected_sha,
        "EXPECTED_VERSION": version,
    }

    def validate(
        candidate: dict[str, object], *, draft_mode: str = "draft"
    ) -> subprocess.CompletedProcess[str]:
        receipt.write_text(
            json.dumps(candidate, sort_keys=True) + "\n", encoding="utf-8"
        )
        return subprocess.run(
            [
                sys.executable,
                str(validator),
                str(receipt),
                str(notes),
                draft_mode,
                "exact",
                str(local),
            ],
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=20,
            check=False,
        )

    assert validate(release).returncode == 0

    published = json.loads(json.dumps(release))
    published["draft"] = False
    published["immutable"] = True
    published["published_at"] = "2026-09-05T00:01:00Z"
    assert validate(published, draft_mode="published").returncode == 0

    mutable_published = json.loads(json.dumps(published))
    mutable_published["immutable"] = False
    result = validate(mutable_published, draft_mode="published")
    assert result.returncode != 0
    assert "published release is not immutable" in result.stderr

    wrong_commit = json.loads(json.dumps(release))
    wrong_commit["target_commitish"] = "b" * 40
    result = validate(wrong_commit)
    assert result.returncode != 0
    assert "metadata differs" in result.stderr

    wrong_digest = json.loads(json.dumps(release))
    wrong_digest["assets"][0]["digest"] = "sha256:" + "0" * 64
    result = validate(wrong_digest)
    assert result.returncode != 0
    assert "digest mismatch" in result.stderr

    unexpected = json.loads(json.dumps(release))
    unexpected["assets"].append(
        {
            "id": 999,
            "name": "unexpected.bin",
            "label": None,
            "state": "uploaded",
            "size": 1,
            "digest": "sha256:" + "0" * 64,
        }
    )
    result = validate(unexpected)
    assert result.returncode != 0
    assert "unexpected assets" in result.stderr


def test_all_github_actions_are_pinned_to_reviewed_commits() -> None:
    seen = {name: 0 for name in PINNED_ACTIONS}
    action_pattern = re.compile(r"uses:\s*(actions/[a-z-]+)@([^\s#]+)(?:\s*#\s*(\S+))?")
    for workflow in sorted(WORKFLOWS.glob("*.y*ml")):
        text = workflow.read_text(encoding="utf-8")
        for name, reference, comment in action_pattern.findall(text):
            expected_sha, expected_version = PINNED_ACTIONS[name]
            assert reference == expected_sha, (workflow.name, name, reference)
            assert comment == expected_version, (workflow.name, name, comment)
            seen[name] += 1
    assert all(count > 0 for count in seen.values()), seen


def test_pull_request_code_never_runs_on_persistent_self_hosted_workers() -> None:
    offenders = []
    for workflow in sorted(WORKFLOWS.glob("*.y*ml")):
        text = workflow.read_text(encoding="utf-8")
        if "pull_request:" in text and re.search(
            r"runs-on:\s*(?:\[\s*)?self-hosted", text
        ):
            offenders.append(workflow.name)
    assert offenders == []


def test_every_self_hosted_job_has_an_explicit_trusted_ref_guard() -> None:
    count = 0
    for workflow in sorted(WORKFLOWS.glob("*.y*ml")):
        lines = workflow.read_text(encoding="utf-8").splitlines()
        current_job = None
        current_if = ""
        for line in lines:
            job = re.fullmatch(r"  ([A-Za-z0-9_-]+):", line)
            if job:
                current_job = job.group(1)
                current_if = ""
            elif line.startswith("    if: "):
                current_if = line.removeprefix("    if: ")
            elif re.match(r"    runs-on:\s*\[self-hosted", line):
                count += 1
                if workflow.name == "pilot-package.yml":
                    assert "startsWith(github.ref, 'refs/tags/v')" in current_if
                else:
                    assert "github.ref == 'refs/heads/main'" in current_if, (
                        workflow.name,
                        current_job,
                        current_if,
                    )
        if "self-hosted" in "\n".join(lines):
            branch_lines = [line.strip() for line in lines if "branches:" in line]
            assert all("[main]" in line for line in branch_lines), (
                workflow.name,
                branch_lines,
            )
    assert not (WORKFLOWS / "zerorun-v040-standalone-branch-package.yml").exists()


def test_release_build_tooling_and_archives_are_version_locked() -> None:
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    pilot_requirements = (ROOT / "pilot" / "build-requirements.txt").read_text(
        encoding="utf-8"
    )
    build_script = (ROOT / "tools" / "build_pilot_package.sh").read_text(
        encoding="utf-8"
    )
    release_workflow = (WORKFLOWS / "pilot-package.yml").read_text(encoding="utf-8")
    commercial_workflow = (WORKFLOWS / "commercial-100-repo-smoke.yml").read_text(
        encoding="utf-8"
    )
    assert 'requires = ["setuptools==84.0.0"]' in pyproject
    assert 'license = "MIT"' in pyproject
    assert 'license-files = ["LICENSE.txt"]' in pyproject
    constraints = (ROOT / "ci" / "release-constraints.txt").read_text(
        encoding="utf-8"
    )
    assert "setuptools==84.0.0" in constraints
    assert "build==1.6.0" in constraints
    assert "pytest==9.1.1" in constraints
    assert "pip==26.2.1" in constraints
    assert "pytest==9.1.1" in pilot_requirements
    assert "Nuitka==4.2" in pilot_requirements
    assert "zstandard==0.25.0" in pilot_requirements
    assert "--only-binary=:all:" in pilot_requirements
    assert "--no-binary=Nuitka" in pilot_requirements

    locked_files = [
        ROOT / "ci" / "release-bootstrap-requirements.txt",
        ROOT / "ci" / "release-build-requirements.txt",
        ROOT / "ci" / "release-test-requirements.txt",
        ROOT / "ci" / "generalization-runtime-requirements.txt",
        ROOT / "pilot" / "build-requirements.txt",
    ]
    for path in locked_files:
        locked = path.read_text(encoding="utf-8")
        lines = locked.splitlines()
        requirements = [
            (index, line)
            for index, line in enumerate(lines)
            if line and not line.startswith(("#", " ", "--"))
        ]
        assert requirements, path
        assert all("==" in line and line.endswith("\\") for _, line in requirements)
        for position, (line_index, requirement) in enumerate(requirements):
            next_index = (
                requirements[position + 1][0]
                if position + 1 < len(requirements)
                else len(lines)
            )
            block = "\n".join(lines[line_index:next_index])
            hashes = re.findall(r"--hash=sha256:([0-9a-f]{64})", block)
            assert hashes, (path, requirement)

    expected_constraints: dict[str, str] = {}
    for path in locked_files:
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line or line.startswith(("#", " ", "--")):
                continue
            pin = line.removesuffix("\\").split(";", 1)[0].strip()
            name, version = pin.split("==", 1)
            prior = expected_constraints.setdefault(name.lower(), version)
            assert prior == version, (name, prior, version)
    actual_constraints = {}
    for line in constraints.splitlines():
        if not line or line.startswith("#"):
            continue
        name, version = line.split("==", 1)
        actual_constraints[name.lower()] = version
    assert actual_constraints == expected_constraints

    release_test_lock = (ROOT / "ci" / "release-test-requirements.txt").read_text(
        encoding="utf-8"
    )
    assert 'colorama==0.4.6 ; sys_platform == "win32" \\' in release_test_lock
    assert (
        "--hash=sha256:4f1d9991f5acc0ca119f9d443620b77f9d6b33703e51011c16baf57afb285fc6"
        in release_test_lock
    )
    assert "jsonschema==4.26.0 \\" in release_test_lock
    rpds_block = release_test_lock.split("rpds-py==0.30.0 \\", 1)[1].split(
        "tomli==", 1
    )[0]
    assert len(re.findall(r"--hash=sha256:([0-9a-f]{64})", rpds_block)) == 10
    assert 'typing-extensions==4.16.0 ; python_version < "3.13" \\' in release_test_lock
    assert commercial_workflow.count("--require-hashes") == 3
    assert "--no-build-isolation" in commercial_workflow
    assert '"schema": "zerorun.release-package.v1"' in commercial_workflow
    assert "package-receipt.json" in commercial_workflow
    assert "build_pilot_package.sh" not in release_workflow
    for marker in (
        "SOURCE_DATE_EPOCH",
        "PYTHONHASHSEED=0",
        "NUITKA_UPDATE_CHECK=never",
        "refusing a pilot release build from a dirty Git checkout",
        "ZERORUN_ALLOW_DIRTY_BUILD",
        "--disable-ccache",
        "--sort=name",
        "--numeric-owner",
        "gzip -n",
    ):
        assert marker in build_script
    assert "--assume-yes-for-downloads" not in build_script

    attributes = (ROOT / ".gitattributes").read_text(encoding="utf-8")
    assert "*.sh text eol=lf" in attributes
    assert ".github/workflows/*.yml text eol=lf" in attributes
    assert (ROOT / "MANIFEST.in").read_text(encoding="utf-8") == (
        "recursive-include tests *.py\n"
    )


def test_active_codex_and_commercial_tools_are_exactly_versioned() -> None:
    commercial = (WORKFLOWS / "commercial-100-repo-smoke.yml").read_text(
        encoding="utf-8"
    )
    full_retest = (WORKFLOWS / "codex-full-product-retest.yml").read_text(
        encoding="utf-8"
    )
    assert commercial.count("--require-hashes") == 3
    assert "ci/release-bootstrap-requirements.txt" in commercial
    assert "ci/release-build-requirements.txt" in commercial
    assert commercial.count("python -m build --no-isolation --outdir") == 2
    assert commercial.count("tools/normalize_sdist.py") == 2
    assert "git -c tar.umask=0022 archive" in commercial
    assert "export SOURCE_DATE_EPOCH=" in commercial
    assert "export PYTHONHASHSEED=0" in commercial
    assert "export TZ=UTC" in commercial
    assert "export LC_ALL=C.UTF-8" in commercial
    assert 'cmp "$RUNNER_TEMP/dist-1/"*.whl' in commercial
    assert 'cmp "$RUNNER_TEMP/dist-1/"*.tar.gz' in commercial
    assert "from tools.validate_release_prerequisites import (" in commercial
    assert "_validate_package(" in commercial
    assert 'candidate_sha=os.environ["GITHUB_SHA"]' in commercial
    assert 'python -m pip install --no-deps candidate/*.whl' in commercial
    assert 'python "$GITHUB_WORKSPACE/tools/commercial_repo_smoke.py"' in commercial
    assert "Path(sys.prefix).resolve()" in commercial
    assert "--no-build-isolation --no-deps" in commercial
    assert "assert len(tools) == 7" in commercial
    for tool_name in (
        "prepare_pytest",
        "run_pytest",
        "run_tests",
        "stats",
        "explain",
        "doctor",
        "list_tasks",
    ):
        assert f'"{tool_name}",' in commercial
    assert "needs: package-reproducibility" in commercial
    assert "needs: [package-reproducibility, smoke]" in commercial
    assert "zerorun-commercial-candidate-${{ github.sha }}" in commercial
    assert '"build_provenance": provenance' in commercial
    assert '"wheel_vs_sdist_exact": True' in commercial
    assert '"module_source_bytes_exact": True' in commercial
    assert '"metadata_semantics_exact": True' in commercial
    assert '"entry_points_exact": True' in commercial
    assert commercial.count('python-version: "3.12.13"') == 3
    assert full_retest.count("--require-hashes") >= 4
    assert "ci/release-test-requirements.txt" in full_retest
    assert "--no-build-isolation --no-deps ." in full_retest
    assert full_retest.count('python-version: "3.12.13"') == 2
    verified_installer = (ROOT / "tools" / "install_verified_codex_cli.py").read_text(
        encoding="utf-8"
    )
    for workflow_text in (commercial, full_retest):
        assert "CODEX_NPM_INTEGRITY:" in workflow_text
        assert "CODEX_LINUX_X64_NPM_INTEGRITY:" in workflow_text
        assert "tools/install_verified_codex_cli.py" in workflow_text
        assert "--main-integrity \"$CODEX_NPM_INTEGRITY\"" in workflow_text
        assert "--linux-x64-integrity \"$CODEX_LINUX_X64_NPM_INTEGRITY\"" in workflow_text
        assert "codex-install" in workflow_text
        assert '--source-commit "$GITHUB_SHA"' in workflow_text
        assert "tools.aggregate_codex_install_evidence" in workflow_text
        assert "npm view" not in workflow_text

    mutable_codex_installs = []
    for workflow in sorted(WORKFLOWS.glob("*.y*ml")):
        for line in workflow.read_text(encoding="utf-8").splitlines():
            if re.search(r"\bnpm install\b", line) and "@openai/codex" in line:
                mutable_codex_installs.append((workflow.name, line.strip()))
    assert mutable_codex_installs == []

    assert 'REGISTRY_ORIGIN = "https://registry.npmjs.org"' in verified_installer
    assert "_verify_sri(main_archive, main_integrity)" in verified_installer
    assert "_verify_sri(platform_archive, platform_integrity)" in verified_installer
    assert verified_installer.count("_extract_authenticated_files(") >= 3
    assert "installed package tree differs from authenticated archive bytes" in verified_installer
    assert '_runtime_identity("npm")' not in verified_installer
    assert '_runtime_file_identity("npm")' not in verified_installer
    assert '"package_manager_invoked": False' in verified_installer
    assert '"installation_method": "direct-authenticated-archive-extraction"' in verified_installer
    assert '"subprocesses_after_integrity_verification": 0' in verified_installer
    assert '"network_operations_after_integrity_verification": 0' in verified_installer
    assert '"network_after_integrity_verification": False' in verified_installer
    assert "tools.aggregate_codex_install_evidence" in commercial
    assert 'assert installs["receipt_count"] == 10' in commercial


def test_all_active_workflow_python_heredocs_compile() -> None:
    pattern = re.compile(
        r"(?ms)^([ ]+).*?python(?:3)?(?: [^\n]*)? - <<'PY'\r?\n(.*?)^\1PY\r?$"
    )
    counts = {}
    for workflow in sorted(WORKFLOWS.glob("*.yml")):
        blocks = pattern.findall(workflow.read_text(encoding="utf-8"))
        for index, (_, body) in enumerate(blocks):
            compile(
                textwrap.dedent(body),
                f"{workflow.name}:python-heredoc-{index}",
                "exec",
            )
        counts[workflow.name] = len(blocks)
    assert counts["commercial-100-repo-smoke.yml"] >= 6
    assert counts["codex-full-product-retest.yml"] >= 7


def test_live_codex_workflow_proves_refusal_without_self_authorizing() -> None:
    workflow = (WORKFLOWS / "codex-full-product-retest.yml").read_text(
        encoding="utf-8"
    )
    assert "Prove the activated profile remains unready without external authority" in workflow
    assert "authority_created_by_workflow\": False" in workflow
    assert 'assert doctor_result["isError"] is True' in workflow
    assert 'assert doctor["ok"] is False' in workflow
    assert 'assert doctor["manifest_authorized"] is False' in workflow
    assert 'assert doctor["pytest_reuse_ready"] is False' in workflow
    assert 'assert refused["isError"] is True' in workflow
    assert 'result("run_pytest", 21)' in workflow
    assert "assert not trust_root.exists(), trust_root" in workflow
    assert "Run the synthetic repository directly outside ZeroRun" in workflow
    assert "python -m pytest -q -p no:cacheprovider" in workflow
    assert re.search(r"\bzerorun(?:\s+--json)?\s+authorize\b", workflow) is None
    assert "authorize_manifest(" not in workflow
    assert "authorize_pytest_profile(" not in workflow
    assert 'assert doctor_result["isError"] is False' not in workflow
    assert 'assert doctor["manifest_authorized"] is True' not in workflow

    isolated_tests = (ROOT / "tests" / "test_codex_integration.py").read_text(
        encoding="utf-8"
    )
    assert "authorize_manifest(" in isolated_tests
    assert "authorize_pytest_profile(" in isolated_tests


def test_generalization_runtime_is_binary_hash_locked_and_receipt_bound() -> None:
    lock = ROOT / "ci" / "generalization-runtime-requirements.txt"
    raw = lock.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    text = raw.decode("utf-8")
    requirements = [
        line.split("==", 1)[0]
        for line in text.splitlines()
        if line and not line.startswith(("#", " ", "--"))
    ]
    assert set(requirements) == {
        "colorama",
        "iniconfig",
        "packaging",
        "pluggy",
        "pretend",
        "Pygments",
        "pytest",
    }
    assert "--only-binary=:all:" in text
    assert len(re.findall(r"--hash=sha256:[0-9a-f]{64}", text)) == len(
        requirements
    )

    workflow = (WORKFLOWS / "codex-full-product-retest.yml").read_text(
        encoding="utf-8"
    )
    match = re.search(
        r'GENERALIZATION_RUNTIME_LOCK_SHA256: "([0-9a-f]{64})"', workflow
    )
    assert match is not None
    assert match.group(1) == digest
    runtime_image = (
        "docker.io/library/python@sha256:"
        "9c47360a2a0355e2da18516d0b1c2126ec22c195d2185e97347c9d98398c5bef"
    )
    assert f'GENERALIZATION_RUNTIME_IMAGE: "{runtime_image}"' in workflow
    assert 'GENERALIZATION_RUNTIME_IMPLEMENTATION: "CPython"' in workflow
    assert 'GENERALIZATION_RUNTIME_PYTHON_VERSION: "3.12.14"' in workflow
    assert '"$RUNTIME_IMAGE" /usr/local/bin/python -I -c' in workflow
    assert (
        'test "$runtime_interpreter" = '
        '"cpython $GENERALIZATION_RUNTIME_PYTHON_VERSION"'
        in workflow
    )
    assert '"--runtime-requirements-sha256"' in workflow
    assert '"--engine-source-sha256"' in workflow
    assert '"--trial-tool-sha256"' in workflow
    assert 'row["runtime_requirements_sha256"] == expected_lock' in workflow
    assert 'row["engine_sha"] == os.environ["GITHUB_SHA"]' in workflow
    assert workflow.count(
        'row["activation_evidence_kind"] == "mechanical-synthetic-formative-fixture"'
    ) == 1
    assert 'row["external_hmac_authority_created"] is False' in workflow
    assert 'Path("ci/generalization-runtime-requirements.txt").read_bytes()' in workflow
    assert workflow.count('source["stable"] is True') == 2
    assert workflow.count('pre["git"]["engine_python_sources_dirty"] is False') >= 2
    assert workflow.count('pre["git"]["trial_tool_dirty"] is False') >= 2
    assert workflow.count('pre == source["post"]') >= 1
    assert workflow.count('identity_sha256 == canonical_sha256(identity_payload)') == 2
    assert workflow.count("actual_sources = list(") == 2
    assert workflow.count("path.is_file() and not path.is_symlink()") == 2
    assert 'probe["_capture_source_identity"]()' in workflow
    attestation = (
        "verified during the single hash-locked dependency-layer build; the exact "
        "pinned image and private read-only layer bytes are re-attested for each "
        "isolated trajectory"
    )
    assert workflow.count(attestation) == 2
    assert workflow.count('layer["build_count"] == 1') == 2
    assert workflow.count('layer["private_materialization_count"] == 2') == 2
    assert workflow.count(
        'layer["private_materialization_method"] == '
        '"exclusive-byte-copy-no-hardlinks"'
    ) == 2
    assert workflow.count('materialization["shared_hardlinks"] is False') == 2
    assert workflow.count('materialization["isolated_result_cache"] is True') == 2
    assert workflow.count(
        'data["cost_ledger_ms"]'
        '["symmetric_environment_bootstrap_charged_to_each_arm"]'
    ) == 2
    assert workflow.count(
        'layer["cleanup_confirmed_before_receipt_return"] is True'
    ) == 2
    assert "timeout-minutes: 240" in workflow
    assert (
        "from tools.validate_release_prerequisites import _validate_performance"
        in workflow
    )
    assert "_validate_performance(" in workflow
    assert "recompute the primary end-to-end totals" in workflow.lower()

    benchmark = (ROOT / "tools" / "product_generalization_benchmark.py").read_text(
        encoding="utf-8"
    )
    assert '"--require-hashes"' in benchmark
    assert '"--only-binary=:all:"' in benchmark
    assert '"/zerorun-env/runtime-requirements.txt"' in benchmark
    assert '"pytest",\n        *extra_requirements' not in benchmark
    assert '"runtime_requirements_sha256": runtime_requirements_sha256' in benchmark
    assert (
        '"activation_evidence_kind": "mechanical-synthetic-formative-fixture"'
        in benchmark
    )
    assert '"external_hmac_authority_created": False' in benchmark
    assert runtime_image.rsplit(":", 1)[1] in benchmark
    assert 'GENERALIZATION_RUNTIME_PYTHON_VERSION = "3.12.14"' in benchmark
    assert '"runtime_python_implementation"' in benchmark
    assert '"runtime_python_version"' in benchmark
    assert '"runtime_python_attestation"' in benchmark
    assert "authorize_manifest(" not in benchmark
    assert "authorize_pytest_profile(" not in benchmark


def _source_identity_fixture(
    *,
    engine_digest: str = "b" * 64,
    tool_digest: str = "c" * 64,
    identity_digest: str = "d" * 64,
    engine_dirty: bool = False,
    tool_dirty: bool = False,
) -> dict[str, object]:
    return {
        "schema": "zerorun.product-generalization-source-identity.v1",
        "engine_version": "0.5.1",
        "engine_python_source": {
            "schema": "zerorun.engine-python-source-identity.v1",
            "files": [],
            "file_count": 0,
            "total_bytes": 0,
            "sha256": engine_digest,
        },
        "trial_tool": {
            "path": "tools/product_generalization_benchmark.py",
            "size": 1,
            "sha256": tool_digest,
        },
        "git": {
            "commit": "a" * 40,
            "engine_python_sources_dirty": engine_dirty,
            "trial_tool_dirty": tool_dirty,
        },
        "identity_sha256": identity_digest,
    }


def test_generalization_source_identity_is_deterministic_and_self_identifying() -> None:
    from tools import product_generalization_benchmark as generalization

    identity = generalization._capture_source_identity()
    assert identity == generalization._capture_source_identity()
    payload = dict(identity)
    digest = payload.pop("identity_sha256")
    engine = identity["engine_python_source"]
    engine_payload = {
        "schema": engine["schema"],
        "files": engine["files"],
    }

    assert digest == generalization._canonical_sha256(payload)
    assert engine["sha256"] == generalization._canonical_sha256(engine_payload)
    assert engine["file_count"] == len(engine["files"])
    assert engine["total_bytes"] == sum(row["size"] for row in engine["files"])
    assert [row["path"] for row in engine["files"]] == sorted(
        row["path"] for row in engine["files"]
    )
    assert identity["trial_tool"]["sha256"] == hashlib.sha256(
        (ROOT / "tools" / "product_generalization_benchmark.py").read_bytes()
    ).hexdigest()


def test_generalization_script_imports_the_adjacent_engine_from_parent_layout(
    tmp_path: Path,
) -> None:
    parent = tmp_path / "parent"
    engine = parent / "engine"
    tool = engine / "tools" / "product_generalization_benchmark.py"
    shutil.copytree(
        ROOT / "zerorun",
        engine / "zerorun",
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )
    tool.parent.mkdir(parents=True)
    shutil.copy2(ROOT / "tools" / tool.name, tool)
    environment = dict(os.environ)
    environment.pop("PYTHONPATH", None)
    probe = (
        "import pathlib,runpy;"
        "tool=pathlib.Path('engine/tools/product_generalization_benchmark.py').resolve();"
        "scope=runpy.run_path(str(tool),run_name='source_attestation_probe');"
        "print(pathlib.Path(scope['_engine_package'].__file__).resolve());"
        "print(pathlib.Path(scope['_ENGINE_ROOT']).resolve())"
    )

    completed = subprocess.run(
        [sys.executable, "-c", probe],
        cwd=parent,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )

    assert completed.returncode == 0, completed.stderr
    assert completed.stdout.splitlines() == [
        str((engine / "zerorun" / "__init__.py").resolve()),
        str(engine.resolve()),
    ]


@pytest.mark.parametrize(
    ("overrides", "message"),
    [
        ({"engine_sha": "f" * 40}, "caller engine commit identity"),
        (
            {"expected_engine_source_sha256": "e" * 64},
            "caller engine Python-source identity",
        ),
        (
            {"expected_trial_tool_sha256": "e" * 64},
            "caller trial-tool identity",
        ),
    ],
)
def test_generalization_rejects_forged_caller_source_identity(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    overrides: dict[str, str],
    message: str,
) -> None:
    from tools import product_generalization_benchmark as generalization

    identity = _source_identity_fixture()
    invoked = False

    def forbidden_benchmark(*args, **kwargs):
        nonlocal invoked
        invoked = True
        raise AssertionError("benchmark executed after a forged identity")

    monkeypatch.setattr(generalization, "_capture_source_identity", lambda: identity)
    monkeypatch.setattr(generalization, "_benchmark_once", forbidden_benchmark)
    arguments = {
        "workload": "fixture",
        "upstream_repo": "example/fixture",
        "frozen_sha": "1" * 40,
        "targets": ("tests",),
        "extra_requirements": (),
        "runtime_image": "python@sha256:" + "2" * 64,
        "case_count": 1,
        "min_compute": 5.0,
        "min_p95_reduction": 50.0,
        "engine_sha": "a" * 40,
        "holdout_class": "old-regression",
        "expected_engine_source_sha256": "b" * 64,
        "expected_trial_tool_sha256": "c" * 64,
    }
    arguments.update(overrides)

    with pytest.raises(
        generalization._SourceIdentityError,
        match=message,
    ) as raised:
        generalization.benchmark(tmp_path, **arguments)
    assert invoked is False
    assert raised.value.source_identity_pre == identity
    assert raised.value.source_identity_post is None


@pytest.mark.parametrize(
    ("identity", "expected_engine", "expected_tool", "message"),
    [
        (
            _source_identity_fixture(engine_dirty=True),
            None,
            "c" * 64,
            "dirty engine Python sources require",
        ),
        (
            _source_identity_fixture(tool_dirty=True),
            "b" * 64,
            None,
            "dirty trial tool requires",
        ),
    ],
)
def test_generalization_dirty_sources_require_explicit_exact_identity(
    identity: dict[str, object],
    expected_engine: str | None,
    expected_tool: str | None,
    message: str,
) -> None:
    from tools import product_generalization_benchmark as generalization

    with pytest.raises(generalization._SourceIdentityError, match=message):
        generalization._validate_caller_source_identity(
            identity,
            engine_sha="a" * 40,
            expected_engine_source_sha256=expected_engine,
            expected_trial_tool_sha256=expected_tool,
        )


def test_generalization_success_receipt_binds_stable_source_identity(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    from tools import product_generalization_benchmark as generalization

    identity = _source_identity_fixture(engine_dirty=True, tool_dirty=True)
    monkeypatch.setattr(
        generalization,
        "_capture_source_identity",
        lambda: identity,
    )
    monkeypatch.setattr(
        generalization,
        "_benchmark_once",
        lambda *args, **kwargs: {"performance_gate_pass": False},
    )

    result = generalization.benchmark(
        tmp_path,
        workload="fixture",
        upstream_repo="example/fixture",
        frozen_sha="1" * 40,
        targets=("tests",),
        extra_requirements=(),
        runtime_image="python@sha256:" + "2" * 64,
        case_count=1,
        min_compute=5.0,
        min_p95_reduction=50.0,
        engine_sha="a" * 40,
        holdout_class="old-regression",
        expected_engine_source_sha256="b" * 64,
        expected_trial_tool_sha256="c" * 64,
    )

    assert result["engine_sha"] == "a" * 40
    assert result["engine_version"] == "0.5.1"
    assert result["source_identity"] == {
        "pre": identity,
        "post": identity,
        "stable": True,
        "caller_expected_engine_sha": "a" * 40,
        "caller_expected_engine_python_source_sha256": "b" * 64,
        "caller_expected_trial_tool_sha256": "c" * 64,
    }


def test_generalization_rejects_source_drift_after_trial(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    from tools import product_generalization_benchmark as generalization

    pre = _source_identity_fixture()
    post = _source_identity_fixture(
        tool_digest="e" * 64,
        identity_digest="f" * 64,
    )
    identities = iter((pre, post))
    monkeypatch.setattr(
        generalization,
        "_capture_source_identity",
        lambda: next(identities),
    )
    monkeypatch.setattr(
        generalization,
        "_benchmark_once",
        lambda *args, **kwargs: {"performance_gate_pass": False},
    )

    with pytest.raises(
        generalization._SourceIdentityError,
        match="identity drifted during the benchmark",
    ) as raised:
        generalization.benchmark(
            tmp_path,
            workload="fixture",
            upstream_repo="example/fixture",
            frozen_sha="1" * 40,
            targets=("tests",),
            extra_requirements=(),
            runtime_image="python@sha256:" + "2" * 64,
            case_count=1,
            min_compute=5.0,
            min_p95_reduction=50.0,
            engine_sha="a" * 40,
            holdout_class="old-regression",
            expected_engine_source_sha256="b" * 64,
            expected_trial_tool_sha256="c" * 64,
        )
    assert raised.value.source_identity_pre == pre
    assert raised.value.source_identity_post == post


def test_generalization_rejects_failed_post_trial_identity_capture(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    from tools import product_generalization_benchmark as generalization

    pre = _source_identity_fixture()
    captures = iter((pre, generalization._SourceIdentityError("source disappeared")))

    def capture():
        value = next(captures)
        if isinstance(value, Exception):
            raise value
        return value

    monkeypatch.setattr(generalization, "_capture_source_identity", capture)
    monkeypatch.setattr(
        generalization,
        "_benchmark_once",
        lambda *args, **kwargs: {"performance_gate_pass": False},
    )

    with pytest.raises(
        generalization._SourceIdentityError,
        match="could not capture the post-trial source identity",
    ) as raised:
        generalization.benchmark(
            tmp_path,
            workload="fixture",
            upstream_repo="example/fixture",
            frozen_sha="1" * 40,
            targets=("tests",),
            extra_requirements=(),
            runtime_image="python@sha256:" + "2" * 64,
            case_count=1,
            min_compute=5.0,
            min_p95_reduction=50.0,
            engine_sha="a" * 40,
            holdout_class="old-regression",
            expected_engine_source_sha256="b" * 64,
            expected_trial_tool_sha256="c" * 64,
        )
    assert raised.value.source_identity_pre == pre
    assert raised.value.source_identity_post is None


def test_generalization_identity_failure_does_not_promote_caller_commit(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    from tools import product_generalization_benchmark as generalization

    def fail_before_trial(*args, **kwargs):
        raise generalization._SourceIdentityError("identity unavailable")

    monkeypatch.setattr(generalization, "benchmark", fail_before_trial)
    output = tmp_path / "rejected.json"
    caller_commit = "a" * 40
    code = generalization.main(
        [
            "--root",
            str(tmp_path),
            "--workload",
            "fixture",
            "--upstream-repo",
            "example/fixture",
            "--frozen-sha",
            "1" * 40,
            "--target",
            "tests",
            "--runtime-image",
            "python@sha256:" + "2" * 64,
            "--engine-sha",
            caller_commit,
            "--holdout-class",
            "old-regression",
            "--output",
            str(output),
        ]
    )

    receipt = json.loads(output.read_text(encoding="utf-8"))
    assert code == 1
    assert receipt["engine_sha"] is None
    assert receipt["source_identity"]["pre"] is None
    assert receipt["source_identity"]["post"] is None
    assert receipt["source_identity"]["stable"] is False
    assert receipt["source_identity"]["caller_expected_engine_sha"] == caller_commit


def test_generalization_rows_retain_direct_and_zerorun_phase_timings(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    from tools import product_generalization_benchmark as generalization

    (tmp_path / ".git").mkdir()
    runtime_digest = generalization._runtime_requirements_sha256()
    runtime_image = generalization.GENERALIZATION_RUNTIME_IMAGE
    task = SimpleNamespace(image=runtime_image)
    manifest = SimpleNamespace(tasks={"task": task})
    profile = SimpleNamespace(task_name="task")

    @contextmanager
    def isolated(*args, **kwargs):
        try:
            yield tmp_path
        finally:
            kwargs["dependency_cleanup_record"].update(
                {
                    "schema": "zerorun.private-dependency-post-use-cleanup.v1",
                    "post_run_integrity_verification_ms": 0.75,
                    "private_environment_cleanup_ms": 1.25,
                    "total_ms": 2.0,
                    "post_run_integrity_verified": True,
                    "cleanup_confirmed": True,
                }
            )

    construction_sha256 = "1" * 64
    content_tree_sha256 = "2" * 64
    manifest_sha256 = "4" * 64

    @contextmanager
    def frozen_layer(*args, **kwargs):
        layer = {
            "root": tmp_path / "unused-frozen-layer",
            "snapshot": {"tree_sha256": content_tree_sha256},
            "construction": {
                "construction_identity_sha256": construction_sha256,
            },
            "runtime_requirements_sha256": runtime_digest,
            "build_ms": 12.0,
            "provenance": {
                "schema": generalization._DEPENDENCY_LAYER_SCHEMA,
                "construction_identity_sha256": construction_sha256,
                "content_tree_sha256": content_tree_sha256,
                "content_addressed_directory_name": content_tree_sha256,
                "runtime_image": runtime_image,
                "runtime_requirements_sha256": runtime_digest,
                "extra_requirements": [],
                "installer_bootstrap_sha256": "5" * 64,
                "installer_arguments_sha256": "6" * 64,
                "wrapper_sha256": "7" * 64,
                "manifest_sha256": manifest_sha256,
                "file_count": 2,
                "directory_count": 1,
                "total_bytes": 1,
                "path_bytes": 1,
                "read_only_mode_and_content_verified": True,
                "source_hardlinks_rejected": True,
                "build_count": 1,
                "build_once_ms": 12.0,
            },
        }
        try:
            yield layer
        finally:
            layer["post_use_cleanup"] = {
                "schema": "zerorun.dependency-layer-post-use-cleanup.v1",
                "final_integrity_verification_ms": 2.0,
                "private_layer_teardown_ms": 3.0,
                "total_ms": 5.0,
                "final_integrity_verified": True,
                "cleanup_confirmed": True,
            }

    def materialize(*args, **kwargs):
        return {
            "schema": (
                "zerorun.generalization-private-dependency-materialization.v1"
            ),
            "content_tree_sha256": content_tree_sha256,
            "construction_identity_sha256": construction_sha256,
            "manifest_sha256": manifest_sha256,
            "environment_bootstrap_ms": 3.0,
            "private_copy_ms": 1.0,
            "verification_ms": 1.0,
            "manifest_write_and_verify_ms": 1.0,
            "timing_remainder_ms": 0.0,
            "private_byte_copy": True,
            "shared_hardlinks": False,
            "read_only_mode_and_content_verified": True,
            "isolated_result_cache": True,
        }

    commits = [f"{index:040x}" for index in range(1, 22)]

    def direct(*args, **kwargs):
        return {
            "exit_code": 0,
            "wall_ms": 100.0,
            "collection_ms": 0.0,
            "execution_ms": 100.0,
            "node_count": None,
            "collection_sha256": None,
            "stdout_tail": "",
            "stderr_tail": "",
            "runner": "independent-docker-plain-pytest",
            "instrumented": False,
        }

    def product(*args, **kwargs):
        return {
            "status": "PYTEST_INCREMENTAL_PASS",
            "exit_code": 0,
            "wall_ms": 10.0,
            "benchmark_outer_wall_ms": 10.0,
            "execution_ms": 7.0,
            "collection_overhead_ms": 1.0,
            "single_pass_wall_ms": 7.0,
            "avoided_execution_reference_ms": 90.0,
            "phase_ms": {"fingerprint": 1.0, "cache_lookup": 0.5},
            "reused_nodes": 1,
            "fresh_nodes": 1,
            "published_nodes": 1,
            "unknown_nodes": 0,
            "total_nodes": 2,
            "collection_sha256": "3" * 64,
            "profile_refresh_required": False,
            "profile_refresh_reasons": [],
            "stderr_tail": "",
        }

    def shadow(*args, **kwargs):
        return {
            "exit_code": 0,
            "wall_ms": 30.0,
            "node_count": 2,
            "nodeids": ["tests/test_fixture.py::test_a", "tests/test_fixture.py::test_b"],
            "nodeid_sha256": "8" * 64,
            "complete_per_node_outcomes": True,
            "all_nodes_non_failing": True,
            "failing_nodeids": [],
            "stderr_tail": "",
        }

    monkeypatch.setattr(generalization, "_host_executable", lambda *args: sys.executable)
    monkeypatch.setattr(generalization, "_isolated_worktree", isolated)
    monkeypatch.setattr(generalization, "_frozen_dependency_layer", frozen_layer)
    monkeypatch.setattr(
        generalization,
        "_materialize_frozen_pytest_environment",
        materialize,
    )
    monkeypatch.setattr(
        generalization,
        "_corpus",
        lambda *args: commits,
    )
    monkeypatch.setattr(generalization, "_checkout", lambda *args: None)
    monkeypatch.setattr(generalization, "_clean_zerorun_state", lambda *args: None)
    monkeypatch.setattr(
        generalization,
        "_build_frozen_pytest_environment",
        lambda *args, **kwargs: runtime_digest,
    )
    monkeypatch.setattr(
        generalization,
        "prepare_candidate",
        lambda *args, **kwargs: {
            "candidate_sha256": "6" * 64,
            "nodes": {
                "tests/test_fixture.py::test_it": {
                    "reviewable": True,
                    "fresh_required": False,
                }
            },
        },
    )
    monkeypatch.setattr(
        generalization,
        "_activate_exact_candidate",
        lambda *args: {
            "candidate_sha256": "6" * 64,
            "review_record_sha256": "7" * 64,
        },
    )
    monkeypatch.setattr(generalization, "load_manifest", lambda *args: manifest)
    monkeypatch.setattr(generalization, "load_pytest_profile", lambda *args: profile)
    monkeypatch.setattr(generalization, "_safe_direct_once", direct)
    monkeypatch.setattr(generalization, "_safe_product_once", product)
    monkeypatch.setattr(generalization, "_safe_shadow_once", shadow)
    monkeypatch.setattr(
        generalization,
        "_safe_product_snapshot",
        lambda *args: (
            {
                "nodeids": [
                    "tests/test_fixture.py::test_a",
                    "tests/test_fixture.py::test_b",
                ],
                "collection_sha256": "3" * 64,
            },
            None,
        ),
    )
    monkeypatch.setattr(
        generalization,
        "_adverse_collection_failure_audit",
        lambda *args, **kwargs: {"status": "PASS", "pass": True},
    )

    result = generalization._benchmark_once(
        tmp_path,
        workload="fixture",
        upstream_repo="example/fixture",
        frozen_sha=commits[-1],
        targets=("tests",),
        extra_requirements=(),
        runtime_image=runtime_image,
        case_count=20,
        min_compute=5.0,
        min_p95_reduction=50.0,
        engine_sha="a" * 40,
        holdout_class="old-regression",
    )

    assert result["end_to_end_plain_pytest_to_zerorun_speedup"] > 9.0
    assert (
        result["same_runner_compute_efficiency"]
        == result["end_to_end_plain_pytest_to_zerorun_speedup"]
    )
    assert result["runtime_image"] == generalization.GENERALIZATION_RUNTIME_IMAGE
    assert result["runtime_python_implementation"] == "CPython"
    assert result["runtime_python_version"] == "3.12.14"
    assert result["p95_reduction_percent"] > 80.0
    assert result["performance_gate_pass"] is True
    assert result["timing_semantics"]["gate_inputs_unchanged"] is True
    assert result["counterbalanced_trajectory_count"] == 2
    assert result["repetitions_per_transition_per_arm"] == 2
    assert result["trajectory_schedule"]["counterbalance_complete"] is True
    assert result["primary_metric"] == "end_to_end_plain_pytest_to_zerorun_speedup"
    assert result["container_resource_envelope"] == {
        "docker_args": list(generalization._PLAIN_DOCKER_RESOURCE_ARGS),
        "identical_for_plain_pytest_and_zerorun": True,
    }
    assert result["cost_ledger_ms"]["direct_seed_charged_to_direct"] == 200.0
    assert result["cost_ledger_ms"]["zerorun_seed_charged_to_zerorun"] == 20.0
    assert (
        result["cost_ledger_ms"][
            "symmetric_environment_bootstrap_charged_to_each_arm"
        ]
        == 27.0
    )
    assert result["frozen_dependency_layer"]["timing_ms"] == {
        "build_once": 17.0,
        "build_only": 12.0,
        "final_integrity_verification": 2.0,
        "private_layer_teardown": 3.0,
        "private_materialization_and_verification_total": 10.0,
        "private_post_run_verification_and_cleanup_total": 4.0,
        "total_charged_symmetrically_to_each_arm": 27.0,
    }
    assert result["frozen_dependency_layer"]["build_only_ms"] == 12.0
    assert result["frozen_dependency_layer"]["build_once_ms"] == 17.0
    assert result["frozen_dependency_layer"]["post_use_cleanup"] == {
        "schema": "zerorun.dependency-layer-post-use-cleanup.v1",
        "final_integrity_verification_ms": 2.0,
        "private_layer_teardown_ms": 3.0,
        "total_ms": 5.0,
        "final_integrity_verified": True,
        "cleanup_confirmed": True,
    }
    assert set(result["cost_ledger_ms"]) == set(
        generalization._PRIMARY_COST_LEDGER_KEYS
    )
    assert not any(
        "shadow" in name or "adverse" in name
        for name in result["cost_ledger_ms"]
    )
    assert result["primary_cost_accounting"] == {
        "schema": "zerorun.primary-end-to-end-cost-accounting.v1",
        "required_components": list(generalization._PRIMARY_COST_LEDGER_KEYS),
        "all_required_components_present": True,
        "all_components_finite_and_nonnegative": True,
        "direct_overhead_before_horizon_amortization_ms": (
            result["cost_ledger_ms"][
                "symmetric_environment_bootstrap_charged_to_each_arm"
            ]
            + 200.0
        ),
        "zerorun_overhead_before_horizon_amortization_ms": (
            round(
                result["cost_ledger_ms"][
                    "symmetric_environment_bootstrap_charged_to_each_arm"
                ]
                + result["cost_ledger_ms"][
                    "zerorun_qualification_charged_to_zerorun"
                ]
                + result["cost_ledger_ms"][
                    "zerorun_activation_charged_to_zerorun"
                ]
                + 20.0,
                3,
            )
        ),
        "horizon_transitions": 20,
        "reconciled_before_gate_evaluation": True,
    }
    assert set(result["excluded_validation_wall_ms"]) == {
        "independent_fresh_shadow_excluded_from_primary_end_to_end",
        "adverse_audits_excluded_from_primary_end_to_end",
    }
    assert result["p95_estimation"]["sample_size"] == 20
    assert result["p95_estimation"]["confidence_interval_reported"] is False
    row = result["rows"][0]
    assert row["direct_collection_separately_measured"] is False
    assert (
        row["direct_collection_included_in_uninstrumented_single_pass_wall"]
        is True
    )
    assert row["direct_runner_independent_of_zerorun_internals"] is True
    assert row["direct_ms"] == row["primary_end_to_end_plain_pytest_ms"]
    assert row["zerorun_ms"] == row["primary_end_to_end_zerorun_ms"]
    assert row["steady_state_plain_pytest_transition_ms"] == 200.0
    assert row["steady_state_zerorun_transition_ms"] == 20.0
    assert row["repetition_count_per_arm"] == 2
    assert row["reused_node_fresh_shadow_coverage"] == 2
    assert row["reused_node_fresh_shadow_denominator"] == 2
    assert row["zerorun_phase_ms_emitted"] is True
    assert row["direct_phase_ms"]["timed_transition_outer_wall_sum"] == 200.0
    assert row["zerorun_phase_ms"] == {
        "cache_lookup": 1.0,
        "fingerprint": 2.0,
    }
    assert row["zerorun_timing_ms"]["outer_wall"] == 20.0
    assert row["zerorun_timing_ms"]["product_reported_wall"] == 20.0
    assert row["zerorun_timing_ms"]["execution"] == 14.0
    assert row["zerorun_timing_ms"]["collection_overhead"] == 2.0
    assert row["zerorun_timing_ms"]["single_pass_wall"] == 14.0
    assert row["zerorun_timing_ms"]["avoided_execution_reference"] == 180.0


def test_packaging_generalization_target_respects_collection_boundary() -> None:
    from zerorun import pytest_runtime

    workflow = (WORKFLOWS / "codex-full-product-retest.yml").read_text(
        encoding="utf-8"
    )
    packaging_case = re.search(
        r"- name: packaging\n"
        r"\s+class: old-regression\n"
        r"\s+repo: pypa/packaging\n"
        r"\s+frozen_sha: 10590c194edb33c82f84a127883d6097c56b7840\n"
        r"(?P<body>.*?)(?=\n\s+- name: pycparser)",
        workflow,
        re.DOTALL,
    )
    assert packaging_case is not None
    packaging_definition = packaging_case.group("body")
    assert "test_version.py expands to 51,523" in packaging_definition
    assert "intentionally exceeds ZeroRun's 25,000-node safety bound" in (
        packaging_definition
    )
    assert 'targets_json: \'["tests/test_tags.py"]\'' in packaging_definition
    assert 'targets_json: \'["tests/test_version.py"]\'' not in packaging_definition
    assert pytest_runtime.PYTEST_MAX_COLLECTION_NODES == 25_000


def test_generalization_environment_installs_only_the_locked_requirements(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from tools import product_generalization_benchmark as generalization

    calls: list[list[str]] = []
    runtime_image = "python@sha256:" + "a" * 64
    container_id = "b" * 64
    state_reads = 0
    container_name = ""

    def fake_bounded(command, **kwargs):
        nonlocal container_name, state_reads
        command = list(command)
        calls.append(command)
        assert kwargs["cwd"] == tmp_path
        assert kwargs["output_limit_bytes"] == generalization._MAX_COMMAND_OUTPUT_BYTES
        if command[1:3] == ["container", "ls"]:
            return subprocess.CompletedProcess(command, 0, b"", b""), False
        if command[1] == "create":
            container_name = command[command.index("--name") + 1]
            assert re.fullmatch(r"zerorun-generalization-env-[0-9a-f]{32}", container_name)
            staging_root = tmp_path / ".zerorun-env"
            staging_owner = staging_root.stat()
            assert command[command.index("--user") + 1] == (
                f"{staging_owner.st_uid}:{staging_owner.st_gid}"
            )
            if os.name != "nt":
                assert stat.S_IMODE(staging_owner.st_mode) == 0o700
            return subprocess.CompletedProcess(
                command, 0, (container_id + "\n").encode(), b""
            ), False
        if command[1:3] == ["container", "inspect"]:
            assert command[-1] == container_id
            if "--format" not in command:
                return subprocess.CompletedProcess(
                    command, 1, b"", b"Error: No such object\n"
                ), False
            state_reads += 1
            state = (
                {"Status": "created", "Running": False, "ExitCode": 0}
                if state_reads == 1
                else {"Status": "exited", "Running": False, "ExitCode": 0}
            )
            output = (
                f"{container_id}\t/{container_name}\t{runtime_image}\t"
                f"{json.dumps(state)}\n"
            )
            return subprocess.CompletedProcess(command, 0, output.encode(), b""), False
        if command[1] == "start":
            assert command[-1] == container_id
            assert (
                kwargs["timeout_seconds"]
                == generalization._DOCKER_BUILD_TIMEOUT_SECONDS
            )
            return subprocess.CompletedProcess(command, 0, b"installed\n", b""), False
        if command[1:3] == ["container", "rm"]:
            assert command[-1] == container_id
            return subprocess.CompletedProcess(
                command, 0, (container_id + "\n").encode(), b""
            ), False
        raise AssertionError(command)

    monkeypatch.setattr(generalization.shutil, "which", lambda name: sys.executable)
    monkeypatch.setattr(generalization, "_run_bounded_process", fake_bounded)

    digest = generalization._build_frozen_pytest_environment(
        tmp_path,
        runtime_image=runtime_image,
        extra_requirements=("pretend",),
    )

    assert digest == hashlib.sha256(
        (ROOT / "ci" / "generalization-runtime-requirements.txt").read_bytes()
    ).hexdigest()
    assert len(calls) == 7
    command = next(call for call in calls if call[1] == "create")
    image_index = command.index(runtime_image)
    assert command[image_index + 1 : image_index + 7] == [
        "/usr/local/bin/python",
        "-I",
        "-c",
        generalization._RUNTIME_INSTALL_BOOTSTRAP,
        "cpython",
        "3.12.14",
    ]
    assert command[image_index + 7] == "install"
    assert "--require-hashes" in command
    assert "--only-binary=:all:" in command
    assert "--no-input" in command
    assert command[command.index("--cpus") + 1] == "2"
    assert command[command.index("--memory") + 1] == "2g"
    assert command[command.index("--memory-swap") + 1] == "2g"
    assert command[command.index("--pids-limit") + 1] == "512"
    assert command[command.index("--cap-drop") + 1] == "ALL"
    assert command[command.index("--security-opt") + 1] == "no-new-privileges"
    assert command[-2:] == [
        "--requirement",
        "/zerorun-env/runtime-requirements.txt",
    ]
    assert "pytest" not in command
    assert "pretend" not in command
    staged_lock = tmp_path / ".zerorun-env" / "runtime-requirements.txt"
    assert staged_lock.read_bytes() == (
        ROOT / "ci" / "generalization-runtime-requirements.txt"
    ).read_bytes()
    wrapper_lines = (tmp_path / ".zerorun-env" / "bin" / "python").read_text(
        encoding="utf-8"
    ).splitlines()
    assert (
        'export PYTHONPATH="${PYTHONPATH:+$PYTHONPATH:}'
        '/workspace/src:/workspace:/workspace/.zerorun-env/site-packages"'
        in wrapper_lines
    )
    assert not any(
        "/workspace/.zerorun-env/site-packages:/workspace/src:/workspace" in line
        for line in wrapper_lines
    )

    with pytest.raises(
        generalization.ConfigurationError,
        match="hash-locked runtime closure",
    ):
        generalization._build_frozen_pytest_environment(
            tmp_path,
            runtime_image=runtime_image,
            extra_requirements=("unreviewed-package",),
        )


def test_release_validator_dependency_contract_matches_live_builder() -> None:
    from tools import product_generalization_benchmark as generalization
    from tools import validate_release_prerequisites as release

    requirements_row, _ = generalization._read_runtime_requirements_identity()
    construction = generalization._dependency_layer_construction_identity(
        runtime_image=generalization.GENERALIZATION_RUNTIME_IMAGE,
        extra_requirements=(),
        runtime_requirements=requirements_row,
    )

    assert construction["schema"] == release.PERFORMANCE_DEPENDENCY_LAYER_SCHEMA
    assert construction["methodology_version"] == release.PERFORMANCE_METHODOLOGY
    assert construction["runtime"]["image"] == release.PERFORMANCE_RUNTIME_IMAGE
    assert construction["installer"]["arguments"] == (
        release.PERFORMANCE_DEPENDENCY_INSTALL_ARGUMENTS
    )
    assert construction["installer"]["bootstrap_sha256"] == (
        release.PERFORMANCE_DEPENDENCY_BOOTSTRAP_SHA256
    )
    assert generalization._canonical_sha256(
        construction["installer"]["arguments"]
    ) == release.PERFORMANCE_DEPENDENCY_INSTALL_ARGUMENTS_SHA256
    assert (
        construction["wrapper_sha256"]
        == release.PERFORMANCE_DEPENDENCY_WRAPPER_SHA256
    )
    assert (
        construction["manifest_sha256"]
        == release.PERFORMANCE_DEPENDENCY_MANIFEST_SHA256
    )


def test_generalization_git_commands_are_bounded(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from tools import product_generalization_benchmark as generalization

    executable = str(Path(sys.executable).resolve())
    result = generalization._run(
        tmp_path,
        [
            executable,
            "-c",
            (
                "import sys; "
                "sys.stdout.buffer.write(b'o'*20000+b'OUT-END'); "
                "sys.stderr.buffer.write(b'e'*20000+b'ERR-END')"
            ),
        ],
        timeout_seconds=10,
    )
    assert len(result.stdout.encode()) <= generalization._MAX_COMMAND_OUTPUT_BYTES
    assert len(result.stderr.encode()) <= generalization._MAX_COMMAND_OUTPUT_BYTES
    assert result.stdout.endswith("OUT-END")
    assert result.stderr.endswith("ERR-END")

    calls: list[dict[str, object]] = []

    def timeout_run(command, **kwargs):
        calls.append(kwargs)
        return subprocess.CompletedProcess(
            command,
            -9,
            b"bounded stdout tail",
            b"bounded stderr tail",
        ), True

    monkeypatch.setattr(generalization, "_run_bounded_process", timeout_run)
    with pytest.raises(
        generalization.ConfigurationError,
        match="benchmark command timed out after 7s",
    ):
        generalization._run(
            tmp_path,
            [executable, "checkout", "--detach", "deadbeef"],
            timeout_seconds=7,
        )
    assert calls[0]["timeout_seconds"] == 7
    assert calls[0]["output_limit_bytes"] == 4096


def test_generalization_rejects_repository_controlled_host_executables(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from tools import product_generalization_benchmark as generalization

    fake_git = tmp_path / "git"
    fake_git.write_bytes(b"repository controlled")
    monkeypatch.setattr(generalization.shutil, "which", lambda name: str(fake_git))
    with pytest.raises(
        generalization.ConfigurationError,
        match="repository-controlled host git executable",
    ):
        generalization._host_executable(tmp_path, "git")


def test_generalization_state_cleanup_rejects_links(
    tmp_path: Path,
) -> None:
    from tools import product_generalization_benchmark as generalization

    outside = tmp_path / "outside"
    outside.mkdir()
    sentinel = outside / "sentinel"
    sentinel.write_text("keep", encoding="utf-8")
    state = tmp_path / ".zerorun"
    try:
        state.symlink_to(outside, target_is_directory=True)
    except OSError as exc:
        pytest.skip(f"directory symlinks are unavailable: {exc}")

    with pytest.raises(
        generalization.ConfigurationError,
        match="linked or reparse-point benchmark state",
    ):
        generalization._clean_zerorun_state(tmp_path)
    assert sentinel.read_text(encoding="utf-8") == "keep"
    assert state.is_symlink()


@pytest.mark.skipif(os.name == "nt", reason="mkfifo is not available on Windows")
def test_generalization_state_cleanup_rejects_special_files(tmp_path: Path) -> None:
    from tools import product_generalization_benchmark as generalization

    special = tmp_path / ".zerorun.json"
    os.mkfifo(special)
    with pytest.raises(
        generalization.ConfigurationError,
        match="special benchmark state",
    ):
        generalization._clean_zerorun_state(tmp_path)
    assert special.exists()


def test_generalization_dependency_timeout_uses_immutable_id_for_cleanup(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from tools import product_generalization_benchmark as generalization

    runtime_image = "python@sha256:" + "c" * 64
    container_id = "d" * 64
    calls: list[list[str]] = []
    container_name = ""

    def fake_bounded(command, **kwargs):
        nonlocal container_name
        command = list(command)
        calls.append(command)
        if command[1:3] == ["container", "ls"]:
            return subprocess.CompletedProcess(command, 0, b"", b""), False
        if command[1] == "create":
            container_name = command[command.index("--name") + 1]
            return subprocess.CompletedProcess(
                command, 0, (container_id + "\n").encode(), b""
            ), False
        if command[1:3] == ["container", "inspect"]:
            assert command[-1] == container_id
            if "--format" not in command:
                return subprocess.CompletedProcess(
                    command, 1, b"", b"Error: No such container\n"
                ), False
            state = {"Status": "created", "Running": False, "ExitCode": 0}
            output = (
                f"{container_id}\t/{container_name}\t{runtime_image}\t"
                f"{json.dumps(state)}\n"
            )
            return subprocess.CompletedProcess(command, 0, output.encode(), b""), False
        if command[1] == "start":
            assert command[-1] == container_id
            return subprocess.CompletedProcess(
                command, -9, b"partial", b"timeout"
            ), True
        if command[1:3] == ["container", "rm"]:
            assert command[-1] == container_id
            return subprocess.CompletedProcess(
                command, 0, (container_id + "\n").encode(), b""
            ), False
        raise AssertionError(command)

    monkeypatch.setattr(generalization.shutil, "which", lambda name: sys.executable)
    monkeypatch.setattr(generalization, "_run_bounded_process", fake_bounded)
    monkeypatch.setattr(
        generalization,
        "_force_remove_container",
        lambda *args, **kwargs: pytest.fail("known container ID used name cleanup"),
    )

    with pytest.raises(
        generalization.ConfigurationError,
        match="benchmark command timed out after 300s",
    ):
        generalization._build_frozen_pytest_environment(
            tmp_path,
            runtime_image=runtime_image,
            extra_requirements=(),
        )
    assert any(call[1:3] == ["container", "rm"] for call in calls)
    assert calls[-1][1:3] == ["container", "inspect"]
    assert calls[-1][-1] == container_id


def test_generalization_uncertain_create_uses_random_name_cleanup(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    from tools import product_generalization_benchmark as generalization

    calls: list[list[str]] = []
    cleaned: list[str] = []

    def fake_bounded(command, **kwargs):
        command = list(command)
        calls.append(command)
        if command[1:3] == ["container", "ls"]:
            return subprocess.CompletedProcess(command, 0, b"", b""), False
        if command[1] == "create":
            return subprocess.CompletedProcess(
                command, -9, b"", b"create timeout"
            ), True
        raise AssertionError(command)

    def fake_force_remove(docker, reference, **kwargs):
        cleaned.append(reference)
        return True

    monkeypatch.setattr(generalization.shutil, "which", lambda name: sys.executable)
    monkeypatch.setattr(generalization, "_run_bounded_process", fake_bounded)
    monkeypatch.setattr(generalization, "_force_remove_container", fake_force_remove)

    with pytest.raises(
        generalization.ConfigurationError,
        match="benchmark command timed out after 30s",
    ):
        generalization._build_frozen_pytest_environment(
            tmp_path,
            runtime_image="python@sha256:" + "e" * 64,
            extra_requirements=(),
        )
    assert len(cleaned) == 1
    assert re.fullmatch(r"zerorun-generalization-env-[0-9a-f]{32}", cleaned[0])


def test_pilot_quickstart_version_is_rendered_and_smoke_verified() -> None:
    template = (ROOT / "pilot" / "QUICKSTART.md").read_text(encoding="utf-8")
    build = (ROOT / "tools" / "build_pilot_package.sh").read_text(
        encoding="utf-8"
    )
    smoke = (ROOT / "tools" / "smoke_pilot_package.sh").read_text(
        encoding="utf-8"
    )
    assert template.count("@ZERORUN_VERSION@") == 2
    assert "v0.4.0 private pilot quick start" not in template
    assert 'sed "s/@ZERORUN_VERSION@/$ZERORUN_VERSION/g"' in build
    assert "pilot quick start contains an unresolved version placeholder" in build
    assert '# ZeroRun v$EXPECTED_VERSION private pilot quick start' in smoke
    assert 'zerorun $EXPECTED_VERSION' in smoke


def test_pilot_installer_publishes_without_following_links_or_special_files() -> None:
    installer = (ROOT / "pilot" / "install.sh").read_text(encoding="utf-8")
    smoke = (ROOT / "tools" / "smoke_pilot_package.sh").read_text(
        encoding="utf-8"
    )
    for marker in (
        "realpath -m -s",
        "Refusing an install directory with a symlinked parent",
        "Refusing a group- or world-writable install directory",
        "Refusing to replace a symlink or special destination",
        'mktemp "$INSTALL_DIR/.zerorun.install.XXXXXXXXXX"',
        'TMP_SOURCE_SHA=$(sha256sum "$TMP")',
        '"$TMP_SOURCE_SHA" != "$EXPECTED_SOURCE_SHA"',
        'sync -f "$TMP"',
        'mv -fT -- "$TMP" "$DEST"',
    ):
        assert marker in installer
    assert "ln -s \"$SYMLINK_TARGET\" \"$INSTALL_DIR/zerorun\"" in smoke
    assert "mkfifo \"$INSTALL_DIR/zerorun\"" in smoke
    assert "ln -s \"$REAL_INSTALL_DIR\" \"$LINKED_INSTALL_DIR\"" in smoke


def test_pilot_build_uses_a_verified_private_temporary_root() -> None:
    build = (ROOT / "tools" / "build_pilot_package.sh").read_text(
        encoding="utf-8"
    )
    assert "mktemp -d /tmp/zerorun-pilot-build.XXXXXXXXXX" in build
    assert 'rm -rf "$BUILD_DIR"' not in build
    assert 'rm -rf -- "$BUILD_DIR"' in build
    assert "refusing a linked or non-directory dist path" in build


@pytest.mark.skipif(sys.platform != "linux", reason="the pilot installer is Linux-only")
def test_pilot_installer_adversarial_publication(tmp_path: Path) -> None:
    package = tmp_path / "package"
    package.mkdir(mode=0o700)
    installer = package / "install.sh"
    binary = package / "zerorun-linux-amd64"
    shutil.copy2(ROOT / "pilot" / "install.sh", installer)
    shutil.copy2("/bin/true", binary)
    installer.chmod(0o755)
    binary.chmod(0o755)

    import hashlib

    checksum_rows = []
    for path in (binary, installer):
        checksum_rows.append(
            f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}"
        )
    (package / "SHA256SUMS.txt").write_text(
        "\n".join(checksum_rows) + "\n", encoding="utf-8"
    )

    def invoke(destination: Path) -> subprocess.CompletedProcess[str]:
        environment = os.environ.copy()
        environment["ZERORUN_INSTALL_DIR"] = str(destination)
        return subprocess.run(
            ["sh", str(installer)],
            cwd=package,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            timeout=30,
        )

    install_dir = tmp_path / "bin"
    install_dir.mkdir(mode=0o700)
    outside = tmp_path / "outside"
    outside.write_text("unchanged\n", encoding="utf-8")
    destination = install_dir / "zerorun"
    destination.symlink_to(outside)
    refused = invoke(install_dir)
    assert refused.returncode != 0, refused
    assert outside.read_text(encoding="utf-8") == "unchanged\n"
    assert destination.is_symlink()
    destination.unlink()

    os.mkfifo(destination, mode=0o600)
    refused = invoke(install_dir)
    assert refused.returncode != 0, refused
    assert destination.is_fifo()
    destination.unlink()

    real_install_dir = tmp_path / "real-bin"
    real_install_dir.mkdir(mode=0o700)
    linked_install_dir = tmp_path / "linked-bin"
    linked_install_dir.symlink_to(real_install_dir, target_is_directory=True)
    refused = invoke(linked_install_dir)
    assert refused.returncode != 0, refused
    assert not (real_install_dir / "zerorun").exists()

    writable_install_dir = tmp_path / "writable-bin"
    writable_install_dir.mkdir(mode=0o777)
    writable_install_dir.chmod(0o777)
    refused = invoke(writable_install_dir)
    assert refused.returncode != 0, refused
    assert not (writable_install_dir / "zerorun").exists()

    installed = invoke(install_dir)
    assert installed.returncode == 0, installed
    assert destination.is_file() and not destination.is_symlink()
    assert destination.read_bytes() == binary.read_bytes()
    assert destination.stat().st_mode & 0o777 == 0o755
    assert not list(install_dir.glob(".zerorun.install.*"))


def test_commercial_100_repository_workflow_is_main_bound_and_digest_pinned() -> None:
    workflow = WORKFLOWS / "commercial-100-repo-smoke.yml"
    text = workflow.read_text(encoding="utf-8")
    selection = json.loads(
        (ROOT / "commercial" / "corpus" / "selection-v1.json").read_text(
            encoding="utf-8"
        )
    )
    match = re.search(r"EXPECTED_SELECTION_SHA256:\s*([0-9a-f]{64})", text)
    assert match is not None
    assert match.group(1) == selection["corpus_sha256"]
    assert "branches: [main]" in text
    assert "batch: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]" in text
    assert 'CODEX_NPM_VERSION: "0.153.3"' in text
    assert "persist-credentials: false" in text
    assert 'python "$GITHUB_WORKSPACE/tools/commercial_repo_smoke.py"' in text
    assert "python -m tools.aggregate_commercial_smoke" in text
    assert 'result["engine_version"] == declared' in text
    assert 'installed_version("zerorun") != declared' in text
    assert 'test "$(zerorun --version)" = "zerorun $version"' in text


def test_cross_repository_performance_and_safety_are_strictly_gated() -> None:
    text = (WORKFLOWS / "codex-full-product-retest.yml").read_text(
        encoding="utf-8"
    )
    assert "frozen-five-repo-strict-gate" in text
    assert 'assert data.get("safety_pass") is True' in text
    assert '"strict: every workload must pass safety, >=5x primary end-to-end "' in text
    assert (
        '"plain-pytest-to-ZeroRun speedup, and >=50% p95 wall-time reduction"'
        in text
    )
    assert "assert all_five, result" in text
    persisted = text.index(
        'receipt_path = Path("product-generalization-five-repo-receipt.json")'
    )
    enforced = text.index("          _validate_performance(", persisted)
    assert persisted < enforced
    assert 'json.dumps(result, indent=2, sort_keys=True, allow_nan=False)' in text
    assert re.search(
        r"- name: Upload combined five-repo receipt\n\s+if: always\(\)", text
    )
    assert "safety only; performance remains diagnostic" not in text
