from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest

from zerorun.manifest import load_manifest
from zerorun.model import ConfigurationError
from zerorun import pytest_prepare_cli


IMAGE = "python@sha256:" + "1" * 64


def _initialize_gitfile_repository(root: Path) -> None:
    git = shutil.which("git")
    if git is None:
        pytest.skip("Git is unavailable")
    separate_git_dir = root.parent / f"{root.name}.git-data"
    subprocess.run(
        [
            git,
            "init",
            "--quiet",
            f"--separate-git-dir={separate_git_dir}",
            str(root),
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=20,
    )
    assert (root / ".git").is_file()


def _manifest(tmp_path: Path, commands: dict[str, list[str]]):
    if not (tmp_path / ".git").exists():
        (tmp_path / ".git").mkdir()
    tasks = {}
    for name, command in commands.items():
        tasks[name] = {
            "command": command,
            "inputs": ["tests"],
            "outputs": [],
            "env": [],
            "cacheable": True,
            "unsafe_effects": [],
            "cache_streams": False,
            "image": IMAGE,
            "platform": "linux/amd64",
            "result_only": True,
            "closure_reviewed": True,
        }
    path = tmp_path / ".zerorun.json"
    path.write_text(json.dumps({"version": 2, "tasks": tasks}), encoding="utf-8")
    return load_manifest(path)


def test_discover_single_pytest_task_and_default_tests_target(tmp_path: Path):
    (tmp_path / "tests").mkdir()
    manifest = _manifest(
        tmp_path,
        {
            "lint": ["python", "-m", "compileall", "src"],
            "unit": ["python", "-m", "pytest", "-q"],
        },
    )
    assert pytest_prepare_cli.discover_pytest_task(manifest, None) == "unit"
    assert pytest_prepare_cli.default_targets(tmp_path) == ("tests",)


def test_discover_requires_selection_when_multiple_pytest_tasks(tmp_path: Path):
    (tmp_path / "tests").mkdir()
    manifest = _manifest(
        tmp_path,
        {
            "unit": ["python", "-m", "pytest", "-q"],
            "integration": ["python", "-m", "pytest", "-q", "integration"],
        },
    )
    with pytest.raises(ConfigurationError, match="multiple pytest tasks"):
        pytest_prepare_cli.discover_pytest_task(manifest, None)
    assert pytest_prepare_cli.discover_pytest_task(manifest, "unit") == "unit"


def test_prepare_candidate_uses_defaults_and_never_activates_reuse(monkeypatch, tmp_path: Path):
    (tmp_path / "tests").mkdir()
    _manifest(tmp_path, {"unit": ["python", "-m", "pytest", "-q"]})
    seen = {}

    def fake_qualify(manifest, *, task_name, targets, output):
        seen.update(
            {
                "root": manifest.root,
                "task": task_name,
                "targets": targets,
                "output": output,
            }
        )
        return {
            "candidate_sha256": "a" * 64,
            "task": task_name,
            "targets": list(targets),
            "nodes": {
                "tests/test_one.py::test_one": {
                    "reviewable": True,
                    "fresh_required": False,
                }
            },
            "authorizes_reuse": False,
        }

    monkeypatch.setattr(pytest_prepare_cli, "qualify_pytest_candidate", fake_qualify)
    result = pytest_prepare_cli.prepare_candidate(tmp_path)

    assert result["authorizes_reuse"] is False
    assert seen["task"] == "unit"
    assert seen["targets"] == ("tests",)
    assert seen["output"] == tmp_path / ".zerorun-pytest.candidate.json"


def test_cli_json_explicitly_reports_reuse_not_activated(monkeypatch, tmp_path: Path, capsys):
    monkeypatch.setattr(
        pytest_prepare_cli,
        "prepare_candidate",
        lambda *args, **kwargs: {
            "candidate_sha256": "b" * 64,
            "task": "unit",
            "targets": ["tests"],
            "nodes": {
                "n1": {"reviewable": True, "fresh_required": False},
                "n2": {"reviewable": False, "fresh_required": True},
            },
        },
    )
    assert pytest_prepare_cli.main(["--root", str(tmp_path), "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["status"] == "CANDIDATE_READY"
    assert payload["authorizes_reuse"] is False
    assert payload["reuse_activated"] is False
    assert payload["candidate_reviewable_nodes"] == 1
    assert payload["fresh_required_nodes"] == 1


def test_prepare_candidate_rejects_symlinked_output_before_profiling(
    monkeypatch, tmp_path: Path
) -> None:
    repository = tmp_path / "repository"
    repository.mkdir()
    _manifest(repository, {"unit": ["python", "-m", "pytest", "-q"]})
    outside = tmp_path / "outside.json"
    outside.write_text("do not replace\n", encoding="utf-8")
    candidate = repository / ".zerorun-pytest.candidate.json"
    try:
        candidate.symlink_to(outside)
    except OSError as exc:
        pytest.skip(f"symbolic links are unavailable: {exc}")
    called = []
    monkeypatch.setattr(
        pytest_prepare_cli,
        "qualify_pytest_candidate",
        lambda *args, **kwargs: called.append((args, kwargs)),
    )

    with pytest.raises(ConfigurationError, match="symbolic link or junction"):
        pytest_prepare_cli.prepare_candidate(repository)

    assert called == []
    assert outside.read_text(encoding="utf-8") == "do not replace\n"


def test_prepare_candidate_accepts_codex_linked_worktree_marker(
    monkeypatch, tmp_path: Path
) -> None:
    _initialize_gitfile_repository(tmp_path)
    (tmp_path / "tests").mkdir()
    _manifest(tmp_path, {"unit": ["python", "-m", "pytest", "-q"]})
    monkeypatch.setattr(
        pytest_prepare_cli,
        "qualify_pytest_candidate",
        lambda manifest, *, task_name, targets, output: {
            "task": task_name,
            "targets": list(targets),
            "candidate_sha256": "f" * 64,
            "authorizes_reuse": False,
        },
    )

    result = pytest_prepare_cli.prepare_candidate(tmp_path)

    assert result["task"] == "unit"
    assert (tmp_path / ".git").is_file()
