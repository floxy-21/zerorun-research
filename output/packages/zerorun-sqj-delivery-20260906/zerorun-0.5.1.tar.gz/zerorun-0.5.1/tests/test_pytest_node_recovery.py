from __future__ import annotations

import pytest

from tools.pytest_node_cache import NodeCacheDecision
from tools.pytest_node_recovery import (
    assert_no_unrecovered_rejections,
    build_recovery_plan,
    rejected_nodeids,
)


def _decision(nodeid: str, status: str) -> NodeCacheDecision:
    return NodeCacheDecision(
        partition="terminal-core",
        nodeid=nodeid,
        cache_task=None,
        key=None,
        fingerprint=None,
        status=status,
        reason=None,
    )


def test_only_final_snapshot_rejections_enter_recovery_batch() -> None:
    rejected = "testing/test_terminal.py::TestTerminal::test_rejected"
    decisions = [
        _decision("testing/test_terminal.py::TestTerminal::test_hit", "HIT_REUSED"),
        _decision(rejected, "REJECTED_INPUT_RACE"),
        _decision("testing/test_terminal.py::TestTerminal::test_miss", "MISS_VERIFIED"),
    ]
    assert rejected_nodeids(decisions) == [rejected]
    plan = build_recovery_plan({"terminal-core": decisions})
    assert len(plan) == 1
    assert plan[0]["nodeids"] == [rejected]
    assert rejected in plan[0]["command"][2]


def test_request_cannot_finish_with_unrecovered_rejection() -> None:
    rejected = "testing/test_terminal.py::TestTerminal::test_rejected"
    with pytest.raises(RuntimeError, match="must execute fresh"):
        assert_no_unrecovered_rejections(
            {"terminal-core": [_decision(rejected, "REJECTED_INPUT_RACE")]}
        )


def test_request_can_finish_when_no_rejections_remain() -> None:
    assert_no_unrecovered_rejections(
        {
            "terminal-core": [
                _decision("testing/test_terminal.py::TestTerminal::test_hit", "HIT_REUSED"),
                _decision("testing/test_terminal.py::TestTerminal::test_miss", "MISS_VERIFIED"),
            ]
        }
    )
