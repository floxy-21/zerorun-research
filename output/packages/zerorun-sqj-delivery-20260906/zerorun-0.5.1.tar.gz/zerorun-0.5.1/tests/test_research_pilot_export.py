"""Evidence exports retain failures and verify each serialized byte stream."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile


SCRIPT = Path(__file__).resolve().parents[1] / "research/phases/export_pilot_evidence.py"


def test_export_preserves_raw_failure_and_wal_but_omits_worktree(tmp_path):
    pilot, linux = tmp_path / "pilot", tmp_path / "linux"
    pilot.mkdir()
    linux.mkdir()
    (pilot / "pilot-receipt.json").write_text('{"status":"FAILED"}')
    (pilot / "stderr.raw").write_text("INTERNALERROR> failed")
    work = pilot / "work"
    work.mkdir()
    (work / "unrelated.py").write_text("pass")
    (work / ".testmondata-wal").write_bytes(b"diagnostic-wal")
    (linux / "tests.xml").write_text("<testsuite/>")
    output = tmp_path / "export.tar.gz"
    command = [sys.executable, str(SCRIPT), "--pilot-root", str(pilot),
               "--linux-tests-root", str(linux), "--output", str(output)]
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    with tarfile.open(output) as archive:
        index = json.load(archive.extractfile("EXPORT_INDEX.json"))
        assert not index["authorizes_reuse"]
        assert not index["evidence_eligible"]
        assert {row["path"] for row in index["entries"]} == {
            "pilot/pilot-receipt.json", "pilot/stderr.raw",
            "pilot/work/.testmondata-wal", "linux-tests/tests.xml"}
        for row in index["entries"]:
            data = archive.extractfile(row["path"]).read()
            assert len(data) == row["size"]
            assert hashlib.sha256(data).hexdigest() == row["sha256"]
    before = output.read_bytes()
    assert subprocess.run(command, capture_output=True).returncode != 0
    assert output.read_bytes() == before


def test_export_rejects_absent_root(tmp_path):
    output = tmp_path / "export.tar.gz"
    result = subprocess.run([sys.executable, str(SCRIPT), "--pilot-root",
                             str(tmp_path / "absent"), "--linux-tests-root",
                             str(tmp_path), "--output", str(output)], capture_output=True)
    assert result.returncode != 0
    assert not output.exists()
