from __future__ import annotations

import hashlib
import json
import os

import pytest

from tools import hermetic_pytest_experiment as experiment
from tools.pytest_batched_executor import (
    _validate_incremental_rows,
    build_incremental_plan,
    build_fresh_plan,
    build_fresh_plan_from_cache,
    container_driver_source,
    container_driver_command,
    execution_ms_by_node,
    incremental_plugin_source,
    prepare_workspace_mountpoints,
    successful_nodeids,
)
from tools.pytest_node_cache import NodeCacheDecision
from tools.pytest_node_recovery import assert_no_unrecovered_rejections, build_recovery_plan


def test_fresh_plan_preserves_partition_configuration_and_targets_exact_nodes() -> None:
    plan = build_fresh_plan(
        {
            "terminal-core": [
                "testing/test_terminal.py::TestTerminal::test_one",
                "testing/test_terminal.py::test_two",
            ],
            "stable-python-api": [
                "testing/python/approx.py::test_simple",
            ],
        }
    )

    by_name = {row["partition"]: row for row in plan}
    assert set(by_name) == {"terminal-core", "stable-python-api"}
    assert by_name["terminal-core"]["node_count"] == 2
    terminal_script = by_name["terminal-core"]["command"][2]
    assert "-k 'not color and not CodeHighlight and not test_header_absolute_testpath'" in terminal_script
    assert "testing/test_terminal.py::TestTerminal::test_one" in terminal_script
    assert "testing/test_terminal.py::test_two" in terminal_script

    stable_script = by_name["stable-python-api"]["command"][2]
    assert "testing/python/approx.py::test_simple" in stable_script
    assert "-p no:terminal" not in stable_script


def test_fresh_plan_deduplicates_nodes_without_reordering_first_occurrence() -> None:
    node = "testing/test_unittest.py::TestUnitTestCase::test_one"
    plan = build_fresh_plan({"unittest-only": [node, node]})

    assert len(plan) == 1
    assert plan[0]["node_count"] == 1
    assert plan[0]["nodeids"] == [node]


def test_fresh_plan_rejects_cross_partition_nodes() -> None:
    with pytest.raises(RuntimeError, match="do not belong"):
        build_fresh_plan(
            {
                "terminal-core": [
                    "testing/test_doctest.py::test_wrong_partition",
                ]
            }
        )


def test_fresh_plan_rejects_unknown_partition() -> None:
    with pytest.raises(RuntimeError, match="unknown pytest partition"):
        build_fresh_plan({"not-a-partition": ["testing/test_terminal.py::test_one"]})


def _collection_payload(nodeid: str, identity: str = "a") -> dict[str, object]:
    row = {
        "nodeid": nodeid,
        "identity_sha256": identity * 64,
        "parameter_identity_supported": True,
    }
    payload: dict[str, object] = {"nodeids": [nodeid], "items": [row]}
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    payload["collection_sha256"] = hashlib.sha256(encoded).hexdigest()
    return payload


def _all_partition_collections():
    from tools import pytest_result_dependency_probe as result_probe

    result_probe.base._configure_harness()
    baselines = {}
    source = {}
    for partition in experiment.PARTITIONS:
        nodeid = f"{partition.targets[0]}::test_zerorun_example"
        baselines[partition.name] = _collection_payload(nodeid)
        source[partition.name] = []
    return baselines, source


def test_incremental_plan_fresh_collects_all_partitions_with_full_targets() -> None:
    baselines, source = _all_partition_collections()
    plan = build_incremental_plan(baselines, source)

    assert [entry["partition"] for entry in plan] == [
        partition.name for partition in experiment.PARTITIONS
    ]
    assert len(plan) == 7
    for partition, entry in zip(experiment.PARTITIONS, plan):
        command = entry["command"]
        assert command[:5] == [
            "python",
            "-m",
            "pytest",
            "-p",
            "zerorun_incremental_plugin",
        ]
        assert all(target in command for target in partition.targets)
        config_index = command.index("-c")
        assert command[config_index + 1] == "/tmp/zerorun-pytest.ini"
        assert "bash" not in command
        assert "conda" not in command
        assert entry["source_fresh_nodeids"] == []


def test_incremental_plan_rejects_missing_or_malformed_source_evidence() -> None:
    baselines, source = _all_partition_collections()
    missing = dict(source)
    missing.pop(next(iter(missing)))
    with pytest.raises(RuntimeError, match="every partition"):
        build_incremental_plan(baselines, missing)

    malformed = dict(source)
    malformed[next(iter(malformed))] = [123]  # type: ignore[list-item]
    with pytest.raises(RuntimeError, match="non-string"):
        build_incremental_plan(baselines, malformed)


def test_incremental_plan_rejects_tampered_baseline_digest() -> None:
    baselines, source = _all_partition_collections()
    first = next(iter(baselines))
    baselines[first]["collection_sha256"] = "0" * 64
    with pytest.raises(RuntimeError, match="digest mismatch"):
        build_incremental_plan(baselines, source)


def test_incremental_plugin_source_compiles_and_handles_empty_hit_safely() -> None:
    source = incremental_plugin_source()
    compile(source, "zerorun_incremental_plugin.py", "exec")
    assert "hookwrapper=True, tryfirst=True" in source
    assert "bool(current[\"nodeids\"]) and not fresh and bool(reusable)" in source
    assert "force_reason is not None" in source


def test_container_driver_forks_before_importing_pytest() -> None:
    source = container_driver_source()
    compile(source, "driver.py", "exec")
    assert "pid = os.fork()" in source
    assert source.index("pid = os.fork()") < source.index("import pytest")
    assert 'process_model = "fork-before-pytest-import"' in source


def test_container_driver_restores_incremental_pytest_setup(tmp_path) -> None:
    source = container_driver_source()
    # Load the exact embedded driver without invoking its main entry point, then
    # run a simulated incremental entry up to the fork boundary. This catches
    # regressions where direct argv execution drops the stable shell prelude.
    definitions, separator, _ = source.rpartition("\nraise SystemExit(main())")
    assert separator
    namespace = {}
    exec(compile(definitions, "driver.py", "exec"), namespace)

    support = tmp_path / "support"
    output = tmp_path / "output"
    workspace = tmp_path / "workspace"
    support.mkdir()
    output.mkdir()
    workspace.mkdir()
    config_path = tmp_path / "zerorun-pytest.ini"
    plan = [
        {
            "mode": "incremental",
            "partition": "terminal-core",
            "command": [
                "python",
                "-m",
                "pytest",
                "-c",
                "/tmp/zerorun-pytest.ini",
            ],
            "nodeids": [],
        }
    ]
    (support / "plan.json").write_text(json.dumps(plan), encoding="utf-8")

    namespace["_ROOT"] = workspace
    namespace["_SUPPORT"] = support
    namespace["_OUTPUT"] = output
    namespace["_PYTEST_INI"] = config_path
    captured = {}

    def clear_for_test(path) -> None:
        if str(path).replace("\\", "/") == "/tmp":
            config_path.unlink(missing_ok=True)

    def run_without_fork(command, child_env, index):
        assert config_path.is_file()
        captured.update(child_env)
        selection = {"fresh_nodeids": []}
        (output / "selection-terminal-core.json").write_text(
            json.dumps(selection), encoding="utf-8"
        )
        return 0, b"", b""

    namespace["_clear_dir"] = clear_for_test
    namespace["_run_forked_pytest"] = run_without_fork
    assert namespace["main"]() == 0

    assert config_path.read_text(encoding="utf-8") == (
        "[pytest]\n"
        "xfail_strict = true\n"
        "pytester_example_dir = testing/example_scripts\n"
    )
    assert captured["PYTHONPATH"] == f"{support}:{workspace / 'src'}"
    assert captured["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] == "1"
    assert captured["PYTEST_ADDOPTS"] == (
        "-W ignore::_pytest.warning_types.PytestUnknownMarkWarning"
    )


def test_incremental_result_validation_recomputes_exact_selection() -> None:
    baseline = _collection_payload("testing/test_terminal.py::test_a", "a")
    current = _collection_payload("testing/test_terminal.py::test_a", "a")
    plan = [
        {
            "partition": "terminal-core",
            "baseline_collection": baseline,
            "source_fresh_nodeids": [],
            "force_full_reason": None,
        }
    ]
    selection = {
        "partition": "terminal-core",
        "mode": "single-pass-incremental",
        "fresh_nodeids": [],
        "reused_nodeids": ["testing/test_terminal.py::test_a"],
        "collection": current,
        "collection_delta": {
            "safe_incremental": True,
            "retained_order_equal": True,
            "added_nodes": [],
            "removed_nodes": [],
            "changed_identity_nodes": [],
            "unsupported_parameter_nodes": [],
            "fresh_current_nodes": [],
            "reusable_existing_nodes": ["testing/test_terminal.py::test_a"],
            "baseline_node_count": 1,
            "current_node_count": 1,
            "reason": None,
        },
    }
    rows = [
        {
            "partition": "terminal-core",
            "process_model": "fork-before-pytest-import",
            "nodeids": [],
            "node_count": 0,
            "incremental_selection": selection,
        }
    ]
    _validate_incremental_rows(plan, rows)

    selection["fresh_nodeids"] = ["testing/test_terminal.py::test_a"]
    with pytest.raises(RuntimeError, match="host classification"):
        _validate_incremental_rows(plan, rows)


def _decision(partition: str, nodeid: str, status: str) -> NodeCacheDecision:
    return NodeCacheDecision(
        partition=partition,
        nodeid=nodeid,
        cache_task=None,
        key=None,
        fingerprint=None,
        status=status,
        reason=None,
    )


def test_cache_decisions_feed_only_fresh_nodes_into_batch_plan() -> None:
    hit = "testing/test_terminal.py::TestTerminal::test_hit"
    miss = "testing/test_terminal.py::TestTerminal::test_miss"
    uncertain = "testing/test_terminal.py::test_uncertain"
    plan = build_fresh_plan_from_cache(
        {
            "terminal-core": [
                _decision("terminal-core", hit, "HIT_PROVISIONAL"),
                _decision("terminal-core", miss, "MISS_KEYED"),
                _decision("terminal-core", uncertain, "MISS_UNCERTAIN"),
            ]
        }
    )

    assert len(plan) == 1
    assert plan[0]["nodeids"] == [miss, uncertain]
    script = plan[0]["command"][2]
    assert miss in script
    assert uncertain in script
    assert hit not in script


def test_rejected_final_snapshot_hit_is_forced_into_recovery_batch() -> None:
    rejected = "testing/test_terminal.py::TestTerminal::test_rejected"
    decisions = {
        "terminal-core": [
            _decision("terminal-core", "testing/test_terminal.py::TestTerminal::test_hit", "HIT_REUSED"),
            _decision("terminal-core", rejected, "REJECTED_INPUT_RACE"),
            _decision("terminal-core", "testing/test_terminal.py::TestTerminal::test_miss", "MISS_VERIFIED"),
        ]
    }
    plan = build_recovery_plan(decisions)
    assert len(plan) == 1
    assert plan[0]["nodeids"] == [rejected]
    assert rejected in plan[0]["command"][2]
    with pytest.raises(RuntimeError, match="must execute fresh"):
        assert_no_unrecovered_rejections(decisions)


def test_success_evidence_only_covers_zero_exit_partition_nodes() -> None:
    result = {
        "partitions": [
            {
                "partition": "terminal-core",
                "nodeids": ["testing/test_terminal.py::test_a", "testing/test_terminal.py::test_b"],
                "exit_code": 0,
                "execution_ms": 20.0,
            },
            {
                "partition": "logging",
                "nodeids": ["testing/logging/test_reporting.py::test_failure"],
                "exit_code": 1,
                "execution_ms": 5.0,
            },
        ]
    }

    assert successful_nodeids(result) == {
        "testing/test_terminal.py::test_a",
        "testing/test_terminal.py::test_b",
    }
    assert execution_ms_by_node(result) == {
        "testing/test_terminal.py::test_a": 10.0,
        "testing/test_terminal.py::test_b": 10.0,
    }


def test_prepare_workspace_mountpoints_creates_private_state_dir(tmp_path) -> None:
    (tmp_path / ".git").mkdir()

    prepare_workspace_mountpoints(tmp_path)

    state = tmp_path / ".zerorun"
    assert state.is_dir()
    proof = state / "windows-restricted-token-proof.txt"
    proof.write_text("writable\n", encoding="utf-8")
    assert proof.read_text(encoding="utf-8") == "writable\n"
    if os.name != "nt":
        assert state.stat().st_mode & 0o777 == 0o700


def test_prepare_workspace_mountpoints_retightens_existing_state_on_posix(
    tmp_path,
) -> None:
    (tmp_path / ".git").mkdir()
    state = tmp_path / ".zerorun"
    state.mkdir()
    if os.name != "nt":
        state.chmod(0o755)

    prepare_workspace_mountpoints(tmp_path)

    assert state.is_dir()
    if os.name != "nt":
        assert state.stat().st_mode & 0o777 == 0o700


def test_prepare_workspace_mountpoints_rejects_symlinked_state(tmp_path) -> None:
    (tmp_path / ".git").mkdir()
    target = tmp_path / "state-target"
    target.mkdir()
    try:
        (tmp_path / ".zerorun").symlink_to(target, target_is_directory=True)
    except OSError as exc:
        if os.name == "nt":
            pytest.skip(f"Windows symlink privilege is unavailable: {exc}")
        raise

    with pytest.raises(RuntimeError, match="not a safe directory"):
        prepare_workspace_mountpoints(tmp_path)


def test_prepare_workspace_mountpoints_requires_real_git_directory(tmp_path) -> None:
    with pytest.raises(RuntimeError, match="real .git directory"):
        prepare_workspace_mountpoints(tmp_path)


def test_batch_driver_uses_pinned_testbed_environment() -> None:
    command = container_driver_command("example.invalid/pytest@sha256:deadbeef")

    assert command[:3] == [
        "example.invalid/pytest@sha256:deadbeef",
        "bash",
        "-c",
    ]
    script = command[3]
    assert "source /opt/miniconda3/etc/profile.d/conda.sh" in script
    assert "conda activate testbed" in script
    assert "python /zerorun-batch/driver.py" in script
