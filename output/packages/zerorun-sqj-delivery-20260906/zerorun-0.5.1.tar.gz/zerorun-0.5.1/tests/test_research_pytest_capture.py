from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from research.artifact import pytest_capture
from research.artifact.pytest_capture import CaptureRefused, canonicalize_events
from tools.research_m1_dispatch import CanonicalOutcomeNormalizer


ROOT = Path(__file__).resolve().parents[1]
CAPTURE = ROOT / "research" / "artifact" / "pytest_capture.py"


def _run_capture(
    project: Path,
    output: Path,
    *pytest_args: str,
    selector_observation: bool = False,
    observe_modules: tuple[str, ...] = (),
    pythonpath: Path | None = None,
) -> subprocess.CompletedProcess[str]:
    environment = os.environ.copy()
    environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    if pythonpath is not None:
        existing = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = str(pythonpath) + (
            os.pathsep + existing if existing else ""
        )
    selector_args = ["--selector-observation"] if selector_observation else []
    module_args = [
        item
        for module in observe_modules
        for item in ("--observe-module", module)
    ]
    return subprocess.run(
        [
            sys.executable,
            str(CAPTURE),
            "--cwd",
            str(project),
            "--output",
            str(output),
            "--synthetic-validation",
            *selector_args,
            *module_args,
            "--",
            "-c",
            os.devnull,
            "--rootdir",
            str(project),
            *pytest_args,
        ],
        cwd=ROOT,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
        timeout=60,
    )


def _receipt(output: Path) -> dict[str, object]:
    return json.loads(output.read_text(encoding="utf-8"))


def _report(
    sequence: int,
    *,
    phase: str,
    outcome: str = "passed",
    was_xfail: bool = False,
    strict_xpass: bool = False,
) -> dict[str, object]:
    return {
        "sequence": sequence,
        "kind": "report",
        "node_id": "test_a.py::test_a",
        "phase": phase,
        "outcome": outcome,
        "was_xfail": was_xfail,
        "xfail_reason": "expected" if was_xfail else None,
        "strict_xpass": strict_xpass,
        "longrepr": None,
        "longrepr_truncated": False,
    }


def test_actual_pytest_semantics_and_canonical_digest(tmp_path: Path) -> None:
    project = tmp_path / "semantics"
    project.mkdir()
    (project / "test_semantics.py").write_text(
        """import pytest

def test_pass():
    assert True

def test_fail():
    assert False

def test_skip():
    pytest.skip("skip")

@pytest.mark.xfail(reason="known")
def test_xfail():
    assert False

@pytest.mark.xfail(reason="surprise")
def test_xpass():
    assert True

@pytest.mark.xfail(reason="strict", strict=True)
def test_strict_xpass():
    assert True
""",
        encoding="utf-8",
    )
    output = tmp_path / "semantics.json"

    completed = _run_capture(project, output, "-q")

    assert completed.returncode == 0, completed.stderr
    receipt = _receipt(output)
    assert receipt["pytest_exit_code"] == 1
    assert receipt["capture_valid"] is True
    assert receipt["oracle_complete"] is True
    assert receipt["authorizes_reuse"] is False
    assert receipt["evidence_eligible"] is False
    assert receipt["study_status_mutated"] is False
    canonical = receipt["canonical_outcome"]
    assert [row["outcome"] for row in canonical["node_outcomes"]] == [
        "passed",
        "failed",
        "skipped",
        "xfailed",
        "xpassed",
        "xpassed",
    ]
    assert canonical["reuse_claims"] == []
    assert canonical["overall_status"] == "failed"
    assert dict(
        CanonicalOutcomeNormalizer().normalize(
            canonical, node_accounting=None, oracle=True
        )
    ) == canonical
    report_phases = {
        (event["node_id"], event["phase"])
        for event in receipt["raw_events"]
        if event["kind"] == "report"
    }
    assert ("test_semantics.py::test_pass", "setup") in report_phases
    assert ("test_semantics.py::test_pass", "call") in report_phases
    assert ("test_semantics.py::test_pass", "teardown") in report_phases


@pytest.mark.parametrize(
    ("body", "expected_exit", "expected_status", "expected_outcome"),
    [
        (
            "@pytest.mark.xfail(reason='nonstrict')\ndef test_case():\n    assert True\n",
            0,
            "passed",
            "xpassed",
        ),
        (
            "@pytest.mark.xfail(reason='strict', strict=True)\ndef test_case():\n    assert True\n",
            1,
            "failed",
            "xpassed",
        ),
        (
            "def test_case():\n    assert False, 'XPASS(strict) is ordinary failure text'\n",
            1,
            "failed",
            "failed",
        ),
    ],
)
def test_actual_pytest_xpass_and_failure_disambiguation(
    tmp_path: Path,
    body: str,
    expected_exit: int,
    expected_status: str,
    expected_outcome: str,
) -> None:
    project = tmp_path / expected_outcome
    project.mkdir()
    (project / "test_case.py").write_text("import pytest\n\n" + body, encoding="utf-8")
    output = tmp_path / f"{expected_status}-{expected_outcome}.json"

    completed = _run_capture(project, output, "-q")

    assert completed.returncode == 0, completed.stderr
    receipt = _receipt(output)
    assert receipt["pytest_exit_code"] == expected_exit
    assert receipt["oracle_complete"] is True
    canonical = receipt["canonical_outcome"]
    assert canonical["overall_status"] == expected_status
    assert canonical["node_outcomes"] == [
        {"node_id": "test_case.py::test_case", "outcome": expected_outcome}
    ]


def test_actual_pytest_setup_and_teardown_outcomes_are_complete(tmp_path: Path) -> None:
    project = tmp_path / "fixture-phases"
    project.mkdir()
    (project / "test_fixtures.py").write_text(
        """import pytest

@pytest.fixture
def setup_error():
    raise RuntimeError("setup")

@pytest.fixture
def setup_skip():
    pytest.skip("setup")

@pytest.fixture
def teardown_error():
    yield
    raise RuntimeError("teardown")

@pytest.fixture
def teardown_skip():
    yield
    pytest.skip("teardown")

def test_setup_error(setup_error):
    pass

def test_setup_skip(setup_skip):
    pass

def test_teardown_error(teardown_error):
    pass

def test_teardown_skip(teardown_skip):
    pass
""",
        encoding="utf-8",
    )
    output = tmp_path / "fixture-phases.json"

    completed = _run_capture(project, output, "-q")

    assert completed.returncode == 0, completed.stderr
    receipt = _receipt(output)
    assert receipt["pytest_exit_code"] == 1
    assert receipt["oracle_complete"] is True
    assert [row["outcome"] for row in receipt["canonical_outcome"]["node_outcomes"]] == [
        "error",
        "skipped",
        "error",
        "skipped",
    ]
    reports = [event for event in receipt["raw_events"] if event["kind"] == "report"]
    assert all(
        any(row["node_id"] == node_id and row["phase"] == "teardown" for row in reports)
        for node_id in receipt["canonical_outcome"]["collection_node_ids"]
    )


@pytest.mark.parametrize(
    ("source", "expected_status", "expected_exit", "oracle_complete"),
    [
        ("", "no_tests", 5, True),
        ("raise RuntimeError('collect')\n", "collection_error", 2, False),
        (
            "def test_interrupt():\n    raise KeyboardInterrupt()\n",
            "interrupted",
            2,
            False,
        ),
    ],
)
def test_actual_pytest_terminal_statuses(
    tmp_path: Path,
    source: str,
    expected_status: str,
    expected_exit: int,
    oracle_complete: bool,
) -> None:
    project = tmp_path / expected_status
    project.mkdir()
    if source:
        (project / "test_terminal.py").write_text(source, encoding="utf-8")
    output = tmp_path / f"{expected_status}.json"

    completed = _run_capture(project, output, "-q")

    assert completed.returncode == 0, completed.stderr
    receipt = _receipt(output)
    assert receipt["pytest_exit_code"] == expected_exit
    assert receipt["canonical_outcome"]["overall_status"] == expected_status
    assert receipt["oracle_complete"] is oracle_complete
    assert receipt["authorizes_reuse"] is False
    collection_captured = any(
        event["kind"] == "collection" for event in receipt["raw_events"]
    )
    if collection_captured:
        assert "terminal pytest failure occurred without a collection snapshot" not in receipt[
            "incompleteness_notes"
        ]


def test_actual_pytest_internal_error(tmp_path: Path) -> None:
    project = tmp_path / "internal"
    project.mkdir()
    (project / "conftest.py").write_text(
        "def pytest_sessionstart(session):\n    raise RuntimeError('internal')\n",
        encoding="utf-8",
    )
    output = tmp_path / "internal.json"

    completed = _run_capture(project, output, "-q")

    assert completed.returncode == 2
    receipt = _receipt(output)
    assert receipt["pytest_exit_code"] == 3
    assert any(event["kind"] == "internal_error" for event in receipt["raw_events"])
    assert receipt["capture_valid"] is False
    assert receipt["canonical_outcome"] is None
    assert "pytest emitted an internal error" in receipt["refusal_reasons"]
    assert receipt["oracle_complete"] is False


def test_duplicate_or_incomplete_events_fail_closed() -> None:
    duplicate = [
        {"sequence": 0, "kind": "collection", "node_ids": ["test_a.py::test_a"]},
        _report(1, phase="setup"),
        _report(2, phase="setup"),
        {"sequence": 3, "kind": "session_finish", "exit_code": 1},
    ]
    incomplete = [
        {"sequence": 0, "kind": "collection", "node_ids": ["test_a.py::test_a"]},
        _report(1, phase="setup"),
        _report(2, phase="call", outcome="failed"),
        {"sequence": 3, "kind": "session_finish", "exit_code": 1},
    ]

    with pytest.raises(CaptureRefused, match="duplicate"):
        canonicalize_events(duplicate, 1)
    with pytest.raises(CaptureRefused, match="incomplete phase"):
        canonicalize_events(incomplete, 1)


@pytest.mark.parametrize(
    ("events", "exit_code", "message"),
    [
        (
            [{"sequence": 0, "kind": "collection", "node_ids": []}],
            0,
            "no final session_finish",
        ),
        (
            [
                {"sequence": 0, "kind": "collection", "node_ids": []},
                {"sequence": 1, "kind": "session_finish", "exit_code": 1},
            ],
            0,
            "contradicts pytest",
        ),
        (
            [
                {"sequence": 0, "kind": "collection", "node_ids": []},
                {"sequence": 1, "kind": "unknown"},
                {"sequence": 2, "kind": "session_finish", "exit_code": 0},
            ],
            0,
            "unknown kind",
        ),
    ],
)
def test_session_completion_and_event_kinds_fail_closed(
    events: list[dict[str, object]], exit_code: int, message: str
) -> None:
    with pytest.raises(CaptureRefused, match=message):
        canonicalize_events(events, exit_code)


def test_internal_error_without_collection_is_explicitly_partial() -> None:
    events = [
        {
            "sequence": 0,
            "kind": "internal_error",
            "longrepr": "boom",
            "longrepr_truncated": False,
        }
    ]

    canonical, oracle_complete, notes = canonicalize_events(events, 3)

    assert canonical["overall_status"] == "internal_error"
    assert canonical["collection_node_ids"] == []
    assert oracle_complete is False
    assert notes == ["terminal pytest failure occurred without a collection snapshot"]


def test_successful_empty_collection_is_never_a_full_oracle() -> None:
    events = [
        {"sequence": 0, "kind": "collection", "node_ids": []},
        {"sequence": 1, "kind": "session_finish", "exit_code": 0},
    ]

    canonical, oracle_complete, notes = canonicalize_events(events, 0)

    assert canonical["overall_status"] == "passed"
    assert canonical["collection_node_ids"] == []
    assert oracle_complete is False
    assert notes == [
        "pytest exited successfully with an empty observed collection; "
        "selector deselection cannot establish a full-suite oracle"
    ]


def test_session_finish_records_status_after_inner_plugin_mutation(
    tmp_path: Path,
) -> None:
    project = tmp_path / "terminal-hook-order"
    project.mkdir()
    observed = project / "inner-hook.txt"
    (project / "conftest.py").write_text(
        "from pathlib import Path\n"
        "import pytest\n\n"
        "@pytest.hookimpl(trylast=True)\n"
        "def pytest_sessionfinish(session, exitstatus):\n"
        f"    Path({str(observed)!r}).write_text(str(int(exitstatus)), encoding='utf-8')\n"
        "    if exitstatus == pytest.ExitCode.NO_TESTS_COLLECTED:\n"
        "        session.exitstatus = pytest.ExitCode.OK\n",
        encoding="utf-8",
    )
    output = tmp_path / "terminal-hook-order.json"

    completed = _run_capture(project, output, "-q")

    assert completed.returncode == 0, completed.stderr
    receipt = _receipt(output)
    assert observed.read_text(encoding="utf-8") == "5"
    assert receipt["pytest_exit_code"] == 0
    assert receipt["raw_events"][-1] == {
        "sequence": 1,
        "kind": "session_finish",
        "exit_code": 0,
    }
    assert receipt["capture_valid"] is True
    assert receipt["oracle_complete"] is False
    assert receipt["canonical_outcome"]["overall_status"] == "passed"


def test_internal_error_refuses_even_when_plugin_clobbers_final_status(
    tmp_path: Path,
) -> None:
    project = tmp_path / "internal-error-status-clobber"
    project.mkdir()
    observed = project / "session-finish-argument.txt"
    (project / "conftest.py").write_text(
        "from pathlib import Path\n"
        "import pytest\n\n"
        "@pytest.hookimpl(trylast=True)\n"
        "def pytest_collection(session):\n"
        "    raise KeyError('lf')\n\n"
        "@pytest.hookimpl(trylast=True)\n"
        "def pytest_sessionfinish(session, exitstatus):\n"
        f"    Path({str(observed)!r}).write_text(str(int(exitstatus)), encoding='utf-8')\n"
        "    session.exitstatus = pytest.ExitCode.OK\n",
        encoding="utf-8",
    )
    output = tmp_path / "internal-error-status-clobber.json"

    completed = _run_capture(project, output, "-q")

    assert completed.returncode == 2
    receipt = _receipt(output)
    assert observed.read_text(encoding="utf-8") == "3"
    assert receipt["pytest_exit_code"] == 0
    kinds = [event["kind"] for event in receipt["raw_events"]]
    assert kinds.count("internal_error") == 1
    assert kinds[-2:] == ["internal_error", "session_finish"]
    assert receipt["raw_events"][-1]["exit_code"] == 0
    assert receipt["capture_valid"] is False
    assert receipt["oracle_complete"] is False
    assert receipt["canonical_outcome"] is None
    assert "pytest emitted an internal error" in receipt["refusal_reasons"]


def test_configure_internal_error_is_captured_and_refused(tmp_path: Path) -> None:
    project = tmp_path / "configure-internal-error"
    project.mkdir()
    plugins = tmp_path / "plugins"
    plugins.mkdir()
    (plugins / "pilot_configure_failure.py").write_text(
        "import pytest\n\n"
        "@pytest.hookimpl(trylast=True)\n"
        "def pytest_configure(config):\n"
        "    raise KeyError('lf')\n",
        encoding="utf-8",
    )
    output = tmp_path / "configure-internal-error.json"

    completed = _run_capture(
        project,
        output,
        "-q",
        "-p",
        "pilot_configure_failure",
        pythonpath=plugins,
    )

    assert completed.returncode == 2
    receipt = _receipt(output)
    assert receipt["pytest_exit_code"] == 3
    assert [event["kind"] for event in receipt["raw_events"]] == [
        "internal_error"
    ]
    assert receipt["capture_valid"] is False
    assert receipt["canonical_outcome"] is None
    assert receipt["refusal_reasons"] == ["pytest emitted an internal error"]


def test_selector_observation_is_never_a_full_oracle(tmp_path: Path) -> None:
    project = tmp_path / "selector"
    project.mkdir()
    (project / "test_selected.py").write_text(
        "def test_selected():\n    assert True\n", encoding="utf-8"
    )
    output = tmp_path / "selector.json"

    completed = _run_capture(
        project, output, "-q", selector_observation=True
    )

    assert completed.returncode == 0, completed.stderr
    receipt = _receipt(output)
    assert receipt["selector_observation"] is True
    assert receipt["capture_valid"] is True
    assert receipt["oracle_complete"] is False
    assert receipt["canonical_outcome"]["reuse_claims"] == []
    assert receipt["incompleteness_notes"][-1] == (
        "selector observation covers only the collection pytest exposed after "
        "selection; it cannot establish a full-suite oracle"
    )


def test_observes_origin_of_module_loaded_by_selected_test(tmp_path: Path) -> None:
    project = tmp_path / "module-origin"
    project.mkdir()
    module = project / "pilot_selected_origin.py"
    module.write_text("VALUE = 42\n", encoding="utf-8")
    (project / "test_origin.py").write_text(
        "import pilot_selected_origin\n\n"
        "def test_value():\n"
        "    assert pilot_selected_origin.VALUE == 42\n",
        encoding="utf-8",
    )
    output = tmp_path / "module-origin.json"

    completed = _run_capture(
        project,
        output,
        "-q",
        observe_modules=("pilot_selected_origin",),
    )

    assert completed.returncode == 0, completed.stderr
    observed = _receipt(output)["observed_module_origins"]["pilot_selected_origin"]
    assert observed["loaded"] is True
    assert Path(observed["file"]).resolve() == module.resolve()
    assert Path(observed["spec_origin"]).resolve() == module.resolve()


def test_observing_missing_module_does_not_import_it(tmp_path: Path) -> None:
    project = tmp_path / "module-not-imported"
    project.mkdir()
    marker = project / "imported.txt"
    (project / "pilot_must_not_import.py").write_text(
        "from pathlib import Path\n"
        f"Path({str(marker)!r}).write_text('imported', encoding='utf-8')\n",
        encoding="utf-8",
    )
    (project / "test_plain.py").write_text(
        "def test_plain():\n    assert True\n", encoding="utf-8"
    )
    output = tmp_path / "module-not-imported.json"

    completed = _run_capture(
        project,
        output,
        "-q",
        observe_modules=("pilot_must_not_import",),
    )

    assert completed.returncode == 0, completed.stderr
    assert not marker.exists()
    assert _receipt(output)["observed_module_origins"] == {
        "pilot_must_not_import": {
            "loaded": False,
            "file": None,
            "spec_origin": None,
        }
    }


def test_raw_event_aggregate_is_bounded(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(pytest_capture, "MAX_RAW_EVENT_BYTES", 80)
    plugin = pytest_capture.PytestEventCapture()

    plugin._append("collection", node_ids=["test_a.py::test_a"])
    plugin._append("session_finish", exit_code=0)

    assert plugin.refusals == ["raw event evidence exceeds 80 bytes"]
    assert len(plugin.events) < 2


def test_unencodable_raw_event_refuses_without_crashing() -> None:
    plugin = pytest_capture.PytestEventCapture()

    plugin._append("collection", node_ids=["\ud800"])

    assert plugin.events == []
    assert plugin.refusals == [
        "raw event evidence is not encodable: UnicodeEncodeError"
    ]


def test_output_is_exclusive_and_pytest_is_not_started(tmp_path: Path) -> None:
    project = tmp_path / "exclusive"
    project.mkdir()
    marker = tmp_path / "executed.txt"
    (project / "test_marker.py").write_text(
        f"from pathlib import Path\nPath({str(marker)!r}).write_text('ran')\n",
        encoding="utf-8",
    )
    output = tmp_path / "existing.json"
    output.write_text("sentinel", encoding="utf-8")

    completed = _run_capture(project, output, "-q")

    assert completed.returncode == 2
    assert output.read_text(encoding="utf-8") == "sentinel"
    assert not marker.exists()
