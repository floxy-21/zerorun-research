from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import FrozenInstanceError
import os
from pathlib import Path
import signal
import threading
import time

import pytest

from zerorun import hermetic_key


def _write_module(path: Path, *, operator: str = "+") -> None:
    path.write_text(
        "VALUE = 7\n\n"
        "class Box:\n"
        "    scale = 2\n\n"
        "    def apply(self, value):\n"
        f"        return value {operator} self.scale\n\n"
        "def selected(value):\n"
        f"    return value {operator} VALUE\n",
        encoding="utf-8",
    )


def _records(root: Path, relative: str = "module.py") -> list[dict]:
    return hermetic_key._symbol_records(
        root,
        (
            f"{relative}::@module-state",
            f"{relative}::@binding:VALUE",
            f"{relative}::Box.@class-state",
            f"{relative}::Box.apply",
            f"{relative}::selected",
        ),
        session=hermetic_key.FingerprintSession(root),
    )


def test_process_cache_reuses_only_parse_and_projection_not_stable_read(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    source = tmp_path / "module.py"
    _write_module(source)
    hermetic_key.clear_symbol_content_caches()
    real_read = hermetic_key.read_stable_file_bytes
    real_parse = hermetic_key.ast.parse
    calls = {"read": 0, "parse": 0}

    def counted_read(path: Path) -> bytes:
        calls["read"] += 1
        return real_read(path)

    def counted_parse(*args, **kwargs):
        calls["parse"] += 1
        return real_parse(*args, **kwargs)

    monkeypatch.setattr(hermetic_key, "read_stable_file_bytes", counted_read)
    monkeypatch.setattr(hermetic_key.ast, "parse", counted_parse)
    first = _records(tmp_path)
    second = _records(tmp_path)

    assert second == first
    assert calls == {"read": 2, "parse": 1}
    assert len(hermetic_key._SYMBOL_ANALYSIS_CACHE) == 1
    assert len(hermetic_key._SYMBOL_PROJECTION_CACHE) == 5


def test_cached_analysis_and_projection_are_deeply_immutable(
    tmp_path: Path,
) -> None:
    _write_module(tmp_path / "module.py")
    hermetic_key.clear_symbol_content_caches()
    _records(tmp_path)
    loaded = next(iter(hermetic_key._SYMBOL_ANALYSIS_CACHE.values()))[1]
    match = loaded.matches["selected"][0]
    projection = next(iter(hermetic_key._SYMBOL_PROJECTION_CACHE.values()))[1]

    with pytest.raises(TypeError):
        loaded.matches["forged"] = ()  # type: ignore[index]
    with pytest.raises(TypeError):
        loaded.binding_projections["VALUE"] = "forged"  # type: ignore[index]
    with pytest.raises(FrozenInstanceError):
        match.source = "forged"  # type: ignore[misc]
    with pytest.raises(FrozenInstanceError):
        projection.sha256 = "0" * 64  # type: ignore[misc]


def test_same_size_restored_mtime_mutation_cannot_reuse_cached_parse(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    source = tmp_path / "module.py"
    _write_module(source, operator="+")
    original_stat = source.stat()
    hermetic_key.clear_symbol_content_caches()
    real_parse = hermetic_key.ast.parse
    parse_calls = 0

    def counted_parse(*args, **kwargs):
        nonlocal parse_calls
        parse_calls += 1
        return real_parse(*args, **kwargs)

    monkeypatch.setattr(hermetic_key.ast, "parse", counted_parse)
    before = _records(tmp_path)
    original_size = source.stat().st_size
    _write_module(source, operator="-")
    assert source.stat().st_size == original_size
    os.utime(
        source,
        ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns),
    )
    after = _records(tmp_path)

    assert after != before
    assert parse_calls == 2
    assert len(hermetic_key._SYMBOL_ANALYSIS_CACHE) == 2


def test_raw_newline_spelling_is_intentionally_action_significant(
    tmp_path: Path,
) -> None:
    source = tmp_path / "module.py"
    lf_source = "VALUE = 7\n\ndef selected(value):\n    return value + VALUE\n"
    source.write_bytes(lf_source.encode("utf-8"))
    hermetic_key.clear_symbol_content_caches()
    selector = ("module.py::selected",)
    lf_records = hermetic_key._symbol_records(
        tmp_path,
        selector,
        session=hermetic_key.FingerprintSession(tmp_path),
    )

    source.write_bytes(lf_source.replace("\n", "\r\n").encode("utf-8"))
    crlf_records = hermetic_key._symbol_records(
        tmp_path,
        selector,
        session=hermetic_key.FingerprintSession(tmp_path),
    )

    assert crlf_records != lf_records
    assert crlf_records[0]["sha256"] != lf_records[0]["sha256"]
    assert len(hermetic_key._SYMBOL_ANALYSIS_CACHE) == 2


def test_mutation_after_one_stable_read_is_seen_by_independent_pass(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    source = tmp_path / "module.py"
    _write_module(source, operator="+")
    hermetic_key.clear_symbol_content_caches()
    real_read = hermetic_key.read_stable_file_bytes
    mutated = False

    def racing_read(path: Path) -> bytes:
        nonlocal mutated
        snapshot = real_read(path)
        if not mutated:
            mutated = True
            _write_module(source, operator="-")
        return snapshot

    monkeypatch.setattr(hermetic_key, "read_stable_file_bytes", racing_read)
    before = _records(tmp_path)
    after = _records(tmp_path)

    assert mutated is True
    assert after != before
    assert len(hermetic_key._SYMBOL_ANALYSIS_CACHE) == 2


def test_identical_bytes_share_analysis_but_keep_path_projection_semantics(
    tmp_path: Path,
) -> None:
    _write_module(tmp_path / "first.py")
    _write_module(tmp_path / "second.py")
    hermetic_key.clear_symbol_content_caches()

    first = _records(tmp_path, "first.py")
    second = _records(tmp_path, "second.py")

    assert len(hermetic_key._SYMBOL_ANALYSIS_CACHE) == 1
    assert len(hermetic_key._SYMBOL_PROJECTION_CACHE) == 10
    assert [row["sha256"] for row in first] == [row["sha256"] for row in second]
    assert {row["path"] for row in first} == {"first.py"}
    assert {row["path"] for row in second} == {"second.py"}


def test_symbol_content_caches_are_thread_safe_and_deterministic(
    tmp_path: Path,
) -> None:
    _write_module(tmp_path / "module.py")
    hermetic_key.clear_symbol_content_caches()
    gate = threading.Barrier(12)

    def fingerprint(_index: int) -> list[dict]:
        gate.wait(timeout=10)
        return _records(tmp_path)

    with ThreadPoolExecutor(max_workers=12) as executor:
        results = list(executor.map(fingerprint, range(12)))

    assert all(result == results[0] for result in results)
    assert len(hermetic_key._SYMBOL_ANALYSIS_CACHE) == 1
    assert len(hermetic_key._SYMBOL_PROJECTION_CACHE) == 5


@pytest.mark.skipif(not hasattr(os, "fork"), reason="requires POSIX fork")
def test_forked_child_reinitializes_cache_lock_and_state(tmp_path: Path) -> None:
    _write_module(tmp_path / "module.py")
    hermetic_key.clear_symbol_content_caches()
    _records(tmp_path)
    acquired = threading.Event()
    release = threading.Event()

    def hold_inherited_lock() -> None:
        with hermetic_key._SYMBOL_CACHE_LOCK:
            acquired.set()
            release.wait(timeout=10)

    holder = threading.Thread(target=hold_inherited_lock)
    holder.start()
    assert acquired.wait(timeout=5)
    read_fd, write_fd = os.pipe()
    child_pid = os.fork()
    if child_pid == 0:  # pragma: no cover - assertions execute in parent
        try:
            os.close(read_fd)
            hermetic_key.clear_symbol_content_caches()
            result = _records(tmp_path)
            os.write(write_fd, b"ok" if result else b"empty")
            os._exit(0)
        except BaseException:
            os._exit(1)

    os.close(write_fd)
    status = None
    payload = b""
    try:
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            waited_pid, candidate_status = os.waitpid(child_pid, os.WNOHANG)
            if waited_pid == child_pid:
                status = candidate_status
                break
            time.sleep(0.02)
        if status is None:
            os.kill(child_pid, signal.SIGKILL)
            _, status = os.waitpid(child_pid, 0)
        payload = os.read(read_fd, 16)
    finally:
        os.close(read_fd)
        release.set()
        holder.join(timeout=5)

    assert os.waitstatus_to_exitcode(status) == 0
    assert payload == b"ok"


def test_symbol_content_caches_enforce_entry_and_weight_bounds(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setattr(hermetic_key, "_SYMBOL_ANALYSIS_CACHE_MAX_ENTRIES", 2)
    monkeypatch.setattr(hermetic_key, "_SYMBOL_PROJECTION_CACHE_MAX_ENTRIES", 3)
    hermetic_key.clear_symbol_content_caches()
    for index, operator in enumerate(("+", "-", "*")):
        relative = f"module_{index}.py"
        _write_module(tmp_path / relative, operator=operator)
        _records(tmp_path, relative)

    assert len(hermetic_key._SYMBOL_ANALYSIS_CACHE) == 2
    assert len(hermetic_key._SYMBOL_PROJECTION_CACHE) == 3
    assert (
        hermetic_key._SYMBOL_ANALYSIS_CACHE_WEIGHT
        <= hermetic_key._SYMBOL_ANALYSIS_CACHE_MAX_WEIGHT
    )
    assert (
        hermetic_key._SYMBOL_PROJECTION_CACHE_WEIGHT
        <= hermetic_key._SYMBOL_PROJECTION_CACHE_MAX_WEIGHT
    )

    hermetic_key.clear_symbol_content_caches()
    assert not hermetic_key._SYMBOL_ANALYSIS_CACHE
    assert not hermetic_key._SYMBOL_PROJECTION_CACHE
    assert hermetic_key._SYMBOL_ANALYSIS_CACHE_WEIGHT == 0
    assert hermetic_key._SYMBOL_PROJECTION_CACHE_WEIGHT == 0
