from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from types import SimpleNamespace

import pytest

from zerorun import pytest_setup
from zerorun.manifest import load_manifest
from zerorun.model import ConfigurationError
from zerorun.pytest_node_key import node_cache_task
from zerorun.pytest_prepare_cli import prepare_candidate
from zerorun.pytest_runtime import _pytest_command
from zerorun.pytest_setup import (
    ENV_DIR,
    TASK_NAME,
    _project_python_version,
    _requirement_files,
    descriptor_hashes,
    managed_task,
    setup_managed_pytest_task,
)


def _fake_install(_root: Path, *, image: str, requirements, build_dir: Path) -> None:
    site = build_dir / "site-packages" / "pytest"
    site.mkdir(parents=True)
    (site / "__init__.py").write_text("__version__ = 'test'\n", encoding="utf-8")


def _initialize_gitfile_repository(root: Path) -> None:
    git = shutil.which("git")
    if git is None:
        pytest.skip("Git is unavailable")
    separate_git_dir = root.parent / f"{root.name}.git-data"
    subprocess.run(
        [
            git,
            "init",
            "--quiet",
            f"--separate-git-dir={separate_git_dir}",
            str(root),
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=20,
    )
    assert (root / ".git").is_file()


def test_managed_task_is_execute_only_but_node_cache_task_is_cacheable():
    task = managed_task("python@sha256:" + "1" * 64, {"pyproject.toml": "2" * 64})
    assert task.cacheable is False
    assert task.result_only is True
    assert task.closure_reviewed is True
    assert task.command[:4] == ("sh", ".zerorun-env/bin/python", "-m", "pytest")

    node = node_cache_task(task, "tests/test_a.py::test_a")
    assert node.cacheable is True
    assert node.result_only is True


def test_managed_setup_image_resolution_uses_bounded_docker_client_environment(
    monkeypatch, tmp_path: Path
) -> None:
    digest = "a" * 64
    docker_environment = {"PATH": "/trusted/docker/path", "DOCKER_HOST": "test"}
    calls = []
    monkeypatch.setattr(pytest_setup, "_docker", lambda _root: "/usr/bin/docker")
    monkeypatch.setattr(
        pytest_setup,
        "_docker_client_environment",
        lambda _docker: docker_environment,
    )

    def fake_run(command, **kwargs):
        calls.append((command, kwargs))
        if command[1] == "pull":
            return subprocess.CompletedProcess(command, 0, b"pulled", b""), False
        payload = json.dumps(
            [
                {
                    "Os": "linux",
                    "Architecture": "amd64",
                    "RepoDigests": [f"python@sha256:{digest}"],
                }
            ]
        ).encode("utf-8")
        return subprocess.CompletedProcess(command, 0, payload, b""), False

    monkeypatch.setattr(pytest_setup, "_run_bounded_process", fake_run)

    resolved = pytest_setup._resolve_python_image((3, 12), repository_root=tmp_path)

    assert resolved == f"python@sha256:{digest}"
    assert len(calls) == 2
    assert all(call[1]["environment"] is docker_environment for call in calls)
    assert calls[0][1]["timeout_seconds"] == pytest_setup.DOCKER_PULL_TIMEOUT_SECONDS
    assert calls[1][1]["timeout_seconds"] == pytest_setup.DOCKER_INSPECT_TIMEOUT_SECONDS
    assert (
        calls[1][1]["output_limit_bytes"]
        == pytest_setup.DOCKER_METADATA_OUTPUT_LIMIT_BYTES
    )


def test_managed_setup_dependency_timeout_cleans_exact_container(
    monkeypatch, tmp_path: Path
) -> None:
    build_dir = tmp_path / "build"
    build_dir.mkdir()
    docker_environment = {"PATH": "/trusted/docker/path"}
    observed = {}
    monkeypatch.setattr(pytest_setup, "_docker", lambda _root: "/usr/bin/docker")
    monkeypatch.setattr(
        pytest_setup,
        "_docker_client_environment",
        lambda _docker: docker_environment,
    )
    monkeypatch.setattr(pytest_setup, "_new_container_name", lambda _prefix: "zerorun-exact")
    monkeypatch.setattr(pytest_setup.os, "getuid", lambda: 1000, raising=False)
    monkeypatch.setattr(pytest_setup.os, "getgid", lambda: 1000, raising=False)
    def fake_created(command, **kwargs):
        observed["command"] = command
        observed["kwargs"] = kwargs
        raise ConfigurationError(
            "managed dependency installation container execution exceeded the "
            "900 second execution boundary"
        )

    monkeypatch.setattr(pytest_setup, "_run_created_container", fake_created)

    with pytest.raises(ConfigurationError, match="exceeded the 900 second"):
        pytest_setup._install_dependencies(
            tmp_path,
            image="python@sha256:" + "b" * 64,
            requirements=(),
            build_dir=build_dir,
        )

    assert observed["kwargs"]["environment"] is docker_environment
    assert (
        observed["kwargs"]["execution_timeout_seconds"]
        == pytest_setup.DOCKER_EXECUTION_TIMEOUT_SECONDS
    )
    assert observed["kwargs"]["docker"] == "/usr/bin/docker"
    assert observed["kwargs"]["container_name"] == "zerorun-exact"
    command = observed["command"]
    for name, value in pytest_setup.FIXED_CONTAINER_ENV.items():
        assert f"{name}={value}" in command


def test_runtime_accepts_managed_python_launcher():
    task = managed_task("python@sha256:" + "1" * 64, {})
    profile = SimpleNamespace(base_args=(), targets=("tests",))
    command = _pytest_command(task, profile)
    assert command[:4] == ["sh", ".zerorun-env/bin/python", "-m", "pytest"]
    assert command[-2:] == ["-p", "no:cacheprovider"]


def test_managed_setup_writes_execute_only_manifest_after_collection_smoke(
    monkeypatch, tmp_path: Path
):
    (tmp_path / ".git" / "info").mkdir(parents=True)
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_basic.py").write_text(
        "def test_basic():\n    assert 2 + 2 == 4\n",
        encoding="utf-8",
    )
    (tmp_path / "requirements.txt").write_text("packaging==24.2\n", encoding="utf-8")

    image = "python@sha256:" + "a" * 64
    monkeypatch.setattr(
        "zerorun.pytest_setup._resolve_python_image",
        lambda _version, *, repository_root: image,
    )
    monkeypatch.setattr("zerorun.pytest_setup._install_dependencies", _fake_install)
    monkeypatch.setattr(
        "zerorun.pytest_setup.inspect_runtime",
        lambda task, **_kwargs: {"requested_image": task.image},
    )
    monkeypatch.setattr(
        "zerorun.pytest_setup.collect_pytest",
        lambda *args, **kwargs: (
            {
                "nodeids": ["tests/test_basic.py::test_basic"],
                "items": [{"nodeid": "tests/test_basic.py::test_basic"}],
                "collection_sha256": "b" * 64,
            },
            12.5,
        ),
    )

    result = setup_managed_pytest_task(tmp_path)

    assert result["status"] == "PYTEST_TASK_READY"
    assert result["task"] == TASK_NAME
    assert result["task_level_reuse"] is False
    assert result["pytest_node_reuse"] is False
    assert result["collected_nodes"] == 1

    manifest = load_manifest(tmp_path / ".zerorun.json")
    task = manifest.tasks[TASK_NAME]
    assert task.cacheable is False
    assert task.image == image
    assert task.command[:4] == ("sh", ".zerorun-env/bin/python", "-m", "pytest")

    wrapper = (tmp_path / ENV_DIR / "bin" / "python").read_text(encoding="utf-8")
    assert '${PYTHONPATH:+$PYTHONPATH:}' in wrapper
    assert wrapper.index('${PYTHONPATH:+$PYTHONPATH:}') < wrapper.index(
        "/workspace/.zerorun-env/site-packages"
    )

    checker = (tmp_path / ENV_DIR / "check.py").read_text(encoding="utf-8")
    assert "WATCHED" in checker
    assert "requirements.txt" in checker
    assert "pyproject.toml" in checker

    exclude = (tmp_path / ".git" / "info" / "exclude").read_text(encoding="utf-8")
    assert f"/{ENV_DIR}/" in exclude


def test_requirement_directives_and_local_sources_are_refused(tmp_path: Path):
    for value in (
        "-r other.txt\n",
        "git+https://example.invalid/repo.git\n",
        "pkg @ https://example.invalid/pkg.whl\n",
        "../local-package\n",
    ):
        (tmp_path / "requirements.txt").write_text(value, encoding="utf-8")
        with pytest.raises(ConfigurationError):
            _requirement_files(tmp_path)


@pytest.mark.parametrize(
    ("name", "operation"),
    (
        (".python-version", "python-version"),
        ("requirements.txt", "requirements"),
        ("pyproject.toml", "descriptors"),
        ("setup.cfg", "descriptors"),
        ("setup.py", "descriptors"),
    ),
)
def test_managed_setup_never_reads_linked_repository_descriptors(
    tmp_path: Path, name: str, operation: str
) -> None:
    outside = tmp_path.parent / f"{tmp_path.name}-{name.replace('.', '_')}-outside"
    outside.write_text("3.12\n" if name == ".python-version" else "secret\n", encoding="utf-8")
    try:
        (tmp_path / name).symlink_to(outside)
    except OSError as exc:
        pytest.skip(f"symbolic links are unavailable: {exc}")

    with pytest.raises(ConfigurationError, match="linked managed-setup descriptor"):
        if operation == "python-version":
            _project_python_version(tmp_path)
        elif operation == "requirements":
            _requirement_files(tmp_path)
        else:
            descriptor_hashes(tmp_path)


@pytest.mark.parametrize("mutation", ["truncate", "grow", "rewrite"])
def test_managed_setup_rejects_descriptor_mutation_during_read(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    mutation: str,
) -> None:
    path = tmp_path / "requirements.txt"
    original_bytes = b"pytest==9.1.1\n"
    path.write_bytes(original_bytes)
    real_read = pytest_setup.os.read
    mutated = False

    def racing_read(descriptor: int, size: int) -> bytes:
        nonlocal mutated
        if not mutated:
            mutated = True
            before = path.stat()
            if mutation == "truncate":
                replacement = original_bytes[:-1]
            elif mutation == "grow":
                replacement = original_bytes + b" "
            else:
                replacement = b"pytest==9.1.2\n"
            path.write_bytes(replacement)
            os.utime(
                path,
                ns=(before.st_atime_ns, before.st_mtime_ns + 1_000_000_000),
            )
        return real_read(descriptor, size)

    monkeypatch.setattr(pytest_setup.os, "read", racing_read)
    with pytest.raises(ConfigurationError, match="changed during validation"):
        pytest_setup._safe_descriptor_bytes(tmp_path, path)


def test_managed_setup_accepts_codex_linked_worktree_git_file(
    monkeypatch, tmp_path: Path
) -> None:
    _initialize_gitfile_repository(tmp_path)
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_basic.py").write_text(
        "def test_basic():\n    assert True\n", encoding="utf-8"
    )
    image = "python@sha256:" + "e" * 64
    monkeypatch.setattr(
        "zerorun.pytest_setup._resolve_python_image",
        lambda _version, *, repository_root: image,
    )
    monkeypatch.setattr("zerorun.pytest_setup._install_dependencies", _fake_install)
    monkeypatch.setattr(
        "zerorun.pytest_setup.inspect_runtime",
        lambda task, **_kwargs: {"requested_image": task.image},
    )
    monkeypatch.setattr(
        "zerorun.pytest_setup.collect_pytest",
        lambda *args, **kwargs: (
            {
                "nodeids": ["tests/test_basic.py::test_basic"],
                "items": [{"nodeid": "tests/test_basic.py::test_basic"}],
                "collection_sha256": "f" * 64,
            },
            1.0,
        ),
    )

    result = setup_managed_pytest_task(tmp_path)

    assert result["status"] == "PYTEST_TASK_READY"
    assert (tmp_path / ".git").is_file()
    assert (tmp_path / ".git").read_text(encoding="utf-8").startswith("gitdir:")


def test_prepare_candidate_bootstraps_when_manifest_is_absent(monkeypatch, tmp_path: Path):
    (tmp_path / ".git").mkdir()

    image = "python@sha256:" + "c" * 64

    def fake_setup(root: Path, *, targets=None):
        payload = {
            "version": 2,
            "tasks": {
                TASK_NAME: {
                    "command": ["sh", ".zerorun-env/bin/python", "-m", "pytest"],
                    "inputs": [".zerorun-env"],
                    "outputs": [],
                    "env": [],
                    "cacheable": False,
                    "unsafe_effects": [],
                    "cache_streams": False,
                    "result_only": True,
                    "closure_reviewed": True,
                    "image": image,
                    "platform": "linux/amd64",
                }
            },
        }
        (root / ".zerorun.json").write_text(json.dumps(payload), encoding="utf-8")
        return {"status": "PYTEST_TASK_READY"}

    seen = {}

    def fake_qualify(manifest, *, task_name, targets, output):
        seen["root"] = manifest.root
        seen["task"] = task_name
        seen["targets"] = targets
        seen["output"] = output
        return {
            "candidate_sha256": "d" * 64,
            "task": task_name,
            "targets": list(targets),
            "nodes": {
                "tests/test_basic.py::test_basic": {
                    "reviewable": False,
                    "fresh_required": True,
                }
            },
        }

    monkeypatch.setattr(
        "zerorun.pytest_prepare_cli.setup_managed_pytest_task",
        fake_setup,
    )
    monkeypatch.setattr(
        "zerorun.pytest_prepare_cli.qualify_pytest_candidate",
        fake_qualify,
    )

    result = prepare_candidate(tmp_path, targets=("tests",))

    assert result["task"] == TASK_NAME
    assert seen["root"] == tmp_path
    assert seen["task"] == TASK_NAME
    assert seen["targets"] == ("tests",)
    assert seen["output"] == tmp_path / ".zerorun-pytest.candidate.json"


def test_existing_invalid_manifest_is_never_overwritten(monkeypatch, tmp_path: Path):
    (tmp_path / ".git").mkdir()
    original = "{ definitely not json }\n"
    (tmp_path / ".zerorun.json").write_text(original, encoding="utf-8")
    called = {"setup": False}

    def fake_setup(*args, **kwargs):
        called["setup"] = True
        raise AssertionError("setup must not run over an existing manifest")

    monkeypatch.setattr(
        "zerorun.pytest_prepare_cli.setup_managed_pytest_task",
        fake_setup,
    )

    with pytest.raises(ConfigurationError):
        prepare_candidate(tmp_path)

    assert called["setup"] is False
    assert (tmp_path / ".zerorun.json").read_text(encoding="utf-8") == original


def test_managed_setup_rejects_preseeded_manifest_temp_symlink_before_work(
    monkeypatch, tmp_path: Path
) -> None:
    (tmp_path / ".git").mkdir()
    outside = tmp_path.parent / f"{tmp_path.name}-outside-manifest"
    outside.write_text("do not replace\n", encoding="utf-8")
    try:
        (tmp_path / ".zerorun.json.tmp").symlink_to(outside)
    except OSError as exc:
        pytest.skip(f"symbolic links are unavailable: {exc}")
    calls = []
    monkeypatch.setattr(
        "zerorun.pytest_setup._resolve_python_image",
        lambda *args, **kwargs: calls.append((args, kwargs)),
    )

    with pytest.raises(ConfigurationError, match=r"\.zerorun\.json\.tmp already exists"):
        setup_managed_pytest_task(tmp_path)

    assert calls == []
    assert outside.read_text(encoding="utf-8") == "do not replace\n"


def test_prepare_candidate_never_inherits_parent_repository_manifest(
    monkeypatch, tmp_path: Path
) -> None:
    parent = tmp_path / "parent"
    child = parent / "child"
    (parent / ".git").mkdir(parents=True)
    (child / ".git").mkdir(parents=True)
    (parent / ".zerorun.json").write_text(
        json.dumps({"version": 1, "tasks": {"parent": {"command": ["true"]}}}),
        encoding="utf-8",
    )

    class ExpectedSetup(Exception):
        pass

    def expected_child_setup(root: Path, *, targets=None):
        assert root == child.resolve()
        raise ExpectedSetup

    monkeypatch.setattr(
        "zerorun.pytest_prepare_cli.setup_managed_pytest_task",
        expected_child_setup,
    )

    with pytest.raises(ExpectedSetup):
        prepare_candidate(child)
