from __future__ import annotations

from contextlib import nullcontext
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from zerorun.api import run_tasks
from zerorun.manifest import load_manifest


IMAGE = "example.invalid/python@sha256:" + "a" * 64
RUNTIME = {
    "runtime": "docker",
    "requested_image": IMAGE,
    "requested_digest": "sha256:" + "a" * 64,
    "platform": "linux/amd64",
    "image_id": "sha256:" + "b" * 64,
    "repo_digests": [IMAGE],
    "rootfs": {"type": "layers", "layers": ["sha256:" + "c" * 64]},
    "config_sha256": "d" * 64,
}


class HermeticBatchUncertaintyTests(unittest.TestCase):
    def test_one_uncertain_selector_does_not_evict_unrelated_batch_hit(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "module.py").write_text(
            "def keep():\n"
            "    return 1\n",
            encoding="utf-8",
        )
        (root / "static.txt").write_text("stable input\n", encoding="utf-8")
        base = {
            "command": ["python", "-c", "pass"],
            "inputs": ["static.txt"],
            "outputs": [],
            "cacheable": True,
            "unsafe_effects": [],
            "env": [],
            "cache_streams": False,
            "result_only": True,
            "closure_reviewed": True,
            "image": IMAGE,
            "platform": "linux/amd64",
        }
        manifest_path = root / ".zerorun.json"
        manifest_path.write_text(
            json.dumps(
                {
                    "version": 2,
                    "tasks": {
                        "uncertain": {
                            **base,
                            "input_symbols": ["module.py::removed"],
                        },
                        "safe": {
                            **base,
                            "input_symbols": ["module.py::keep"],
                        },
                    },
                }
            ),
            encoding="utf-8",
        )
        manifest = load_manifest(manifest_path)
        tasks = (manifest.tasks["uncertain"], manifest.tasks["safe"])
        streams = {task.name: io.BytesIO() for task in tasks}

        def cached_result(store, task, key, fingerprint):
            if task.name == "safe":
                return {"execution_ms": 120.0}
            self.fail("projection-uncertain task must not perform cache lookup")

        with patch("zerorun.hermetic.validate_host"), patch(
            "zerorun.hermetic.inspect_runtime", return_value=RUNTIME
        ), patch(
            "zerorun.hermetic.hermetic_environment", return_value=({}, {})
        ), patch(
            "zerorun.hermetic._action_lock", side_effect=lambda *args, **kwargs: nullcontext()
        ), patch(
            "zerorun.hermetic._load_result_entry", side_effect=cached_result
        ), patch(
            "zerorun.hermetic._docker_execute", return_value=(0, 75.0, b"", b"")
        ) as execute, patch("zerorun.hermetic._save_result_entry") as save:
            results = run_tasks(
                manifest,
                tasks,
                stdout_by_task=streams,
                stderr_by_task=streams,
            )

        by_task = {result.task: result for result in results}
        self.assertEqual(by_task["uncertain"].status, "MISS_EXECUTED")
        self.assertEqual(by_task["uncertain"].exit_code, 0)
        self.assertIsNone(by_task["uncertain"].cache_key)
        self.assertIn("cache bypassed", by_task["uncertain"].reason)
        self.assertEqual(by_task["safe"].status, "HIT_REUSED")
        self.assertEqual(by_task["safe"].exit_code, 0)
        self.assertIsNotNone(by_task["safe"].cache_key)
        execute.assert_called_once()
        self.assertEqual(execute.call_args.args[1].name, "uncertain")
        save.assert_not_called()


if __name__ == "__main__":
    unittest.main()
