from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

from zerorun import pytest_runtime


def _run_single_pass_plugin(
    root: Path,
    *,
    baseline: dict | None,
    fresh_nodeids: list[str],
) -> dict:
    support = root / "support"
    support.mkdir(exist_ok=True)
    (support / "zerorun_single_pass_plugin.py").write_text(
        pytest_runtime._SINGLE_PASS_PLUGIN,
        encoding="utf-8",
    )
    request = support / "request.json"
    output = support / "output.json"
    request.write_text(
        json.dumps(
            {
                "baseline_collection": baseline,
                "fresh_nodeids": fresh_nodeids,
            },
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    output.write_text("{}", encoding="utf-8")
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(support)
    # Match ZeroRun's container invariant: collection and execution must read
    # source, never an adjacent timestamp-based ``.pyc`` left by the preceding
    # baseline process.  Several CPython/pytest combinations otherwise accept
    # stale bytecode when a test file is rewritten to same-length contents
    # within one filesystem timestamp tick (as the reorder regression does).
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONPYCACHEPREFIX"] = str(support / "isolated-pycache")
    environment["ZERORUN_SELECTION_INPUT"] = str(request)
    environment["ZERORUN_SELECTION_OUTPUT"] = str(output)
    process = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-q",
            "-p",
            "no:cacheprovider",
            "-p",
            "zerorun_single_pass_plugin",
            "--rootdir",
            str(root),
            "test_target.py",
        ],
        cwd=root,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert process.returncode in {0, 5}, process.stdout + process.stderr
    return json.loads(output.read_text(encoding="utf-8"))


def _baseline(root: Path) -> dict:
    result = _run_single_pass_plugin(root, baseline=None, fresh_nodeids=[])
    assert result["mode"] == "whole-target-fresh"
    assert result["executed_nodeids"] == result["fresh_nodeids"]
    return result["collection"]


def test_added_node_executes_fresh_while_identical_nodes_align(tmp_path: Path) -> None:
    target = tmp_path / "test_target.py"
    target.write_text(
        "def test_a():\n    assert True\n\n"
        "def test_b():\n    assert True\n",
        encoding="utf-8",
    )
    baseline = _baseline(tmp_path)
    target.write_text(
        target.read_text(encoding="utf-8")
        + "\ndef test_added():\n    assert True\n",
        encoding="utf-8",
    )

    result = _run_single_pass_plugin(
        tmp_path,
        baseline=baseline,
        fresh_nodeids=[],
    )

    assert result["mode"] == "per-node-aligned-incremental", result
    assert result["reused_nodeids"] == [
        "test_target.py::test_a",
        "test_target.py::test_b",
    ]
    assert result["fresh_nodeids"] == ["test_target.py::test_added"]
    assert result["executed_nodeids"] == result["fresh_nodeids"]


def test_changed_item_identity_executes_fresh_without_poisoning_sibling(
    tmp_path: Path,
) -> None:
    target = tmp_path / "test_target.py"
    target.write_text(
        "def test_a():\n    assert True\n\n"
        "def test_b():\n    assert True\n",
        encoding="utf-8",
    )
    baseline = _baseline(tmp_path)
    target.write_text(
        "def test_a(capsys):\n    print('aligned')\n    assert capsys.readouterr().out == 'aligned\\n'\n\n"
        "def test_b():\n    assert True\n",
        encoding="utf-8",
    )

    result = _run_single_pass_plugin(
        tmp_path,
        baseline=baseline,
        fresh_nodeids=[],
    )

    assert result["mode"] == "per-node-aligned-incremental", result
    assert result["fresh_nodeids"] == ["test_target.py::test_a"]
    assert result["reused_nodeids"] == ["test_target.py::test_b"]
    assert result["executed_nodeids"] == result["fresh_nodeids"]


def test_reordered_shared_nodes_fail_closed_to_whole_target_fresh(
    tmp_path: Path,
) -> None:
    target = tmp_path / "test_target.py"
    target.write_text(
        "def test_a():\n    assert True\n\n"
        "def test_b():\n    assert True\n",
        encoding="utf-8",
    )
    baseline = _baseline(tmp_path)
    target.write_text(
        "def test_b():\n    assert True\n\n"
        "def test_a():\n    assert True\n",
        encoding="utf-8",
    )

    result = _run_single_pass_plugin(
        tmp_path,
        baseline=baseline,
        fresh_nodeids=[],
    )

    assert result["mode"] == "whole-target-fresh"
    assert result["reused_nodeids"] == []
    assert result["fresh_nodeids"] == [
        "test_target.py::test_b",
        "test_target.py::test_a",
    ]
    assert result["executed_nodeids"] == result["fresh_nodeids"]


def test_explicit_miss_never_becomes_aligned_reuse(tmp_path: Path) -> None:
    target = tmp_path / "test_target.py"
    target.write_text(
        "def test_a():\n    assert True\n\n"
        "def test_b():\n    assert True\n",
        encoding="utf-8",
    )
    baseline = _baseline(tmp_path)
    target.write_text(
        target.read_text(encoding="utf-8")
        + "\ndef test_added():\n    assert True\n",
        encoding="utf-8",
    )

    result = _run_single_pass_plugin(
        tmp_path,
        baseline=baseline,
        fresh_nodeids=["test_target.py::test_a"],
    )

    assert result["mode"] == "per-node-aligned-incremental"
    assert result["reused_nodeids"] == ["test_target.py::test_b"]
    assert result["fresh_nodeids"] == [
        "test_target.py::test_a",
        "test_target.py::test_added",
    ]
