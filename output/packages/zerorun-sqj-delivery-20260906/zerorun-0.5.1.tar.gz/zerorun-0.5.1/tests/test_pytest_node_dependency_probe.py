from tools import hermetic_pytest_experiment as experiment
from tools.pytest_node_dependency_probe import _SESSION_NODE, _partition_summary
from tools.pytest_result_dependency_probe import (
    _RESULT_CONSUMER_HOOKS,
    _RESULT_PHASE_HOOKS,
    _RESULT_PLUGIN_SOURCE,
    _annotate_report,
)


def test_partition_summary_attributes_dependencies_to_outer_nodes() -> None:
    partition = experiment.Partition(
        "candidate",
        ("testing/example.py",),
        frozenset({"terminal"}),
    )
    calls = {
        "testing/example.py::test_a": {
            ("src/_pytest/terminal.py", 100, "TerminalReporter.write"),
            ("src/_pytest/cacheprovider.py", 200, "Cache.get"),
        },
        "testing/example.py::test_b": {
            ("src/_pytest/cacheprovider.py", 200, "Cache.get"),
        },
        _SESSION_NODE: {
            ("src/_pytest/terminal.py", 50, "pytest_configure"),
        },
    }

    row = _partition_summary(
        partition,
        ["testing/example.py::test_a", "testing/example.py::test_b"],
        calls,
        123.456,
    )

    assert row["node_count"] == 2
    assert row["nodes_without_tracked_calls"] == 0
    assert row["tracked_file_node_counts"]["src/_pytest/terminal.py"] == 1
    assert row["tracked_file_node_counts"]["src/_pytest/cacheprovider.py"] == 2
    assert row["session_tracked_file_dependencies"]["src/_pytest/terminal.py"] is True
    assert row["session_implementation_call_site_count"] == 1
    assert row["dependency_signature_family_count"] == 2
    assert row["largest_dependency_family_node_count"] == 1
    assert row["largest_dependency_family_fraction"] == 0.5


def test_partition_summary_counts_nodes_without_tracked_calls() -> None:
    partition = experiment.Partition(
        "candidate",
        ("testing/example.py",),
        frozenset(),
    )
    row = _partition_summary(
        partition,
        ["testing/example.py::test_a", "testing/example.py::test_b"],
        {"testing/example.py::test_a": {("src/_pytest/logging.py", 10, "LogCaptureHandler.emit")}},
        1.0,
    )

    assert row["nodes_without_tracked_calls"] == 1
    assert row["dependency_signature_family_count"] == 2
    assert row["tracked_file_node_counts"]["src/_pytest/logging.py"] == 1


def test_result_probe_tracks_result_producers_not_protocol_report_consumers() -> None:
    assert "def pytest_runtest_protocol" not in _RESULT_PLUGIN_SOURCE
    for hook in _RESULT_PHASE_HOOKS:
        assert f"def {hook}" in _RESULT_PLUGIN_SOURCE
    for hook in _RESULT_CONSUMER_HOOKS:
        assert f"def {hook}" not in _RESULT_PLUGIN_SOURCE
    assert "def pytest_collection_finish" in _RESULT_PLUGIN_SOURCE


def test_result_probe_evidence_declares_the_narrower_contract() -> None:
    report = {"profiling_semantics": {"outer_node_context": True}}
    annotated = _annotate_report(report)
    semantics = annotated["profiling_semantics"]

    assert semantics["cached_contract"] == "v2-result-only-success-status"
    assert semantics["node_context_scope"] == "result-producing-hooks-only"
    assert semantics["result_phase_hooks"] == list(_RESULT_PHASE_HOOKS)
    assert semantics["excluded_result_consumers"] == list(_RESULT_CONSUMER_HOOKS)
    assert semantics["outer_node_context"] is False
    assert semantics["result_phase_node_context"] is True
    assert len(semantics["result_plugin_sha256"]) == 64
