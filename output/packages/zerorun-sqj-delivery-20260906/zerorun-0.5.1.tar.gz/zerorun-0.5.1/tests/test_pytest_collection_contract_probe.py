from __future__ import annotations

from tools.pytest_collection_contract_probe import (
    _baseline_contract,
    validate_current_collection,
)


def _row(nodeid: str, digest: str, *, supported: bool = True) -> dict[str, object]:
    return {
        "nodeid": nodeid,
        "identity_sha256": digest,
        "parameter_identity_supported": supported,
        "parameter_identity_uncertainty": [] if supported else ["unsupported"],
    }


def test_baseline_contract_retains_exact_order_and_item_digests() -> None:
    payload = {
        "collection_sha256": "collection",
        "nodeids": ["a", "b"],
        "items": [_row("a", "1"), _row("b", "2")],
    }

    contract = _baseline_contract(payload)

    assert contract["collection_sha256"] == "collection"
    assert contract["nodeids"] == ["a", "b"]
    assert [row["identity_sha256"] for row in contract["items"]] == ["1", "2"]
    assert isinstance(contract["contract_sha256"], str)
    assert len(contract["contract_sha256"]) == 64


def test_current_collection_must_match_order_identity_and_supported_params() -> None:
    expected = {
        "items": [_row("a", "1"), _row("b", "2")],
    }
    current = {
        "items": [_row("a", "1"), _row("b", "2")],
    }

    validation = validate_current_collection(expected, current)

    assert validation["safe"] is True
    assert validation["node_order_equal"] is True
    assert validation["added_nodes"] == []
    assert validation["removed_nodes"] == []
    assert validation["changed_identity_nodes"] == []
    assert validation["unsupported_parameter_nodes"] == []


def test_current_collection_fails_closed_on_order_or_identity_change() -> None:
    expected = {
        "items": [_row("a", "1"), _row("b", "2")],
    }
    reordered = {
        "items": [_row("b", "2"), _row("a", "1")],
    }
    changed = {
        "items": [_row("a", "9"), _row("b", "2")],
    }

    assert validate_current_collection(expected, reordered)["safe"] is False
    changed_validation = validate_current_collection(expected, changed)
    assert changed_validation["safe"] is False
    assert changed_validation["changed_identity_nodes"] == ["a"]


def test_current_collection_fails_closed_on_unsupported_parameter_identity() -> None:
    expected = {"items": [_row("a", "1")]}
    current = {"items": [_row("a", "1", supported=False)]}

    validation = validate_current_collection(expected, current)

    assert validation["safe"] is False
    assert validation["unsupported_parameter_nodes"] == ["a"]
