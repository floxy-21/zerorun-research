from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from zerorun import hermetic_batch_key
from zerorun.hermetic_key import task_fingerprint_v2 as canonical_task_fingerprint_v2
from zerorun.manifest import load_manifest


IMAGE = "example.invalid/python@sha256:" + "a" * 64
RUNTIME = {
    "runtime": "docker",
    "requested_image": IMAGE,
    "requested_digest": "sha256:" + "a" * 64,
    "platform": "linux/amd64",
    "image_id": "sha256:" + "b" * 64,
    "repo_digests": [IMAGE],
    "rootfs": {"type": "layers", "layers": ["sha256:" + "c" * 64]},
    "config_sha256": "d" * 64,
}


class HermeticBatchKeyTests(unittest.TestCase):
    def test_batch_projection_cache_preserves_canonical_action_keys(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "module.py").write_text(
            "VALUE = 1\n\n"
            "def keep():\n"
            "    return VALUE\n",
            encoding="utf-8",
        )
        (root / "static.txt").write_text("stable input\n", encoding="utf-8")
        base = {
            "inputs": ["static.txt"],
            "input_symbols": ["module.py::keep"],
            "outputs": [],
            "cacheable": True,
            "unsafe_effects": [],
            "env": [],
            "cache_streams": False,
            "result_only": True,
            "closure_reviewed": True,
            "image": IMAGE,
            "platform": "linux/amd64",
        }
        manifest_path = root / ".zerorun.json"
        manifest_path.write_text(
            json.dumps(
                {
                    "version": 2,
                    "tasks": {
                        "first": {**base, "command": ["python", "-c", "pass"]},
                        "second": {**base, "command": ["python", "-c", "pass; 1"]},
                    },
                }
            ),
            encoding="utf-8",
        )
        manifest = load_manifest(manifest_path)
        session = hermetic_batch_key.FingerprintSession(root)

        canonical = {
            name: canonical_task_fingerprint_v2(
                manifest,
                task,
                RUNTIME,
                environment_fingerprint={},
            )
            for name, task in manifest.tasks.items()
        }
        real_projection = hermetic_batch_key._symbol_record_from_loaded
        with patch(
            "zerorun.hermetic_batch_key._symbol_record_from_loaded",
            wraps=real_projection,
        ) as projection:
            optimized = {
                name: hermetic_batch_key.task_fingerprint_v2(
                    manifest,
                    task,
                    RUNTIME,
                    environment_fingerprint={},
                    session=session,
                )
                for name, task in manifest.tasks.items()
            }

        self.assertEqual(optimized, canonical)
        self.assertEqual(projection.call_count, 1)


if __name__ == "__main__":
    unittest.main()
