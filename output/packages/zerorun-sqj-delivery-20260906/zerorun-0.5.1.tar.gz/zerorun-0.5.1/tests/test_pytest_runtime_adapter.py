from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from zerorun.hermetic_batch_key import FingerprintSession
from zerorun.manifest import load_manifest
from zerorun.model import ConfigurationError
from zerorun.pytest_node_cache import (
    NodeCacheContext,
    prepare_node_cache,
    publish_verified_successes,
    verify_node_cache_snapshot,
)
from zerorun.pytest_node_key import build_pytest_source_review
from zerorun.pytest_profile import load_pytest_profile
from zerorun import pytest_node_cache, pytest_qualify, pytest_runtime
from zerorun.store import Store


IMAGE = "python@sha256:" + "1" * 64
REVIEW = "2" * 64


def _full_runtime_identity() -> dict:
    return {
        "runtime": "docker",
        "requested_image": IMAGE,
        "requested_digest": IMAGE.rsplit("@", 1)[1],
        "platform": "linux/amd64",
        "image_id": "sha256:" + "3" * 64,
        "repo_digests": [IMAGE],
        "rootfs": {"type": "layers", "layers": ["sha256:" + "4" * 64]},
        "config_sha256": "5" * 64,
    }


def test_profile_refresh_summary_includes_unknown_nodes() -> None:
    decisions = [
        SimpleNamespace(
            status="MISS_UNCERTAIN",
            reason="node action identity is uncertain: selector no longer resolves",
        )
    ]
    required, count, reasons = pytest_runtime._profile_refresh_summary(
        decisions,
        unknown_nodeids=("tests/test_new.py::test_new",),
    )
    assert required is True
    assert count == 2
    assert reasons == [
        "collection contains 1 node(s) absent from the reviewed profile",
        "node action identity is uncertain: selector no longer resolves",
    ]


def test_collection_evidence_recomputes_each_item_identity() -> None:
    collection = _collection()
    assert pytest_runtime._validate_collection_evidence(
        collection,
        label="test collection",
        expected_targets=("tests",),
    ) == collection

    tampered = json.loads(json.dumps(collection))
    tampered["items"][0]["name"] = "different"
    encoded = json.dumps(
        {
            "invocation": tampered["invocation"],
            "items": tampered["items"],
            "nodeids": tampered["nodeids"],
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    import hashlib
    tampered["collection_sha256"] = hashlib.sha256(encoded).hexdigest()
    import pytest
    from zerorun.model import ConfigurationError
    with pytest.raises(ConfigurationError, match="item 0 identity digest mismatch"):
        pytest_runtime._validate_collection_evidence(
            tampered,
            label="test collection",
            expected_targets=("tests",),
        )


def test_single_pass_plugin_attests_actual_runtest_nodeids() -> None:
    assert "def pytest_runtest_logstart(nodeid, location):" in pytest_runtime._SINGLE_PASS_PLUGIN
    assert '_SELECTION_PAYLOAD["executed_nodeids"]' in pytest_runtime._SINGLE_PASS_PLUGIN


def test_collection_evidence_rejects_node_count_and_nested_complexity(
    monkeypatch,
) -> None:
    collection = _collection(extra=True)
    monkeypatch.setattr(pytest_runtime, "PYTEST_MAX_COLLECTION_NODES", 1)
    import pytest
    from zerorun.model import ConfigurationError

    with pytest.raises(ConfigurationError, match="structurally invalid"):
        pytest_runtime._validate_collection_evidence(
            collection,
            label="bounded collection",
            expected_targets=("tests",),
        )

    monkeypatch.setattr(pytest_runtime, "PYTEST_MAX_COLLECTION_NODES", 25_000)
    nested: object = "leaf"
    for _ in range(pytest_runtime.PYTEST_MAX_JSON_DEPTH + 2):
        nested = [nested]
    hostile = _collection()
    hostile["items"][0]["callspec_params"] = {"value": nested}
    unsigned = dict(hostile["items"][0])
    unsigned.pop("identity_sha256")
    import hashlib

    hostile["items"][0]["identity_sha256"] = hashlib.sha256(
        json.dumps(unsigned, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    hostile["collection_sha256"] = hashlib.sha256(
        json.dumps(
            {
                "invocation": hostile["invocation"],
                "items": hostile["items"],
                "nodeids": hostile["nodeids"],
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()
    with pytest.raises(ConfigurationError, match="structural complexity"):
        pytest_runtime._validate_collection_evidence(
            hostile,
            label="bounded collection",
            expected_targets=("tests",),
        )


def test_bounded_json_rejects_oversized_and_linked_evidence(tmp_path: Path) -> None:
    import pytest
    from zerorun.model import ConfigurationError

    oversized = tmp_path / "oversized.json"
    oversized.write_bytes(b" " * 65)
    with pytest.raises(ConfigurationError, match="exceeds the 64-byte"):
        pytest_runtime._read_bounded_json(
            oversized,
            label="hostile evidence",
            limit_bytes=64,
        )

    target = tmp_path / "target.json"
    target.write_text("{}", encoding="utf-8")
    linked = tmp_path / "linked.json"
    try:
        linked.symlink_to(target)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symbolic links unavailable: {exc}")
    with pytest.raises(ConfigurationError, match="must not be a symbolic link"):
        pytest_runtime._read_bounded_json(
            linked,
            label="hostile evidence",
            limit_bytes=64,
        )


@pytest.mark.parametrize("mutation", ["truncate", "grow", "rewrite"])
def test_bounded_json_rejects_in_place_mutation(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    mutation: str,
) -> None:
    path = tmp_path / "evidence.json"
    original_bytes = b"{}\n"
    path.write_bytes(original_bytes)
    real_read = pytest_runtime.os.read
    mutated = False

    def racing_read(descriptor: int, size: int) -> bytes:
        nonlocal mutated
        if not mutated:
            mutated = True
            before = path.stat()
            if mutation == "truncate":
                replacement = b"{"
            elif mutation == "grow":
                replacement = original_bytes + b" "
            else:
                replacement = b"[]\n"
            path.write_bytes(replacement)
            os.utime(
                path,
                ns=(before.st_atime_ns, before.st_mtime_ns + 1_000_000_000),
            )
        return real_read(descriptor, size)

    monkeypatch.setattr(pytest_runtime.os, "read", racing_read)
    with pytest.raises(ConfigurationError, match="changed while it was being read"):
        pytest_runtime._read_bounded_json(
            path,
            label="hostile evidence",
            limit_bytes=64,
        )


def test_linked_worktree_marker_is_supported_and_masked(
    monkeypatch,
    tmp_path: Path,
) -> None:
    (tmp_path / ".git").write_text(
        "gitdir: worktree-metadata\n",
        encoding="utf-8",
    )
    (tmp_path / "worktree-metadata").mkdir()

    class LocalStore:
        def __init__(self, root):
            self.state = Path(root) / ".zerorun"

        def ensure(self):
            self.state.mkdir()

    monkeypatch.setattr(pytest_runtime, "Store", LocalStore)
    pytest_runtime._prepare_mountpoints(tmp_path)

    manifest_path = tmp_path / ".zerorun.json"
    manifest_path.write_text(
        json.dumps(
            {
                "version": 2,
                "tasks": {
                    "pytest": {
                        "command": ["python", "-m", "pytest"],
                        "inputs": ["tests"],
                        "outputs": [],
                        "env": [],
                        "cacheable": True,
                        "unsafe_effects": [],
                        "cache_streams": False,
                        "image": IMAGE,
                        "platform": "linux/amd64",
                        "result_only": True,
                        "closure_reviewed": True,
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    manifest = load_manifest(manifest_path)
    from unittest.mock import patch

    with patch.object(pytest_runtime, "_docker_path", return_value="/usr/bin/docker"):
        command, _, container_environment = pytest_runtime._docker_base(
            manifest,
            manifest.tasks["pytest"],
            runtime_identity={"requested_image": IMAGE},
            environment={},
        )
    assert "type=bind,src=/dev/null,dst=/workspace/.git,readonly" in command
    assert b"LANG=C\n" in container_environment
    assert b"PYTHONPYCACHEPREFIX=/tmp/zerorun-pycache\n" in container_environment


def test_isolated_pycache_prefix_ignores_prebuilt_workspace_bytecode(
    tmp_path: Path,
) -> None:
    """The container policy cannot import attacker-controlled adjacent pyc."""

    import importlib.util
    import py_compile
    import subprocess
    import sys

    source = tmp_path / "sample_module.py"
    malicious_source = tmp_path / "malicious_source.py"
    source.write_text("VALUE = 'source'\n", encoding="utf-8")
    malicious_source.write_text("VALUE = 'workspace-pyc'\n", encoding="utf-8")
    adjacent_pyc = Path(importlib.util.cache_from_source(str(source)))
    adjacent_pyc.parent.mkdir(parents=True)
    py_compile.compile(
        str(malicious_source),
        cfile=str(adjacent_pyc),
        doraise=True,
        invalidation_mode=py_compile.PycInvalidationMode.UNCHECKED_HASH,
    )
    malicious_source.unlink()

    base_environment = dict(os.environ)
    base_environment["PYTHONDONTWRITEBYTECODE"] = "1"
    base_environment.pop("PYTHONPYCACHEPREFIX", None)
    command = [
        sys.executable,
        "-c",
        "import sample_module; print(sample_module.VALUE)",
    ]
    unprotected = subprocess.check_output(
        command, cwd=tmp_path, env=base_environment, text=True
    ).strip()
    assert unprotected == "workspace-pyc"

    protected_environment = dict(base_environment)
    protected_environment["PYTHONPYCACHEPREFIX"] = str(
        tmp_path / "empty-execution-pycache"
    )
    protected = subprocess.check_output(
        command, cwd=tmp_path, env=protected_environment, text=True
    ).strip()
    assert protected == "source"

    # The prefix does not protect legacy/sourceless ``module.pyc`` files that
    # sit directly on sys.path. ZeroRun therefore rejects that distinct shape
    # before qualification, direct comparison, execution, or a cache hit.
    from zerorun.oci import reject_sourceless_workspace_bytecode

    sourceless_source = tmp_path / "sourceless_source.py"
    sourceless_pyc = tmp_path / "sourceless_module.pyc"
    sourceless_source.write_text("VALUE = 'sourceless-pyc'\n", encoding="utf-8")
    py_compile.compile(
        str(sourceless_source),
        cfile=str(sourceless_pyc),
        doraise=True,
        invalidation_mode=py_compile.PycInvalidationMode.UNCHECKED_HASH,
    )
    sourceless_source.unlink()
    sourceless = subprocess.check_output(
        [
            sys.executable,
            "-c",
            "import sourceless_module; print(sourceless_module.VALUE)",
        ],
        cwd=tmp_path,
        env=protected_environment,
        text=True,
    ).strip()
    assert sourceless == "sourceless-pyc"
    with pytest.raises(ConfigurationError, match="sourceless/direct Python bytecode"):
        reject_sourceless_workspace_bytecode(tmp_path)


def test_pytest_container_preflight_rejects_late_sourceless_bytecode(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, _profile = _repo(tmp_path)
    (tmp_path / "late_module.pyc").write_bytes(b"untrusted")
    monkeypatch.setattr(
        pytest_runtime,
        "_docker_path",
        lambda _root: pytest.fail("Docker lookup must follow bytecode preflight"),
    )

    with pytest.raises(ConfigurationError, match="sourceless/direct Python bytecode"):
        pytest_runtime._docker_base(
            manifest,
            manifest.tasks["pytest"],
            runtime_identity={"requested_image": IMAGE},
            environment={},
        )


def test_pytest_timeout_cleans_only_exact_random_container(monkeypatch, tmp_path: Path) -> None:
    import subprocess

    command = [
        "/usr/bin/docker",
        "create",
        "--name",
        "zerorun-pytest-0123456789abcdef01234567",
        "--env-file",
        pytest_runtime._ENV_FILE_PLACEHOLDER,
        IMAGE,
    ]

    observed = {}

    def fake_created(_command, **kwargs):
        observed.update(kwargs)
        raise ConfigurationError(
            "pytest container execution exceeded the 900 second execution boundary"
        )

    monkeypatch.setattr(pytest_runtime, "_run_created_container", fake_created)
    with pytest.raises(ConfigurationError, match="exceeded the 900 second"):
        pytest_runtime._run_docker_process(
            command,
            cwd=tmp_path,
            environment={"PATH": "/usr/bin"},
            container_environment=b"LANG=C\n",
        )
    assert observed["docker"] == "/usr/bin/docker"
    assert observed["container_name"] == "zerorun-pytest-0123456789abcdef01234567"
    assert observed["environment"] == {"PATH": "/usr/bin"}
    assert observed["execution_timeout_seconds"] == 900.0


def _repo(tmp_path: Path):
    (tmp_path / ".git").mkdir()
    (tmp_path / "src").mkdir()
    (tmp_path / "tests").mkdir()
    (tmp_path / "src" / "calc.py").write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
    (tmp_path / "tests" / "test_calc.py").write_text(
        "from src.calc import add\n\ndef test_add():\n    assert add(1, 2) == 3\n",
        encoding="utf-8",
    )
    (tmp_path / "conftest.py").write_text("# stable session input\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text("[tool.pytest.ini_options]\n", encoding="utf-8")
    manifest_path = tmp_path / ".zerorun.json"
    manifest_path.write_text(
        json.dumps(
            {
                "version": 2,
                "tasks": {
                    "pytest": {
                        "command": ["python", "-m", "pytest"],
                        "inputs": ["src", "tests", "conftest.py", "pyproject.toml"],
                        "outputs": [],
                        "env": [],
                        "cacheable": True,
                        "unsafe_effects": [],
                        "cache_streams": False,
                        "image": IMAGE,
                        "platform": "linux/amd64",
                        "result_only": True,
                        "closure_reviewed": True,
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    profile_path = tmp_path / ".zerorun-pytest.json"
    profile_payload = {
                "schema": 1,
                "task": "pytest",
                "base_args": [],
                "targets": ["tests"],
                "static_inputs": ["pyproject.toml", "conftest.py"],
                "session_closure": {"selectors": [], "fallback_files": ["conftest.py"]},
                "nodes": {
                    "tests/test_calc.py::test_add": {
                        "reviewable": True,
                        "fresh_required": False,
                        "selectors": [],
                        "fallback_files": ["src/calc.py", "tests/test_calc.py"],
                    }
                },
                "independence_review_sha256": REVIEW,
            }
    profile_payload["source_review"] = build_pytest_source_review(
        tmp_path,
        static_inputs=tuple(profile_payload["static_inputs"]),
        session_closure=profile_payload["session_closure"],
        nodes=profile_payload["nodes"],
        profiler_sha256=pytest_qualify.profiler_sha256(),
        collection_plugin_sha256=pytest_runtime.collection_plugin_sha256(),
    )
    profile_path.write_text(
        json.dumps(profile_payload),
        encoding="utf-8",
    )
    manifest = load_manifest(manifest_path)
    profile = load_pytest_profile(profile_path, manifest)
    return manifest, profile


def _profile_with_session_absences(profile, *patterns: str):
    from dataclasses import replace

    session_closure = dict(profile.session_closure)
    session_closure["absent_files"] = list(patterns)
    return replace(profile, session_closure=session_closure)


def _collection_item(nodeid: str, *, path: str = "tests/test_calc.py") -> dict:
    row = {
        "nodeid": nodeid,
        "item_type": "_pytest.python.Function",
        "path": path,
        "name": nodeid.rsplit("::", 1)[-1],
        "fixturenames": [],
        "callspec_params": {},
        "parameter_identity_supported": True,
        "parameter_identity_uncertainty": [],
    }
    import hashlib
    encoded = json.dumps(row, sort_keys=True, separators=(",", ":")).encode()
    row["identity_sha256"] = hashlib.sha256(encoded).hexdigest()
    return row


def _sealed_collection(
    items: list[dict],
    nodeids: list[str],
    *,
    rootpath: str = ".",
    args: list[str] | None = None,
    pyargs: bool = False,
    addopts: list[str] | None = None,
) -> dict:
    payload = {
        "invocation": {
            "rootpath": rootpath,
            "args": list(args if args is not None else ["tests"]),
            "pyargs": pyargs,
            "addopts": list(addopts or []),
        },
        "items": items,
        "nodeids": nodeids,
    }
    payload["collection_sha256"] = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return payload


def _collection(extra: bool = False):
    items = [_collection_item("tests/test_calc.py::test_add")]
    nodeids = ["tests/test_calc.py::test_add"]
    if extra:
        items.append(_collection_item("tests/test_calc.py::test_new"))
        nodeids.append("tests/test_calc.py::test_new")
    return _sealed_collection(items, nodeids)


def _run_embedded_collection_plugin(
    root: Path,
    *,
    target: str,
    output_name: str,
) -> dict:
    (root / "zerorun_collection_plugin.py").write_text(
        pytest_runtime._COLLECTION_PLUGIN,
        encoding="utf-8",
    )
    output = root / output_name
    environment = os.environ.copy()
    environment.update(
        {
            "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "ZERORUN_COLLECTION_OUTPUT": str(output),
        }
    )
    process = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-p",
            "no:cacheprovider",
            "-p",
            "zerorun_collection_plugin",
            "--collect-only",
            target,
        ],
        cwd=root,
        env=environment,
        capture_output=True,
        check=False,
        timeout=30,
    )
    assert process.returncode in {0, 5}, (
        process.stdout + process.stderr
    ).decode("utf-8", errors="replace")
    assert output.is_file()
    return json.loads(output.read_text(encoding="utf-8"))


@pytest.mark.parametrize(
    "plugin_source",
    [pytest_runtime._COLLECTION_PLUGIN, pytest_runtime._SINGLE_PASS_PLUGIN],
)
def test_embedded_collection_plugins_require_real_regular_item_paths(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    plugin_source: str,
) -> None:
    (tmp_path / "tests").mkdir()
    regular = tmp_path / "tests" / "test_real.py"
    regular.write_text("def test_real():\n    assert True\n", encoding="utf-8")
    directory = tmp_path / "tests" / "directory"
    directory.mkdir()
    outside = tmp_path.parent / f"{tmp_path.name}-outside.py"
    outside.write_text("# outside\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    namespace: dict[str, object] = {}
    exec(compile(plugin_source, "embedded-collection-plugin", "exec"), namespace)
    item_path = namespace["_item_path"]
    config = SimpleNamespace(rootpath=tmp_path)

    assert item_path(SimpleNamespace(path=regular), config) == "tests/test_real.py"
    assert item_path(SimpleNamespace(path=directory), config) is None
    assert item_path(SimpleNamespace(path=outside), config) is None
    assert item_path(SimpleNamespace(path="tests/test_real.py"), config) is None

    linked = tmp_path / "tests" / "linked.py"
    try:
        linked.symlink_to(regular)
    except (OSError, NotImplementedError):
        pass
    else:
        assert item_path(SimpleNamespace(path=linked), config) is None


def test_collection_plugin_binds_nested_root_and_node_selector(
    tmp_path: Path,
) -> None:
    (tmp_path / "pkg" / "tests").mkdir(parents=True)
    (tmp_path / "pkg" / "pytest.ini").write_text(
        "[pytest]\n",
        encoding="utf-8",
    )
    (tmp_path / "pkg" / "tests" / "test_nested.py").write_text(
        "def test_one():\n    assert True\n\n"
        "def test_two():\n    assert True\n",
        encoding="utf-8",
    )
    target = "pkg/tests/test_nested.py::test_one"
    evidence = _run_embedded_collection_plugin(
        tmp_path,
        target=target,
        output_name="nested-collection.json",
    )

    validated = pytest_runtime._validate_collection_evidence(
        evidence,
        label="nested-root collection",
        expected_targets=(target,),
    )
    assert validated["invocation"] == {
        "rootpath": "pkg",
        "args": [target],
        "pyargs": False,
        "addopts": [],
    }
    assert validated["nodeids"] == ["tests/test_nested.py::test_one"]
    assert validated["items"][0]["path"] == "pkg/tests/test_nested.py"


def test_collection_plugin_rejects_empty_addopts_target_before_it_gains_tests(
    tmp_path: Path,
) -> None:
    (tmp_path / "tests").mkdir()
    (tmp_path / "extra").mkdir()
    (tmp_path / "tests" / "test_main.py").write_text(
        "def test_main():\n    assert True\n",
        encoding="utf-8",
    )
    (tmp_path / "pytest.ini").write_text(
        "[pytest]\naddopts = extra\n",
        encoding="utf-8",
    )

    before = _run_embedded_collection_plugin(
        tmp_path,
        target="tests",
        output_name="before-collection.json",
    )
    assert before["invocation"]["args"] == ["extra", "tests"]
    with pytest.raises(ConfigurationError, match="do not exactly match"):
        pytest_runtime._validate_collection_evidence(
            before,
            label="empty extra target collection",
            expected_targets=("tests",),
        )

    (tmp_path / "extra" / "test_later.py").write_text(
        "def test_later():\n    assert False\n",
        encoding="utf-8",
    )
    after = _run_embedded_collection_plugin(
        tmp_path,
        target="tests",
        output_name="after-collection.json",
    )
    assert "extra/test_later.py::test_later" in after["nodeids"]
    with pytest.raises(ConfigurationError, match="do not exactly match"):
        pytest_runtime._validate_collection_evidence(
            after,
            label="populated extra target collection",
            expected_targets=("tests",),
        )


def test_collection_plugin_accepts_packaging_negative_logging_plugin_config(
    tmp_path: Path,
) -> None:
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_main.py").write_text(
        "def test_main():\n    assert True\n",
        encoding="utf-8",
    )
    (tmp_path / "pyproject.toml").write_text(
        "[tool.pytest.ini_options]\naddopts = ['-p', 'no:logging']\n",
        encoding="utf-8",
    )

    evidence = _run_embedded_collection_plugin(
        tmp_path,
        target="tests",
        output_name="negative-plugin-collection.json",
    )

    assert evidence["invocation"]["addopts"] == ["-p", "no:logging"]
    assert (
        pytest_runtime._validate_collection_evidence(
            evidence,
            label="negative plugin collection",
            expected_targets=("tests",),
        )
        is evidence
    )


def test_collection_plugin_disable_in_config_cannot_validate_evidence(
    tmp_path: Path,
) -> None:
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_main.py").write_text(
        "def test_main():\n    assert True\n",
        encoding="utf-8",
    )
    (tmp_path / "pytest.ini").write_text(
        "[pytest]\naddopts = -p no:zerorun_collection_plugin\n",
        encoding="utf-8",
    )
    (tmp_path / "zerorun_collection_plugin.py").write_text(
        pytest_runtime._COLLECTION_PLUGIN,
        encoding="utf-8",
    )
    output = tmp_path / "disabled-plugin-collection.json"
    output.write_bytes(b"")
    environment = os.environ.copy()
    environment.update(
        {
            "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "ZERORUN_COLLECTION_OUTPUT": str(output),
        }
    )

    process = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-p",
            "no:cacheprovider",
            "-p",
            "zerorun_collection_plugin",
            "--collect-only",
            "tests",
        ],
        cwd=tmp_path,
        env=environment,
        capture_output=True,
        check=False,
        timeout=30,
    )

    assert process.returncode in {0, 5}
    evidence = pytest_runtime._read_bounded_json(
        output,
        label="disabled collection plugin evidence",
        limit_bytes=pytest_runtime.PYTEST_EVIDENCE_LIMIT_BYTES,
    )
    with pytest.raises(ConfigurationError, match="unreviewed pytest plugin"):
        pytest_runtime._validate_collection_evidence(
            evidence,
            label="disabled collection plugin evidence",
            expected_targets=("tests",),
        )


@pytest.mark.parametrize(
    ("mutation", "message"),
    [
        ("pyargs", "--pyargs"),
        ("argfile", "argument files"),
        ("absolute-root", "cwd-relative POSIX"),
        ("absolute-item", "cwd-relative POSIX"),
        ("outside-item", "canonical in-workspace"),
        ("virtual-item", "no reviewable workspace path"),
    ],
)
def test_runtime_collection_contract_rejects_unreviewed_resolution_surfaces(
    mutation: str,
    message: str,
) -> None:
    evidence = _collection()
    if mutation == "pyargs":
        evidence["invocation"]["pyargs"] = True
    elif mutation == "argfile":
        evidence["invocation"]["addopts"] = ["@pytest.args"]
    elif mutation == "absolute-root":
        evidence["invocation"]["rootpath"] = "/workspace"
    elif mutation == "absolute-item":
        evidence["items"][0]["path"] = "/workspace/tests/test_calc.py"
    elif mutation == "outside-item":
        evidence["items"][0]["path"] = "../outside/test_calc.py"
    else:
        evidence["items"][0]["path"] = None
    with pytest.raises(ConfigurationError, match=message):
        pytest_runtime._validate_collection_evidence(
            evidence,
            label="hostile runtime collection",
            expected_targets=("tests",),
        )


def test_node_selector_target_guards_underlying_file_and_mutation_runs_fresh(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, original_profile = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    raw_profile = json.loads(original_profile.path.read_text(encoding="utf-8"))
    raw_profile["targets"] = [nodeid]
    raw_profile["source_review"] = build_pytest_source_review(
        tmp_path,
        static_inputs=tuple(raw_profile["static_inputs"]),
        session_closure=raw_profile["session_closure"],
        nodes=raw_profile["nodes"],
        profiler_sha256=pytest_qualify.profiler_sha256(),
        collection_plugin_sha256=pytest_runtime.collection_plugin_sha256(),
    )
    original_profile.path.write_text(json.dumps(raw_profile), encoding="utf-8")
    profile = load_pytest_profile(original_profile.path, manifest)
    collection = _sealed_collection(
        [_collection_item(nodeid)],
        [nodeid],
        args=[nodeid],
    )
    runtime = _full_runtime_identity()
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: runtime,
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    executions = 0

    def single_pass(*_args, **_kwargs):
        nonlocal executions
        executions += 1
        return (
            0,
            100.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no trusted baseline",
                "collection": collection,
                "fresh_nodeids": [nodeid],
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    first_guard = pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity=runtime,
        environment_fingerprint={},
    )
    first = pytest_runtime.run_pytest_profile(manifest, profile)
    assert first["fresh_nodes"] == 1

    test_file = tmp_path / "tests" / "test_calc.py"
    test_file.write_text(
        test_file.read_text(encoding="utf-8") + "\n# selector source changed\n",
        encoding="utf-8",
    )
    second_guard = pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity=runtime,
        environment_fingerprint={},
    )
    second = pytest_runtime.run_pytest_profile(manifest, profile)

    assert second_guard != first_guard
    assert second["fresh_nodes"] == 1
    assert second["reused_nodes"] == 0
    assert second["reuse_authorized"] is False
    assert executions == 2


def _two_node_repo(tmp_path: Path):
    manifest, original_profile = _repo(tmp_path)
    add_node = "tests/test_calc.py::test_add"
    sub_node = "tests/test_calc.py::test_sub"
    (tmp_path / "src" / "add.py").write_text(
        "def add(a, b):\n    return a + b\n", encoding="utf-8"
    )
    (tmp_path / "src" / "sub.py").write_text(
        "def sub(a, b):\n    return a - b\n", encoding="utf-8"
    )
    (tmp_path / "tests" / "test_calc.py").write_text(
        "from src.add import add\nfrom src.sub import sub\n\n"
        "def test_add():\n    assert add(1, 2) == 3\n\n"
        "def test_sub():\n    assert sub(3, 2) == 1\n",
        encoding="utf-8",
    )
    payload = json.loads(original_profile.path.read_text(encoding="utf-8"))
    payload["nodes"] = {
        add_node: {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [],
            "fallback_files": ["src/add.py", "tests/test_calc.py"],
        },
        sub_node: {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [],
            "fallback_files": ["src/sub.py", "tests/test_calc.py"],
        },
    }
    payload["source_review"] = build_pytest_source_review(
        tmp_path,
        static_inputs=tuple(payload["static_inputs"]),
        session_closure=payload["session_closure"],
        nodes=payload["nodes"],
        profiler_sha256=pytest_qualify.profiler_sha256(),
        collection_plugin_sha256=pytest_runtime.collection_plugin_sha256(),
    )
    original_profile.path.write_text(json.dumps(payload), encoding="utf-8")
    profile = load_pytest_profile(original_profile.path, manifest)
    items = [_collection_item(add_node), _collection_item(sub_node)]
    collection = _sealed_collection(items, [add_node, sub_node])
    return manifest, profile, collection, add_node, sub_node


def _context(profile, collection):
    return NodeCacheContext(
        runtime_identity={"requested_image": IMAGE, "platform": "linux/amd64"},
        environment_fingerprint={},
        collection_contract_sha256=collection["collection_sha256"],
        collection_plugin_sha256="5" * 64,
        independence_review_sha256=profile.independence_review_sha256,
        profile_sha256=profile.profile_sha256,
    )


def test_node_cache_miss_publish_hit_and_source_edit_invalidation(tmp_path: Path):
    manifest, profile = _repo(tmp_path)
    task = manifest.tasks["pytest"]
    collection = _collection()
    row = profile.nodes["tests/test_calc.py::test_add"]
    store = Store(tmp_path)

    initial = prepare_node_cache(
        tmp_path,
        task,
        node_rows=[row],
        session_closure=profile.session_closure,
        static_inputs=profile.static_inputs,
        collection_items=collection["items"],
        context=_context(profile, collection),
        store=store,
        session=FingerprintSession(tmp_path),
    )
    assert initial[0].status == "MISS_KEYED"

    verified = verify_node_cache_snapshot(
        tmp_path,
        task,
        decisions=initial,
        node_rows=[row],
        session_closure=profile.session_closure,
        static_inputs=profile.static_inputs,
        collection_items=collection["items"],
        final_context=_context(profile, collection),
        session=FingerprintSession(tmp_path),
    )
    assert verified[0].status == "MISS_VERIFIED"
    assert publish_verified_successes(
        tmp_path,
        verified,
        successful_nodeids={"tests/test_calc.py::test_add"},
        execution_ms_by_node={"tests/test_calc.py::test_add": 1000.0},
        store=store,
    ) == 1

    second = prepare_node_cache(
        tmp_path,
        task,
        node_rows=[row],
        session_closure=profile.session_closure,
        static_inputs=profile.static_inputs,
        collection_items=collection["items"],
        context=_context(profile, collection),
        store=store,
        session=FingerprintSession(tmp_path),
    )
    assert second[0].status == "HIT_PROVISIONAL"
    second_verified = verify_node_cache_snapshot(
        tmp_path,
        task,
        decisions=second,
        node_rows=[row],
        session_closure=profile.session_closure,
        static_inputs=profile.static_inputs,
        collection_items=collection["items"],
        final_context=_context(profile, collection),
        session=FingerprintSession(tmp_path),
    )
    assert second_verified[0].status == "HIT_REUSED"

    (tmp_path / "src" / "calc.py").write_text(
        "def add(a, b):\n    return a + b + 0\n", encoding="utf-8"
    )
    after_edit = prepare_node_cache(
        tmp_path,
        task,
        node_rows=[row],
        session_closure=profile.session_closure,
        static_inputs=profile.static_inputs,
        collection_items=collection["items"],
        context=_context(profile, collection),
        store=store,
        session=FingerprintSession(tmp_path),
    )
    assert after_edit[0].status == "MISS_KEYED"


def test_runtime_miss_then_hit_without_docker(monkeypatch, tmp_path: Path):
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    real_open = pytest_runtime.CacheTrustSession.open
    trust_open_modes = []

    def counted_open(*args, **kwargs):
        trust_open_modes.append(bool(kwargs.get("create_secret")))
        return real_open(*args, **kwargs)

    monkeypatch.setattr(
        pytest_runtime.CacheTrustSession,
        "open",
        staticmethod(counted_open),
    )
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    calls = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity, environment
        calls.append(
            {
                "baseline": baseline_collection,
                "fresh": list(fresh_nodeids),
            }
        )
        if baseline_collection is None:
            fresh = list(collection["nodeids"])
            reused = []
            mode = "whole-target-fresh"
        else:
            fresh = list(fresh_nodeids)
            reused = [
                nodeid
                for nodeid in collection["nodeids"]
                if nodeid not in set(fresh)
            ]
            mode = "single-pass-incremental"
        return (
            0,
            1000.0 if fresh else 100.0,
            b"ok",
            b"",
            {
                "mode": mode,
                "reason": None,
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(
        pytest_runtime, "execute_single_pass", single_pass
    )

    first = pytest_runtime.run_pytest_profile(manifest, profile)
    assert first["exit_code"] == 0
    assert first["fresh_nodes"] == 1
    assert first["reused_nodes"] == 0
    assert first["published_nodes"] == 1
    assert first["selection_mode"] == "whole-target-fresh"
    # The cache is empty, so lookup has no payload to authenticate. Only the
    # mandatory publication phase opens a pre/post-attested trust session.
    assert trust_open_modes == [True]

    def should_not_rebuild(*args, **kwargs):
        raise AssertionError("verified action snapshot should bypass node-key rebuild")

    monkeypatch.setattr(
        pytest_runtime, "prepare_node_cache", should_not_rebuild
    )
    monkeypatch.setattr(
        pytest_runtime, "verify_node_cache_snapshot", should_not_rebuild
    )

    second = pytest_runtime.run_pytest_profile(manifest, profile)
    assert second["exit_code"] == 0
    assert second["fresh_nodes"] == 0
    assert second["reused_nodes"] == 1
    assert second["reuse_authorized"] is True
    assert second["selection_mode"] == "zero-miss-elided"
    assert second["fast_path"] == "verified-action-snapshot"
    assert calls == [{"baseline": None, "fresh": []}]
    # The second request opens one lookup session for both the persisted
    # collection HMAC and the in-memory verified-action shortcut, then closes
    # it with the mandatory post-attestation before returning the hit.
    assert trust_open_modes == [True, False]


def test_all_hit_hot_paths_bound_hash_and_trust_work(monkeypatch, tmp_path: Path):
    """Warm and persisted hits do no redundant work inside one snapshot.

    Both a process-local verified-action hit and a persisted hit need two
    independent source snapshots before reuse can escape.  The in-memory entry
    is only a performance hint, not immutable filesystem authority.  Both
    paths still use one pre/post trust attestation for the collection snapshot
    and node-cache payloads together.
    """

    from collections import Counter

    from zerorun import fingerprint, trust

    manifest, profile = _repo(tmp_path)
    collection = _collection()
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    execution_calls = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity, environment
        fresh = (
            list(collection["nodeids"])
            if baseline_collection is None
            else list(fresh_nodeids)
        )
        reused = [
            nodeid
            for nodeid in collection["nodeids"]
            if nodeid not in set(fresh)
        ]
        execution_calls.append({"baseline": baseline_collection, "fresh": fresh})
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": (
                    "whole-target-fresh"
                    if baseline_collection is None
                    else "single-pass-incremental"
                ),
                "reason": None,
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["published_nodes"] == 1

    real_sha256_file = fingerprint.sha256_file
    hash_calls: Counter[Path] = Counter()

    def counted_sha256_file(path: Path) -> str:
        hash_calls[path.resolve()] += 1
        return real_sha256_file(path)

    real_tracked_paths = trust.tracked_zerorun_paths
    tracked_calls = 0

    def counted_tracked_paths(root: Path):
        nonlocal tracked_calls
        tracked_calls += 1
        return real_tracked_paths(root)

    monkeypatch.setattr(fingerprint, "sha256_file", counted_sha256_file)
    monkeypatch.setattr(trust, "tracked_zerorun_paths", counted_tracked_paths)
    expected_files = {
        (tmp_path / relative).resolve()
        for relative in (
            "conftest.py",
            "pyproject.toml",
            "src/calc.py",
            "tests/test_calc.py",
        )
    }

    warm = pytest_runtime.run_pytest_profile(manifest, profile)
    assert warm["fast_path"] == "verified-action-snapshot"
    assert execution_calls == [{"baseline": None, "fresh": collection["nodeids"]}]
    assert hash_calls == Counter({path: 2 for path in expected_files})
    # One Store construction validates that runtime state is untracked; the
    # shared lookup session contributes exactly one pre and one post check.
    assert tracked_calls == 3

    # Simulate a new long-lived worker/process that retains persisted HMAC
    # evidence but not the in-memory verified-action snapshot.
    pytest_runtime._VERIFIED_ACTION_SNAPSHOTS.clear()
    hash_calls.clear()
    tracked_calls = 0
    persisted = pytest_runtime.run_pytest_profile(manifest, profile)
    assert persisted["selection_mode"] == "zero-miss-elided"
    assert persisted.get("fast_path") is None
    assert execution_calls == [{"baseline": None, "fresh": collection["nodeids"]}]
    assert hash_calls == Counter({path: 2 for path in expected_files})
    assert tracked_calls == 3

    # The fully reverified persisted hit now recreates only the process-local
    # aggregate proof. A restarted long-lived worker therefore pays the node
    # rebuild once, then regains the guarded hot path without running pytest.
    hash_calls.clear()
    tracked_calls = 0
    rewarm = pytest_runtime.run_pytest_profile(manifest, profile)
    assert rewarm["fast_path"] == "verified-action-snapshot"
    assert rewarm["reused_nodes"] == 1
    assert rewarm["fresh_nodes"] == 0
    assert execution_calls == [{"baseline": None, "fresh": collection["nodeids"]}]
    assert hash_calls == Counter({path: 2 for path in expected_files})
    assert tracked_calls == 3


def test_verified_action_snapshot_rechecks_source_before_return(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """A mutation after the warm hint's first hash cannot escape as a hit."""

    manifest, profile = _repo(tmp_path)
    collection = _collection()
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    execution_calls: list[dict[str, object]] = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity, environment
        fresh = (
            list(collection["nodeids"])
            if baseline_collection is None
            else list(fresh_nodeids)
        )
        reused = [
            nodeid
            for nodeid in collection["nodeids"]
            if nodeid not in set(fresh)
        ]
        execution_calls.append(
            {"baseline": baseline_collection, "fresh": list(fresh)}
        )
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": (
                    "whole-target-fresh"
                    if baseline_collection is None
                    else "single-pass-incremental"
                ),
                "reason": (
                    "no trusted baseline" if baseline_collection is None else None
                ),
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["published_nodes"] == 1

    real_try = pytest_runtime._try_verified_action_snapshot
    attempts = 0

    def racing_try(*args, **kwargs):
        nonlocal attempts
        attempts += 1
        result = real_try(*args, **kwargs)
        if attempts == 1 and result is not None:
            (tmp_path / "src" / "calc.py").write_text(
                "def add(a, b):\n    return a + b + 1\n",
                encoding="utf-8",
            )
        return result

    monkeypatch.setattr(
        pytest_runtime, "_try_verified_action_snapshot", racing_try
    )
    raced = pytest_runtime.run_pytest_profile(manifest, profile)

    assert attempts == 2
    assert raced.get("fast_path") is None
    assert raced["fresh_nodes"] == 1
    assert raced["reused_nodes"] == 0
    assert raced["published_nodes"] == 0
    assert execution_calls == [
        {"baseline": None, "fresh": collection["nodeids"]},
        {"baseline": None, "fresh": collection["nodeids"]},
    ]


@pytest.mark.parametrize("cache_path", ["warm", "persisted"])
@pytest.mark.parametrize("mutation", ["source", "environment", "bytecode"])
def test_all_hit_paths_recheck_source_and_environment_after_trust_attestation(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    cache_path: str,
    mutation: str,
) -> None:
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    environment_state: dict[str, str] = {}
    execution_calls: list[dict[str, object]] = []
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )

    def current_environment(_task):
        raw = dict(environment_state)
        fingerprint = {
            name: {"present": True, "value": value}
            for name, value in sorted(raw.items())
        }
        return raw, fingerprint

    monkeypatch.setattr(
        pytest_runtime, "hermetic_environment", current_environment
    )

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity
        fresh = (
            list(collection["nodeids"])
            if baseline_collection is None
            else list(fresh_nodeids)
        )
        reused = [
            nodeid
            for nodeid in collection["nodeids"]
            if nodeid not in set(fresh)
        ]
        execution_calls.append(
            {
                "baseline": baseline_collection,
                "fresh": fresh,
                "environment": dict(environment),
            }
        )
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": (
                    "whole-target-fresh"
                    if baseline_collection is None
                    else "single-pass-incremental"
                ),
                "reason": None,
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["published_nodes"] == 1
    if cache_path == "persisted":
        pytest_runtime._VERIFIED_ACTION_SNAPSHOTS.clear()

    real_verify = pytest_runtime.CacheTrustSession.verify_unchanged
    mutated = False

    def racing_verify(session):
        nonlocal mutated
        real_verify(session)
        if mutated:
            return
        mutated = True
        if mutation == "source":
            (tmp_path / "src" / "calc.py").write_text(
                "def add(a, b):\n    return a + b + 1\n",
                encoding="utf-8",
            )
        elif mutation == "environment":
            environment_state["FLAG"] = "changed"
        else:
            (tmp_path / "late_module.pyc").write_bytes(b"not trusted bytecode")

    monkeypatch.setattr(
        pytest_runtime.CacheTrustSession,
        "verify_unchanged",
        racing_verify,
    )
    raced = pytest_runtime.run_pytest_profile(manifest, profile)

    assert mutated is True
    assert raced.get("fast_path") is None
    assert raced["fresh_nodes"] == 1
    assert raced["reused_nodes"] == 0
    assert raced["published_nodes"] == 0
    assert execution_calls[-1]["baseline"] is None
    assert execution_calls[-1]["fresh"] == collection["nodeids"]
    if mutation == "environment":
        assert execution_calls[-1]["environment"] == {"FLAG": "changed"}


def test_signed_suite_result_skips_runtime_inspection_after_canonical_fresh_seed(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    runtime = _full_runtime_identity()
    inspection_calls = 0

    def inspect(_task, **_kwargs):
        nonlocal inspection_calls
        inspection_calls += 1
        return runtime

    monkeypatch.setattr(pytest_runtime, "inspect_runtime", inspect)
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    execution_calls = 0

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        nonlocal execution_calls
        del baseline_collection, fresh_nodeids, runtime_identity, environment
        execution_calls += 1
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no trusted baseline",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["fresh_nodes"] == 1
    receipt = pytest_runtime._suite_result_path(Store(tmp_path), profile)
    assert receipt.is_file()
    inspections_after_seed = inspection_calls

    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda *_args, **_kwargs: pytest.fail(
            "signed suite hit must not inspect Docker"
        ),
    )
    monkeypatch.setattr(
        pytest_runtime,
        "execute_single_pass",
        lambda *_args, **_kwargs: pytest.fail(
            "signed suite hit must not execute pytest"
        ),
    )
    hit = pytest_runtime.run_pytest_profile(manifest, profile)

    assert hit["fast_path"] == "signed-suite-result"
    assert hit["reused_nodes"] == 1
    assert hit["fresh_nodes"] == 0
    assert execution_calls == 1
    assert inspection_calls == inspections_after_seed


@pytest.mark.parametrize(
    "failure", ["runtime", "source", "environment", "profile", "trust"]
)
def test_failed_suite_republication_preserves_older_receipt(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    failure: str,
) -> None:
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    runtime = _full_runtime_identity()
    monkeypatch.setattr(
        pytest_runtime, "inspect_runtime", lambda _task, **_kwargs: runtime
    )
    environment_state: dict[str, str] = {}
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: (
            dict(environment_state),
            {
                name: {"present": True, "value": value}
                for name, value in sorted(environment_state.items())
            },
        ),
    )
    monkeypatch.setattr(
        pytest_runtime,
        "execute_single_pass",
        lambda *_args, **_kwargs: (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no trusted baseline",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        ),
    )
    real_save = pytest_runtime._save_signed_suite_result
    captured: dict[str, object] = {}

    def capture_save(*args, **kwargs):
        captured["args"] = args
        captured["kwargs"] = kwargs
        return real_save(*args, **kwargs)

    monkeypatch.setattr(
        pytest_runtime, "_save_signed_suite_result", capture_save
    )
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["fresh_nodes"] == 1
    receipt = pytest_runtime._suite_result_path(Store(tmp_path), profile)
    old_bytes = receipt.read_bytes()
    assert old_bytes

    if failure == "runtime":
        def fail_final_runtime(*_args, **_kwargs):
            raise ConfigurationError("simulated final runtime drift")

        monkeypatch.setattr(pytest_runtime, "inspect_runtime", fail_final_runtime)
    else:
        real_verify = pytest_runtime.CacheTrustSession.verify_unchanged

        def fail_after_trust(session):
            if failure == "trust":
                session.abort()
                raise ConfigurationError("simulated publication trust drift")
            real_verify(session)
            if failure == "source":
                (tmp_path / "src" / "calc.py").write_text(
                    "def add(a, b):\n    return a + b + 1\n",
                    encoding="utf-8",
                )
            elif failure == "environment":
                environment_state["FLAG"] = "changed"
            else:
                profile.path.write_text(
                    profile.path.read_text(encoding="utf-8") + "\n",
                    encoding="utf-8",
                )

        monkeypatch.setattr(
            pytest_runtime.CacheTrustSession,
            "verify_unchanged",
            fail_after_trust,
        )
    assert real_save(*captured["args"], **captured["kwargs"]) is False
    assert receipt.read_bytes() == old_bytes


def test_signed_suite_result_detects_source_race_between_guard_passes(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    runtime = _full_runtime_identity()
    monkeypatch.setattr(
        pytest_runtime, "inspect_runtime", lambda _task, **_kwargs: runtime
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )

    def single_pass(*_args, **_kwargs):
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no trusted baseline",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["fresh_nodes"] == 1

    real_guard = pytest_runtime._suite_guard_snapshot
    guard_calls = 0

    def racing_guard(*args, **kwargs):
        nonlocal guard_calls
        guard_calls += 1
        result = real_guard(*args, **kwargs)
        if guard_calls == 1:
            (tmp_path / "src" / "calc.py").write_text(
                "def add(a, b):\n    return a + b + 1\n",
                encoding="utf-8",
            )
        return result

    monkeypatch.setattr(pytest_runtime, "_suite_guard_snapshot", racing_guard)
    raced = pytest_runtime.run_pytest_profile(manifest, profile)

    assert guard_calls >= 2
    assert raced.get("fast_path") != "signed-suite-result"
    assert raced["fresh_nodes"] == 1
    assert raced["reused_nodes"] == 0


@pytest.mark.skipif(os.name == "nt", reason="POSIX executable mode semantics")
def test_collection_mode_change_cannot_reuse_signed_suite_result(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """A custom collector may make executable files test items.

    Content-only collection guards would miss a chmod from dormant to
    collectable. The guard binds file and directory type/mode, so the signed
    pass receipt is rejected and the current failing suite executes.
    """

    manifest, profile = _repo(tmp_path)
    collection = _collection()
    dormant = tmp_path / "tests" / "dormant.collect"
    dormant.write_text("same bytes\n", encoding="utf-8")
    dormant.chmod(0o644)
    runtime = _full_runtime_identity()
    monkeypatch.setattr(
        pytest_runtime, "inspect_runtime", lambda _task, **_kwargs: runtime
    )
    monkeypatch.setattr(
        pytest_runtime, "hermetic_environment", lambda _task: ({}, {})
    )
    execution_calls = 0

    def single_pass(*_args, **_kwargs):
        nonlocal execution_calls
        execution_calls += 1
        collectable = bool(dormant.stat().st_mode & 0o111)
        return (
            1 if collectable else 0,
            1000.0,
            b"failed custom-collected executable" if collectable else b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "custom executable collector",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["exit_code"] == 0
    assert pytest_runtime._suite_result_path(Store(tmp_path), profile).is_file()

    dormant.chmod(0o755)
    current_mode = dormant.stat().st_mode & 0o777
    assert current_mode == 0o755
    changed = pytest_runtime.run_pytest_profile(manifest, profile)

    assert execution_calls == 2
    assert changed.get("fast_path") != "signed-suite-result"
    assert changed["exit_code"] == 1


def test_collection_guard_binds_directory_type_and_mode(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Directory metadata used by custom collectors is part of the guard."""

    _manifest, profile = _repo(tmp_path)
    records = [{"path": "tests", "type": "directory", "mode": 0o755}]
    monkeypatch.setattr(
        pytest_runtime,
        "expand_inputs",
        lambda *_args, **_kwargs: [dict(row) for row in records],
    )
    first = pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity={"requested_image": IMAGE},
        environment_fingerprint={},
    )
    records[0]["mode"] = 0o700
    mode_changed = pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity={"requested_image": IMAGE},
        environment_fingerprint={},
    )
    records[0] = {
        "path": "tests",
        "type": "file",
        "mode": 0o700,
        "size": 0,
        "sha256": hashlib.sha256(b"").hexdigest(),
    }
    type_changed = pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity={"requested_image": IMAGE},
        environment_fingerprint={},
    )

    assert mode_changed != first
    assert type_changed != mode_changed


def _raw_git_change(status_code: str, path: str) -> bytes:
    old_oid = b"1" * 40
    new_oid = b"2" * 40
    header = (
        b":100644 100644 "
        + old_oid
        + b" "
        + new_oid
        + b" "
        + status_code.encode("ascii")
    )
    return header + b"\x00" + path.encode("utf-8") + b"\x00"


@pytest.mark.parametrize(
    "raw",
    [
        _raw_git_change("M", "src/calc.py"),
        _raw_git_change("D", "src/calc.py"),
        _raw_git_change("T", "src/calc.py"),
        _raw_git_change("D", "src/calc.py")
        + _raw_git_change("A", "archive/calc.py"),
        _raw_git_change("D", "docs/old.py")
        + _raw_git_change("A", "tests/new.py"),
    ],
)
def test_revision_filter_rejects_relevant_change_kinds(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    raw: bytes,
) -> None:
    saved = {
        "schema": 1,
        "commit": "1" * 40,
        "tree": "2" * 40,
        "guard_paths": ["src/calc.py", "tests"],
    }
    current = {
        "schema": 1,
        "commit": "3" * 40,
        "tree": "4" * 40,
        "guard_paths": [],
    }
    monkeypatch.setattr(
        pytest_runtime, "_repository_revision_hint", lambda *_a, **_kw: current
    )
    monkeypatch.setattr(
        pytest_runtime, "_run_git_hint", lambda *_a, **_kw: raw
    )

    assert not pytest_runtime._repository_hint_allows_guard_validation(
        tmp_path, saved
    )


def test_revision_filter_allows_only_full_validation_for_irrelevant_change(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    saved = {
        "schema": 1,
        "commit": "1" * 40,
        "tree": "2" * 40,
        "guard_paths": ["src/calc.py", "tests"],
    }
    current = {
        "schema": 1,
        "commit": "3" * 40,
        "tree": "4" * 40,
        "guard_paths": [],
    }
    monkeypatch.setattr(
        pytest_runtime, "_repository_revision_hint", lambda *_a, **_kw: current
    )
    monkeypatch.setattr(
        pytest_runtime,
        "_run_git_hint",
        lambda *_a, **_kw: _raw_git_change("M", "docs/readme.md"),
    )

    # True means only "continue to both authoritative guards", never hit.
    assert pytest_runtime._repository_hint_allows_guard_validation(
        tmp_path, saved
    )


@pytest.mark.parametrize(
    "raw",
    [
        None,
        b"not-raw-git-output\x00",
        _raw_git_change("R", "src/calc.py"),
        _raw_git_change("M", "../escape.py"),
    ],
)
def test_revision_filter_fails_closed_on_error_or_malformed_stream(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    raw: bytes | None,
) -> None:
    saved = {
        "schema": 1,
        "commit": "1" * 40,
        "tree": "2" * 40,
        "guard_paths": ["src/calc.py"],
    }
    current = {
        "schema": 1,
        "commit": "3" * 40,
        "tree": "4" * 40,
        "guard_paths": [],
    }
    monkeypatch.setattr(
        pytest_runtime, "_repository_revision_hint", lambda *_a, **_kw: current
    )
    monkeypatch.setattr(
        pytest_runtime, "_run_git_hint", lambda *_a, **_kw: raw
    )

    assert not pytest_runtime._repository_hint_allows_guard_validation(
        tmp_path, saved
    )


@pytest.mark.parametrize("timed_out", [False, True])
def test_revision_filter_rejects_bounded_output_overflow_and_timeout(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    timed_out: bool,
) -> None:
    monkeypatch.setattr(
        pytest_runtime, "_trusted_git_executable", lambda _root: Path("git")
    )
    monkeypatch.setattr(
        pytest_runtime,
        "_run_bounded_process",
        lambda *_a, **_kw: (
            SimpleNamespace(
                returncode=0,
                stdout=b"x" * pytest_runtime._GIT_DIFF_LIMIT_BYTES,
                stderr=b"",
            ),
            timed_out,
        ),
    )

    assert (
        pytest_runtime._run_git_hint(
            tmp_path,
            ["diff"],
            limit=pytest_runtime._GIT_DIFF_LIMIT_BYTES,
        )
        is None
    )


def test_revision_filter_rejects_head_race_after_complete_diff(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    saved = {
        "schema": 1,
        "commit": "1" * 40,
        "tree": "2" * 40,
        "guard_paths": ["src/calc.py"],
    }
    current = {
        "schema": 1,
        "commit": "3" * 40,
        "tree": "4" * 40,
        "guard_paths": [],
    }
    raced = {
        "schema": 1,
        "commit": "5" * 40,
        "tree": "6" * 40,
        "guard_paths": [],
    }
    revisions = iter([current, raced])
    monkeypatch.setattr(
        pytest_runtime,
        "_repository_revision_hint",
        lambda *_a, **_kw: next(revisions),
    )
    monkeypatch.setattr(
        pytest_runtime,
        "_run_git_hint",
        lambda *_a, **_kw: _raw_git_change("M", "docs/readme.md"),
    )

    assert not pytest_runtime._repository_hint_allows_guard_validation(
        tmp_path, saved
    )


def test_suite_receipt_hits_unrelated_commit_and_cheaply_misses_relevant_commit(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    runtime = _full_runtime_identity()
    revision = {"commit": "1" * 40, "tree": "2" * 40}

    def revision_hint(_root, *, guard_paths=None):
        return {
            "schema": 1,
            "commit": revision["commit"],
            "tree": revision["tree"],
            "guard_paths": sorted(set(guard_paths or [])),
        }

    monkeypatch.setattr(
        pytest_runtime, "_repository_revision_hint", revision_hint
    )
    monkeypatch.setattr(
        pytest_runtime, "inspect_runtime", lambda _task, **_kwargs: runtime
    )
    monkeypatch.setattr(
        pytest_runtime, "hermetic_environment", lambda _task: ({}, {})
    )
    monkeypatch.setattr(
        pytest_runtime,
        "execute_single_pass",
        lambda *_args, **_kwargs: (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no trusted baseline",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        ),
    )
    pytest_runtime.run_pytest_profile(manifest, profile)
    store = Store(tmp_path)
    receipt_payload = json.loads(
        pytest_runtime._suite_result_path(store, profile).read_text(
            encoding="utf-8"
        )
    )
    mismatched_scope = json.loads(json.dumps(receipt_payload))
    mismatched_scope["repository_revision_hint"]["guard_paths"] = [
        "docs/readme.md"
    ]
    assert (
        pytest_runtime._validate_suite_result_payload(
            mismatched_scope,
            manifest=manifest,
            task=manifest.tasks[profile.task_name],
            profile=profile,
            environment_fingerprint={},
        )
        is None
    )

    revision.update(commit="3" * 40, tree="4" * 40)
    monkeypatch.setattr(
        pytest_runtime,
        "_run_git_hint",
        lambda *_a, **_kw: _raw_git_change("M", "docs/readme.md"),
    )
    unrelated = pytest_runtime._try_signed_suite_result(
        manifest,
        manifest.tasks[profile.task_name],
        profile,
        store=store,
        manifest_digest=pytest_runtime.manifest_sha256(manifest),
    )
    assert unrelated is not None

    revision.update(commit="5" * 40, tree="6" * 40)
    monkeypatch.setattr(
        pytest_runtime,
        "_run_git_hint",
        lambda *_a, **_kw: _raw_git_change("M", "src/calc.py"),
    )
    guard_calls = 0
    real_guard = pytest_runtime._suite_guard_snapshot

    def counted_guard(*args, **kwargs):
        nonlocal guard_calls
        guard_calls += 1
        return real_guard(*args, **kwargs)

    monkeypatch.setattr(pytest_runtime, "_suite_guard_snapshot", counted_guard)
    relevant = pytest_runtime._try_signed_suite_result(
        manifest,
        manifest.tasks[profile.task_name],
        profile,
        store=store,
        manifest_digest=pytest_runtime.manifest_sha256(manifest),
    )
    assert relevant is None
    assert guard_calls == 0


def test_mixed_verified_run_publishes_current_composition_receipt(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, profile, collection, add_node, sub_node = _two_node_repo(tmp_path)
    runtime = _full_runtime_identity()
    revision = {"commit": "1" * 40, "tree": "2" * 40}
    diff_raw = {"value": b""}

    def revision_hint(_root, *, guard_paths=None):
        return {
            "schema": 1,
            "commit": revision["commit"],
            "tree": revision["tree"],
            "guard_paths": sorted(set(guard_paths or [])),
        }

    monkeypatch.setattr(
        pytest_runtime, "_repository_revision_hint", revision_hint
    )
    monkeypatch.setattr(
        pytest_runtime, "_run_git_hint", lambda *_a, **_kw: diff_raw["value"]
    )
    monkeypatch.setattr(
        pytest_runtime, "inspect_runtime", lambda _task, **_kwargs: runtime
    )
    monkeypatch.setattr(
        pytest_runtime, "hermetic_environment", lambda _task: ({}, {})
    )
    real_save = pytest_runtime._save_signed_suite_result
    saved_calls: list[tuple[tuple[object, ...], dict[str, object]]] = []

    def capture_save(*args, **kwargs):
        saved_calls.append((args, kwargs))
        return real_save(*args, **kwargs)

    monkeypatch.setattr(
        pytest_runtime, "_save_signed_suite_result", capture_save
    )
    execution_calls: list[dict[str, object]] = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity, environment
        fresh = (
            list(collection["nodeids"])
            if baseline_collection is None
            else list(fresh_nodeids)
        )
        reused = [
            nodeid for nodeid in collection["nodeids"] if nodeid not in set(fresh)
        ]
        execution_calls.append({"fresh": fresh, "reused": reused})
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": (
                    "whole-target-fresh"
                    if baseline_collection is None
                    else "single-pass-incremental"
                ),
                "reason": None,
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["fresh_nodes"] == 2
    assert seeded["published_nodes"] == 2
    pytest_runtime._VERIFIED_ACTION_SNAPSHOTS.clear()

    # Force one current-key cache miss without changing reviewed source. This
    # models a valid partial store (eviction/crash cleanup): one node executes
    # canonically while its independently authenticated sibling is reused.
    real_load_result = pytest_node_cache._load_result_entry
    forced_miss = False

    def miss_first_entry_once(*args, **kwargs):
        nonlocal forced_miss
        if not forced_miss:
            forced_miss = True
            return None
        return real_load_result(*args, **kwargs)

    monkeypatch.setattr(
        pytest_node_cache, "_load_result_entry", miss_first_entry_once
    )
    revision.update(commit="3" * 40, tree="4" * 40)
    diff_raw["value"] = _raw_git_change("M", "src/add.py")
    mixed = pytest_runtime.run_pytest_profile(manifest, profile)
    assert mixed["fresh_nodes"] == 1
    assert mixed["reused_nodes"] == 1
    assert mixed["published_nodes"] == 1
    assert execution_calls[-1] == {"fresh": [add_node], "reused": [sub_node]}

    receipt = json.loads(
        pytest_runtime._suite_result_path(Store(tmp_path), profile).read_text(
            encoding="utf-8"
        )
    )
    assert receipt["kind"] == "hermetic-composed-result-only-suite"
    assert receipt["composition"] == {"fresh_nodes": 1, "reused_nodes": 1}

    revision.update(commit="5" * 40, tree="6" * 40)
    diff_raw["value"] = _raw_git_change("M", "docs/readme.md")
    hit = pytest_runtime.run_pytest_profile(manifest, profile)
    assert hit["fast_path"] == "signed-suite-result"
    assert hit["reused_nodes"] == 2
    assert len(execution_calls) == 2

    # A mixed receipt is published only if both the old authenticated hit and
    # the newly published miss can be reloaded by exact key/fingerprint. Loss
    # or tamper of either partition preserves the last valid receipt.
    mixed_call = saved_calls[-1]
    old_receipt = pytest_runtime._suite_result_path(
        Store(tmp_path), profile
    ).read_bytes()
    decisions = mixed_call[1]["decisions"]
    real_runtime_load = pytest_runtime._load_result_entry

    # An incomplete current collection must not replace an older usable
    # aggregate receipt. The next lookup would reject that receipt safely, but
    # preserving the prior bytes prevents a transient collector failure from
    # degrading availability.
    removed_collection = _sealed_collection(
        [collection["items"][0]],
        [add_node],
    )
    removed_args = list(mixed_call[0])
    removed_args[3] = removed_collection
    assert real_save(*removed_args, **mixed_call[1]) is False
    assert (
        pytest_runtime._suite_result_path(Store(tmp_path), profile).read_bytes()
        == old_receipt
    )

    for status in ("HIT_REUSED", "MISS_VERIFIED"):
        target = next(decision for decision in decisions if decision.status == status)

        def missing_partition(
            store,
            task,
            key,
            fingerprint,
            *,
            result_identity=None,
            trust_session,
        ):
            if key == target.key:
                return None
            return real_runtime_load(
                store,
                task,
                key,
                fingerprint,
                result_identity=result_identity,
                trust_session=trust_session,
            )

        with monkeypatch.context() as inner:
            inner.setattr(
                pytest_runtime, "_load_result_entry", missing_partition
            )
            assert real_save(*mixed_call[0], **mixed_call[1]) is False
            assert (
                pytest_runtime._suite_result_path(
                    Store(tmp_path), profile
                ).read_bytes()
                == old_receipt
            )

    # The Git filter is rejection-only. A relevant dirty/untracked source
    # change absent from the commit diff still reaches the complete guards and
    # invalidates the composed result.
    (tmp_path / "src" / "sub.py").write_text(
        "def sub(a, b):\n    return a - b + 1\n", encoding="utf-8"
    )
    revision.update(commit="7" * 40, tree="8" * 40)
    diff_raw["value"] = _raw_git_change("M", "docs/readme.md")
    assert (
        pytest_runtime._try_signed_suite_result(
            manifest,
            manifest.tasks[profile.task_name],
            profile,
            store=Store(tmp_path),
            manifest_digest=pytest_runtime.manifest_sha256(manifest),
        )
        is None
    )


def test_signed_suite_result_detects_profile_race_before_return(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    runtime = _full_runtime_identity()
    monkeypatch.setattr(
        pytest_runtime, "inspect_runtime", lambda _task, **_kwargs: runtime
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    monkeypatch.setattr(
        pytest_runtime,
        "execute_single_pass",
        lambda *_args, **_kwargs: (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no trusted baseline",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        ),
    )
    pytest_runtime.run_pytest_profile(manifest, profile)

    real_guard = pytest_runtime._suite_guard_snapshot
    guard_calls = 0

    def racing_guard(*args, **kwargs):
        nonlocal guard_calls
        guard_calls += 1
        result = real_guard(*args, **kwargs)
        if guard_calls == 1:
            profile.path.write_text(
                profile.path.read_text(encoding="utf-8") + "\n",
                encoding="utf-8",
            )
        return result

    monkeypatch.setattr(pytest_runtime, "_suite_guard_snapshot", racing_guard)
    with pytest.raises(ConfigurationError, match="profile changed"):
        pytest_runtime.run_pytest_profile(manifest, profile)
    assert guard_calls == 2


@pytest.mark.parametrize(
    "mutation", ["source", "profile", "environment", "bytecode"]
)
def test_signed_suite_result_rechecks_after_slow_trust_attestation(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    mutation: str,
) -> None:
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    runtime = _full_runtime_identity()
    environment_state: dict[str, str] = {}
    monkeypatch.setattr(
        pytest_runtime, "inspect_runtime", lambda _task, **_kwargs: runtime
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: (
            dict(environment_state),
            {
                name: {"present": True, "value": value}
                for name, value in sorted(environment_state.items())
            },
        ),
    )
    execution_calls = 0

    def single_pass(*_args, **_kwargs):
        nonlocal execution_calls
        execution_calls += 1
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no trusted baseline",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    pytest_runtime.run_pytest_profile(manifest, profile)
    real_verify = pytest_runtime.CacheTrustSession.verify_unchanged
    mutated = False

    def racing_verify(session):
        nonlocal mutated
        real_verify(session)
        if mutated:
            return
        mutated = True
        if mutation == "source":
            (tmp_path / "src" / "calc.py").write_text(
                "def add(a, b):\n    return a + b + 1\n",
                encoding="utf-8",
            )
        elif mutation == "profile":
            profile.path.write_text(
                profile.path.read_text(encoding="utf-8") + "\n",
                encoding="utf-8",
            )
        elif mutation == "environment":
            environment_state["FLAG"] = "changed"
        else:
            (tmp_path / "late_module.pyc").write_bytes(b"not trusted bytecode")

    monkeypatch.setattr(
        pytest_runtime.CacheTrustSession,
        "verify_unchanged",
        racing_verify,
    )
    if mutation == "profile":
        with pytest.raises(ConfigurationError, match="profile changed"):
            pytest_runtime.run_pytest_profile(manifest, profile)
    else:
        result = pytest_runtime.run_pytest_profile(manifest, profile)
        assert result.get("fast_path") != "signed-suite-result"
        assert result["fresh_nodes"] == 1
        assert result["reused_nodes"] == 0
    assert mutated is True


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("reference_execution_ms", 9_999_999.0),
        ("reference_execution_ms", 10**255),
        ("created_at", 10**255),
        ("exit_code", False),
        ("reference_execution_ms", float("nan")),
        ("created_at", float("inf")),
    ],
)
def test_signed_suite_result_tamper_falls_back_without_authorizing_reuse(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    field: str,
    value: object,
) -> None:
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    runtime = _full_runtime_identity()
    monkeypatch.setattr(
        pytest_runtime, "inspect_runtime", lambda _task, **_kwargs: runtime
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    calls = 0

    def single_pass(*_args, **_kwargs):
        nonlocal calls
        calls += 1
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no trusted baseline",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    pytest_runtime.run_pytest_profile(manifest, profile)
    path = pytest_runtime._suite_result_path(Store(tmp_path), profile)
    receipt = json.loads(path.read_text(encoding="utf-8"))
    receipt[field] = value
    path.write_text(json.dumps(receipt), encoding="utf-8")

    result = pytest_runtime.run_pytest_profile(manifest, profile)

    assert result.get("fast_path") != "signed-suite-result"
    assert result["saved_ms"] != 9_999_999.0


def test_shared_fingerprint_work_is_equivalent_and_final_snapshot_detects_drift(
    monkeypatch, tmp_path: Path
):
    """Request-local memoization preserves digests and cannot cross a race check."""

    from collections import Counter

    from zerorun import fingerprint

    manifest, profile = _repo(tmp_path)
    task = manifest.tasks[profile.task_name]
    runtime_identity = {"requested_image": IMAGE}
    environment_fingerprint = {}
    real_sha256_file = fingerprint.sha256_file
    hash_calls: Counter[Path] = Counter()

    def counted_sha256_file(path: Path) -> str:
        hash_calls[path.resolve()] += 1
        return real_sha256_file(path)

    monkeypatch.setattr(fingerprint, "sha256_file", counted_sha256_file)
    pre_session = FingerprintSession(tmp_path)
    shared_review = pytest_runtime._source_review_coverage(
        tmp_path,
        profile,
        session=pre_session,
    )
    shared_collection = pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity=runtime_identity,
        environment_fingerprint=environment_fingerprint,
        session=pre_session,
    )
    shared_input = pytest_runtime._profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        runtime_identity=runtime_identity,
        environment_fingerprint=environment_fingerprint,
        session=pre_session,
    )
    expected_files = {
        (tmp_path / relative).resolve()
        for relative in (
            "conftest.py",
            "pyproject.toml",
            "src/calc.py",
            "tests/test_calc.py",
        )
    }
    assert hash_calls == Counter({path: 1 for path in expected_files})

    # The optimized shared pass is byte-for-byte equivalent to independent
    # uncached computations at the same stable source state.
    assert shared_review == pytest_runtime._source_review_coverage(
        tmp_path,
        profile,
        session=FingerprintSession(tmp_path),
    )
    assert shared_collection == pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity=runtime_identity,
        environment_fingerprint=environment_fingerprint,
    )
    assert shared_input == pytest_runtime._profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        runtime_identity=runtime_identity,
        environment_fingerprint=environment_fingerprint,
    )

    (tmp_path / "tests" / "test_calc.py").write_text(
        "from src.calc import add\n\ndef test_add():\n    assert add(1, 2) == 3\n# drift\n",
        encoding="utf-8",
    )
    final_session = FingerprintSession(tmp_path)
    final_review = pytest_runtime._source_review_coverage(
        tmp_path,
        profile,
        session=final_session,
    )
    final_collection = pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity=runtime_identity,
        environment_fingerprint=environment_fingerprint,
        session=final_session,
    )
    final_input = pytest_runtime._profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        runtime_identity=runtime_identity,
        environment_fingerprint=environment_fingerprint,
        session=final_session,
    )
    assert final_review != shared_review
    assert final_collection != shared_collection
    assert final_input != shared_input


def test_static_discovery_prunes_excluded_root_trees_before_descent(
    monkeypatch, tmp_path: Path
):
    from zerorun import pytest_closure

    def fake_walk(root, *, topdown, onerror, followlinks):
        assert topdown is True
        assert followlinks is False
        assert callable(onerror)
        directories = ["pkg", ".zerorun-env", ".zerorun", ".git"]
        yield str(root), directories, []
        # os.walk observes the caller's in-place edit before descending.
        assert directories == ["pkg"]
        yield str(Path(root) / "pkg"), [], ["conftest.py"]

    monkeypatch.setattr(pytest_closure.os, "walk", fake_walk)
    assert pytest_closure.discover_pytest_static_inputs(tmp_path) == (
        "pkg/conftest.py",
    )


def test_static_discovery_matches_pytest_9_config_precedence_even_empty(
    tmp_path: Path,
):
    from zerorun import pytest_closure

    precedence = (
        "pytest.toml",
        ".pytest.toml",
        "pytest.ini",
        ".pytest.ini",
        "pyproject.toml",
        "tox.ini",
        "setup.cfg",
    )
    for name in reversed(precedence):
        (tmp_path / name).write_text("", encoding="utf-8")

    assert pytest_closure.discover_pytest_static_inputs(tmp_path) == precedence


def test_static_config_order_matches_pinned_pytest_locator(tmp_path: Path):
    from _pytest.config.findpaths import locate_config
    from zerorun import pytest_closure

    candidates = (
        ("pytest.toml", ""),
        (".pytest.toml", ""),
        ("pytest.ini", ""),
        (".pytest.ini", ""),
        ("pyproject.toml", "[tool.pytest.ini_options]\n"),
        ("tox.ini", "[pytest]\n"),
        ("setup.cfg", "[tool:pytest]\n"),
    )
    assert pytest_closure._PYTEST_CONFIG_INPUT_NAMES == tuple(
        name for name, _contents in candidates
    )
    for name, contents in candidates:
        (tmp_path / name).write_text(contents, encoding="utf-8")

    for expected, _contents in candidates:
        root, config, _values, _ignored = locate_config(tmp_path, [tmp_path])
        assert root == tmp_path
        assert config == tmp_path / expected
        (tmp_path / expected).unlink()


def test_static_discovery_inventories_nested_target_ancestor_configs(
    tmp_path: Path,
):
    from zerorun import pytest_closure

    target_directory = tmp_path / "tests" / "unit"
    target_directory.mkdir(parents=True)
    (target_directory / ".pytest.ini").write_text("", encoding="utf-8")
    (target_directory / "pytest.toml").write_text("", encoding="utf-8")
    (target_directory / "setup.py").write_text("", encoding="utf-8")

    assert pytest_closure.discover_pytest_static_inputs(tmp_path) == (
        "tests/unit/pytest.toml",
        "tests/unit/.pytest.ini",
        "tests/unit/setup.py",
    )


def test_targeted_static_discovery_excludes_unreachable_repo_subtrees(
    tmp_path: Path,
) -> None:
    from zerorun import pytest_closure

    target = tmp_path / "tests" / "unit" / "test_selected.py"
    target.parent.mkdir(parents=True)
    target.write_text("def test_selected():\n    assert True\n", encoding="utf-8")
    (tmp_path / "tests" / "conftest.py").write_text("# parent\n", encoding="utf-8")
    (target.parent / "conftest.py").write_text("# nearest\n", encoding="utf-8")
    nested = target.parent / "nested"
    nested.mkdir()
    (nested / "conftest.py").write_text("# descendant\n", encoding="utf-8")
    unrelated = tmp_path / "examples" / "demo"
    unrelated.mkdir(parents=True)
    (unrelated / "conftest.py").write_text("# unrelated\n", encoding="utf-8")
    (unrelated / "pyproject.toml").write_text(
        "[tool.pytest.ini_options]\n",
        encoding="utf-8",
    )
    (tmp_path / "pyproject.toml").write_text(
        "[tool.pytest.ini_options]\n",
        encoding="utf-8",
    )

    file_inventory = pytest_closure.discover_pytest_static_inputs(
        tmp_path,
        targets=("tests/unit/test_selected.py::test_selected",),
    )
    directory_inventory = pytest_closure.discover_pytest_static_inputs(
        tmp_path,
        targets=("tests/unit",),
    )

    assert "pyproject.toml" in file_inventory
    assert "tests/conftest.py" in file_inventory
    assert "tests/unit/conftest.py" in file_inventory
    assert "tests/unit/nested/conftest.py" not in file_inventory
    assert "examples/demo/conftest.py" not in file_inventory
    assert "examples/demo/pyproject.toml" not in file_inventory
    assert "tests/unit/nested/conftest.py" in directory_inventory


def test_targeted_static_discovery_rejects_linked_target_component(
    tmp_path: Path,
) -> None:
    from zerorun import pytest_closure

    outside = tmp_path / "outside"
    outside.mkdir()
    link = tmp_path / "linked"
    try:
        link.symlink_to(outside, target_is_directory=True)
    except (NotImplementedError, OSError) as exc:
        pytest.skip(f"directory symlink is unavailable: {exc}")

    with pytest.raises(ConfigurationError, match="symbolic link or junction"):
        pytest_closure.discover_pytest_static_inputs(
            tmp_path,
            targets=("linked/test_selected.py",),
        )


def test_guard_helpers_use_one_request_local_expansion_session(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    task = manifest.tasks["pytest"]
    session = FingerprintSession(tmp_path)
    real_expand = session.expand_inputs
    real_expand_absent = session.expand_expected_absent_inputs
    calls: list[tuple[str, ...]] = []
    absent_calls: list[tuple[str, ...]] = []

    def observed_expand(root: Path, patterns: tuple[str, ...]):
        calls.append(patterns)
        return real_expand(root, patterns)

    def observed_expand_absent(root: Path, patterns: tuple[str, ...]):
        absent_calls.append(patterns)
        return real_expand_absent(root, patterns)

    monkeypatch.setattr(session, "expand_inputs", observed_expand)
    monkeypatch.setattr(
        session,
        "expand_expected_absent_inputs",
        observed_expand_absent,
    )
    pytest_runtime._collection_guard_sha256(
        tmp_path,
        profile,
        runtime_identity=_full_runtime_identity(),
        environment_fingerprint={},
        session=session,
    )
    pytest_runtime._profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        runtime_identity=_full_runtime_identity(),
        environment_fingerprint={},
        session=session,
    )

    assert len(calls) == 2
    assert calls[0] == tuple(
        dict.fromkeys(target.partition("::")[0] for target in profile.targets)
    )
    assert set(profile.static_inputs).issubset(set(calls[1]))
    assert absent_calls == [tuple(
        sorted(
            {
                path
                for closure in (profile.session_closure, *profile.nodes.values())
                for path in closure.get("absent_files", [])
                if closure.get("reviewable", True) is True
                and closure.get("fresh_required", False) is not True
            }
        )
    )]


def test_profile_guard_hierarchical_absence_is_digest_equivalent(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    profile = _profile_with_session_absences(
        profile,
        "src/optional_shadow.py",
        "src/optional_shadow/__init__.py",
    )
    task = manifest.tasks[profile.task_name]
    runtime_identity = _full_runtime_identity()
    calls: list[tuple[str, ...]] = []
    real_optimized = pytest_runtime.expand_expected_absent_inputs

    def observed_optimized(root: Path, patterns: tuple[str, ...]):
        calls.append(patterns)
        return real_optimized(root, patterns)

    monkeypatch.setattr(
        pytest_runtime,
        "expand_expected_absent_inputs",
        observed_optimized,
    )
    optimized = pytest_runtime._profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        runtime_identity=runtime_identity,
        environment_fingerprint={},
    )

    def generic_absence(root: Path, patterns: tuple[str, ...]):
        return pytest_runtime.expand_inputs(root, patterns)

    monkeypatch.setattr(
        pytest_runtime,
        "expand_expected_absent_inputs",
        generic_absence,
    )
    generic = pytest_runtime._profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        runtime_identity=runtime_identity,
        environment_fingerprint={},
    )

    assert calls == [
        ("src/optional_shadow.py", "src/optional_shadow/__init__.py")
    ]
    assert optimized == generic


def test_profile_guard_hierarchical_absence_rejects_present_candidate(
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    profile = _profile_with_session_absences(profile, "src/optional_shadow.py")
    task = manifest.tasks[profile.task_name]
    arguments = {
        "runtime_identity": _full_runtime_identity(),
        "environment_fingerprint": {},
    }
    pytest_runtime._profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        **arguments,
    )

    (tmp_path / "src" / "optional_shadow.py").write_text(
        "VALUE = 1\n",
        encoding="utf-8",
    )
    with pytest.raises(ConfigurationError, match="negative import candidate"):
        pytest_runtime._profile_input_guard_sha256(
            tmp_path,
            task,
            profile,
            **arguments,
        )


def test_suite_guard_independent_pass_observes_negative_surface_race(
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    profile = _profile_with_session_absences(profile, "src/optional_shadow.py")
    task = manifest.tasks[profile.task_name]
    arguments = {
        "runtime_identity": _full_runtime_identity(),
        "environment_fingerprint": {},
    }
    first = pytest_runtime._suite_guard_snapshot(
        tmp_path,
        task,
        profile,
        **arguments,
    )
    assert first["action_guard_sha256"]

    (tmp_path / "src" / "optional_shadow.py").write_text(
        "VALUE = 1\n",
        encoding="utf-8",
    )
    with pytest.raises(ConfigurationError, match="negative import candidate"):
        pytest_runtime._suite_guard_snapshot(
            tmp_path,
            task,
            profile,
            **arguments,
        )


def test_profile_guard_unsupported_absence_pattern_falls_back_exactly(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    from zerorun import fingerprint

    manifest, profile = _repo(tmp_path)
    unsupported = "src/*/optional_shadow.py"
    profile = _profile_with_session_absences(profile, unsupported)
    task = manifest.tasks[profile.task_name]
    real_expand = fingerprint.expand_inputs
    fallback_calls: list[tuple[str, ...]] = []

    def observed_fallback(root: Path, patterns: tuple[str, ...], **kwargs):
        fallback_calls.append(patterns)
        return real_expand(root, patterns, **kwargs)

    monkeypatch.setattr(fingerprint, "expand_inputs", observed_fallback)
    digest = pytest_runtime._profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        runtime_identity=_full_runtime_identity(),
        environment_fingerprint={},
    )

    assert digest
    assert fallback_calls == [(unsupported,)]


def test_static_discovery_propagates_unreadable_directory_uncertainty(
    monkeypatch, tmp_path: Path
):
    from zerorun import pytest_closure

    def unreadable_walk(root, *, topdown, onerror, followlinks):
        del root, topdown, followlinks
        onerror(PermissionError("simulated unreadable test tree"))
        yield  # pragma: no cover - keeps this function a generator

    monkeypatch.setattr(pytest_closure.os, "walk", unreadable_walk)
    with pytest.raises(PermissionError, match="simulated unreadable test tree"):
        pytest_closure.discover_pytest_static_inputs(tmp_path)


def test_new_conftest_disables_reuse_and_publication(
    monkeypatch, tmp_path: Path
):
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    calls = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del fresh_nodeids, runtime_identity, environment
        calls.append(baseline_collection)
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no reviewed baseline was available",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    first = pytest_runtime.run_pytest_profile(manifest, profile)
    assert first["published_nodes"] == 1

    pytest_runtime._VERIFIED_ACTION_SNAPSHOTS.clear()
    (tmp_path / "tests" / "conftest.py").write_text(
        "import pytest\n\n@pytest.fixture(autouse=True)\ndef changed_context():\n    yield\n",
        encoding="utf-8",
    )
    second = pytest_runtime.run_pytest_profile(manifest, profile)

    assert calls == [None, None]
    assert second["fresh_nodes"] == 1
    assert second["reused_nodes"] == 0
    assert second["published_nodes"] == 0
    assert second["unknown_nodes"] == 1
    assert second["profile_refresh_required"] is True
    assert second["profile_refresh_node_count"] == 1
    assert second["profile_refresh_reasons"] == [
        "pytest static discovery surface changed; refresh the reviewed profile before reuse"
    ]


@pytest.mark.parametrize(
    ("relative", "contents"),
    (
        (
            "pytest.toml",
            '[pytest]\npython_files = ["check_*.py"]\n',
        ),
        (".pytest.ini", ""),
    ),
    ids=("behavior-changing-pytest-toml", "empty-hidden-pytest-ini"),
)
def test_new_higher_precedence_config_forces_recollection_without_publication(
    monkeypatch,
    tmp_path: Path,
    relative: str,
    contents: str,
):
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    baselines = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del fresh_nodeids, runtime_identity, environment
        baselines.append(baseline_collection)
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no reviewed baseline was available",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["published_nodes"] == 1

    pytest_runtime._VERIFIED_ACTION_SNAPSHOTS.clear()
    (tmp_path / relative).write_text(contents, encoding="utf-8")
    changed = pytest_runtime.run_pytest_profile(manifest, profile)

    assert baselines == [None, None]
    assert changed["fresh_nodes"] == 1
    assert changed["reused_nodes"] == 0
    assert changed["published_nodes"] == 0
    assert changed["unknown_nodes"] == 1
    assert changed["profile_refresh_required"] is True
    assert changed["profile_refresh_node_count"] == 1
    assert changed["profile_refresh_reasons"] == [
        "pytest static discovery surface changed; refresh the reviewed profile before reuse"
    ]


def test_reviewed_config_negative_plugin_drift_is_fresh_and_nonpublishing(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    initial = _collection()
    changed = _sealed_collection(
        initial["items"],
        initial["nodeids"],
        addopts=["-p", "no:logging"],
    )
    collection = {"value": initial}
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    baselines: list[dict | None] = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del fresh_nodeids, runtime_identity, environment
        baselines.append(baseline_collection)
        current = collection["value"]
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no reviewed baseline was available",
                "collection": current,
                "fresh_nodeids": list(current["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["published_nodes"] == 1

    pytest_runtime._VERIFIED_ACTION_SNAPSHOTS.clear()
    (tmp_path / "pyproject.toml").write_text(
        "[tool.pytest.ini_options]\naddopts = ['-p', 'no:logging']\n",
        encoding="utf-8",
    )
    collection["value"] = changed
    result = pytest_runtime.run_pytest_profile(manifest, profile)

    assert baselines == [None, None]
    assert result["fresh_nodes"] == 1
    assert result["reused_nodes"] == 0
    assert result["published_nodes"] == 0
    assert result["unknown_nodes"] == 1
    assert result["reuse_authorized"] is False
    assert result["profile_refresh_required"] is True
    assert result["profile_refresh_reasons"] == [
        "pytest shared source-review authority changed (static_inputs_sha256); "
        "explicit requalification is required"
    ]


def test_runtime_rejects_explicit_config_before_suite_result_lookup(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    from dataclasses import replace

    manifest, profile = _repo(tmp_path)
    unbound = replace(
        profile,
        base_args=("--config-file=late-unreviewed.ini",),
    )
    monkeypatch.setattr(
        pytest_runtime,
        "_try_signed_suite_result",
        lambda *_args, **_kwargs: pytest.fail(
            "suite-result lookup must follow effective-command validation"
        ),
    )

    with pytest.raises(
        ConfigurationError,
        match="empty profile base_args",
    ):
        pytest_runtime.run_pytest_profile(manifest, unbound)


def test_legacy_unanchored_profile_is_fresh_and_nonpublishing(
    monkeypatch, tmp_path: Path
):
    manifest, _ = _repo(tmp_path)
    profile_path = tmp_path / ".zerorun-pytest.json"
    raw_profile = json.loads(profile_path.read_text(encoding="utf-8"))
    raw_profile.pop("source_review")
    profile_path.write_text(json.dumps(raw_profile), encoding="utf-8")
    profile = load_pytest_profile(profile_path, manifest)
    collection = _collection()
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )

    def single_pass(*_args, **kwargs):
        assert kwargs["baseline_collection"] is None
        return (
            0,
            100.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "no reviewed baseline was available",
                "collection": collection,
                "fresh_nodeids": list(collection["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    result = pytest_runtime.run_pytest_profile(manifest, profile)

    assert result["fresh_nodes"] == 1
    assert result["reused_nodes"] == 0
    assert result["published_nodes"] == 0
    assert result["profile_refresh_required"] is True
    assert result["profile_refresh_reasons"] == [
        "pytest profile predates source-review anchoring; explicit requalification is required"
    ]


def test_lookup_trust_drift_forces_every_node_fresh(
    monkeypatch, tmp_path: Path
):
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    calls = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity, environment
        fresh = (
            list(collection["nodeids"])
            if baseline_collection is None
            else list(fresh_nodeids)
        )
        reused = [
            nodeid
            for nodeid in collection["nodeids"]
            if nodeid not in set(fresh)
        ]
        calls.append({"baseline": baseline_collection, "fresh": fresh})
        return (
            0,
            100.0,
            b"ok",
            b"",
            {
                "mode": (
                    "whole-target-fresh"
                    if baseline_collection is None
                    else "single-pass-incremental"
                ),
                "reason": None,
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    first = pytest_runtime.run_pytest_profile(manifest, profile)
    assert first["published_nodes"] == 1
    pytest_runtime._VERIFIED_ACTION_SNAPSHOTS.clear()

    original_verify = pytest_runtime.CacheTrustSession.verify_unchanged
    verify_calls = 0

    def drift_once(session):
        nonlocal verify_calls
        verify_calls += 1
        if verify_calls == 1:
            session.abort()
            raise ConfigurationError("simulated tracked-state drift")
        return original_verify(session)

    monkeypatch.setattr(
        pytest_runtime.CacheTrustSession,
        "verify_unchanged",
        drift_once,
    )
    second = pytest_runtime.run_pytest_profile(manifest, profile)

    assert second["exit_code"] == 0
    assert second["fresh_nodes"] == 1
    assert second["reused_nodes"] == 0
    assert second["reuse_authorized"] is False
    # Authority drift invalidates the collection baseline as well as the node
    # hits. The recovery run must execute the whole target and publish nothing.
    assert calls[1]["baseline"] is None
    assert calls[1]["fresh"] == list(collection["nodeids"])


@pytest.mark.parametrize(
    "mutation", ["source", "environment", "profile", "bytecode"]
)
def test_partial_reuse_is_reverified_after_slow_trust_attestation(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    mutation: str,
) -> None:
    """A provisional sibling reuse cannot escape a post-execution trust race."""

    manifest, original_profile = _repo(tmp_path)
    add_node = "tests/test_calc.py::test_add"
    sub_node = "tests/test_calc.py::test_sub"
    (tmp_path / "src" / "add.py").write_text(
        "def add(a, b):\n    return a + b\n", encoding="utf-8"
    )
    (tmp_path / "src" / "sub.py").write_text(
        "def sub(a, b):\n    return a - b\n", encoding="utf-8"
    )
    (tmp_path / "tests" / "test_calc.py").write_text(
        "from src.add import add\nfrom src.sub import sub\n\n"
        "def test_add():\n    assert add(1, 2) == 3\n\n"
        "def test_sub():\n    assert sub(3, 2) == 1\n",
        encoding="utf-8",
    )
    profile_payload = json.loads(
        original_profile.path.read_text(encoding="utf-8")
    )
    profile_payload["nodes"] = {
        add_node: {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [],
            "fallback_files": ["src/add.py", "tests/test_calc.py"],
        },
        sub_node: {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [],
            "fallback_files": ["src/sub.py", "tests/test_calc.py"],
        },
    }
    profile_payload["source_review"] = build_pytest_source_review(
        tmp_path,
        static_inputs=tuple(profile_payload["static_inputs"]),
        session_closure=profile_payload["session_closure"],
        nodes=profile_payload["nodes"],
        profiler_sha256=pytest_qualify.profiler_sha256(),
        collection_plugin_sha256=pytest_runtime.collection_plugin_sha256(),
    )
    original_profile.path.write_text(
        json.dumps(profile_payload), encoding="utf-8"
    )
    profile = load_pytest_profile(original_profile.path, manifest)
    items = [_collection_item(add_node), _collection_item(sub_node)]
    collection = _sealed_collection(items, [add_node, sub_node])
    environment_state: dict[str, str] = {}
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )

    def current_environment(_task):
        raw = dict(environment_state)
        return raw, {
            name: {"present": True, "value": value}
            for name, value in sorted(raw.items())
        }

    monkeypatch.setattr(
        pytest_runtime, "hermetic_environment", current_environment
    )
    execution_calls: list[dict[str, object]] = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity
        fresh = (
            list(collection["nodeids"])
            if baseline_collection is None
            else list(fresh_nodeids)
        )
        reused = [
            nodeid
            for nodeid in collection["nodeids"]
            if nodeid not in set(fresh)
        ]
        execution_calls.append(
            {
                "baseline": baseline_collection,
                "fresh": fresh,
                "reused": reused,
                "environment": dict(environment),
            }
        )
        return (
            0,
            1000.0,
            b"ok",
            b"",
            {
                "mode": (
                    "whole-target-fresh"
                    if baseline_collection is None
                    else "single-pass-incremental"
                ),
                "reason": None,
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    seeded = pytest_runtime.run_pytest_profile(manifest, profile)
    assert seeded["published_nodes"] == 2
    (tmp_path / "src" / "add.py").write_text(
        "def add(a, b):\n    return a + b + 0\n", encoding="utf-8"
    )

    real_verify = pytest_runtime.CacheTrustSession.verify_unchanged
    mutated = False

    def racing_verify(session):
        nonlocal mutated
        real_verify(session)
        if mutated:
            return
        mutated = True
        if mutation == "source":
            (tmp_path / "src" / "sub.py").write_text(
                "def sub(a, b):\n    return a - b + 1\n", encoding="utf-8"
            )
        elif mutation == "environment":
            environment_state["FLAG"] = "changed"
        elif mutation == "profile":
            profile.path.write_text(
                profile.path.read_text(encoding="utf-8") + "\n",
                encoding="utf-8",
            )
        else:
            (tmp_path / "late_module.pyc").write_bytes(b"not trusted bytecode")

    monkeypatch.setattr(
        pytest_runtime.CacheTrustSession, "verify_unchanged", racing_verify
    )
    result = pytest_runtime.run_pytest_profile(manifest, profile)

    assert mutated is True
    assert execution_calls[1]["baseline"] is not None
    assert execution_calls[1]["fresh"] == [add_node]
    assert execution_calls[1]["reused"] == [sub_node]
    assert execution_calls[2]["baseline"] is None
    assert execution_calls[2]["fresh"] == [add_node, sub_node]
    if mutation == "environment":
        assert execution_calls[2]["environment"] == {"FLAG": "changed"}
    assert result["status"] == "PYTEST_FRESH_RECOVERY"
    assert result["fresh_nodes"] == 2
    assert result["reused_nodes"] == 0
    assert result["published_nodes"] == 0
    assert result["reuse_authorized"] is False


def test_reviewed_function_new_dependency_stays_fresh_until_requalification(
    monkeypatch, tmp_path: Path
):
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    real_open = pytest_runtime.CacheTrustSession.open
    trust_open_modes = []

    def counted_open(*args, **kwargs):
        trust_open_modes.append(bool(kwargs.get("create_secret")))
        return real_open(*args, **kwargs)

    monkeypatch.setattr(
        pytest_runtime.CacheTrustSession,
        "open",
        staticmethod(counted_open),
    )
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity, environment
        fresh = (
            list(collection["nodeids"])
            if baseline_collection is None
            else list(fresh_nodeids)
        )
        reused = [
            nodeid
            for nodeid in collection["nodeids"]
            if nodeid not in set(fresh)
        ]
        return (
            0,
            100.0,
            b"ok",
            b"",
            {
                "mode": (
                    "whole-target-fresh"
                    if baseline_collection is None
                    else "single-pass-incremental"
                ),
                "reason": None,
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)
    first = pytest_runtime.run_pytest_profile(manifest, profile)
    assert first["published_nodes"] == 1
    assert trust_open_modes == [True]

    (tmp_path / "src" / "calc.py").write_text(
        "def hidden_dependency(a, b):\n    return a + b\n\n"
        "def add(a, b):\n    return hidden_dependency(a, b)\n",
        encoding="utf-8",
    )
    second = pytest_runtime.run_pytest_profile(manifest, profile)
    assert second.get("fast_path") is None
    assert second["fresh_nodes"] == 1
    assert second["reused_nodes"] == 0
    assert second["published_nodes"] == 0
    assert second["profile_refresh_required"] is True
    assert second["profile_refresh_reasons"] == [
        "pytest node source-review authority changed; explicit requalification is required before reuse or publication"
    ]

    # A second request at the same edited source must not turn the fresh result
    # into a hit under the stale closure. Only explicit requalification may
    # authorize the newly introduced dependency topology.
    third = pytest_runtime.run_pytest_profile(manifest, profile)
    assert third["fresh_nodes"] == 1
    assert third["reused_nodes"] == 0
    assert third["published_nodes"] == 0
    assert third["profile_refresh_required"] is True
    assert trust_open_modes == [True]


def test_collection_drift_runs_current_collection_fresh_in_same_pass(
    monkeypatch, tmp_path: Path
):
    manifest, profile = _repo(tmp_path)
    initial = _collection()
    changed = _collection(extra=True)
    pytest_runtime._prepare_mountpoints(tmp_path)
    pytest_runtime._save_collection_snapshot(
        tmp_path, profile, initial
    )
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )

    def single_pass(*args, **kwargs):
        return (
            0,
            150.0,
            b"ok",
            b"",
            {
                "mode": "whole-target-fresh",
                "reason": "collection changed",
                "collection": changed,
                "fresh_nodeids": list(changed["nodeids"]),
                "reused_nodeids": [],
            },
        )

    monkeypatch.setattr(
        pytest_runtime, "execute_single_pass", single_pass
    )
    result = pytest_runtime.run_pytest_profile(manifest, profile)

    assert result["status"] == "PYTEST_INCREMENTAL_PASS"
    assert result["reuse_authorized"] is False
    assert result["fresh_nodes"] == 2
    assert result["reused_nodes"] == 0
    assert result["selection_mode"] == "whole-target-fresh"


def test_forged_persisted_collection_snapshot_cannot_elide_new_test(
    tmp_path: Path,
) -> None:
    manifest, profile = _repo(tmp_path)
    pytest_runtime._prepare_mountpoints(tmp_path)
    pytest_runtime._save_collection_snapshot(
        manifest,
        profile,
        _collection(),
        collection_guard_sha256="a" * 64,
    )
    snapshot_path = (
        tmp_path / ".zerorun" / pytest_runtime._COLLECTION_SNAPSHOT
    )
    forged = json.loads(snapshot_path.read_text(encoding="utf-8"))
    # This is internally valid public collection evidence for an added test,
    # and the public guard can also be recomputed. The external MAC cannot.
    forged["collection"] = _collection(extra=True)
    forged["collection_guard_sha256"] = "b" * 64
    snapshot_path.write_text(json.dumps(forged), encoding="utf-8")

    assert pytest_runtime._load_collection_snapshot(manifest, profile) is None


def test_large_selection_is_file_backed_not_host_argv(monkeypatch, tmp_path: Path):
    manifest, profile = _repo(tmp_path)
    task = manifest.tasks["pytest"]
    runtime = {"requested_image": IMAGE}
    captured = {}

    monkeypatch.setattr(
        pytest_runtime,
        "_docker_base",
        lambda *args, **kwargs: (
            [
                "docker",
                "create",
                "--name",
                "zerorun-test-container",
                "--env-file",
                pytest_runtime._ENV_FILE_PLACEHOLDER,
                IMAGE,
            ],
            {},
            b"LANG=C\n",
        ),
    )

    class Result:
        returncode = 0
        stdout = b"ok"
        stderr = b""

    def fake_run(command, **kwargs):
        captured["command"] = list(command)
        support = None
        for index, value in enumerate(command):
            if value == "--mount" and index + 1 < len(command):
                mount = command[index + 1]
                if (
                    mount.startswith("type=bind,src=")
                    and ",dst=/zerorun-pytest,readonly" in mount
                ):
                    support = Path(
                        mount.split("type=bind,src=", 1)[1].split(",dst=", 1)[0]
                    )
        assert support is not None
        request = json.loads(
            (support / "selection-input.json").read_text(encoding="utf-8")
        )
        current_nodeids = list(request["fresh_nodeids"])
        current = _sealed_collection(
            [_collection_item(nodeid) for nodeid in current_nodeids],
            current_nodeids,
        )
        (support / "selection-output.json").write_text(
            json.dumps(
                {
                    "mode": "whole-target-fresh",
                    "reason": "no exact baseline was supplied",
                    "collection": current,
                    "fresh_nodeids": current["nodeids"],
                    "reused_nodeids": [],
                    "executed_nodeids": current["nodeids"],
                }
            ),
            encoding="utf-8",
        )
        return Result()

    monkeypatch.setattr(pytest_runtime, "_run_created_container", fake_run)
    nodeids = [
        f"tests/test_calc.py::test_{index:05d}"
        for index in range(10000)
    ]
    pytest_runtime.execute_single_pass(
        manifest,
        task,
        profile,
        baseline_collection=None,
        fresh_nodeids=nodeids,
        runtime_identity=runtime,
        environment={},
    )
    command = captured["command"]
    assert not any(nodeid in command for nodeid in nodeids)
    assert profile.targets[0] in command


def test_host_rejects_forged_per_node_alignment_identity(
    monkeypatch, tmp_path: Path
):
    manifest, profile = _repo(tmp_path)
    baseline = _collection()
    current = _collection(extra=True)
    current["items"][0]["fixturenames"] = ["new_autouse_fixture"]
    unsigned_item = dict(current["items"][0])
    unsigned_item.pop("identity_sha256")
    import hashlib

    current["items"][0]["identity_sha256"] = hashlib.sha256(
        json.dumps(unsigned_item, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    current["collection_sha256"] = hashlib.sha256(
        json.dumps(
            {
                "invocation": current["invocation"],
                "items": current["items"],
                "nodeids": current["nodeids"],
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()
    monkeypatch.setattr(
        pytest_runtime,
        "_docker_base",
        lambda *args, **kwargs: (
            [
                "docker",
                "create",
                "--name",
                "zerorun-test-container",
                "--env-file",
                pytest_runtime._ENV_FILE_PLACEHOLDER,
                IMAGE,
            ],
            {},
            b"LANG=C\n",
        ),
    )

    class Result:
        returncode = 0
        stdout = b"ok"
        stderr = b""

    def fake_run(command, **_kwargs):
        output = None
        for index, value in enumerate(command):
            if value != "--mount" or index + 1 >= len(command):
                continue
            mount = command[index + 1]
            if f",dst={pytest_runtime._SINGLE_PASS_OUTPUT}" in mount:
                output = Path(
                    mount.split("type=bind,src=", 1)[1].split(",dst=", 1)[0]
                )
                break
        assert output is not None
        # The embedded plugin is an untrusted evidence producer from the
        # host's perspective. Forge a reuse claim for the structurally changed
        # old node; independent host recomputation must reject it.
        output.write_text(
            json.dumps(
                {
                    "mode": "per-node-aligned-incremental",
                    "reason": None,
                    "collection": current,
                    "fresh_nodeids": ["tests/test_calc.py::test_new"],
                    "reused_nodeids": ["tests/test_calc.py::test_add"],
                    "executed_nodeids": ["tests/test_calc.py::test_new"],
                }
            ),
            encoding="utf-8",
        )
        return Result()

    monkeypatch.setattr(pytest_runtime, "_run_docker_process", fake_run)
    with pytest.raises(
        ConfigurationError,
        match="per-node alignment evidence does not match",
    ):
        pytest_runtime.execute_single_pass(
            manifest,
            manifest.tasks["pytest"],
            profile,
            baseline_collection=baseline,
            fresh_nodeids=[],
            runtime_identity={"requested_image": IMAGE},
            environment={},
        )



def test_guard_drift_uses_in_process_exact_collection_check(
    monkeypatch, tmp_path: Path
):
    manifest, profile = _repo(tmp_path)
    collection = _collection()
    monkeypatch.setattr(
        pytest_runtime,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_runtime,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    guard = {"value": "a" * 64}
    monkeypatch.setattr(
        pytest_runtime,
        "_collection_guard_sha256",
        lambda *args, **kwargs: guard["value"],
    )
    calls = []

    def single_pass(
        _manifest,
        _task,
        _profile,
        *,
        baseline_collection,
        fresh_nodeids,
        runtime_identity,
        environment,
    ):
        del runtime_identity, environment
        calls.append(
            {
                "baseline": baseline_collection,
                "fresh": list(fresh_nodeids),
            }
        )
        if baseline_collection is None:
            fresh = list(collection["nodeids"])
            reused = []
            mode = "whole-target-fresh"
        else:
            fresh = list(fresh_nodeids)
            reused = [
                nodeid
                for nodeid in collection["nodeids"]
                if nodeid not in set(fresh)
            ]
            mode = "single-pass-incremental"
        return (
            0,
            100.0,
            b"ok",
            b"",
            {
                "mode": mode,
                "reason": None,
                "collection": collection,
                "fresh_nodeids": fresh,
                "reused_nodeids": reused,
            },
        )

    monkeypatch.setattr(pytest_runtime, "execute_single_pass", single_pass)

    first = pytest_runtime.run_pytest_profile(manifest, profile)
    assert first["fresh_nodes"] == 1
    assert first["published_nodes"] == 1

    guard["value"] = "b" * 64
    second = pytest_runtime.run_pytest_profile(manifest, profile)
    assert second["exit_code"] == 0
    assert second["reused_nodes"] == 1
    assert second["fresh_nodes"] == 0
    assert second["selection_mode"] == "single-pass-incremental"
    assert calls[1]["baseline"] == collection
    assert calls[1]["fresh"] == []
