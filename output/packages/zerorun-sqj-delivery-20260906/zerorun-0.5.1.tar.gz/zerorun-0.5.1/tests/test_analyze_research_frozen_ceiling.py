from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

import pytest

from tools import analyze_research_frozen_ceiling as analyzer
from zerorun.model import ConfigurationError


ROOT = Path(__file__).resolve().parents[1]
ARCHIVED_ROOT = (
    ROOT
    / "research/results/formative/more-itertools-fe24c33-pre-thread-support"
)
ARCHIVED_RECEIPT = ARCHIVED_ROOT / "raw/more-itertools-ceiling-v1.json"
ARCHIVED_SNAPSHOT = (
    ROOT
    / "research/artifact/historical-tools"
    / "3052655088efd69a48f1fc773279c2e0bffa7574f7d41657d772bd219007bc6a"
)
ARCHIVED_SUMMARY = ARCHIVED_ROOT / "summary.json"
ARCHIVED_LATEX = ROOT / "research/paper/generated/frozen_ceiling_results.tex"
STAMP = "2026-09-05T12:00:00.000Z"
EXPECTED_CONTAINER_ENVIRONMENT = {
    "LANG": "C",
    "LC_ALL": "C",
    "PYTHONHASHSEED": "0",
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONPATH": "/workspace/src:/workspace:/workspace/.zerorun-env/site-packages",
    "TZ": "UTC",
}
EXPECTED_RESOURCE_ARGS = [
    "--cpus",
    "2",
    "--memory",
    "2g",
    "--memory-swap",
    "2g",
    "--pids-limit",
    "512",
]


def _stream(tail: str = "passed") -> dict[str, object]:
    return {
        "capture_scope": "bounded_last_2000_unicode_characters",
        "tail": tail,
        "tail_char_count": len(tail),
        "tail_utf8_sha256": hashlib.sha256(tail.encode("utf-8")).hexdigest(),
    }


def _execution(wall_ms: float) -> dict[str, object]:
    return {
        "exit_code": 0,
        "wall_ms": wall_ms,
        "runner": analyzer.RUNNER,
        "instrumented": False,
        "stdout": _stream(),
        "stderr": _stream(""),
    }


def _tool_identity() -> dict[str, object]:
    files = []
    for relative in (
        "tools/research_frozen_ceiling.py",
        "tools/product_generalization_benchmark.py",
    ):
        raw = (ROOT / relative).read_bytes()
        files.append(
            {
                "path": relative,
                "size": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest(),
            }
        )
    payload: dict[str, object] = {
        "schema": "zerorun.ceiling-tool-identity.v1",
        "files": files,
    }
    payload["sha256"] = analyzer._canonical_sha256(payload)
    return payload


def _valid_receipt() -> dict[str, object]:
    requested_digest = analyzer.LOCKED_RUNTIME_IMAGE.rsplit("@", 1)[1]
    unsafe = [
        "tests/test_more.py::CallbackIterTests::test_abort",
        "tests/test_more.py::TestConcurrentTee::test_concurrent_consumers",
    ]
    repetitions = 2
    schedule = analyzer._expected_schedule(repetitions)
    full_values = iter((100.0, 120.0))
    unsafe_values = iter((80.0, 100.0))
    observations = []
    for slot in schedule:
        arm = slot["arm"]
        wall = next(full_values if arm == "full" else unsafe_values)
        targets = analyzer.FULL_TARGETS if arm == "full" else unsafe
        observations.append(
            {
                **slot,
                "targets_sha256": analyzer._canonical_sha256(targets),
                **_execution(wall),
            }
        )
    phases = [
        "before-warmup-1-full",
        "after-warmup-1-full",
        "before-warmup-2-unsafe",
        "after-warmup-2-unsafe",
    ]
    for slot in schedule:
        label = f"measured-{slot['sequence_position']}-{slot['arm']}"
        phases.extend((f"before-{label}", f"after-{label}"))
    phases.append("post-attestation")
    checks = [
        {
            "phase": phase,
            "checked_at_utc": STAMP,
            "running_container_count": 0,
            "running_container_ids_sha256": analyzer.EMPTY_IDS_SHA256,
        }
        for phase in phases
    ]
    receipt: dict[str, object] = {
        "schema": analyzer.RECEIPT_SCHEMA,
        "artifact_role": analyzer.RECEIPT_ROLE,
        "confirmatory_evidence": False,
        "release_gate_evidence": False,
        "workload": analyzer.WORKLOAD,
        "claim_boundary": analyzer.CLAIM_BOUNDARY,
        "counterfactual": analyzer.COUNTERFACTUAL,
        "started_at_utc": STAMP,
        "completed_at_utc": STAMP,
        "repository_identity": {
            "repository": analyzer.FROZEN_REPOSITORY,
            "root": "/home/floxy/benchmark-more-itertools",
            "origin": "https://github.com/more-itertools/more-itertools.git",
            "head": analyzer.FROZEN_SEED_SHA,
            "tree": analyzer.FROZEN_SEED_TREE,
            "tracked_clean": True,
            "allowed_generated_untracked": [
                ".zerorun-env/",
                ".zerorun-pytest.candidate.json",
                ".zerorun.json",
            ],
            "submodules": [],
            "git_launcher": {
                "resolved_path": "/usr/bin/git",
                "size": 3_662_344,
                "sha256": "1" * 64,
            },
        },
        "runtime": {
            "runtime_identity": {
                "runtime": "docker",
                "requested_image": analyzer.LOCKED_RUNTIME_IMAGE,
                "requested_digest": requested_digest,
                "platform": "linux/amd64",
                "image_id": requested_digest,
                "repo_digests": ["python@" + requested_digest],
                "rootfs": {
                    "type": "layers",
                    "layers": ["sha256:" + "2" * 64],
                },
                "config_sha256": "3" * 64,
            },
            "docker_version": {
                "client": {"Version": "29.1.3"},
                "server": {"Version": "29.1.3"},
            },
            "docker_launcher": {
                "resolved_path": "/usr/bin/docker",
                "size": 12_345,
                "sha256": "4" * 64,
            },
        },
        "locked_environment": {
            "runtime_requirements_sha256": analyzer.LOCKED_REQUIREMENTS_SHA256,
            "file_count": 500,
            "total_bytes": 5_000_000,
            "file_tree_sha256": "5" * 64,
            "controlled_container_environment": dict(EXPECTED_CONTAINER_ENVIRONMENT),
            "docker_resource_args": list(EXPECTED_RESOURCE_ARGS),
            "network": "none",
            "root_filesystem": "read-only",
            "platform": "linux/amd64",
        },
        "host": {
            "system": "Linux",
            "release": "6.8.0",
            "machine": "x86_64",
            "python_implementation": "CPython",
            "python_version": "3.10.12",
            "logical_cpu_count": 5,
        },
        "tool_identity": _tool_identity(),
        "docker_isolation": {
            "required_running_container_count": 0,
            "before_and_after_every_direct_observation": True,
            "post_attestation_check": True,
            "check_count": len(checks),
            "checks": checks,
        },
        "candidate": {
            "candidate_sha256": "6" * 64,
            "candidate_file_sha256": "7" * 64,
            "schema": "zerorun-pytest-candidate-v1",
            "authorizes_reuse": False,
            "collection_node_count": analyzer.FROZEN_COLLECTION_NODE_COUNT,
            "reviewable_node_count": analyzer.FROZEN_COLLECTION_NODE_COUNT - len(unsafe),
            "mandatory_unsafe_node_count": len(unsafe),
            "mandatory_unsafe_nodeids": unsafe,
            "mandatory_unsafe_nodeids_sha256": analyzer._canonical_sha256(unsafe),
            "uncertainty_kind_required": "thread-start",
        },
        "protocol": {
            "full_targets": analyzer.FULL_TARGETS,
            "warmup_runs_per_arm": 1,
            "warmups_excluded": True,
            "measured_repetitions_per_arm": repetitions,
            "sequence": schedule,
            "counterbalanced": True,
            "runner": analyzer.RUNNER,
            "instrumented": False,
        },
        "warmups": [
            {
                "warmup_index": 1,
                "arm": "full",
                "excluded_from_statistics": True,
                **_execution(101.0),
            },
            {
                "warmup_index": 2,
                "arm": "unsafe",
                "excluded_from_statistics": True,
                **_execution(81.0),
            },
        ],
        "observations": observations,
        "summary": {
            "full_wall_ms": [100.0, 120.0],
            "mandatory_unsafe_wall_ms": [80.0, 100.0],
            "median_full_wall_ms": 110.0,
            "median_mandatory_unsafe_wall_ms": 90.0,
            "observed_theoretical_zero_cost_clean_ceiling_multiple": 110.0 / 90.0,
            "formula": analyzer.FORMULA,
            "strict_gate_asserted": False,
        },
    }
    receipt["record_sha256"] = analyzer._canonical_sha256(receipt)
    return receipt


def _reseal(receipt: dict[str, object]) -> None:
    receipt.pop("record_sha256", None)
    receipt["record_sha256"] = analyzer._canonical_sha256(receipt)


def _write(path: Path, receipt: dict[str, object]) -> None:
    path.write_text(json.dumps(receipt, sort_keys=True, separators=(",", ":")) + "\n", encoding="utf-8")


def test_valid_receipt_generates_formative_summary_and_latex(tmp_path: Path) -> None:
    receipt_path = tmp_path / "receipt.json"
    summary_path = tmp_path / "summary.json"
    latex_path = tmp_path / "frozen_ceiling_results.tex"
    _write(receipt_path, _valid_receipt())
    analysis = analyzer.analyze(
        receipt_path=receipt_path,
        summary_output=summary_path,
        latex_output=latex_path,
        source_root=ROOT,
    )
    assert analysis["formative_only"] is True
    assert analysis["confirmatory_evidence"] is False
    assert analysis["release_gate_evidence"] is False
    assert analysis["strict_gate_asserted"] is False
    assert analysis["median_full_wall_ms"] == 110.0
    assert analysis["median_mandatory_unsafe_wall_ms"] == 90.0
    assert analysis["observed_theoretical_zero_cost_clean_ceiling_multiple"] == 110.0 / 90.0
    unsigned = dict(analysis)
    claimed = unsigned.pop("analysis_sha256")
    assert claimed == analyzer._canonical_sha256(unsigned)
    assert json.loads(summary_path.read_text(encoding="utf-8")) == analysis
    latex = latex_path.read_text(encoding="utf-8")
    assert r"\newcommand{\FrozenCeilingEvidenceRole}{Formative-only}" in latex
    assert r"\newcommand{\FrozenCeilingConfirmatoryEvidence}{No}" in latex
    assert r"\newcommand{\FrozenCeilingReleaseGateEvidence}{No}" in latex
    assert r"\newcommand{\FrozenCeilingMultiple}{1.222x}" in latex


def test_receipt_reader_rejects_duplicate_keys_and_nonfinite_numbers(tmp_path: Path) -> None:
    duplicate = tmp_path / "duplicate.json"
    duplicate.write_text('{"schema":"a","schema":"b"}', encoding="utf-8")
    with pytest.raises(ConfigurationError, match="duplicate JSON member"):
        analyzer._read_receipt(duplicate)
    nonfinite = tmp_path / "nonfinite.json"
    nonfinite.write_text('{"wall":NaN}', encoding="utf-8")
    with pytest.raises(ConfigurationError, match="non-finite"):
        analyzer._read_receipt(nonfinite)


def test_validator_recomputes_top_level_self_digest() -> None:
    receipt = _valid_receipt()
    receipt["workload"] = "changed-after-seal"
    with pytest.raises(ConfigurationError, match="self-digest"):
        analyzer.validate_receipt(
            receipt,
            receipt_file_sha256="a" * 64,
            source_root=ROOT,
        )


def _set_release(value):
    value["release_gate_evidence"] = True


def _set_confirmatory(value):
    value["confirmatory_evidence"] = True


def _set_observation_exit(value):
    value["observations"][0]["exit_code"] = 1


def _set_tail_digest(value):
    value["observations"][0]["stdout"]["tail_utf8_sha256"] = "0" * 64


def _set_target_digest(value):
    value["observations"][0]["targets_sha256"] = "0" * 64


def _set_schedule(value):
    value["protocol"]["sequence"][0]["arm"] = "unsafe"


def _set_isolation_count(value):
    value["docker_isolation"]["checks"][0]["running_container_count"] = 1


def _remove_isolation_check(value):
    value["docker_isolation"]["checks"].pop()
    value["docker_isolation"]["check_count"] -= 1


def _set_summary_median(value):
    value["summary"]["median_full_wall_ms"] = 109.0


def _set_summary_ceiling(value):
    value["summary"]["observed_theoretical_zero_cost_clean_ceiling_multiple"] = 5.0


def _set_candidate_count(value):
    value["candidate"]["mandatory_unsafe_node_count"] = 1


def _set_candidate_digest(value):
    value["candidate"]["mandatory_unsafe_nodeids_sha256"] = "0" * 64


def _set_seed(value):
    value["repository_identity"]["head"] = "0" * 40


def _set_image(value):
    value["runtime"]["runtime_identity"]["requested_image"] = "python@sha256:" + "0" * 64


def _set_lock(value):
    value["locked_environment"]["runtime_requirements_sha256"] = "0" * 64


def _misspell_python_no_bytecode(value):
    environment = value["locked_environment"]["controlled_container_environment"]
    environment["PYTHONDWRITEBYTECODE"] = environment.pop("PYTHONDONTWRITEBYTECODE")


@pytest.mark.parametrize(
    "mutate",
    [
        _set_release,
        _set_confirmatory,
        _set_observation_exit,
        _set_tail_digest,
        _set_target_digest,
        _set_schedule,
        _set_isolation_count,
        _remove_isolation_check,
        _set_summary_median,
        _set_summary_ceiling,
        _set_candidate_count,
        _set_candidate_digest,
        _set_seed,
        _set_image,
        _set_lock,
        _misspell_python_no_bytecode,
    ],
)
def test_validator_rejects_resealed_adversarial_receipts(mutate) -> None:
    receipt = _valid_receipt()
    mutate(receipt)
    _reseal(receipt)
    with pytest.raises(ConfigurationError):
        analyzer.validate_receipt(
            receipt,
            receipt_file_sha256="a" * 64,
            source_root=ROOT,
        )


def test_validator_binds_receipt_to_local_measurement_sources() -> None:
    receipt = _valid_receipt()
    receipt["tool_identity"]["files"][0]["sha256"] = "0" * 64
    nested = {
        "schema": receipt["tool_identity"]["schema"],
        "files": receipt["tool_identity"]["files"],
    }
    receipt["tool_identity"]["sha256"] = analyzer._canonical_sha256(nested)
    _reseal(receipt)
    with pytest.raises(ConfigurationError, match="differs from local source"):
        analyzer.validate_receipt(
            receipt,
            receipt_file_sha256="a" * 64,
            source_root=ROOT,
        )


def test_analysis_outputs_are_non_overwriting(tmp_path: Path) -> None:
    receipt_path = tmp_path / "receipt.json"
    summary_path = tmp_path / "summary.json"
    latex_path = tmp_path / "results.tex"
    _write(receipt_path, _valid_receipt())
    summary_path.write_text("owner data", encoding="utf-8")
    with pytest.raises(ConfigurationError, match="overwrite"):
        analyzer.analyze(
            receipt_path=receipt_path,
            summary_output=summary_path,
            latex_output=latex_path,
            source_root=ROOT,
        )
    assert summary_path.read_text(encoding="utf-8") == "owner data"
    assert not latex_path.exists()


def test_isolation_timestamps_must_be_inside_receipt_interval() -> None:
    receipt = _valid_receipt()
    receipt["docker_isolation"]["checks"][0]["checked_at_utc"] = "2026-09-05T11:59:59.000Z"
    _reseal(receipt)
    with pytest.raises(ConfigurationError, match="outside the receipt interval"):
        analyzer.validate_receipt(
            receipt,
            receipt_file_sha256="a" * 64,
            source_root=ROOT,
        )


def test_archived_tool_snapshot_reproduces_historical_outputs(tmp_path: Path) -> None:
    summary = tmp_path / "summary.json"
    latex = tmp_path / "results.tex"
    analysis = analyzer.analyze(
        receipt_path=ARCHIVED_RECEIPT,
        summary_output=summary,
        latex_output=latex,
        source_root=ARCHIVED_SNAPSHOT,
    )

    assert analysis == json.loads(ARCHIVED_SUMMARY.read_text(encoding="utf-8"))
    assert summary.read_bytes() == ARCHIVED_SUMMARY.read_bytes()
    assert latex.read_bytes() == ARCHIVED_LATEX.read_bytes()
    assert analysis["formative_only"] is True
    assert analysis["confirmatory_evidence"] is False
    assert analysis["release_gate_evidence"] is False


def test_archived_snapshot_rejects_raw_byte_tamper(tmp_path: Path) -> None:
    snapshot = tmp_path / "snapshot"
    shutil.copytree(ARCHIVED_SNAPSHOT, snapshot)
    archive = snapshot / "tools/product_generalization_benchmark.py"
    raw = archive.read_bytes()
    archive.write_bytes(bytes([raw[0] ^ 1]) + raw[1:])

    receipt, receipt_sha = analyzer._read_receipt(ARCHIVED_RECEIPT)
    with pytest.raises(ConfigurationError, match="differs from local source"):
        analyzer.validate_receipt(
            receipt,
            receipt_file_sha256=receipt_sha,
            source_root=snapshot,
        )


def test_archived_snapshot_rejects_substituted_tool_even_if_manifest_is_updated(
    tmp_path: Path,
) -> None:
    snapshot = tmp_path / "snapshot"
    shutil.copytree(ARCHIVED_SNAPSHOT, snapshot)
    archive = snapshot / "tools/product_generalization_benchmark.py"
    archive.write_bytes(b"substituted historical tool\n")
    manifest_path = snapshot / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    row = manifest["files"][1]
    row["size"] = archive.stat().st_size
    row["sha256"] = hashlib.sha256(archive.read_bytes()).hexdigest()
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )

    receipt, receipt_sha = analyzer._read_receipt(ARCHIVED_RECEIPT)
    with pytest.raises(ConfigurationError, match="snapshot identity differs"):
        analyzer.validate_receipt(
            receipt,
            receipt_file_sha256=receipt_sha,
            source_root=snapshot,
        )


def test_archived_snapshot_rejects_forged_git_context(tmp_path: Path) -> None:
    snapshot = tmp_path / "snapshot"
    shutil.copytree(ARCHIVED_SNAPSHOT, snapshot)
    manifest_path = snapshot / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["base_git_commit_context"]["commit"] = "0" * 40
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )

    receipt, receipt_sha = analyzer._read_receipt(ARCHIVED_RECEIPT)
    with pytest.raises(ConfigurationError, match="Git context differs"):
        analyzer.validate_receipt(
            receipt,
            receipt_file_sha256=receipt_sha,
            source_root=snapshot,
        )


def test_historical_receipt_cannot_be_relabelled_as_current_source() -> None:
    receipt, receipt_sha = analyzer._read_receipt(ARCHIVED_RECEIPT)
    with pytest.raises(ConfigurationError, match="differs from local source"):
        analyzer.validate_receipt(
            receipt,
            receipt_file_sha256=receipt_sha,
            source_root=ROOT,
        )
