from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
import stat
import tarfile
from dataclasses import dataclass, field
from pathlib import Path

import pytest

from tools import normalize_sdist as normalizer


ROOT_NAME = "zerorun-0.5.1"
EPOCH = 1_788_580_800


@dataclass(frozen=True)
class Entry:
    name: str
    data: bytes = b""
    member_type: bytes = tarfile.REGTYPE
    mode: int = 0o644
    linkname: str = ""
    pax_headers: dict[str, str] = field(default_factory=dict)


def _base_entries(*, reverse: bool = False, fractional_mtime: bool = False):
    long_name = f"{ROOT_NAME}/zerorun/" + "long-module-" + "x" * 105 + ".py"
    entries = [
        Entry(ROOT_NAME, member_type=tarfile.DIRTYPE, mode=0o755),
        Entry(
            f"{ROOT_NAME}/PKG-INFO",
            b"Metadata-Version: 2.4\nName: zerorun\nVersion: 0.5.1\n",
        ),
        Entry(
            f"{ROOT_NAME}/pyproject.toml",
            b'[project]\nname = "zerorun"\nversion = "0.5.1"\n',
        ),
        Entry(
            f"{ROOT_NAME}/zerorun",
            member_type=tarfile.DIRTYPE,
            mode=0o755,
        ),
        Entry(
            f"{ROOT_NAME}/zerorun/__init__.py",
            b'__version__ = "0.5.1"\n',
        ),
        Entry(
            f"{ROOT_NAME}/zerorun/runner.py",
            b"def main():\n    return 0\n",
            mode=0o755,
        ),
        Entry(long_name, b"VALUE = 1\n"),
    ]
    if fractional_mtime:
        entries = [
            Entry(
                entry.name,
                entry.data,
                entry.member_type,
                entry.mode,
                entry.linkname,
                {**entry.pax_headers, "mtime": "1700000000.125"},
            )
            for entry in entries
        ]
    return list(reversed(entries)) if reverse else entries


def _write_archive(
    path: Path,
    entries: list[Entry],
    *,
    gzip_mtime: int = 1_700_000_000,
    member_mtime: int = 1_600_000_000,
    uid: int = 123,
    gid: int = 456,
    uname: str = "builder",
    gname: str = "workers",
    gzip_filename: str = "host-specific-name.tar",
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as raw:
        with gzip.GzipFile(
            filename=gzip_filename,
            mode="wb",
            compresslevel=6,
            fileobj=raw,
            mtime=gzip_mtime,
        ) as compressed:
            with tarfile.open(
                fileobj=compressed,
                mode="w|",
                format=tarfile.PAX_FORMAT,
            ) as archive:
                for entry in entries:
                    info = tarfile.TarInfo(entry.name)
                    info.type = entry.member_type
                    info.mode = entry.mode
                    info.uid = uid
                    info.gid = gid
                    info.uname = uname
                    info.gname = gname
                    info.mtime = member_mtime
                    info.linkname = entry.linkname
                    info.pax_headers = dict(entry.pax_headers)
                    info.size = len(entry.data) if entry.member_type == tarfile.REGTYPE else 0
                    archive.addfile(
                        info,
                        fileobj=(
                            io.BytesIO(entry.data)
                            if entry.member_type == tarfile.REGTYPE
                            else None
                        ),
                    )


def _snapshot(path: Path):
    rows = []
    with tarfile.open(path, mode="r:gz") as archive:
        for member in archive.getmembers():
            payload = b""
            if member.isfile():
                extracted = archive.extractfile(member)
                assert extracted is not None
                payload = extracted.read()
            rows.append(
                {
                    "name": member.name,
                    "type": member.type,
                    "mode": member.mode,
                    "uid": member.uid,
                    "gid": member.gid,
                    "uname": member.uname,
                    "gname": member.gname,
                    "mtime": member.mtime,
                    "pax_headers": dict(member.pax_headers),
                    "payload": payload,
                }
            )
    return rows


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_normalization_is_byte_reproducible_semantic_and_idempotent(
    tmp_path: Path,
) -> None:
    first = tmp_path / "first" / f"{ROOT_NAME}.tar.gz"
    second = tmp_path / "second" / f"{ROOT_NAME}.tar.gz"
    first_entries = _base_entries(reverse=False, fractional_mtime=False)
    second_entries = _base_entries(reverse=True, fractional_mtime=True)
    _write_archive(
        first,
        first_entries,
        gzip_mtime=1_600_000_001,
        member_mtime=1_500_000_001,
        uid=101,
        gid=102,
        uname="first-host",
        gname="first-group",
        gzip_filename="first-build.tar",
    )
    _write_archive(
        second,
        second_entries,
        gzip_mtime=1_700_000_002,
        member_mtime=1_500_000_002,
        uid=201,
        gid=202,
        uname="second-host",
        gname="second-group",
        gzip_filename="second-build.tar",
    )
    assert first.read_bytes() != second.read_bytes()

    expected_payloads = {
        entry.name: entry.data
        for entry in first_entries
        if entry.member_type == tarfile.REGTYPE
    }
    expected_modes = {entry.name: entry.mode for entry in first_entries}
    first_receipt = normalizer.normalize_sdist(first, EPOCH)
    second_receipt = normalizer.normalize_sdist(second, EPOCH)

    assert first.read_bytes() == second.read_bytes()
    assert first_receipt == second_receipt
    assert first_receipt == {
        "artifact": f"{ROOT_NAME}.tar.gz",
        "artifact_sha256": _sha256(first),
        "content_manifest_sha256": first_receipt["content_manifest_sha256"],
        "member_count": len(first_entries),
        "source_date_epoch": EPOCH,
    }

    header = first.read_bytes()[:10]
    assert header[:3] == b"\x1f\x8b\x08"
    assert header[3] & 0x08 == 0  # no original filename in the gzip header
    assert int.from_bytes(header[4:8], "little") == EPOCH

    snapshot = _snapshot(first)
    assert [row["name"] for row in snapshot] == sorted(expected_modes)
    assert {row["name"]: row["mode"] for row in snapshot} == expected_modes
    assert {
        row["name"]: row["payload"]
        for row in snapshot
        if row["type"] in {tarfile.REGTYPE, tarfile.AREGTYPE}
    } == expected_payloads
    for row in snapshot:
        assert row["mtime"] == EPOCH
        assert row["uid"] == 0
        assert row["gid"] == 0
        assert row["uname"] == ""
        assert row["gname"] == ""
        assert set(row["pax_headers"]) <= {"path"}
        if "path" in row["pax_headers"]:
            assert row["pax_headers"]["path"] == row["name"]

    once = first.read_bytes()
    repeated = normalizer.normalize_sdist(first, EPOCH)
    assert first.read_bytes() == once
    assert repeated["artifact_sha256"] == first_receipt["artifact_sha256"]
    assert repeated["content_manifest_sha256"] == first_receipt[
        "content_manifest_sha256"
    ]
    assert not list(first.parent.glob(f".{first.name}.normalize-*.tmp"))
    if os.name != "nt":
        assert stat.S_IMODE(first.stat().st_mode) == 0o644


def _unsafe_entries(case: str) -> list[Entry]:
    entries = _base_entries()
    if case == "absolute":
        entries.append(Entry("/absolute"))
    elif case == "traversal":
        entries.append(Entry(f"{ROOT_NAME}/../escape"))
    elif case == "dot":
        entries.append(Entry(f"{ROOT_NAME}/./escape"))
    elif case == "double-separator":
        entries.append(Entry(f"{ROOT_NAME}//escape"))
    elif case == "backslash":
        entries.append(Entry(f"{ROOT_NAME}\\escape"))
    elif case == "second-root":
        entries.append(Entry("another-root/file"))
    elif case == "duplicate":
        entries.append(Entry(f"{ROOT_NAME}/PKG-INFO", b"replacement"))
    elif case == "symlink":
        entries.append(
            Entry(
                f"{ROOT_NAME}/linked",
                member_type=tarfile.SYMTYPE,
                linkname="PKG-INFO",
            )
        )
    elif case == "hardlink":
        entries.append(
            Entry(
                f"{ROOT_NAME}/hard-linked",
                member_type=tarfile.LNKTYPE,
                linkname=f"{ROOT_NAME}/PKG-INFO",
            )
        )
    elif case == "character-device":
        entries.append(
            Entry(f"{ROOT_NAME}/device", member_type=tarfile.CHRTYPE)
        )
    elif case == "block-device":
        entries.append(
            Entry(f"{ROOT_NAME}/device", member_type=tarfile.BLKTYPE)
        )
    elif case == "fifo":
        entries.append(Entry(f"{ROOT_NAME}/fifo", member_type=tarfile.FIFOTYPE))
    elif case == "sparse":
        entries.append(
            Entry(f"{ROOT_NAME}/sparse", member_type=tarfile.GNUTYPE_SPARSE)
        )
    elif case == "special-mode":
        entries.append(Entry(f"{ROOT_NAME}/setuid", b"x", mode=0o4755))
    elif case == "extended-pax":
        entries.append(
            Entry(
                f"{ROOT_NAME}/xattr",
                b"x",
                pax_headers={"SCHILY.xattr.user.demo": "value"},
            )
        )
    else:  # pragma: no cover - protects this test helper
        raise AssertionError(case)
    return entries


@pytest.mark.parametrize(
    "case",
    [
        "absolute",
        "traversal",
        "dot",
        "double-separator",
        "backslash",
        "second-root",
        "duplicate",
        "symlink",
        "hardlink",
        "character-device",
        "block-device",
        "fifo",
        "sparse",
        "special-mode",
        "extended-pax",
    ],
)
def test_normalization_rejects_unsafe_or_nonportable_members_without_mutation(
    tmp_path: Path,
    case: str,
) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    _write_archive(artifact, _unsafe_entries(case))
    before = artifact.read_bytes()
    with pytest.raises(normalizer.SdistNormalizationError):
        normalizer.normalize_sdist(artifact, EPOCH)
    assert artifact.read_bytes() == before
    assert not list(tmp_path.glob(f".{artifact.name}.normalize-*.tmp"))


@pytest.mark.parametrize("required", ["PKG-INFO", "pyproject.toml"])
def test_normalization_requires_standard_sdist_files(
    tmp_path: Path,
    required: str,
) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    entries = [
        entry
        for entry in _base_entries()
        if entry.name != f"{ROOT_NAME}/{required}"
    ]
    _write_archive(artifact, entries)
    before = artifact.read_bytes()
    with pytest.raises(
        normalizer.SdistNormalizationError,
        match="missing required regular file",
    ):
        normalizer.normalize_sdist(artifact, EPOCH)
    assert artifact.read_bytes() == before


def test_normalization_requires_filename_derived_root_directory(tmp_path: Path) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    entries = [
        entry
        for entry in _base_entries()
        if entry.name != ROOT_NAME
    ]
    _write_archive(artifact, entries)
    with pytest.raises(
        normalizer.SdistNormalizationError,
        match="missing its filename-derived top-level directory",
    ):
        normalizer.normalize_sdist(artifact, EPOCH)


@pytest.mark.parametrize(
    ("limit_name", "limit_value", "message"),
    [
        ("_MAX_COMPRESSED_BYTES", 1, "compressed archive limit"),
        ("_MAX_UNCOMPRESSED_TAR_BYTES", 1_024, "uncompressed tar limit"),
        ("_MAX_MEMBER_BYTES", 4, "per-file limit"),
        ("_MAX_TOTAL_FILE_BYTES", 8, "total payload limit"),
        ("_MAX_MEMBER_COUNT", 2, "member-count limit"),
        ("_MAX_MEMBER_NAME_BYTES", 12, "empty or too long"),
    ],
)
def test_normalization_enforces_resource_limits_before_replacement(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    limit_name: str,
    limit_value: int,
    message: str,
) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    _write_archive(artifact, _base_entries())
    before = artifact.read_bytes()
    monkeypatch.setattr(normalizer, limit_name, limit_value)
    with pytest.raises(normalizer.SdistNormalizationError, match=message):
        normalizer.normalize_sdist(artifact, EPOCH)
    assert artifact.read_bytes() == before


@pytest.mark.parametrize("epoch", [-1, 1 << 32, True, 1.25, "1700000000"])
def test_normalization_rejects_invalid_epochs_without_mutation(
    tmp_path: Path,
    epoch,
) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    _write_archive(artifact, _base_entries())
    before = artifact.read_bytes()
    with pytest.raises(normalizer.SdistNormalizationError, match="must be"):
        normalizer.normalize_sdist(artifact, epoch)
    assert artifact.read_bytes() == before


def test_normalization_rejects_corrupt_or_misnamed_inputs(tmp_path: Path) -> None:
    corrupt = tmp_path / f"{ROOT_NAME}.tar.gz"
    corrupt.write_bytes(b"not a gzip archive")
    with pytest.raises(
        normalizer.SdistNormalizationError,
        match="valid gzip-compressed tar archive",
    ):
        normalizer.normalize_sdist(corrupt, EPOCH)

    wrong_extension = tmp_path / f"{ROOT_NAME}.zip"
    _write_archive(wrong_extension, _base_entries())
    with pytest.raises(
        normalizer.SdistNormalizationError,
        match="must end in .tar.gz",
    ):
        normalizer.normalize_sdist(wrong_extension, EPOCH)


def test_normalization_rejects_directory_and_link_inputs(tmp_path: Path) -> None:
    directory = tmp_path / f"{ROOT_NAME}.tar.gz"
    directory.mkdir()
    with pytest.raises(
        normalizer.SdistNormalizationError,
        match="must be a regular file",
    ):
        normalizer.normalize_sdist(directory, EPOCH)
    directory.rmdir()

    target = tmp_path / "target.tar.gz"
    _write_archive(target, _base_entries())
    linked = tmp_path / f"{ROOT_NAME}.tar.gz"
    try:
        linked.symlink_to(target)
    except OSError as exc:
        pytest.skip(f"file symlinks are unavailable: {exc}")
    before = target.read_bytes()
    with pytest.raises(
        normalizer.SdistNormalizationError,
        match="must be a regular file",
    ):
        normalizer.normalize_sdist(linked, EPOCH)
    assert target.read_bytes() == before
    assert linked.is_symlink()


def test_normalization_rejects_linked_parent(tmp_path: Path) -> None:
    real_parent = tmp_path / "real"
    artifact = real_parent / f"{ROOT_NAME}.tar.gz"
    _write_archive(artifact, _base_entries())
    linked_parent = tmp_path / "linked"
    try:
        linked_parent.symlink_to(real_parent, target_is_directory=True)
    except OSError as exc:
        pytest.skip(f"directory symlinks are unavailable: {exc}")
    linked_artifact = linked_parent / artifact.name
    before = artifact.read_bytes()
    with pytest.raises(
        normalizer.SdistNormalizationError,
        match="must be a real directory",
    ):
        normalizer.normalize_sdist(linked_artifact, EPOCH)
    assert artifact.read_bytes() == before


@pytest.mark.skipif(os.name == "nt", reason="mkfifo is unavailable on Windows")
def test_normalization_rejects_special_input_without_opening_it(tmp_path: Path) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    os.mkfifo(artifact, mode=0o600)
    with pytest.raises(
        normalizer.SdistNormalizationError,
        match="must be a regular file",
    ):
        normalizer.normalize_sdist(artifact, EPOCH)
    assert artifact.is_fifo()


def test_cli_prints_a_machine_readable_receipt(tmp_path: Path, capsys) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    _write_archive(artifact, _base_entries())
    assert (
        normalizer.main(
            [
                "--source-date-epoch",
                str(EPOCH),
                str(artifact),
            ]
        )
        == 0
    )
    captured = capsys.readouterr()
    receipt = json.loads(captured.out)
    assert captured.err == ""
    assert receipt["artifact"] == artifact.name
    assert receipt["artifact_sha256"] == _sha256(artifact)
    assert receipt["source_date_epoch"] == EPOCH


def test_cli_fails_closed_without_replacing_an_invalid_archive(
    tmp_path: Path,
    capsys,
) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    artifact.write_bytes(b"invalid")
    before = artifact.read_bytes()
    assert (
        normalizer.main(
            [
                "--source-date-epoch",
                str(EPOCH),
                str(artifact),
            ]
        )
        == 1
    )
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "normalize-sdist: error:" in captured.err
    assert artifact.read_bytes() == before


def test_write_failure_removes_only_its_owned_temporary_file(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    artifact = tmp_path / f"{ROOT_NAME}.tar.gz"
    _write_archive(artifact, _base_entries())
    before = artifact.read_bytes()

    def fail_fsync(_descriptor: int) -> None:
        raise OSError("simulated durable-write failure")

    monkeypatch.setattr(normalizer.os, "fsync", fail_fsync)
    with pytest.raises(OSError, match="simulated durable-write failure"):
        normalizer.normalize_sdist(artifact, EPOCH)
    assert artifact.read_bytes() == before
    assert not list(tmp_path.glob(f".{artifact.name}.normalize-*.tmp"))
