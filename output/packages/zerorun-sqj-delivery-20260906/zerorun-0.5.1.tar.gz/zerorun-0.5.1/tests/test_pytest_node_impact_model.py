from __future__ import annotations

from pathlib import Path
import tempfile

import pytest

from tools.pytest_node_impact_model import (
    framework_closure_fingerprint,
    node_source_identity_fingerprint,
)
from tools.pytest_reviewed_source_equivalence import apply_reviewed_equivalence
from zerorun.hermetic_batch_key import FingerprintSession
from zerorun.model import ConfigurationError


_PR8749_PATCH = "10cf662c76a1778d8c30b35315888914a95d72a4739d123282f1240fa44ea4fe"
_ADDITIONAL_REVIEWED_EQUIVALENCES = (
    (
        9624,
        "42ce2ac8fd537830181ec231d31f6a2e94aed250e4805dca8a53d738efaec76a",
        "src/_pytest/unittest.py::@module-state",
        "src/_pytest/unittest.py::TestCaseFunction.runtest",
        ("_pytest.python.Function", "_pytest.python.PyobjMixin"),
        None,
    ),
    (
        9628,
        "d5d545c92cb405e74bf66b5caabf2a0baf99bb985b19d1b0975dd019a6f50bd9",
        "src/_pytest/terminal.py::TerminalReporter.report_collect",
        "testing/test_cacheprovider.py::TestLastFailed.test_lastfailed_no_failures_behavior_all_passed",
        None,
        None,
    ),
    (
        9875,
        "757308ad5c498b0f3095f941e0ffd90a04c6947ec12d09cf81057510d2321a5f",
        "src/_pytest/terminal.py::@module-state",
        "testing/test_terminal.py::test_line_with_reprcrash",
        None,
        None,
    ),
    (
        9933,
        "484b2716dcba7923218926cda7ac5517706844f9708d92f34df79e31c25a89cd",
        "src/_pytest/terminal.py::@module-state",
        "testing/test_terminal.py::test_fail_extra_reporting",
        None,
        None,
    ),
    (
        9915,
        "6bd3179c86469f0a393a798001bb1462396fccfdc75da4aa0ef3a78f4ef41e1a",
        "src/_pytest/cacheprovider.py::Cache.get",
        "testing/test_cacheprovider.py::@module-state",
        None,
        {"default_text_write_utf8": True, "default_text_bytes_hex": "c3a9"},
    ),
    (
        10051,
        "f3a8ca89d952a2fd0be9deffa6cd7fb3133827e43f8016fb10014c7da3c746d3",
        "src/_pytest/logging.py::@module-state",
        "src/_pytest/logging.py::LogCaptureFixture.clear",
        None,
        None,
    ),
)


def _root(source: str) -> tuple[tempfile.TemporaryDirectory, Path]:
    temporary = tempfile.TemporaryDirectory()
    root = Path(temporary.name)
    package = root / "src" / "_pytest"
    package.mkdir(parents=True)
    (package / "example.py").write_text(source, encoding="utf-8")
    return temporary, root


def test_framework_closure_fingerprint_tracks_selected_behavior_not_line_position() -> None:
    temporary, root = _root(
        "VALUE = 1\n\n"
        "def helper():\n"
        "    return VALUE\n\n"
        "def unrelated():\n"
        "    return 2\n"
    )
    node = {
        "selectors": [
            "src/_pytest/example.py::@module-state",
            "src/_pytest/example.py::@binding:VALUE",
            "src/_pytest/example.py::helper",
        ],
        "fallback_files": [],
    }
    try:
        before, _ = framework_closure_fingerprint(root, node)
        path = root / "src" / "_pytest" / "example.py"
        path.write_text("# line shift\n\n" + path.read_text(encoding="utf-8"), encoding="utf-8")
        shifted, _ = framework_closure_fingerprint(root, node)
        assert shifted == before

        path.write_text(
            path.read_text(encoding="utf-8").replace("return VALUE", "return VALUE + 1"),
            encoding="utf-8",
        )
        changed, _ = framework_closure_fingerprint(root, node)
        assert changed != before
    finally:
        temporary.cleanup()


def test_framework_closure_fingerprint_tracks_module_state() -> None:
    temporary, root = _root(
        "FLAG = 1\n\n"
        "def helper():\n"
        "    return 1\n"
    )
    node = {
        "selectors": ["src/_pytest/example.py::@module-state", "src/_pytest/example.py::helper"],
        "fallback_files": [],
    }
    try:
        before, _ = framework_closure_fingerprint(root, node)
        path = root / "src" / "_pytest" / "example.py"
        path.write_text(path.read_text(encoding="utf-8").replace("FLAG = 1", "FLAG = 2"), encoding="utf-8")
        after, _ = framework_closure_fingerprint(root, node)
        assert after != before
    finally:
        temporary.cleanup()


def test_framework_closure_fingerprint_tracks_fallback_files() -> None:
    temporary, root = _root("def helper():\n    return 1\n")
    fallback = root / "src" / "_pytest" / "fallback.py"
    fallback.write_text("VALUE = 1\n", encoding="utf-8")
    node = {
        "selectors": ["src/_pytest/example.py::helper"],
        "fallback_files": ["src/_pytest/fallback.py"],
    }
    try:
        before, _ = framework_closure_fingerprint(root, node)
        fallback.write_text("VALUE = 2\n", encoding="utf-8")
        after, _ = framework_closure_fingerprint(root, node)
        assert after != before
    finally:
        temporary.cleanup()


def test_framework_closure_fingerprint_fails_closed_on_missing_fallback() -> None:
    temporary, root = _root("def helper():\n    return 1\n")
    node = {
        "selectors": ["src/_pytest/example.py::helper"],
        "fallback_files": ["src/_pytest/missing.py"],
    }
    try:
        with pytest.raises(ConfigurationError, match="fallback became unavailable"):
            framework_closure_fingerprint(root, node)
    finally:
        temporary.cleanup()


def test_node_source_identity_includes_shared_session_closure() -> None:
    temporary, root = _root(
        "SESSION = 1\n\n"
        "def node_helper():\n"
        "    return 1\n\n"
        "def session_helper():\n"
        "    return SESSION\n"
    )
    node = {
        "selectors": ["src/_pytest/example.py::node_helper"],
        "fallback_files": [],
    }
    session_row = {
        "selectors": [
            "src/_pytest/example.py::@binding:SESSION",
            "src/_pytest/example.py::session_helper",
        ],
        "fallback_files": [],
    }
    try:
        before, _ = node_source_identity_fingerprint(root, node, session_row)
        path = root / "src" / "_pytest" / "example.py"
        path.write_text(
            path.read_text(encoding="utf-8").replace("SESSION = 1", "SESSION = 2"),
            encoding="utf-8",
        )
        after, _ = node_source_identity_fingerprint(root, node, session_row)
        assert after != before
    finally:
        temporary.cleanup()


def test_pr8749_review_drops_only_unprotected_coarse_module_state() -> None:
    selectors = (
        "src/_pytest/logging.py::@module-state",
        "src/_pytest/logging.py::pytest_addoption",
    )
    effective, review = apply_reviewed_equivalence(
        pr=8749,
        patch_sha256=_PR8749_PATCH,
        selectors=selectors,
    )
    assert review is not None
    assert effective == ("src/_pytest/logging.py::pytest_addoption",)


def test_pr8749_review_keeps_full_identity_when_affected_class_is_referenced() -> None:
    selectors = (
        "src/_pytest/logging.py::@module-state",
        "src/_pytest/logging.py::@binding:LogCaptureFixture",
        "src/_pytest/logging.py::LogCaptureFixture.at_level",
    )
    effective, review = apply_reviewed_equivalence(
        pr=8749,
        patch_sha256=_PR8749_PATCH,
        selectors=selectors,
    )
    assert review is None
    assert effective == selectors


def test_reviewed_source_equivalence_is_patch_identity_bound() -> None:
    selectors = ("src/_pytest/logging.py::@module-state",)
    effective, review = apply_reviewed_equivalence(
        pr=8749,
        patch_sha256="0" * 64,
        selectors=selectors,
    )
    assert review is None
    assert effective == selectors


@pytest.mark.parametrize(
    (
        "pr",
        "patch_sha256",
        "coarse_selector",
        "protected_selector",
        "observed_receiver_mro",
        "runtime_text_encoding",
    ),
    _ADDITIONAL_REVIEWED_EQUIVALENCES,
)
def test_reviewed_equivalences_drop_only_unprotected_coarse_module_state(
    pr: int,
    patch_sha256: str,
    coarse_selector: str,
    protected_selector: str,
    observed_receiver_mro: tuple[str, ...] | None,
    runtime_text_encoding: dict[str, object] | None,
) -> None:
    unrelated = "src/_pytest/config/__init__.py::pytest_configure"
    effective, review = apply_reviewed_equivalence(
        pr=pr,
        patch_sha256=patch_sha256,
        selectors=(coarse_selector, unrelated),
        observed_receiver_mro=observed_receiver_mro,
        runtime_text_encoding=runtime_text_encoding,
    )
    assert review is not None
    assert effective == (unrelated,)

    protected = (coarse_selector, protected_selector)
    protected_effective, protected_review = apply_reviewed_equivalence(
        pr=pr,
        patch_sha256=patch_sha256,
        selectors=protected,
        observed_receiver_mro=observed_receiver_mro,
        runtime_text_encoding=runtime_text_encoding,
    )
    assert protected_review is None
    assert protected_effective == protected
