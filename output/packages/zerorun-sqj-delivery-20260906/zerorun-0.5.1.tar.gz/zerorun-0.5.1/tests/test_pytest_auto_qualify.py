from __future__ import annotations

import ast
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from types import CodeType

import pytest

from zerorun import pytest_closure, pytest_node_cache, pytest_qualify
from zerorun.hermetic_batch_key import FingerprintSession
from zerorun.manifest import load_manifest
from zerorun.model import ConfigurationError
from zerorun.pytest_closure import CallSite, ExecutedImportEdge, resolve_symbol_closure
from zerorun.pytest_node_cache import NodeCacheContext, prepare_node_cache
from zerorun.pytest_node_key import _closure_fingerprint
from zerorun.pytest_profile import load_pytest_profile


IMAGE = "python@sha256:" + "1" * 64


def _repo(tmp_path: Path):
    (tmp_path / ".git").mkdir()
    (tmp_path / "src").mkdir()
    (tmp_path / "tests").mkdir()
    (tmp_path / "src" / "calc.py").write_text(
        "OFFSET = 1\n\ndef add(a, b):\n    return a + b + OFFSET\n",
        encoding="utf-8",
    )
    (tmp_path / "tests" / "test_calc.py").write_text(
        "from src.calc import add\n\ndef test_add():\n    assert add(1, 1) == 3\n",
        encoding="utf-8",
    )
    (tmp_path / "conftest.py").write_text("# session\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text("[tool.pytest.ini_options]\n", encoding="utf-8")
    manifest_path = tmp_path / ".zerorun.json"
    manifest_path.write_text(
        json.dumps(
            {
                "version": 2,
                "tasks": {
                    "pytest": {
                        "command": ["python", "-m", "pytest"],
                        "inputs": ["src", "tests", "conftest.py", "pyproject.toml"],
                        "outputs": [],
                        "env": [],
                        "cacheable": True,
                        "unsafe_effects": [],
                        "cache_streams": False,
                        "image": IMAGE,
                        "platform": "linux/amd64",
                        "result_only": True,
                        "closure_reviewed": True,
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    return load_manifest(manifest_path)


def _collection_invocation(
    targets: tuple[str, ...] = ("tests",),
    *,
    rootpath: str = ".",
    pyargs: bool = False,
    addopts: tuple[str, ...] = (),
) -> dict:
    return {
        "rootpath": rootpath,
        "args": list(targets),
        "pyargs": pyargs,
        "addopts": list(addopts),
    }


def _with_fused_collection(
    profile: dict[str, object],
    collection: dict[str, object],
) -> dict[str, object]:
    return {
        "import_observations": {
            "external_modules": [],
            "stable_external_toplevels": [],
            "project_search_roots": [],
        },
        **profile,
        "collection": collection,
    }


def _exact_collection(
    nodeids: tuple[str, ...] = ("tests/test_calc.py::test_add",),
    *,
    targets: tuple[str, ...] = ("tests",),
) -> dict[str, object]:
    items: list[dict[str, object]] = []
    for nodeid in nodeids:
        unsigned = {
            "nodeid": nodeid,
            "item_type": "_pytest.python.Function",
            "path": nodeid.split("::", 1)[0],
            "name": nodeid.rsplit("::", 1)[-1],
            "fixturenames": [],
            "callspec_params": {},
            "parameter_identity_supported": True,
            "parameter_identity_uncertainty": [],
        }
        encoded = json.dumps(
            unsigned,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        items.append(
            {**unsigned, "identity_sha256": hashlib.sha256(encoded).hexdigest()}
        )
    unsigned_collection = {
        "invocation": _collection_invocation(targets),
        "items": items,
        "nodeids": list(nodeids),
    }
    encoded_collection = json.dumps(
        unsigned_collection,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return {
        **unsigned_collection,
        "collection_sha256": hashlib.sha256(encoded_collection).hexdigest(),
    }


def _profile_output_source(command: list[str]) -> Path:
    for index, value in enumerate(command):
        if value != "--mount" or index + 1 >= len(command):
            continue
        mount = command[index + 1]
        if f",dst={pytest_qualify._PROFILE_OUTPUT_MOUNT}" in mount:
            return Path(mount.split("type=bind,src=", 1)[1].split(",dst=", 1)[0])
    raise AssertionError("profile output mount missing")


def test_qualification_rejects_unreviewed_command_suffix_before_docker(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    raw_manifest = json.loads(manifest.path.read_text(encoding="utf-8"))
    raw_manifest["tasks"]["pytest"]["command"].append("-ccustom.ini")
    manifest.path.write_text(json.dumps(raw_manifest), encoding="utf-8")
    changed_manifest = load_manifest(manifest.path)
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda *_args, **_kwargs: pytest.fail(
            "unbound explicit config must be rejected before Docker inspection"
        ),
    )

    with pytest.raises(
        ConfigurationError,
        match="unsupported pytest command arguments",
    ):
        pytest_qualify.qualify_pytest_candidate(
            changed_manifest,
            task_name="pytest",
            targets=("tests",),
            output=tmp_path / ".zerorun-pytest.candidate.json",
        )


@pytest.mark.parametrize(
    "target",
    [
        "../outside",
        "/tmp/outside",
        "C:/outside",
        "tests\\test_calc.py",
        "@targets.txt",
        "-q",
        "./tests",
        "tests//test_calc.py",
    ],
)
def test_qualification_rejects_unbound_target_forms_before_runtime_inspection(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    target: str,
) -> None:
    manifest = _repo(tmp_path)
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda *_args, **_kwargs: pytest.fail(
            "unsafe target must be rejected before runtime inspection"
        ),
    )

    with pytest.raises(ConfigurationError, match="pytest qualification targets"):
        pytest_qualify.qualify_pytest_candidate(
            manifest,
            task_name="pytest",
            targets=(target,),
            output=tmp_path / ".zerorun-pytest.candidate.json",
        )


@pytest.mark.parametrize(
    ("case", "message"),
    [
        ("missing", "unexpected or missing fields"),
        ("extra-target", "do not exactly match"),
        ("empty-targets", "do not exactly match"),
        ("pyargs", "--pyargs"),
        ("outside-root", "canonical in-workspace path"),
        ("absolute-root", "cwd-relative POSIX path"),
        ("argfile", "argument files"),
    ],
)
def test_qualification_rejects_unbound_collection_invocation_from_profile(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    case: str,
    message: str,
) -> None:
    manifest = _repo(tmp_path)
    invocation = _collection_invocation()
    if case == "missing":
        invocation.pop("rootpath")
    elif case == "extra-target":
        invocation["args"] = ["tests", "outside"]
        invocation["addopts"] = ["outside"]
    elif case == "empty-targets":
        invocation["args"] = []
    elif case == "pyargs":
        invocation["pyargs"] = True
    elif case == "outside-root":
        invocation["rootpath"] = "../outside"
    elif case == "absolute-root":
        invocation["rootpath"] = "/workspace"
    elif case == "argfile":
        invocation["addopts"] = ["@pytest.args"]
    collection = {
        "invocation": invocation,
        "items": [{"path": "tests/test_calc.py"}],
        "nodeids": ["tests/test_calc.py::test_add"],
        "collection_sha256": "4" * 64,
    }
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *_args, **_kwargs: ({"collection": collection}, 1.0, 0, "ok"),
    )

    with pytest.raises(ConfigurationError, match=message):
        pytest_qualify.qualify_pytest_candidate(
            manifest,
            task_name="pytest",
            targets=("tests",),
            output=tmp_path / ".zerorun-pytest.candidate.json",
        )


@pytest.mark.parametrize(
    ("rootpath", "item_path", "message"),
    [
        (".", None, "no reviewable workspace path"),
        (".", "/workspace/tests/test_calc.py", "cwd-relative POSIX path"),
        (".", "../outside/test_calc.py", "canonical in-workspace path"),
        (".", "tests\\test_calc.py", "cwd-relative POSIX path"),
        (".", "other/test_calc.py", "outside the reviewed pytest targets"),
        ("tests/unit", "tests/test_calc.py", "outside the reported pytest rootpath"),
    ],
)
def test_qualification_rejects_outside_or_virtual_collection_items(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    rootpath: str,
    item_path: object,
    message: str,
) -> None:
    manifest = _repo(tmp_path)
    collection = {
        "invocation": _collection_invocation(rootpath=rootpath),
        "items": [{"path": item_path}],
        "nodeids": ["tests/test_calc.py::test_add"],
        "collection_sha256": "4" * 64,
    }
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *_args, **_kwargs: ({"collection": collection}, 1.0, 0, "ok"),
    )

    with pytest.raises(ConfigurationError, match=message):
        pytest_qualify.qualify_pytest_candidate(
            manifest,
            task_name="pytest",
            targets=("tests",),
            output=tmp_path / ".zerorun-pytest.candidate.json",
        )


def test_collection_contract_preserves_exact_node_selector_target() -> None:
    targets = ("tests/test_calc.py::test_add[param::value]",)
    invocation = _collection_invocation(targets)

    validated = pytest_qualify.validate_collection_invocation_contract(
        invocation,
        expected_targets=targets,
        field="test collection invocation",
    )
    pytest_qualify.validate_collection_item_paths(
        [{"path": "tests/test_calc.py"}],
        expected_targets=targets,
        rootpath=str(validated["rootpath"]),
        field="test collection",
    )

    assert validated["args"] == list(targets)


@pytest.mark.parametrize(
    "addopts",
    [
        ("-p",),
        ("-p", "evil_plugin"),
        ("-pevil_plugin",),
        ("-p=no:cacheprovider",),
        ("--plugins",),
        ("--plugins", "evil_plugin"),
        ("--plugins=evil_plugin",),
        ("--plugins-prefix-trick=evil_plugin",),
    ],
)
def test_collection_contract_rejects_addopts_plugin_injection(
    addopts: tuple[str, ...],
) -> None:
    with pytest.raises(ConfigurationError, match="unreviewed pytest plugin"):
        pytest_qualify.validate_collection_invocation_contract(
            _collection_invocation(addopts=addopts),
            expected_targets=("tests",),
            field="test collection invocation",
        )


def test_collection_contract_allows_exact_disabled_cacheprovider_addopts() -> None:
    invocation = _collection_invocation(addopts=("-p", "no:cacheprovider"))

    assert (
        pytest_qualify.validate_collection_invocation_contract(
            invocation,
            expected_targets=("tests",),
            field="test collection invocation",
        )
        is invocation
    )


def _valid_process_profile(pid: int = 123) -> dict:
    nodeids = ["tests/test_calc.py::test_add"]
    return {
        "loaded": True,
        "pid": pid,
        "pytest_plugin_loaded": True,
        "integrity_violations": [],
        "collection_nodeids": nodeids,
        "selected_nodeids": nodeids,
        "started_nodeids": nodeids,
        "completed_nodeids": nodeids,
        "uncertainties": {},
        "thread_observations": {},
        "non_function_fixtures": [],
        "filesystem_mutations": {},
        "import_observations": {
            "external_modules": [],
            "stable_external_toplevels": [],
            "project_search_roots": [],
        },
        "executed_imports": {},
        "buckets": {},
    }


def _embedded_profile_payloads(tmp_path: Path, nodeid: str) -> list[dict]:
    support = tmp_path / "support"
    support.mkdir()
    (support / pytest_qualify._CONTEXT_FILE).write_text(
        pytest_qualify._CONTEXT_SOURCE,
        encoding="utf-8",
    )
    (support / pytest_qualify._PLUGIN_FILE).write_text(
        pytest_qualify._PLUGIN_SOURCE,
        encoding="utf-8",
    )
    site = pytest_qualify._SITE_SOURCE.replace(
        '_ROOT = "/workspace"',
        f"_ROOT = {tmp_path.as_posix()!r}",
    ).replace(
        '_OUT_DIR = "/zerorun-pytest-qualify-output"',
        f"_OUT_DIR = {support.as_posix()!r}",
    )
    (support / pytest_qualify._SITE_FILE).write_text(site, encoding="utf-8")
    environment = dict(os.environ)
    environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    environment["PYTHONPATH"] = str(support)
    process = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-p", "zerorun_qualify_plugin", nodeid],
        cwd=tmp_path,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    return [
        json.loads(path.read_text(encoding="utf-8"))
        for path in support.glob("profile-*.json")
    ]


def test_docker_profiler_has_separate_read_only_code_and_bounded_output(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    captured = {}

    monkeypatch.setattr(pytest_qualify, "_docker_path", lambda _root: "/usr/bin/docker")
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda *_args, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))

    def fake_created(command, **kwargs):
        captured["command"] = list(command)
        captured["environment"] = dict(kwargs["environment"])
        output = _profile_output_source(command)
        (output / "profile-123.json").write_text(
            json.dumps(_valid_process_profile()),
            encoding="utf-8",
        )
        (output / pytest_qualify._COLLECTION_OUTPUT_FILE).write_text(
            json.dumps(_exact_collection()),
            encoding="utf-8",
        )
        return subprocess.CompletedProcess(command, 0, b"ok", b"")

    monkeypatch.setattr(pytest_qualify, "_run_created_container", fake_created)
    profile, _, code, _ = pytest_qualify._docker_profile(
        manifest,
        manifest.tasks["pytest"],
        targets=("tests",),
    )
    joined = " ".join(captured["command"])
    assert code == 0
    assert profile["process_count"] == 1
    assert f"dst={pytest_qualify._PROFILE_MOUNT},readonly" in joined
    assert f"dst={pytest_qualify._PROFILE_OUTPUT_MOUNT}" in joined
    assert "type=bind,src=/dev/null" not in joined
    assert "/workspace/.git:rw,nosuid,nodev,noexec" in joined
    assert "LANG" not in captured["environment"]


def test_docker_profiler_rejects_oversized_process_evidence(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    monkeypatch.setattr(pytest_qualify, "_docker_path", lambda _root: "/usr/bin/docker")
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda *_args, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(pytest_qualify, "DOCKER_METADATA_OUTPUT_LIMIT_BYTES", 64)

    def fake_created(command, **_kwargs):
        output = _profile_output_source(command)
        (output / "profile-123.json").write_bytes(b" " * 65)
        return subprocess.CompletedProcess(command, 0, b"", b"")

    monkeypatch.setattr(pytest_qualify, "_run_created_container", fake_created)
    with pytest.raises(ConfigurationError, match="exceeds the byte boundary"):
        pytest_qualify._docker_profile(
            manifest,
            manifest.tasks["pytest"],
            targets=("tests",),
        )


def test_docker_profiler_timeout_removes_exact_container(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    observed = {}
    monkeypatch.setattr(pytest_qualify, "_docker_path", lambda _root: "/usr/bin/docker")
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda *_args, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    def fake_created(command, **kwargs):
        observed["command"] = list(command)
        observed.update(kwargs)
        raise ConfigurationError(
            "profiled pytest container execution exceeded the 7 second execution boundary"
        )

    monkeypatch.setattr(pytest_qualify, "_run_created_container", fake_created)
    with pytest.raises(ConfigurationError, match="exceeded the 7 second"):
        pytest_qualify._docker_profile(
            manifest,
            manifest.tasks["pytest"],
            targets=("tests",),
            timeout_seconds=7,
        )
    assert observed["docker"] == "/usr/bin/docker"
    assert observed["container_name"].startswith("zerorun-qualify-")
    assert len(observed["container_name"]) == len("zerorun-qualify-") + 24
    assert observed["execution_timeout_seconds"] == 7
    assert observed["command"][1] == "create"


def test_docker_profiler_rejects_legacy_sourceless_bytecode_before_docker(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    (tmp_path / "legacy_module.pyc").write_bytes(b"not-even-valid-bytecode")
    docker_lookup_attempted = False

    def unexpected_docker_lookup(_root):
        nonlocal docker_lookup_attempted
        docker_lookup_attempted = True
        return "/usr/bin/docker"

    monkeypatch.setattr(pytest_qualify, "_docker_path", unexpected_docker_lookup)
    with pytest.raises(
        ConfigurationError,
        match="sourceless/direct Python bytecode.*legacy_module[.]pyc",
    ):
        pytest_qualify._docker_profile(
            manifest,
            manifest.tasks["pytest"],
            targets=("tests",),
        )
    assert docker_lookup_attempted is False


def test_pycache_prefix_does_not_hide_legacy_sourceless_module(
    tmp_path: Path,
) -> None:
    """Document why qualification needs the explicit workspace refusal."""

    import py_compile

    source = tmp_path / "legacy_visible.py"
    bytecode = tmp_path / "legacy_visible.pyc"
    source.write_text("VALUE = 'sourceless-visible'\n", encoding="utf-8")
    py_compile.compile(str(source), cfile=str(bytecode), doraise=True)
    source.unlink()
    isolated_prefix = tmp_path / "empty-pycache-prefix"
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONPYCACHEPREFIX"] = str(isolated_prefix)

    process = subprocess.run(
        [
            sys.executable,
            "-c",
            (
                "import legacy_visible; "
                "print(legacy_visible.VALUE); "
                "print(type(legacy_visible.__loader__).__name__)"
            ),
        ],
        cwd=tmp_path,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    assert process.stdout.splitlines() == [
        "sourceless-visible",
        "SourcelessFileLoader",
    ]


def test_docker_profiler_attests_exact_isolated_selection(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    nodeids = (
        "tests/test_calc.py::test_unsafe",
        "tests/test_calc.py::test_clean",
    )
    clean = (nodeids[1],)
    captured = {}
    monkeypatch.setattr(pytest_qualify, "_docker_path", lambda _root: "/usr/bin/docker")
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda *_args, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_qualify,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )

    def fake_created(command, **_kwargs):
        captured["command"] = list(command)
        output = _profile_output_source(command)
        payload = _valid_process_profile()
        payload.update(
            {
                "collection_nodeids": list(nodeids),
                "selected_nodeids": list(clean),
                "started_nodeids": list(clean),
                "completed_nodeids": list(clean),
            }
        )
        (output / "profile-123.json").write_text(
            json.dumps(payload),
            encoding="utf-8",
        )
        return subprocess.CompletedProcess(command, 0, b"ok", b"")

    monkeypatch.setattr(pytest_qualify, "_run_created_container", fake_created)
    profile, _, code, _ = pytest_qualify._docker_profile(
        manifest,
        manifest.tasks["pytest"],
        targets=("tests",),
        expected_collection_nodeids=nodeids,
        selected_nodeids=clean,
    )
    assert code == 0
    assert profile["collection_attested"] is True
    assert profile["started_nodeids"] == list(clean)
    assert profile["completed_nodeids"] == list(clean)
    assert any(
        value == "ZERORUN_PROFILE_SELECTION=/zerorun-pytest-qualify/profile-selection.json"
        for value in captured["command"]
    )


@pytest.mark.parametrize(
    ("completed", "buckets", "message"),
    [
        ([], {}, "did not execute the exact selected nodes"),
        (
            ["tests/test_calc.py::test_clean"],
            {"tests/test_calc.py::test_unsafe": []},
            "observed an unattributed node bucket",
        ),
    ],
)
def test_docker_profiler_rejects_incomplete_or_unattributed_isolation(
    monkeypatch,
    tmp_path: Path,
    completed: list[str],
    buckets: dict,
    message: str,
) -> None:
    manifest = _repo(tmp_path)
    nodeids = (
        "tests/test_calc.py::test_unsafe",
        "tests/test_calc.py::test_clean",
    )
    clean = (nodeids[1],)
    monkeypatch.setattr(pytest_qualify, "_docker_path", lambda _root: "/usr/bin/docker")
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda *_args, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))

    def fake_created(command, **_kwargs):
        output = _profile_output_source(command)
        payload = _valid_process_profile()
        payload.update(
            {
                "collection_nodeids": list(nodeids),
                "selected_nodeids": list(clean),
                "started_nodeids": list(clean),
                "completed_nodeids": completed,
                "buckets": buckets,
            }
        )
        (output / "profile-123.json").write_text(
            json.dumps(payload),
            encoding="utf-8",
        )
        return subprocess.CompletedProcess(command, 0, b"ok", b"")

    monkeypatch.setattr(pytest_qualify, "_run_created_container", fake_created)
    with pytest.raises(ConfigurationError, match=message):
        pytest_qualify._docker_profile(
            manifest,
            manifest.tasks["pytest"],
            targets=("tests",),
            expected_collection_nodeids=nodeids,
            selected_nodeids=clean,
        )


def _single_lambda_firstlineno(source: str, filename: str) -> int:
    """Return the observed line for one lambda using this interpreter's compiler."""
    pending = [compile(source, filename, "exec")]
    matches = []
    while pending:
        code = pending.pop()
        nested = [constant for constant in code.co_consts if isinstance(constant, CodeType)]
        pending.extend(nested)
        matches.extend(constant for constant in nested if constant.co_name == "<lambda>")
    assert len(matches) == 1
    return matches[0].co_firstlineno


def _stub_single_node_qualification(
    monkeypatch: pytest.MonkeyPatch,
    *,
    nodeid: str,
    buckets: dict[str, list[list[object]]],
) -> None:
    collection = _exact_collection((nodeid,))
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_qualify,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *_args, **_kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *_args, **_kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": buckets,
                "uncertainties": {},
                "thread_observations": {},
            },
            2.0,
            0,
            "1 passed",
        ),
    )


def test_symbol_closure_resolves_function_and_global_binding(tmp_path: Path):
    _repo(tmp_path)
    closure = resolve_symbol_closure(
        tmp_path,
        [
            CallSite(
                path="src/calc.py",
                firstlineno=3,
                name="add",
                globals=("OFFSET",),
            )
        ],
    )
    assert "src/calc.py::add" in closure.selectors
    assert "src/calc.py::@binding:OFFSET" in closure.selectors
    assert "src/calc.py::@module-state" in closure.selectors
    assert closure.fallback_files == ()


def _executed_edge_for_import(
    relative: str,
    source: str,
    *,
    firstlineno: int,
    code_name: str,
    module: str,
    fromlist: tuple[str, ...] = (),
    level: int = 0,
) -> ExecutedImportEdge:
    tree = ast.parse(source, filename=relative)
    matches: list[ast.Import | ast.ImportFrom] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            if level == 0 and not fromlist and any(
                alias.name == module for alias in node.names
            ):
                matches.append(node)
        elif isinstance(node, ast.ImportFrom) and (
            (node.module or "") == module
            and int(node.level or 0) == level
            and tuple(alias.name for alias in node.names) == fromlist
        ):
            matches.append(node)
    assert len(matches) == 1
    node = matches[0]
    return ExecutedImportEdge(
        path=relative,
        firstlineno=firstlineno,
        code_name=code_name,
        instruction_offset=2,
        lineno=node.lineno,
        end_lineno=node.end_lineno or node.lineno,
        col_offset=node.col_offset,
        end_col_offset=node.end_col_offset or node.col_offset,
        module=module,
        fromlist=fromlist,
        level=level,
    )


def test_forged_typing_operation_edge_is_rejected(tmp_path: Path) -> None:
    _repo(tmp_path)
    relative = "src/typing_surface.py"
    source = "import typing as t\nvalue = t.List[int]\n"
    (tmp_path / relative).write_text(source, encoding="utf-8")
    import_edge = _executed_edge_for_import(
        relative,
        source,
        firstlineno=1,
        code_name="<module>",
        module="typing",
    )
    operation = next(
        node for node in ast.walk(ast.parse(source)) if isinstance(node, ast.Subscript)
    )
    forged_callback_edge = ExecutedImportEdge(
        path=relative,
        firstlineno=1,
        code_name="<module>",
        instruction_offset=4,
        lineno=operation.lineno,
        end_lineno=operation.end_lineno or operation.lineno,
        col_offset=operation.col_offset,
        end_col_offset=operation.end_col_offset or operation.col_offset,
        module="typing",
        fromlist=(),
        level=0,
    )

    closure = resolve_symbol_closure(
        tmp_path,
        [CallSite(path=relative, firstlineno=1, name="<module>")],
        external_modules=("typing",),
        executed_imports=(import_edge, forged_callback_edge),
    )

    assert any(
        "does not map to exactly one selected import" in reason
        for reason in closure.unresolved_imports
    )


def test_executed_import_projection_excludes_latent_local_module(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    package = tmp_path / "src" / "pkg"
    package.mkdir()
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "executed_dependency.py").write_text("VALUE = 3\n", encoding="utf-8")
    (package / "latent_dependency.py").write_text("VALUE = 5\n", encoding="utf-8")
    relative = "src/pkg/runner.py"
    source = (
        "def run(enabled):\n"
        "    if enabled:\n"
        "        from . import executed_dependency\n"
        "    if False:\n"
        "        from . import latent_dependency\n"
        "    return 1\n"
    )
    (tmp_path / relative).write_text(source, encoding="utf-8")
    site = CallSite(path=relative, firstlineno=1, name="run")
    edge = _executed_edge_for_import(
        relative,
        source,
        firstlineno=1,
        code_name="run",
        module="",
        fromlist=("executed_dependency",),
        level=1,
    )

    closure = resolve_symbol_closure(
        tmp_path,
        [site],
        executed_imports=[edge],
    )
    all_paths = (*closure.fallback_files, *closure.absent_files, *closure.selectors)
    assert "src/pkg/executed_dependency.py" not in closure.fallback_files
    assert "src/pkg/executed_dependency.py::@module-state" in closure.selectors
    assert not any("latent_dependency" in value for value in all_paths)
    assert closure.unresolved_imports == ()
    closure_row = {
        "selectors": list(closure.selectors),
        "fallback_files": list(closure.fallback_files),
        "absent_files": list(closure.absent_files),
    }
    before_sha256, _ = _closure_fingerprint(
        tmp_path,
        closure_row,
        session=FingerprintSession(tmp_path),
    )
    (package / "executed_dependency.py").write_text("VALUE = 4\n", encoding="utf-8")
    after_sha256, _ = _closure_fingerprint(
        tmp_path,
        closure_row,
        session=FingerprintSession(tmp_path),
    )
    assert after_sha256 != before_sha256

    latent_only = resolve_symbol_closure(
        tmp_path,
        [site],
        executed_imports=[],
    )
    assert not any(
        "dependency" in value
        for value in (
            *latent_only.fallback_files,
            *latent_only.absent_files,
            *latent_only.selectors,
        )
    )


def test_whole_file_fallback_resolves_only_proven_executed_import_edges(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    (tmp_path / "src" / "dependency.py").write_text(
        "def dormant():\n    return 'old'\nVALUE = 3\n",
        encoding="utf-8",
    )
    (tmp_path / "src" / "latent.py").write_text("VALUE = 5\n", encoding="utf-8")
    relative = "src/runner.py"
    source = (
        "import dependency\n"
        "def run():\n"
        "    globals()\n"
        "    if False:\n"
        "        import latent\n"
        "    return dependency.VALUE\n"
    )
    (tmp_path / relative).write_text(source, encoding="utf-8")
    edge = _executed_edge_for_import(
        relative,
        source,
        firstlineno=1,
        code_name="<module>",
        module="dependency",
    )

    closure = resolve_symbol_closure(
        tmp_path,
        [
            CallSite(path=relative, firstlineno=1, name="<module>"),
            CallSite(
                path=relative,
                firstlineno=2,
                name="run",
                globals=("globals", "dependency"),
                dynamic_globals=True,
            ),
        ],
        executed_imports=(edge,),
    )

    assert closure.unresolved_imports == ()
    assert closure.fallback_files == (relative,)
    assert "src/dependency.py::@module-state" in closure.selectors
    assert not any(
        "latent" in value
        for value in (
            *closure.fallback_files,
            *closure.absent_files,
            *closure.selectors,
        )
    )


def test_module_import_edge_reconstructs_missing_monitoring_call_surface(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    (tmp_path / "src" / "dependency.py").write_text("VALUE = 3\n", encoding="utf-8")
    relative = "src/bootstrap.py"
    source = "import dependency\nREADY = dependency.VALUE\n"
    (tmp_path / relative).write_text(source, encoding="utf-8")
    edge = _executed_edge_for_import(
        relative,
        source,
        firstlineno=1,
        code_name="<module>",
        module="dependency",
    )

    closure = resolve_symbol_closure(
        tmp_path,
        (),
        executed_imports=(edge,),
    )

    assert closure.unresolved_imports == ()
    assert "src/bootstrap.py::@module-state" in closure.selectors
    assert "src/dependency.py" not in closure.fallback_files
    assert "src/dependency.py::@module-state" in closure.selectors
    assert CallSite(path=relative, firstlineno=1, name="<module>") in closure.call_sites


def test_missing_nonmodule_import_caller_surface_remains_unresolved(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    (tmp_path / "src" / "dependency.py").write_text("VALUE = 3\n", encoding="utf-8")
    relative = "src/bootstrap.py"
    source = "def load():\n    import dependency\n    return dependency.VALUE\n"
    (tmp_path / relative).write_text(source, encoding="utf-8")
    edge = _executed_edge_for_import(
        relative,
        source,
        firstlineno=1,
        code_name="load",
        module="dependency",
    )

    closure = resolve_symbol_closure(
        tmp_path,
        (),
        executed_imports=(edge,),
    )

    assert closure.selectors == ()
    assert closure.fallback_files == ()
    assert closure.unresolved_imports == (
        "executed import edge has no observed project call surface:src/bootstrap.py",
    )


def test_type_checking_false_branch_is_pruned_only_when_canonical(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    package = tmp_path / "src" / "pkg"
    package.mkdir()
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "shell_completion.py").write_text("VALUE = 7\n", encoding="utf-8")
    relative = "src/pkg/core.py"
    source = (
        "from typing import TYPE_CHECKING\n"
        "if TYPE_CHECKING:\n"
        "    from . import shell_completion\n"
        "\n"
        "def run():\n"
        "    return 1\n"
    )
    (tmp_path / relative).write_text(source, encoding="utf-8")
    typing_edge = _executed_edge_for_import(
        relative,
        source,
        firstlineno=1,
        code_name="<module>",
        module="typing",
        fromlist=("TYPE_CHECKING",),
    )
    closure = resolve_symbol_closure(
        tmp_path,
        [CallSite(path=relative, firstlineno=1, name="<module>")],
        external_modules=("typing",),
        executed_imports=(typing_edge,),
    )
    assert closure.unresolved_imports == ()
    assert not any(
        "shell_completion" in value
        for value in (
            *closure.fallback_files,
            *closure.absent_files,
            *closure.selectors,
        )
    )

    rebound_source = source.replace(
        "if TYPE_CHECKING:",
        "TYPE_CHECKING = False\nif TYPE_CHECKING:",
    ).replace(
        "from . import shell_completion",
        "__import__('pkg.shell_completion')",
    )
    (tmp_path / relative).write_text(rebound_source, encoding="utf-8")
    rebound_edge = _executed_edge_for_import(
        relative,
        rebound_source,
        firstlineno=1,
        code_name="<module>",
        module="typing",
        fromlist=("TYPE_CHECKING",),
    )
    rebound = resolve_symbol_closure(
        tmp_path,
        [CallSite(path=relative, firstlineno=1, name="<module>")],
        external_modules=("typing",),
        executed_imports=(rebound_edge,),
    )
    assert any(
        "selected import projection" in reason
        for reason in rebound.unresolved_imports
    )


def test_click_shaped_unexecuted_shell_completion_import_stays_out_of_closure(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    package = tmp_path / "src" / "click_like"
    package.mkdir()
    (package / "__init__.py").write_text("", encoding="utf-8")
    shell = package / "shell_completion.py"
    shell.write_text("def complete():\n    return 'old'\n", encoding="utf-8")
    relative = "src/click_like/core.py"
    source = (
        "import typing as t\n"
        "if t.TYPE_CHECKING:\n"
        "    from .shell_completion import CompletionItem\n"
        "\n"
        "class Command:\n"
        "    def _main_shell_completion(self, instruction):\n"
        "        if instruction is None:\n"
        "            return None\n"
        "        from .shell_completion import complete\n"
        "        return complete()\n"
    )
    (tmp_path / relative).write_text(source, encoding="utf-8")
    call_site = CallSite(
        path=relative,
        firstlineno=6,
        name="_main_shell_completion",
    )

    before = resolve_symbol_closure(
        tmp_path,
        [call_site],
        executed_imports=(),
    )
    closure_row = {
        "selectors": list(before.selectors),
        "fallback_files": list(before.fallback_files),
        "absent_files": list(before.absent_files),
    }
    before_sha256, _ = _closure_fingerprint(
        tmp_path,
        closure_row,
        session=FingerprintSession(tmp_path),
    )
    shell.write_text("def complete():\n    return 'new'\n", encoding="utf-8")
    after = resolve_symbol_closure(
        tmp_path,
        [call_site],
        executed_imports=(),
    )

    assert before == after
    assert before.unresolved_imports == ()
    assert "src/click_like/shell_completion.py" not in before.fallback_files
    assert "src/click_like/shell_completion.py" not in before.absent_files
    assert not any(
        value.startswith("src/click_like/shell_completion.py::")
        for value in before.selectors
    )
    dormant_target_sha256, _ = _closure_fingerprint(
        tmp_path,
        closure_row,
        session=FingerprintSession(tmp_path),
    )
    assert dormant_target_sha256 == before_sha256

    # If a later change activates the syntactic import, the selected origin
    # itself changes and therefore cannot reuse the old node result.  A new
    # qualification run would additionally observe/certify the import edge.
    (tmp_path / relative).write_text(
        source.replace("if instruction is None:", "if instruction is not None:"),
        encoding="utf-8",
    )
    activated_sha256, _ = _closure_fingerprint(
        tmp_path,
        closure_row,
        session=FingerprintSession(tmp_path),
    )
    assert activated_sha256 != before_sha256


def test_executed_import_edge_requires_exact_selected_source_location(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    (tmp_path / "src" / "dependency.py").write_text("VALUE = 1\n", encoding="utf-8")
    relative = "src/runner.py"
    source = "def run():\n    import dependency\n    return dependency.VALUE\n"
    (tmp_path / relative).write_text(source, encoding="utf-8")
    edge = _executed_edge_for_import(
        relative,
        source,
        firstlineno=1,
        code_name="run",
        module="dependency",
    )
    malformed = ExecutedImportEdge(
        **{**edge.__dict__, "col_offset": edge.col_offset + 1}
    )
    closure = resolve_symbol_closure(
        tmp_path,
        [CallSite(path=relative, firstlineno=1, name="run")],
        executed_imports=(malformed,),
    )
    assert any(
        "does not map to exactly one selected import" in reason
        for reason in closure.unresolved_imports
    )


def test_executed_import_validator_rejects_malformed_noncomparable_rows() -> None:
    raw = {
        "tests/test_calc.py::test_add": [
            [
                "tests/test_calc.py",
                1,
                "test_add",
                2,
                2,
                2,
                4,
                15,
                "src.calc",
                [],
                0,
            ],
            [
                "tests/test_calc.py",
                "not-an-integer",
                "test_add",
                4,
                3,
                3,
                4,
                15,
                "src.calc",
                [],
                0,
            ],
        ]
    }

    with pytest.raises(ConfigurationError, match="invalid import edge"):
        pytest_qualify._validate_executed_imports(
            raw,
            label="hostile executed imports",
        )


def test_symbol_closure_binds_literal_local_pytest_plugin_and_shadow_surface(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    support = tmp_path / "support"
    support.mkdir()
    (support / "plugin.py").write_text("VALUE = 1\n", encoding="utf-8")
    (tmp_path / "conftest.py").write_text(
        "pytest_plugins = ['support.plugin']\n",
        encoding="utf-8",
    )

    closure = resolve_symbol_closure(
        tmp_path,
        [CallSite(path="conftest.py", firstlineno=1, name="<module>")],
    )

    assert "support/plugin.py" in closure.fallback_files
    assert "support.py" in closure.absent_files
    assert closure.unresolved_imports == ()


def test_identical_call_sites_share_decode_and_closure_work_without_row_drift(
    monkeypatch,
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    raw = [["src/calc.py", 3, "add", ["OFFSET", "OFFSET"], False]]
    decode_cache = {}
    first_sites = pytest_qualify._decode_sites(raw, cache=decode_cache)
    second_sites = pytest_qualify._decode_sites(raw, cache=decode_cache)
    assert second_sites is first_sites

    original = pytest_qualify.resolve_symbol_closure
    calls = 0

    def counted(*args, **kwargs):
        nonlocal calls
        calls += 1
        return original(*args, **kwargs)

    monkeypatch.setattr(pytest_qualify, "resolve_symbol_closure", counted)
    analysis_cache = pytest_qualify.SymbolClosureAnalysisCache(tmp_path)
    row_cache = {}
    first_row = pytest_qualify._closure_row(
        tmp_path,
        first_sites,
        analysis_cache=analysis_cache,
        row_cache=row_cache,
    )
    second_row = pytest_qualify._closure_row(
        tmp_path,
        second_sites,
        analysis_cache=analysis_cache,
        row_cache=row_cache,
    )
    assert calls == 1
    assert second_row == first_row
    assert second_row["selectors"] is not first_row["selectors"]
    assert second_row["fallback_files"] is not first_row["fallback_files"]


def test_call_site_memoization_preserves_exact_candidate_and_source_review_bytes(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    nodeids = (
        "tests/test_calc.py::test_add_one",
        "tests/test_calc.py::test_add_two",
    )
    collection = {
        "invocation": _collection_invocation(),
        "items": [
            {
                "nodeid": nodeid,
                "identity_sha256": f"{index:064x}",
                "parameter_identity_supported": True,
                "path": "tests/test_calc.py",
            }
            for index, nodeid in enumerate(nodeids, start=1)
        ],
        "nodeids": list(nodeids),
        "collection_sha256": "4" * 64,
    }
    shared_site = [["src/calc.py", 3, "add", ["OFFSET"], False]]
    profile = {
        "loaded": True,
        "buckets": {nodeid: shared_site for nodeid in nodeids},
        "uncertainties": {},
        "thread_observations": {},
        "non_function_fixtures": [],
    }
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            _with_fused_collection(profile, collection),
            2.0,
            0,
            "2 passed",
        ),
    )

    memoized_path = tmp_path / "memoized-candidate.json"
    memoized = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=memoized_path,
    )

    memoized_decode = pytest_qualify._decode_sites
    memoized_closure_row = pytest_qualify._closure_row

    def uncached_decode(raw, **_kwargs):
        return memoized_decode(raw)

    def uncached_closure_row(root, sites, *, analysis_cache=None, **_kwargs):
        return memoized_closure_row(
            root,
            sites,
            analysis_cache=analysis_cache,
        )

    monkeypatch.setattr(pytest_qualify, "_decode_sites", uncached_decode)
    monkeypatch.setattr(pytest_qualify, "_closure_row", uncached_closure_row)
    uncached_path = tmp_path / "uncached-candidate.json"
    uncached = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=uncached_path,
    )

    assert memoized == uncached
    assert memoized["source_review"] == uncached["source_review"]
    assert memoized_path.read_bytes() == uncached_path.read_bytes()


def test_module_level_lambda_is_covered_by_module_state(tmp_path: Path):
    _repo(tmp_path)
    path = tmp_path / "src" / "module_lambda.py"
    source = (
        "VALUES = [3, 1, 2]\n"
        "VALUES.sort(key=lambda item: item, reverse=True)\n"
    )
    path.write_text(source, encoding="utf-8")
    closure = resolve_symbol_closure(
        tmp_path,
        [
            CallSite(
                path="src/module_lambda.py",
                firstlineno=_single_lambda_firstlineno(source, str(path)),
                name="<lambda>",
                globals=(),
            )
        ],
    )
    assert closure.fallback_files == ()
    assert closure.selectors == ("src/module_lambda.py::@module-state",)


def test_lambda_inside_unresolved_function_still_falls_back(tmp_path: Path):
    _repo(tmp_path)
    path = tmp_path / "src" / "nested_lambda.py"
    source = (
        "def outer():\n"
        "    return (lambda value: value + 1)(1)\n"
    )
    path.write_text(source, encoding="utf-8")
    closure = resolve_symbol_closure(
        tmp_path,
        [
            CallSite(
                path="src/nested_lambda.py",
                firstlineno=_single_lambda_firstlineno(source, str(path)),
                name="<lambda>",
                globals=(),
            )
        ],
    )
    assert closure.fallback_files == ("src/nested_lambda.py",)

def test_dynamic_globals_force_whole_file_fallback(tmp_path: Path):
    _repo(tmp_path)
    closure = resolve_symbol_closure(
        tmp_path,
        [
            CallSite(
                path="src/calc.py",
                firstlineno=3,
                name="add",
                globals=("globals",),
                dynamic_globals=True,
            )
        ],
    )
    assert closure.fallback_files == ("src/calc.py",)
    assert not any(selector.startswith("src/calc.py::") for selector in closure.selectors)


def test_candidate_generation_is_non_authorizing(monkeypatch, tmp_path: Path):
    manifest = _repo(tmp_path)
    collection = _exact_collection()
    monkeypatch.setattr(pytest_qualify, "inspect_runtime", lambda _task, **_kwargs: {"requested_image": IMAGE})
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 11.0),
    )
    profile = {
        "loaded": True,
        "buckets": {
            "__session__": [["conftest.py", 1, "<module>", [], False]],
            "tests/test_calc.py::test_add": [
                ["src/calc.py", 3, "add", ["OFFSET"], False],
                ["tests/test_calc.py", 3, "test_add", ["add"], False],
            ],
        },
    }
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            _with_fused_collection(profile, collection),
            25.0,
            0,
            "1 passed",
        ),
    )

    output = tmp_path / ".zerorun-pytest.candidate.json"
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=output,
    )

    assert candidate["authorizes_reuse"] is False
    assert candidate["candidate_only"] is True
    assert candidate["review"]["required"] is True
    assert candidate["review"]["independence_review_sha256"] is None
    row = candidate["nodes"]["tests/test_calc.py::test_add"]
    assert row["reviewable"] is True
    assert "src.py" in row["absent_files"]
    assert "tests/__init__.py" in row["absent_files"]
    assert output.is_file()
    with pytest.raises(ConfigurationError):
        load_pytest_profile(output, manifest)


def test_no_call_site_node_uses_conservative_static_import_candidate(
    monkeypatch, tmp_path: Path
):
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    collection = _exact_collection((nodeid,))
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_qualify,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": {
                    "__session__": [["conftest.py", 1, "<module>", [], False]],
                    nodeid: [],
                },
            },
            1.0,
            0,
            "1 skipped",
        ),
    )

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    row = candidate["nodes"][nodeid]
    assert row["reviewable"] is True
    assert row["fresh_required"] is False
    assert row["selectors"] == []
    assert row["fallback_files"] == ["src/calc.py", "tests/test_calc.py"]
    assert "src.py" in row["absent_files"]
    assert "tests/__init__.py" in row["absent_files"]
    assert candidate["authorizes_reuse"] is False
    assert candidate["review"]["required"] is True


def test_candidate_activation_requires_exact_candidate_and_review_digests(monkeypatch, tmp_path: Path):
    manifest = _repo(tmp_path)
    collection = _exact_collection()
    monkeypatch.setattr(pytest_qualify, "inspect_runtime", lambda _task, **_kwargs: {"requested_image": IMAGE})
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(pytest_qualify, "collect_pytest", lambda *args, **kwargs: (collection, 1.0))
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": {
                    "__session__": [["conftest.py", 1, "<module>", [], False]],
                    "tests/test_calc.py::test_add": [["src/calc.py", 3, "add", ["OFFSET"], False]],
                },
            },
            2.0,
            0,
            "ok",
        ),
    )
    candidate_path = tmp_path / ".zerorun-pytest.candidate.json"
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=candidate_path,
    )

    with pytest.raises(ConfigurationError):
        pytest_qualify.activate_pytest_candidate(
            candidate_path,
            expected_candidate_sha256="0" * 64,
            independence_review_sha256="5" * 64,
            output=tmp_path / ".zerorun-pytest.json",
        )

    profile_path = tmp_path / ".zerorun-pytest.json"
    pytest_qualify.activate_pytest_candidate(
        candidate_path,
        expected_candidate_sha256=candidate["candidate_sha256"],
        independence_review_sha256="5" * 64,
        output=profile_path,
    )
    loaded = load_pytest_profile(profile_path, manifest)
    assert loaded.independence_review_sha256 == "5" * 64
    assert loaded.nodes["tests/test_calc.py::test_add"]["reviewable"] is True
    assert "src.py" in loaded.nodes["tests/test_calc.py::test_add"]["absent_files"]
    assert loaded.source_review == candidate["source_review"]
    assert loaded.source_review["profiler_sha256"] == pytest_qualify.profiler_sha256()


def test_candidate_digest_detects_tampering(monkeypatch, tmp_path: Path):
    manifest = _repo(tmp_path)
    collection = _exact_collection()
    monkeypatch.setattr(pytest_qualify, "inspect_runtime", lambda _task, **_kwargs: {"requested_image": IMAGE})
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (
            {
                "invocation": _collection_invocation(),
                "items": [{"nodeid": "tests/test_calc.py::test_add", "identity_sha256": "3" * 64, "parameter_identity_supported": True, "path": "tests/test_calc.py"}],
                "nodeids": ["tests/test_calc.py::test_add"],
                "collection_sha256": "4" * 64,
            },
            1.0,
        ),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": {
                    "tests/test_calc.py::test_add": [
                        ["src/calc.py", 3, "add", ["OFFSET"], False]
                    ]
                },
            },
            1.0,
            0,
            "ok",
        ),
    )
    path = tmp_path / ".zerorun-pytest.candidate.json"
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest, task_name="pytest", targets=("tests",), output=path
    )
    raw = json.loads(path.read_text())
    raw["targets"] = ["other-tests"]
    path.write_text(json.dumps(raw), encoding="utf-8")
    with pytest.raises(ConfigurationError):
        pytest_qualify.activate_pytest_candidate(
            path,
            expected_candidate_sha256=candidate["candidate_sha256"],
            independence_review_sha256="5" * 64,
            output=tmp_path / ".zerorun-pytest.json",
        )


def test_no_call_node_uses_reviewable_static_local_import_fallback(
    monkeypatch, tmp_path: Path
):
    manifest = _repo(tmp_path)
    collection = _exact_collection()
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {"loaded": True, "collection": collection, "buckets": {}},
            1.0,
            0,
            "ok",
        ),
    )

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    row = candidate["nodes"]["tests/test_calc.py::test_add"]
    assert row["reviewable"] is True
    assert row["fresh_required"] is False
    assert row["selectors"] == []
    assert "tests/test_calc.py" in row["fallback_files"]
    assert "src/calc.py" in row["fallback_files"]
    assert "recursively resolved local Python imports" in row[
        "candidate_fallback_reason"
    ]
    assert "src.py" in row["absent_files"]
    assert "tests/__init__.py" in row["absent_files"]


def test_qualified_profile_fails_closed_after_local_shadow_creation(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    _stub_single_node_qualification(
        monkeypatch,
        nodeid=nodeid,
        buckets={nodeid: []},
    )
    candidate_path = tmp_path / ".zerorun-pytest.candidate.json"
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=candidate_path,
    )
    profile_path = tmp_path / ".zerorun-pytest.json"
    pytest_qualify.activate_pytest_candidate(
        candidate_path,
        expected_candidate_sha256=candidate["candidate_sha256"],
        independence_review_sha256="5" * 64,
        output=profile_path,
    )
    closure = load_pytest_profile(profile_path, manifest).nodes[nodeid]

    assert "src.py" in closure["absent_files"]
    _closure_fingerprint(
        tmp_path,
        closure,
        session=FingerprintSession(tmp_path),
    )
    (tmp_path / "src.py").write_text(
        "raise RuntimeError('shadowed namespace package')\n",
        encoding="utf-8",
    )

    with pytest.raises(
        ConfigurationError,
        match="negative import candidate became available",
    ):
        _closure_fingerprint(
            tmp_path,
            closure,
            session=FingerprintSession(tmp_path),
        )


def test_qualification_rechecks_negative_import_surface_before_publication(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    _stub_single_node_qualification(
        monkeypatch,
        nodeid=nodeid,
        buckets={nodeid: []},
    )
    real_validate = pytest_qualify.validate_absent_import_paths
    calls = 0

    def racing_validate(root: Path, absent_files) -> None:
        nonlocal calls
        calls += 1
        captured = tuple(absent_files)
        assert "src.py" in captured
        if calls == 2:
            (root / "src.py").write_text("VALUE = 'late shadow'\n", encoding="utf-8")
        real_validate(root, captured)

    monkeypatch.setattr(
        pytest_qualify,
        "validate_absent_import_paths",
        racing_validate,
    )
    output = tmp_path / ".zerorun-pytest.candidate.json"

    with pytest.raises(
        ConfigurationError,
        match="negative local import candidate changed during qualification",
    ):
        pytest_qualify.qualify_pytest_candidate(
            manifest,
            task_name="pytest",
            targets=("tests",),
            output=output,
        )
    assert calls == 2
    assert not output.exists()


def test_static_fallback_with_unresolved_external_import_remains_fresh(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    (tmp_path / "tests" / "test_calc.py").write_text(
        "import json\n\ndef test_add():\n    assert json.loads('1') == 1\n",
        encoding="utf-8",
    )
    _stub_single_node_qualification(
        monkeypatch,
        nodeid=nodeid,
        buckets={nodeid: []},
    )

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    row = candidate["nodes"][nodeid]

    assert row["reviewable"] is False
    assert row["fresh_required"] is True
    assert "external or unresolved import 'json'" in row["reason"]


def test_attested_external_import_binds_every_project_shadow_root(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    (tmp_path / "vendor").mkdir()
    (tmp_path / "tests" / "test_calc.py").write_text(
        "import json\n\ndef test_json():\n    assert json.loads('1') == 1\n",
        encoding="utf-8",
    )

    files, absences, uncertainty = pytest_qualify._static_import_fallback(
        tmp_path,
        "tests/test_calc.py",
        external_modules=("json",),
        import_search_roots=(".", "src", "vendor"),
    )

    assert uncertainty is None
    assert "tests/test_calc.py" in files
    assert "json.py" in absences
    assert "src/json.py" in absences
    assert "vendor/json.py" in absences
    assert "vendor/json/__init__.py" in absences
    (tmp_path / "vendor" / "json.py").write_text(
        "raise RuntimeError('shadowed immutable dependency')\n",
        encoding="utf-8",
    )
    with pytest.raises(
        ConfigurationError,
        match="negative local import candidate changed",
    ):
        pytest_qualify.validate_absent_import_paths(tmp_path, absences)


def test_negative_native_pattern_rejects_parent_replaced_by_file(
    tmp_path: Path,
) -> None:
    (tmp_path / "shadowed").write_text("not a package\n", encoding="utf-8")

    with pytest.raises(
        ConfigurationError,
        match="pattern parent is not a directory",
    ):
        pytest_qualify.validate_absent_import_paths(
            tmp_path,
            ("shadowed/__init__*.so",),
        )


def test_negative_import_guard_rejects_in_root_linked_parent(
    tmp_path: Path,
) -> None:
    real_parent = tmp_path / "real-parent"
    real_parent.mkdir()
    linked_parent = tmp_path / "linked-parent"
    try:
        linked_parent.symlink_to(real_parent, target_is_directory=True)
    except (NotImplementedError, OSError) as exc:
        pytest.skip(f"directory symlink is unavailable: {exc}")

    with pytest.raises(
        ConfigurationError,
        match="symbolic link or junction",
    ):
        pytest_qualify.validate_absent_import_paths(
            tmp_path,
            ("linked-parent/shadow.py",),
        )


def test_negative_import_guard_never_follows_linklike_component(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    from zerorun import pytest_closure

    linked_parent = tmp_path / "linked-parent"
    linked_parent.mkdir()
    monkeypatch.setattr(
        pytest_closure,
        "is_link_like",
        lambda path: path == linked_parent,
    )

    with pytest.raises(
        ConfigurationError,
        match="symbolic link or junction",
    ):
        pytest_qualify.validate_absent_import_paths(
            tmp_path,
            ("linked-parent/shadow.py",),
        )


def test_never_executed_unattested_conditional_import_remains_fresh(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    (tmp_path / "tests" / "test_calc.py").write_text(
        "if False:\n    import never_executed_dependency\n\n"
        "def test_clean():\n    assert True\n",
        encoding="utf-8",
    )

    _, _, uncertainty = pytest_qualify._static_import_fallback(
        tmp_path,
        "tests/test_calc.py",
        external_modules=("json",),
        import_search_roots=(".", "src"),
    )

    assert uncertainty is not None
    assert "never_executed_dependency" in uncertainty


def test_type_checking_only_import_binds_shadow_without_external_load(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    source = (
        "from typing import TYPE_CHECKING\n"
        "if TYPE_CHECKING:\n    import _typeshed\n\n"
        "def test_clean():\n    assert True\n"
    )
    path = tmp_path / "tests" / "test_calc.py"
    path.write_text(source, encoding="utf-8")
    tree = ast.parse(source, filename="tests/test_calc.py")

    required, optional = pytest_qualify.static_import_requests(
        tmp_path,
        "tests/test_calc.py",
        tree,
    )
    assert required == ("typing",)
    assert "_typeshed" in optional
    files, absences, uncertainty = pytest_qualify._static_import_fallback(
        tmp_path,
        "tests/test_calc.py",
        external_modules=("typing",),
        import_search_roots=(".", "src"),
    )
    assert uncertainty is None
    assert "tests/test_calc.py" in files
    assert "_typeshed.py" in absences


def test_reassigned_type_checking_guard_does_not_suppress_required_import(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    source = (
        "from typing import TYPE_CHECKING\n"
        "TYPE_CHECKING = True\n"
        "if TYPE_CHECKING:\n    import runtime_dependency\n"
    )
    tree = ast.parse(source, filename="tests/test_calc.py")

    required, optional = pytest_qualify.static_import_requests(
        tmp_path,
        "tests/test_calc.py",
        tree,
    )
    assert "runtime_dependency" in required
    assert "runtime_dependency" not in optional


def test_import_observation_schema_rejects_forged_origin_as_provenance() -> None:
    with pytest.raises(ConfigurationError, match="invalid module row"):
        pytest_qualify._validate_import_observations(
            {
                "external_modules": [["json", "/forged/origin.py"]],
                "stable_external_toplevels": [],
                "project_search_roots": ["."],
            },
            label="forged evidence",
        )


@pytest.mark.parametrize(
    "declaration",
    [
        "pytest_plugins = ['external_review_plugin']\n",
        "PLUGINS = ['external_review_plugin']\npytest_plugins = PLUGINS\n",
    ],
)
def test_unresolved_or_dynamic_pytest_plugins_force_all_nodes_fresh(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    declaration: str,
) -> None:
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    (tmp_path / "conftest.py").write_text(declaration, encoding="utf-8")
    _stub_single_node_qualification(
        monkeypatch,
        nodeid=nodeid,
        buckets={
            "__session__": [["conftest.py", 1, "<module>", [], False]],
            nodeid: [["src/calc.py", 3, "add", ["OFFSET"], False]],
        },
    )

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    row = candidate["nodes"][nodeid]

    assert row["reviewable"] is False
    assert row["fresh_required"] is True
    assert "unresolved session import surface" in row["reason"]


def test_no_call_static_fallback_stays_fresh_on_dynamic_import(
    monkeypatch, tmp_path: Path
):
    manifest = _repo(tmp_path)
    (tmp_path / "tests" / "test_calc.py").write_text(
        "def test_dynamic():\n"
        "    name = 'src.calc'\n"
        "    assert __import__(name) is not None\n",
        encoding="utf-8",
    )
    collection = _exact_collection(("tests/test_calc.py::test_dynamic",))
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {"loaded": True, "collection": collection, "buckets": {}},
            1.0,
            0,
            "ok",
        ),
    )

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    row = candidate["nodes"]["tests/test_calc.py::test_dynamic"]
    assert row["reviewable"] is False
    assert row["fresh_required"] is True
    assert "dynamic import/evaluation" in row["reason"]


def test_thread_or_subprocess_uncertainty_forces_nodes_fresh(
    monkeypatch, tmp_path: Path
):
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    collection = {
        "invocation": _collection_invocation(),
        "items": [{
            "nodeid": nodeid,
            "identity_sha256": "3" * 64,
            "parameter_identity_supported": True,
            "path": "tests/test_calc.py",
        }],
        "nodeids": [nodeid],
        "collection_sha256": "4" * 64,
    }
    monkeypatch.setattr(
        pytest_qualify, "inspect_runtime", lambda _task, **_kwargs: {"requested_image": IMAGE}
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify, "collect_pytest", lambda *args, **kwargs: (collection, 1.0)
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": {
                    nodeid: [["src/calc.py", 3, "add", ["OFFSET"], False]]
                },
                "uncertainties": {nodeid: ["thread-start", "subprocess.Popen"]},
                "non_function_fixtures": [],
            },
            1.0,
            0,
            "ok",
        ),
    )

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    row = candidate["nodes"][nodeid]
    assert row["reviewable"] is False
    assert row["fresh_required"] is True
    assert row["profiling_uncertainties"] == ["subprocess.Popen", "thread-start"]
    assert "attribution is incomplete" in row["reason"]


def test_uncertain_node_is_permanently_fresh_but_clean_sibling_is_reviewable(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    unsafe = "tests/test_calc.py::test_unsafe"
    clean = "tests/test_calc.py::test_clean"
    nodeids = (unsafe, clean)
    (tmp_path / "tests" / "test_calc.py").write_text(
        "from src.calc import add\n\n"
        "def test_unsafe():\n    assert add(1, 1) == 3\n\n"
        "def test_clean():\n    assert add(2, 1) == 4\n",
        encoding="utf-8",
    )
    collection = _exact_collection(nodeids)


    initial = {
        "loaded": True,
        "buckets": {
            "__session__": [["conftest.py", 1, "<module>", [], False]],
            unsafe: [["src/calc.py", 3, "add", ["OFFSET"], False]],
            clean: [["src/calc.py", 3, "add", ["OFFSET"], False]],
        },
        "uncertainties": {
            unsafe: ["subprocess.Popen", "thread-start"],
            "__session__": ["unattributed-child-process-project-calls"],
        },
        "non_function_fixtures": [],
    }
    isolated = {
        "loaded": True,
        "buckets": {
            "__session__": [["conftest.py", 1, "<module>", [], False]],
            clean: [["src/calc.py", 3, "add", ["OFFSET"], False]],
        },
        "uncertainties": {},
        "non_function_fixtures": [],
    }
    calls = []

    def fake_profile(*_args, **kwargs):
        calls.append(dict(kwargs))
        if len(calls) == 1:
            return _with_fused_collection(initial, collection), 2.0, 0, "2 passed"
        assert kwargs["targets"] == ("tests",)
        assert kwargs["expected_collection_nodeids"] == nodeids
        assert kwargs["selected_nodeids"] == (clean,)
        return isolated, 3.0, 0, "1 passed, 1 deselected"

    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_qualify,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(pytest_qualify, "_docker_profile", fake_profile)
    candidate_path = tmp_path / ".zerorun-pytest.candidate.json"
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=candidate_path,
    )

    assert len(calls) == 2
    assert candidate["uncertainty_isolation"]["result"] == "clean-siblings-reprofiled"
    assert candidate["uncertainty_isolation"]["isolated_fresh_nodeids"] == [unsafe]
    assert candidate["nodes"][unsafe]["fresh_required"] is True
    assert candidate["nodes"][unsafe]["reviewable"] is False
    assert candidate["nodes"][unsafe]["selectors"] == []
    assert candidate["nodes"][clean]["fresh_required"] is False
    assert candidate["nodes"][clean]["reviewable"] is True

    profile_path = tmp_path / ".zerorun-pytest.json"
    activated = pytest_qualify.activate_pytest_candidate(
        candidate_path,
        expected_candidate_sha256=candidate["candidate_sha256"],
        independence_review_sha256="8" * 64,
        output=profile_path,
    )
    fingerprinted = []

    def fake_fingerprint(_root, task, *, nodeid, **_kwargs):
        fingerprinted.append(nodeid)
        return task, "9" * 64, {"nodeid": nodeid}

    monkeypatch.setattr(pytest_node_cache, "node_action_fingerprint", fake_fingerprint)
    decisions = prepare_node_cache(
        tmp_path,
        manifest.tasks["pytest"],
        node_rows=[
            {"nodeid": nodeid, **activated["nodes"][nodeid]}
            for nodeid in nodeids
        ],
        session_closure=activated["session_closure"],
        static_inputs=tuple(activated["static_inputs"]),
        collection_items=collection["items"],
        context=NodeCacheContext(
            runtime_identity={"resolved_image": "sha256:" + "a" * 64},
            environment_fingerprint={},
            collection_contract_sha256="b" * 64,
            collection_plugin_sha256="c" * 64,
            independence_review_sha256="8" * 64,
            profile_sha256="d" * 64,
        ),
        allow_cache_lookup=False,
    )
    by_node = {decision.nodeid: decision for decision in decisions}
    assert by_node[unsafe].status == "MISS_UNCERTAIN"
    assert by_node[unsafe].key is None
    assert by_node[clean].status == "MISS_KEYED"
    assert fingerprinted == [clean]


def test_large_collection_nine_uncertain_nodes_isolates_clean_siblings(
    monkeypatch,
    tmp_path: Path,
) -> None:
    """Keep uncertainty node-local in a large synthetic collection."""

    manifest = _repo(tmp_path)
    nodeids = tuple(
        f"tests/test_calc.py::test_add[case-{index:03d}]" for index in range(600)
    )
    unsafe = nodeids[-9:]
    clean = nodeids[:-9]
    collection = _exact_collection(nodeids)
    initial = {
        "loaded": True,
        "buckets": {},
        "uncertainties": {
            nodeid: ["thread-start"] for nodeid in unsafe
        },
        "non_function_fixtures": [],
    }
    isolated = {
        "loaded": True,
        "buckets": {},
        "uncertainties": {},
        "non_function_fixtures": [],
    }
    calls: list[dict] = []

    def fake_profile(*_args, **kwargs):
        calls.append(dict(kwargs))
        if len(calls) == 1:
            return _with_fused_collection(initial, collection), 2.0, 0, "600 passed"
        assert kwargs["expected_collection_nodeids"] == nodeids
        assert kwargs["selected_nodeids"] == clean
        return isolated, 3.0, 0, "591 passed, 9 deselected"

    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_qualify,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(pytest_qualify, "_docker_profile", fake_profile)

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )

    assert len(calls) == 2
    assert candidate["uncertainty_isolation"] == {
        "attempted": True,
        "isolated_fresh_nodeids": list(unsafe),
        "sibling_node_count": 591,
        "result": "clean-siblings-reprofiled",
        "profile_ms": 3.0,
        "exit_code": 0,
        "uncertainties": {},
    }
    reviewable = [
        nodeid
        for nodeid, row in candidate["nodes"].items()
        if row["reviewable"] is True and row["fresh_required"] is False
    ]
    forced_fresh = [
        nodeid
        for nodeid, row in candidate["nodes"].items()
        if row["fresh_required"] is True
    ]
    assert reviewable == list(clean)
    assert forced_fresh == list(unsafe)
    assert all(
        candidate["nodes"][nodeid]["profiling_uncertainties"]
        == ["thread-start"]
        for nodeid in unsafe
    )


def test_uncertain_clean_reprofile_cannot_promote_any_sibling(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    unsafe = "tests/test_calc.py::test_unsafe"
    clean = "tests/test_calc.py::test_clean"
    nodeids = (unsafe, clean)
    collection = {
        "invocation": _collection_invocation(),
        "items": [
            {
                "nodeid": nodeid,
                "identity_sha256": str(index) * 64,
                "parameter_identity_supported": True,
                "path": "tests/test_calc.py",
            }
            for index, nodeid in enumerate(nodeids, start=3)
        ],
        "nodeids": list(nodeids),
        "collection_sha256": "7" * 64,
    }
    profiles = iter(
        [
                {
                    "loaded": True,
                    "collection": collection,
                    "buckets": {},
                    "uncertainties": {unsafe: ["thread-start"]},
                "non_function_fixtures": [],
            },
            {
                "loaded": True,
                "buckets": {},
                "uncertainties": {"__session__": ["subprocess.Popen"]},
                "non_function_fixtures": [],
            },
        ]
    )
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (next(profiles), 1.0, 0, "ok"),
    )
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    assert candidate["uncertainty_isolation"]["result"] == "uncertain-failed-closed"
    assert candidate["nodes"][unsafe]["fresh_required"] is True
    assert candidate["nodes"][clean]["fresh_required"] is True
    assert candidate["nodes"][clean]["reviewable"] is False


def test_session_process_uncertainty_forces_every_node_fresh(monkeypatch, tmp_path: Path):
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    collection = {
        "invocation": _collection_invocation(),
        "items": [{
            "nodeid": nodeid,
            "identity_sha256": "3" * 64,
            "parameter_identity_supported": True,
            "path": "tests/test_calc.py",
        }],
        "nodeids": [nodeid],
        "collection_sha256": "4" * 64,
    }
    monkeypatch.setattr(
        pytest_qualify, "inspect_runtime", lambda _task, **_kwargs: {"requested_image": IMAGE}
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify, "collect_pytest", lambda *args, **kwargs: (collection, 1.0)
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": {},
                "uncertainties": {"__session__": ["os.fork"]},
                "non_function_fixtures": [],
            },
            1.0,
            0,
            "ok",
        ),
    )

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    assert candidate["nodes"][nodeid]["fresh_required"] is True
    assert candidate["profiling_uncertainties"] == {"__session__": ["os.fork"]}


def test_joined_thread_candidate_keeps_selective_child_call_closure(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    collection = _exact_collection((nodeid,))
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": {
                    nodeid: [["src/calc.py", 3, "add", [], False]],
                },
                "uncertainties": {},
                "thread_observations": {
                    nodeid: {
                        "started": 10,
                        "joined": 10,
                        "terminated": 10,
                        "start_failed": 0,
                        "complete_before_boundary": True,
                    }
                },
                "non_function_fixtures": [],
            },
            1.0,
            0,
            "ok",
        ),
    )
    candidate_path = tmp_path / ".zerorun-pytest.candidate.json"
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=candidate_path,
    )

    row = candidate["nodes"][nodeid]
    assert row["reviewable"] is True
    assert row["fresh_required"] is False
    assert row["fallback_files"] == ["src/calc.py", "tests/test_calc.py"]
    assert "src/calc.py::add" in row["selectors"]
    assert all("tests/test_calc.py" not in selector for selector in row["selectors"])
    assert candidate["thread_observations"][nodeid]["complete_before_boundary"] is True
    assert "semantic determinism" in candidate["review"]["reason"]


def test_no_call_static_fallback_rejects_untracked_file_reads(monkeypatch, tmp_path: Path):
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_data"
    (tmp_path / "tests" / "test_calc.py").write_text(
        "from pathlib import Path\n\ndef test_data():\n"
        "    assert Path('payload.txt').read_text() == 'ok'\n",
        encoding="utf-8",
    )
    collection = _exact_collection((nodeid,))
    monkeypatch.setattr(
        pytest_qualify, "inspect_runtime", lambda _task, **_kwargs: {"requested_image": IMAGE}
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify, "collect_pytest", lambda *args, **kwargs: (collection, 1.0)
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {"loaded": True, "collection": collection, "buckets": {}},
            1.0,
            0,
            "ok",
        ),
    )

    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / ".zerorun-pytest.candidate.json",
    )
    row = candidate["nodes"][nodeid]
    assert row["reviewable"] is False
    assert row["fresh_required"] is True
    assert "file-system operation" in row["reason"]


def test_profiler_instruments_non_function_fixtures_and_thread_lifecycle() -> None:
    assert "def pytest_fixture_setup(fixturedef, request):" in pytest_qualify._PLUGIN_SOURCE
    assert "mark_non_function_fixture" in pytest_qualify._PLUGIN_SOURCE
    assert "threading.Thread.start = _thread_start" in pytest_qualify._SITE_SOURCE
    assert "threading.Thread.join = _thread_join" in pytest_qualify._SITE_SOURCE
    assert "_thread.start_new_thread = _lowlevel_thread_start" in pytest_qualify._SITE_SOURCE
    assert "_thread.start_new = _lowlevel_thread_start" in pytest_qualify._SITE_SOURCE
    assert "_ORIGINAL_THREADING_SETPROFILE(None)" in pytest_qualify._SITE_SOURCE
    assert 'getattr(_MONITORING.events, "PY_START", None)' in pytest_qualify._SITE_SOURCE
    assert 'getattr(_MONITORING.events, "PY_RESUME", None)' in pytest_qualify._SITE_SOURCE
    # The one remaining call is the guarded public API wrapper; node boundaries
    # must never invoke the global restart operation themselves.
    assert pytest_qualify._SITE_SOURCE.count(
        "_ORIGINAL_MONITORING_RESTART_EVENTS()"
    ) == 1
    assert "if _project_relative(filename) is None:" in pytest_qualify._SITE_SOURCE
    assert "return _MONITORING.DISABLE" in pytest_qualify._SITE_SOURCE
    assert "_ORIGINAL_THREADING_SETPROFILE(_profile)" in pytest_qualify._SITE_SOURCE
    assert 'if event == "sys.setprofile":' in pytest_qualify._SITE_SOURCE
    assert "threading.setprofile = _threading_setprofile" in pytest_qualify._SITE_SOURCE
    assert "if bucket in _UNCERTAINTIES and any(" in pytest_qualify._SITE_SOURCE
    assert (
        'not kind.startswith("ephemeral-filesystem-mutation:")'
        in pytest_qualify._SITE_SOURCE
    )
    assert "sys.addaudithook(_audit)" in pytest_qualify._SITE_SOURCE
    assert '"os.posix_spawn"' in pytest_qualify._SITE_SOURCE
    assert "thread-not-joined-before-node-completion" in pytest_qualify._SITE_SOURCE
    assert "thread-alive-at-node-completion" in pytest_qualify._SITE_SOURCE
    assert "elif sys.getprofile() is not _profile:" in pytest_qualify._SITE_SOURCE
    assert '_UNCERTAINTIES.setdefault("__session__", set())' not in pytest_qualify._SITE_SOURCE


def test_profiler_runtime_records_fixture_thread_lifecycle_and_subprocess_uncertainty(
    tmp_path: Path,
) -> None:
    support = tmp_path / "support"
    support.mkdir()
    (support / pytest_qualify._CONTEXT_FILE).write_text(
        pytest_qualify._CONTEXT_SOURCE, encoding="utf-8"
    )
    (support / pytest_qualify._PLUGIN_FILE).write_text(
        pytest_qualify._PLUGIN_SOURCE, encoding="utf-8"
    )
    root_text = tmp_path.as_posix()
    support_text = support.as_posix()
    site = pytest_qualify._SITE_SOURCE.replace(
        '_ROOT = "/workspace"', f"_ROOT = {root_text!r}"
    ).replace(
        '_OUT_DIR = "/zerorun-pytest-qualify-output"', f"_OUT_DIR = {support_text!r}"
    )
    (support / pytest_qualify._SITE_FILE).write_text(site, encoding="utf-8")
    (tmp_path / "conftest.py").write_text(
        "import pytest\n\n@pytest.fixture(scope='session')\n"
        "def shared_value():\n    return 7\n",
        encoding="utf-8",
    )
    nodeid = "test_profile_target.py::test_threaded"
    (tmp_path / "child_project.py").write_text(
        "def child_value():\n    return 7\n",
        encoding="utf-8",
    )
    (tmp_path / "test_profile_target.py").write_text(
        "import subprocess\nimport sys\nimport threading\n\ndef test_threaded(shared_value):\n"
        "    worker = threading.Thread(target=lambda: None)\n"
        "    worker.start()\n    worker.join()\n"
        "    subprocess.run([sys.executable, '-c', "
        "'import child_project; assert child_project.child_value() == 7'], check=True)\n"
        "    assert shared_value == 7\n",
        encoding="utf-8",
    )
    environment = dict(os.environ)
    environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    environment["PYTHONPATH"] = str(support)
    process = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-p", "zerorun_qualify_plugin", nodeid],
        cwd=tmp_path,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    payloads = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in support.glob("profile-*.json")
    ]
    assert any(payload.get("pytest_plugin_loaded") is True for payload in payloads)
    fixtures = [
        fixture
        for payload in payloads
        for fixture in payload.get("non_function_fixtures", [])
    ]
    assert any(
        fixture[0] == "conftest.py"
        and fixture[2] == "shared_value"
        and fixture[3] == "session"
        for fixture in fixtures
    ), (fixtures, payloads)
    uncertainties = {
        kind
        for payload in payloads
        for kind in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "subprocess.Popen" in uncertainties
    thread_observations = {
        bucket: observation
        for payload in payloads
        for bucket, observation in payload.get("thread_observations", {}).items()
    }
    assert "thread-start" not in uncertainties
    assert thread_observations[nodeid] == {
        "started": 1,
        "joined": 1,
        "terminated": 1,
        "start_failed": 0,
        "complete_before_boundary": True,
    }
    session_uncertainties = {
        kind
        for payload in payloads
        for kind in payload.get("uncertainties", {}).get("__session__", [])
    }
    assert "thread-start" not in session_uncertainties
    assert "subprocess.Popen" not in session_uncertainties
    assert any(
        payload.get("pytest_plugin_loaded") is False and payload.get("buckets")
        for payload in payloads
    ), payloads


def test_profiler_attributes_joined_child_calls_once_per_code_per_node(
    tmp_path: Path,
) -> None:
    support = tmp_path / "support"
    support.mkdir()
    (support / pytest_qualify._CONTEXT_FILE).write_text(
        pytest_qualify._CONTEXT_SOURCE,
        encoding="utf-8",
    )
    (support / pytest_qualify._PLUGIN_FILE).write_text(
        pytest_qualify._PLUGIN_SOURCE,
        encoding="utf-8",
    )
    site = pytest_qualify._SITE_SOURCE.replace(
        '_ROOT = "/workspace"',
        f"_ROOT = {tmp_path.as_posix()!r}",
    ).replace(
        '_OUT_DIR = "/zerorun-pytest-qualify-output"',
        f"_OUT_DIR = {support.as_posix()!r}",
    )
    (support / pytest_qualify._SITE_FILE).write_text(site, encoding="utf-8")
    (tmp_path / "project_calls.py").write_text(
        "def leaf():\n    return 7\n\n"
        "def before_taint():\n    return leaf()\n\n"
        "def after_taint():\n    return leaf()\n\n"
        "def child_work():\n"
        "    for _ in range(10000):\n"
        "        leaf()\n",
        encoding="utf-8",
    )
    nodeid = "test_taint_target.py::test_thread_taint"
    (tmp_path / "test_taint_target.py").write_text(
        "import threading\n"
        "from project_calls import after_taint, before_taint, child_work\n\n"
        "def test_thread_taint():\n"
        "    assert before_taint() == 7\n"
        "    worker = threading.Thread(target=child_work)\n"
        "    worker.start()\n"
        "    worker.join()\n"
        "    assert after_taint() == 7\n",
        encoding="utf-8",
    )
    environment = dict(os.environ)
    environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    environment["PYTHONPATH"] = str(support)
    process = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-q",
            "-p",
            "zerorun_qualify_plugin",
            nodeid,
        ],
        cwd=tmp_path,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    payloads = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in support.glob("profile-*.json")
    ]
    uncertainties = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    node_sites = {
        (site[0], site[2])
        for payload in payloads
        for site in payload.get("buckets", {}).get(nodeid, [])
    }
    assert ("project_calls.py", "before_taint") in node_sites
    assert ("project_calls.py", "leaf") in node_sites
    assert "thread-start" not in uncertainties
    assert ("project_calls.py", "after_taint") in node_sites
    assert ("project_calls.py", "child_work") in node_sites
    observations = [
        payload.get("thread_observations", {}).get(nodeid)
        for payload in payloads
        if nodeid in payload.get("thread_observations", {})
    ]
    assert observations == [{
        "started": 1,
        "joined": 1,
        "terminated": 1,
        "start_failed": 0,
        "complete_before_boundary": True,
    }]


def test_profiler_fails_closed_when_finished_thread_was_not_joined(
    tmp_path: Path,
) -> None:
    nodeid = "test_unjoined.py::test_unjoined"
    (tmp_path / "test_unjoined.py").write_text(
        "import threading\nimport time\n\n"
        "def worker():\n    return 7\n\n"
        "def test_unjoined():\n"
        "    thread = threading.Thread(target=worker)\n"
        "    thread.start()\n"
        "    while thread.is_alive():\n        time.sleep(0.001)\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "thread-not-joined-before-node-completion" in reasons
    observations = [
        payload["thread_observations"][nodeid]
        for payload in payloads
        if nodeid in payload.get("thread_observations", {})
    ]
    assert observations == [{
        "started": 1,
        "joined": 0,
        "terminated": 1,
        "start_failed": 0,
        "complete_before_boundary": False,
    }]


def test_profiler_fails_closed_when_daemon_thread_outlives_node(
    tmp_path: Path,
) -> None:
    nodeid = "test_background.py::test_background"
    (tmp_path / "test_background.py").write_text(
        "import threading\n\n"
        "BLOCK = threading.Event()\n\n"
        "def worker():\n    BLOCK.wait()\n\n"
        "def test_background():\n"
        "    thread = threading.Thread(target=worker, daemon=True)\n"
        "    thread.start()\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "thread-alive-at-node-completion" in reasons
    assert "thread-not-joined-before-node-completion" in reasons
    observations = [
        payload["thread_observations"][nodeid]
        for payload in payloads
        if nodeid in payload.get("thread_observations", {})
    ]
    assert observations == [{
        "started": 1,
        "joined": 0,
        "terminated": 0,
        "start_failed": 0,
        "complete_before_boundary": False,
    }]


def test_profiler_fails_closed_for_unmanaged_low_level_thread(
    tmp_path: Path,
) -> None:
    nodeid = "test_lowlevel.py::test_lowlevel"
    (tmp_path / "test_lowlevel.py").write_text(
        "import _thread\nimport threading\n\n"
        "DONE = threading.Event()\n\n"
        "def worker():\n    DONE.set()\n\n"
        "def test_lowlevel():\n"
        "    _thread.start_new_thread(worker, ())\n"
        "    assert DONE.wait(5)\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "unmanaged-thread-start" in reasons
    assert all(
        nodeid not in payload.get("thread_observations", {})
        for payload in payloads
    )


def test_profiler_rejects_spoofed_managed_attribute_for_raw_joinable_thread(
    tmp_path: Path,
) -> None:
    nodeid = "test_spoofed_lowlevel.py::test_spoofed_lowlevel"
    (tmp_path / "test_spoofed_lowlevel.py").write_text(
        "import _thread\nimport threading\n\n"
        "DONE = threading.Event()\n\n"
        "def worker():\n    DONE.set()\n\n"
        "def test_spoofed_lowlevel():\n"
        "    threading.current_thread()._zerorun_managed_start = True\n"
        "    if hasattr(_thread, 'start_joinable_thread'):\n"
        "        handle = _thread.start_joinable_thread(worker)\n"
        "        handle.join()\n"
        "    else:\n"
        "        _thread.start_new_thread(worker, ())\n"
        "        assert DONE.wait(5)\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "unmanaged-thread-start" in reasons
    assert all(
        nodeid not in payload.get("thread_observations", {})
        for payload in payloads
    )


def test_profiler_uses_private_registry_when_child_owner_attribute_is_spoofed(
    tmp_path: Path,
) -> None:
    nodeid = "test_spoofed_owner.py::test_spoofed_owner"
    (tmp_path / "child_owner.py").write_text(
        "def observed_child_call():\n    return 7\n",
        encoding="utf-8",
    )
    (tmp_path / "test_spoofed_owner.py").write_text(
        "import threading\nfrom child_owner import observed_child_call\n\n"
        "class SpoofingThread(threading.Thread):\n"
        "    def __setattr__(self, name, value):\n"
        "        if name == '_zerorun_profile_owner':\n"
        "            value = '__session__'\n"
        "        super().__setattr__(name, value)\n\n"
        "def worker():\n"
        "    threading.current_thread()._zerorun_profile_owner = '__session__'\n"
        "    assert observed_child_call() == 7\n\n"
        "def test_spoofed_owner():\n"
        "    thread = SpoofingThread(target=worker)\n"
        "    thread.start()\n"
        "    thread.join()\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    node_sites = {
        (site[0], site[2])
        for payload in payloads
        for site in payload.get("buckets", {}).get(nodeid, [])
    }
    session_sites = {
        (site[0], site[2])
        for payload in payloads
        for site in payload.get("buckets", {}).get("__session__", [])
    }
    assert ("child_owner.py", "observed_child_call") in node_sites
    assert ("child_owner.py", "observed_child_call") not in session_sites


def test_profiler_attributes_child_project_file_observation_to_owner(
    tmp_path: Path,
) -> None:
    nodeid = "test_child_read.py::test_child_read"
    (tmp_path / "payload.txt").write_text("secret input\n", encoding="utf-8")
    (tmp_path / "test_child_read.py").write_text(
        "import threading\nfrom pathlib import Path\n\n"
        "def worker():\n"
        "    assert Path('payload.txt').read_text(encoding='utf-8') == 'secret input\\n'\n\n"
        "def test_child_read():\n"
        "    thread = threading.Thread(target=worker)\n"
        "    thread.start()\n"
        "    thread.join()\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    node_reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    session_reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get("__session__", [])
    }
    assert "project-file-observation:open" in node_reasons
    assert "project-file-observation:open" not in session_reasons


def test_monitoring_boundary_recaptures_same_code_for_session_bucket(
    tmp_path: Path,
) -> None:
    nodeid = "test_boundary.py::test_boundary"
    (tmp_path / "session_helper.py").write_text(
        "def shared_helper():\n    return 7\n",
        encoding="utf-8",
    )
    (tmp_path / "conftest.py").write_text(
        "import pytest\nfrom session_helper import shared_helper\n\n"
        "@pytest.hookimpl(trylast=True)\n"
        "def pytest_sessionfinish(session, exitstatus):\n"
        "    assert shared_helper() == 7\n",
        encoding="utf-8",
    )
    (tmp_path / "test_boundary.py").write_text(
        "from session_helper import shared_helper\n\n"
        "def test_boundary():\n    assert shared_helper() == 7\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    node_sites = {
        (site[0], site[2])
        for payload in payloads
        for site in payload.get("buckets", {}).get(nodeid, [])
    }
    session_sites = {
        (site[0], site[2])
        for payload in payloads
        for site in payload.get("buckets", {}).get("__session__", [])
    }
    session_imports = [
        edge
        for payload in payloads
        for edge in payload.get("executed_imports", {}).get("__session__", [])
    ]
    assert ("session_helper.py", "shared_helper") in node_sites
    assert ("session_helper.py", "shared_helper") in session_sites
    assert any(
        edge[0] == "conftest.py"
        and edge[4:8] == [1, 1, 0, 13]
        and edge[8:] == ["pytest", [], 0]
        for edge in session_imports
    )
    assert all(
        "incomplete-import-edge-attribution:position"
        not in payload.get("uncertainties", {}).get("__session__", [])
        for payload in payloads
    )


@pytest.mark.skipif(
    sys.version_info[:2] != (3, 10),
    reason="exercises the Python 3.10 source-span compatibility path",
)
def test_python310_import_span_fallback_rejects_ambiguous_source(
    tmp_path: Path,
) -> None:
    nodeid = "test_ambiguous_import.py::test_ambiguous_import"
    (tmp_path / "test_ambiguous_import.py").write_text(
        "def test_ambiguous_import():\n"
        "    if True: import os; import os\n"
        "    assert os.path.sep\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "incomplete-import-edge-attribution:position" in reasons


def test_source_span_read_audit_bypass_requires_internal_call_chain(
    tmp_path: Path,
) -> None:
    nodeid = "test_direct_span_read.py::test_direct_span_read"
    (tmp_path / "unobserved.py").write_text("import os\n", encoding="utf-8")
    (tmp_path / "test_direct_span_read.py").write_text(
        "import sitecustomize\n\n"
        "def test_direct_span_read():\n"
        "    assert sitecustomize._source_import_spans('unobserved.py') is not None\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "project-file-observation:open" in reasons


def test_source_span_cache_rejects_replaced_source(tmp_path: Path) -> None:
    nodeid = "test_replaced_span.py::test_replaced_span"
    (tmp_path / "cached_source.py").write_text("import os\n", encoding="utf-8")
    (tmp_path / "test_replaced_span.py").write_text(
        "import os\nimport sitecustomize\n\n"
        "def test_replaced_span():\n"
        "    assert sitecustomize._source_import_spans('cached_source.py') is not None\n"
        "    with open('replacement.py', 'w', encoding='utf-8') as handle:\n"
        "        handle.write('import sys\\n')\n"
        "    os.replace('replacement.py', 'cached_source.py')\n"
        "    assert sitecustomize._source_import_spans('cached_source.py') is None\n",
        encoding="utf-8",
    )
    _embedded_profile_payloads(tmp_path, nodeid)


def test_source_span_cache_enforces_global_byte_bound_under_concurrency(
    tmp_path: Path,
) -> None:
    nodeid = "test_span_bound.py::test_span_bound"
    (tmp_path / "span_a.py").write_text("import os\n", encoding="utf-8")
    (tmp_path / "span_b.py").write_text("import os\n", encoding="utf-8")
    (tmp_path / "test_span_bound.py").write_text(
        "import os\nimport sitecustomize\nimport threading\n\n"
        "def test_span_bound():\n"
        "    baseline_bytes = sitecustomize._SOURCE_IMPORT_BYTE_COUNT\n"
        "    baseline_rows = sitecustomize._SOURCE_IMPORT_ROW_COUNT\n"
        "    original_limit = sitecustomize._MAX_SOURCE_IMPORT_BYTES\n"
        "    source_bytes = os.path.getsize('span_a.py')\n"
        "    sitecustomize._MAX_SOURCE_IMPORT_BYTES = baseline_bytes + source_bytes\n"
        "    results = []\n"
        "    ready = threading.Barrier(3)\n"
        "    def inspect(relative):\n"
        "        ready.wait()\n"
        "        results.append(sitecustomize._source_import_spans(relative))\n"
        "    workers = [threading.Thread(target=inspect, args=(relative,)) "
        "for relative in ('span_a.py', 'span_b.py')]\n"
        "    try:\n"
        "        for worker in workers:\n"
        "            worker.start()\n"
        "        ready.wait()\n"
        "        for worker in workers:\n"
        "            worker.join()\n"
        "    finally:\n"
        "        sitecustomize._MAX_SOURCE_IMPORT_BYTES = original_limit\n"
        "    assert len(results) == 2\n"
        "    assert sum(result is not None for result in results) == 1\n"
        "    assert sitecustomize._SOURCE_IMPORT_BYTE_COUNT == baseline_bytes + source_bytes\n"
        "    assert sitecustomize._SOURCE_IMPORT_ROW_COUNT == baseline_rows + 1\n",
        encoding="utf-8",
    )
    _embedded_profile_payloads(tmp_path, nodeid)


def test_profiler_fails_closed_when_child_disables_its_profile_hook(
    tmp_path: Path,
) -> None:
    nodeid = "test_child_profile.py::test_child_profile"
    (tmp_path / "test_child_profile.py").write_text(
        "import sys\nimport threading\n\n"
        "def worker():\n    sys.setprofile(None)\n\n"
        "def test_child_profile():\n"
        "    thread = threading.Thread(target=worker)\n"
        "    thread.start()\n"
        "    thread.join()\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "thread-profile-hook-changed" in reasons


def test_profiler_internal_thread_local_flag_cannot_authorize_profile_disable(
    tmp_path: Path,
) -> None:
    nodeid = "test_internal_flag.py::test_internal_flag"
    (tmp_path / "test_internal_flag.py").write_text(
        "import sitecustomize\nimport sys\nimport threading\n\n"
        "def worker():\n"
        "    sitecustomize._THREAD_LOCAL.internal_profile_change = True\n"
        "    sys.setprofile(None)\n\n"
        "def test_internal_flag():\n"
        "    thread = threading.Thread(target=worker)\n"
        "    thread.start()\n"
        "    thread.join()\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert "thread-profile-hook-changed" in reasons


@pytest.mark.skipif(not hasattr(sys, "monitoring"), reason="requires PEP 669")
def test_profiler_fails_closed_for_transient_monitoring_disable(
    tmp_path: Path,
) -> None:
    nodeid = "test_monitoring_disable.py::test_monitoring_disable"
    (tmp_path / "test_monitoring_disable.py").write_text(
        "import sys\n\n"
        "def hidden_project_call():\n    return 7\n\n"
        "def test_monitoring_disable():\n"
        "    tool = sys.monitoring.PROFILER_ID\n"
        "    events = (sys.monitoring.events.PY_START | "
        "sys.monitoring.events.PY_RESUME)\n"
        "    sys.monitoring.set_events(tool, 0)\n"
        "    assert hidden_project_call() == 7\n"
        "    sys.monitoring.set_events(tool, events)\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for bucket in (nodeid, "__session__")
        for reason in payload.get("uncertainties", {}).get(bucket, [])
    }
    assert "monitoring-configuration-changed:set_events" in reasons


def test_profiler_fails_closed_when_global_child_profile_is_disabled_before_start(
    tmp_path: Path,
) -> None:
    nodeid = "test_global_profile.py::test_global_profile"
    (tmp_path / "test_global_profile.py").write_text(
        "import threading\n\n"
        "def worker():\n    return 7\n\n"
        "def test_global_profile():\n"
        "    threading.setprofile(None)\n"
        "    thread = threading.Thread(target=worker)\n"
        "    thread.start()\n"
        "    thread.join()\n",
        encoding="utf-8",
    )
    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    session_reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get("__session__", [])
    }
    violations = {
        reason
        for payload in payloads
        for reason in payload.get("integrity_violations", [])
    }
    assert "threading-profile-configuration-changed" in reasons
    assert "threading-profile-configuration-changed" in session_reasons
    if not hasattr(sys, "monitoring"):
        assert any("threading child profile hook was replaced" in item for item in violations)


def test_profiler_marks_project_data_reads_as_node_uncertainty(tmp_path: Path) -> None:
    support = tmp_path / "support"
    support.mkdir()
    (support / pytest_qualify._CONTEXT_FILE).write_text(
        pytest_qualify._CONTEXT_SOURCE,
        encoding="utf-8",
    )
    (support / pytest_qualify._PLUGIN_FILE).write_text(
        pytest_qualify._PLUGIN_SOURCE,
        encoding="utf-8",
    )
    site = pytest_qualify._SITE_SOURCE.replace(
        '_ROOT = "/workspace"',
        f"_ROOT = {tmp_path.as_posix()!r}",
    ).replace(
        '_OUT_DIR = "/zerorun-pytest-qualify-output"',
        f"_OUT_DIR = {support.as_posix()!r}",
    )
    (support / pytest_qualify._SITE_FILE).write_text(site, encoding="utf-8")
    (tmp_path / "payload.txt").write_text("review me\n", encoding="utf-8")
    nodeid = "test_data_target.py::test_project_data"
    (tmp_path / "test_data_target.py").write_text(
        "from pathlib import Path\n\n"
        "def test_project_data():\n"
        "    assert Path('payload.txt').read_text(encoding='utf-8') == 'review me\\n'\n",
        encoding="utf-8",
    )
    environment = dict(os.environ)
    environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    environment["PYTHONPATH"] = str(support)
    process = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-q",
            "-p",
            "zerorun_qualify_plugin",
            nodeid,
        ],
        cwd=tmp_path,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    uncertainties = {
        kind
        for path in support.glob("profile-*.json")
        for kind in json.loads(path.read_text(encoding="utf-8"))
        .get("uncertainties", {})
        .get(nodeid, [])
    }
    assert "project-file-observation:open" in uncertainties


def test_profiler_marks_project_metadata_observations_as_node_uncertainty(
    tmp_path: Path,
) -> None:
    created_file = tmp_path / "created-flag"
    created_file.write_text("present\n", encoding="utf-8")
    deleted_file = tmp_path / "deleted-flag"
    deleted_file.write_text("transient\n", encoding="utf-8")
    deleted_file.unlink()
    created_directory = tmp_path / "created-directory"
    created_directory.mkdir()
    permission_file = tmp_path / "permission-flag"
    permission_file.write_text("mode-sensitive\n", encoding="utf-8")
    permission_file.chmod(0o400)
    nodeid = "test_metadata_target.py::test_project_metadata"
    (tmp_path / "test_metadata_target.py").write_text(
        "import os\nfrom pathlib import Path\n\n"
        "def test_project_metadata():\n"
        "    assert os.stat('permission-flag').st_size > 0\n"
        "    assert os.lstat('permission-flag').st_size > 0\n"
        "    os.access('permission-flag', os.R_OK)\n"
        "    assert os.path.exists('created-flag')\n"
        "    assert not os.path.lexists('deleted-flag')\n"
        "    assert os.path.isfile('created-flag')\n"
        "    assert os.path.isdir('created-directory')\n"
        "    assert Path('permission-flag').stat().st_size > 0\n"
        "    assert Path('permission-flag').lstat().st_size > 0\n"
        "    assert not Path('deleted-flag').exists()\n"
        "    assert Path('created-flag').is_file()\n"
        "    assert Path('created-directory').is_dir()\n",
        encoding="utf-8",
    )

    try:
        payloads = _embedded_profile_payloads(tmp_path, nodeid)
    finally:
        permission_file.chmod(0o600)
    node_reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    session_reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get("__session__", [])
    }
    assert {
        "project-metadata-observation:stat",
        "project-metadata-observation:lstat",
        "project-metadata-observation:access",
        "project-metadata-observation:exists",
        "project-metadata-observation:lexists",
        "project-metadata-observation:isfile",
        "project-metadata-observation:isdir",
        "project-metadata-observation:is_file",
        "project-metadata-observation:is_dir",
    }.issubset(node_reasons)
    assert not any(
        reason.startswith("project-metadata-observation:")
        for reason in session_reasons
    )


def test_profiler_installs_and_integrity_checks_every_metadata_channel() -> None:
    assignments = {
        "os.stat = _metadata_stat",
        "os.lstat = _metadata_lstat",
        "os.access = _metadata_access",
        "os.path.exists = _metadata_path_exists",
        "os.path.lexists = _metadata_path_lexists",
        "os.path.isfile = _metadata_path_isfile",
        "os.path.isdir = _metadata_path_isdir",
        "pathlib.Path.stat = _metadata_path_stat",
        "pathlib.Path.lstat = _metadata_path_lstat",
        "pathlib.Path.exists = _metadata_pathlib_exists",
        "pathlib.Path.is_file = _metadata_pathlib_is_file",
        "pathlib.Path.is_dir = _metadata_pathlib_is_dir",
    }
    assert all(assignment in pytest_qualify._SITE_SOURCE for assignment in assignments)
    integrity_labels = {
        '"os.stat"',
        '"os.lstat"',
        '"os.access"',
        '"os.path.exists"',
        '"os.path.lexists"',
        '"os.path.isfile"',
        '"os.path.isdir"',
        '"Path.stat"',
        '"Path.lstat"',
        '"Path.exists"',
        '"Path.is_file"',
        '"Path.is_dir"',
    }
    assert all(label in pytest_qualify._SITE_SOURCE for label in integrity_labels)


def test_metadata_uncertainty_survives_activation_as_permanently_fresh(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    nodeid = "tests/test_calc.py::test_add"
    collection = _exact_collection((nodeid,))
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *args, **kwargs: (collection, 1.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *args, **kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": {},
                "uncertainties": {
                    nodeid: ["project-metadata-observation:exists"],
                },
                "non_function_fixtures": [],
            },
            1.0,
            0,
            "ok",
        ),
    )
    candidate_path = tmp_path / ".zerorun-pytest.candidate.json"
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=candidate_path,
    )
    assert candidate["nodes"][nodeid]["fresh_required"] is True
    assert candidate["nodes"][nodeid]["reviewable"] is False

    profile_path = tmp_path / ".zerorun-pytest.json"
    activated = pytest_qualify.activate_pytest_candidate(
        candidate_path,
        expected_candidate_sha256=candidate["candidate_sha256"],
        independence_review_sha256="8" * 64,
        output=profile_path,
    )
    monkeypatch.setattr(
        pytest_node_cache,
        "node_action_fingerprint",
        lambda *_args, **_kwargs: pytest.fail(
            "permanently fresh metadata-dependent node must never be keyed"
        ),
    )
    decisions = prepare_node_cache(
        tmp_path,
        manifest.tasks["pytest"],
        node_rows=[{"nodeid": nodeid, **activated["nodes"][nodeid]}],
        session_closure=activated["session_closure"],
        static_inputs=tuple(activated["static_inputs"]),
        collection_items=collection["items"],
        context=NodeCacheContext(
            runtime_identity={"resolved_image": "sha256:" + "a" * 64},
            environment_fingerprint={},
            collection_contract_sha256="b" * 64,
            collection_plugin_sha256="c" * 64,
            independence_review_sha256="8" * 64,
            profile_sha256="d" * 64,
        ),
        allow_cache_lookup=False,
    )
    assert len(decisions) == 1
    assert decisions[0].status == "MISS_UNCERTAIN"
    assert decisions[0].key is None


def test_profiler_marks_project_create_chmod_delete_as_node_uncertainty(
    tmp_path: Path,
) -> None:
    nodeid = "test_mutation_target.py::test_project_mutation"
    (tmp_path / "test_mutation_target.py").write_text(
        "from pathlib import Path\n\n"
        "def test_project_mutation():\n"
        "    target = Path('transient-project-file')\n"
        "    target.touch()\n"
        "    target.chmod(0o600)\n"
        "    target.unlink()\n",
        encoding="utf-8",
    )

    payloads = _embedded_profile_payloads(tmp_path, nodeid)
    node_reasons = {
        reason
        for payload in payloads
        for reason in payload.get("uncertainties", {}).get(nodeid, [])
    }
    assert {
        "project-filesystem-mutation:open",
        "project-filesystem-mutation:os.chmod",
        "project-filesystem-mutation:os.remove",
    }.issubset(node_reasons)
    assert all(
        not any(
            reason.startswith("project-filesystem-mutation:")
            for reason in payload.get("uncertainties", {}).get("__session__", [])
        )
        for payload in payloads
    )


def test_static_import_fallback_rejects_metadata_dependent_code(
    tmp_path: Path,
) -> None:
    target = tmp_path / "test_metadata_fallback.py"
    target.write_text(
        "import os\nfrom pathlib import Path\n\n"
        "def test_metadata():\n"
        "    return Path('flag').exists() or os.access('flag', os.R_OK)\n",
        encoding="utf-8",
    )

    files, absent_files, reason = pytest_qualify._static_import_fallback(
        tmp_path, target.name
    )

    assert files == ()
    assert absent_files == ()
    assert reason is not None
    assert "file-system operation" in reason


@pytest.mark.parametrize("operation", ["touch", "chmod", "unlink"])
def test_static_import_fallback_rejects_project_filesystem_mutations(
    tmp_path: Path,
    operation: str,
) -> None:
    target = tmp_path / f"test_{operation}_fallback.py"
    argument = "0o600" if operation == "chmod" else ""
    target.write_text(
        "from pathlib import Path\n\n"
        "def test_mutation():\n"
        f"    Path('transient').{operation}({argument})\n",
        encoding="utf-8",
    )

    files, absent_files, reason = pytest_qualify._static_import_fallback(
        tmp_path, target.name
    )

    assert files == ()
    assert absent_files == ()
    assert reason is not None
    assert operation in reason


def _ordinary_collection_item(
    path: str,
    nodeid: str,
    *,
    name: str,
) -> dict[str, object]:
    return {
        "nodeid": nodeid,
        "item_type": "_pytest.python.Function",
        "path": path,
        "name": name,
    }


def test_collected_source_analysis_ignores_unselected_function_body_effects(
    tmp_path: Path,
) -> None:
    relative = "test_targeted_fallback.py"
    (tmp_path / relative).write_text(
        "def test_other():\n"
        "    with open('other.txt', 'w') as handle:\n"
        "        handle.write('other')\n\n"
        "def test_selected():\n"
        "    assert True\n",
        encoding="utf-8",
    )
    item = _ordinary_collection_item(
        relative,
        relative + "::test_selected",
        name="test_selected",
    )

    files, _absent, reason = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=item,
    )

    assert reason is None
    assert files == (relative,)


def test_collected_target_effect_requires_restored_ephemeral_profile_proof(
    tmp_path: Path,
) -> None:
    relative = "test_targeted_open.py"
    (tmp_path / relative).write_text(
        "def test_selected():\n"
        "    with open('result.txt', 'w') as handle:\n"
        "        handle.write('selected')\n",
        encoding="utf-8",
    )
    item = _ordinary_collection_item(
        relative,
        relative + "::test_selected",
        name="test_selected",
    )

    rejected = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=item,
    )
    accepted = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=item,
        proven_ephemeral_mutations=("open",),
    )

    assert rejected[0:2] == ((), ())
    assert rejected[2] is not None and "operation 'open'" in rejected[2]
    assert accepted[0] == (relative,)
    assert accepted[2] is None


def test_module_and_class_setup_effects_cannot_borrow_node_mutation_proof(
    tmp_path: Path,
) -> None:
    relative = "test_setup_effect.py"
    (tmp_path / relative).write_text(
        "class TestGroup:\n"
        "    marker = open('setup.txt', 'w')\n\n"
        "    def test_selected(self):\n"
        "        marker = open('node.txt', 'w')\n"
        "        marker.close()\n",
        encoding="utf-8",
    )
    item = _ordinary_collection_item(
        relative,
        relative + "::TestGroup::test_selected",
        name="test_selected",
    )

    files, absent, reason = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=item,
        proven_ephemeral_mutations=("open", "open"),
    )

    assert files == ()
    assert absent == ()
    assert reason is not None and "operation 'open'" in reason


def test_request_local_static_import_session_reuses_exact_shadow_surfaces(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    relative = "test_shared_import.py"
    (tmp_path / "localpkg").mkdir()
    (tmp_path / "localpkg" / "__init__.py").write_text("", encoding="utf-8")
    (tmp_path / "localpkg" / "helper.py").write_text(
        "VALUE = 1\n",
        encoding="utf-8",
    )
    (tmp_path / relative).write_text(
        "from localpkg import helper\n\n"
        "def test_one():\n    assert helper.VALUE == 1\n\n"
        "def test_two():\n    assert helper.VALUE == 1\n",
        encoding="utf-8",
    )
    first_item = _ordinary_collection_item(
        relative,
        relative + "::test_one",
        name="test_one",
    )
    second_item = _ordinary_collection_item(
        relative,
        relative + "::test_two",
        name="test_two",
    )
    real_resolve = pytest_closure.resolve_local_import_surface
    resolved: list[str] = []

    def counted_resolve(*args, **kwargs):
        resolved.append(str(args[1]))
        return real_resolve(*args, **kwargs)

    monkeypatch.setattr(
        pytest_closure,
        "resolve_local_import_surface",
        counted_resolve,
    )
    session = pytest_qualify._StaticImportFallbackSession(tmp_path)
    first = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=first_item,
        analysis_session=session,
    )
    first_resolution_count = len(resolved)
    second = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=second_item,
        analysis_session=session,
    )

    assert first[2] is None
    assert second == first
    assert first_resolution_count > 0
    assert len(resolved) == first_resolution_count
    assert set(first[0]) == {
        relative,
        "localpkg/__init__.py",
        "localpkg/helper.py",
    }
    session.revalidate()


def test_request_local_static_import_session_detects_source_change(
    tmp_path: Path,
) -> None:
    relative = "test_snapshot_change.py"
    target = tmp_path / relative
    target.write_text("def test_clean():\n    assert True\n", encoding="utf-8")
    item = _ordinary_collection_item(
        relative,
        relative + "::test_clean",
        name="test_clean",
    )
    session = pytest_qualify._StaticImportFallbackSession(tmp_path)

    files, _absent, reason = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=item,
        analysis_session=session,
    )
    assert files == (relative,)
    assert reason is None

    target.write_text(
        "def test_clean():\n    return eval('True')\n",
        encoding="utf-8",
    )
    with pytest.raises(
        ConfigurationError,
        match="static import source changed during qualification",
    ):
        session.revalidate()

    # A new request-local session observes the changed execution surface; it
    # never inherits cached authority from the prior candidate construction.
    new_result = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=item,
        analysis_session=pytest_qualify._StaticImportFallbackSession(tmp_path),
    )
    assert new_result[0:2] == ((), ())
    assert new_result[2] is not None and "dynamic import/evaluation" in new_result[2]


def test_common_reviewed_closure_factorization_is_exact_and_idempotent() -> None:
    session = {
        "selectors": ["session.py::setup"],
        "fallback_files": ["session.py", "present-conflict.py"],
        "absent_files": ["session-missing.py"],
    }
    nodes = {
        "test_mod.py::test_a": {
            "reviewable": True,
            "fresh_required": False,
            "selectors": ["shared.py::common", "test_mod.py::test_a"],
            "fallback_files": ["shared.py", "a.py"],
            "absent_files": [
                "common-missing.py",
                "present-conflict.py",
                "a-missing.py",
            ],
        },
        "test_mod.py::test_b": {
            "reviewable": True,
            "fresh_required": False,
            "selectors": ["test_mod.py::test_b", "shared.py::common"],
            "fallback_files": ["b.py", "shared.py"],
            "absent_files": [
                "b-missing.py",
                "present-conflict.py",
                "common-missing.py",
            ],
        },
        "test_mod.py::test_fresh": {
            "reviewable": False,
            "fresh_required": True,
            "reason": "intentional uncertainty",
            "selectors": [],
            "fallback_files": [],
            "absent_files": [],
        },
    }
    before_session = json.loads(json.dumps(session))
    before_nodes = json.loads(json.dumps(nodes))

    pytest_qualify._hoist_common_reviewed_closure(session, nodes)

    for nodeid in ("test_mod.py::test_a", "test_mod.py::test_b"):
        for field in ("selectors", "fallback_files", "absent_files"):
            before_effective = set(before_session[field]) | set(
                before_nodes[nodeid][field]
            )
            after_effective = set(session[field]) | set(nodes[nodeid][field])
            assert after_effective == before_effective
    assert session["selectors"] == before_session["selectors"]
    assert session["fallback_files"] == before_session["fallback_files"]
    assert all(
        nodes[nodeid]["selectors"] == before_nodes[nodeid]["selectors"]
        and nodes[nodeid]["fallback_files"]
        == before_nodes[nodeid]["fallback_files"]
        for nodeid in ("test_mod.py::test_a", "test_mod.py::test_b")
    )
    assert nodes["test_mod.py::test_fresh"] == before_nodes["test_mod.py::test_fresh"]
    assert "common-missing.py" in session["absent_files"]
    assert all(
        "common-missing.py" not in nodes[nodeid]["absent_files"]
        for nodeid in ("test_mod.py::test_a", "test_mod.py::test_b")
    )
    # A present-vs-absent conflict remains node-local for the existing
    # validator to reject; factoring must never hide it in session state.
    assert "present-conflict.py" not in session["absent_files"]
    assert all(
        "present-conflict.py" in nodes[nodeid]["absent_files"]
        for nodeid in ("test_mod.py::test_a", "test_mod.py::test_b")
    )
    assert session["absent_files"] == sorted(session["absent_files"])

    stable = json.dumps(
        {"session": session, "nodes": nodes},
        sort_keys=True,
        separators=(",", ":"),
    )
    pytest_qualify._hoist_common_reviewed_closure(session, nodes)
    assert json.dumps(
        {"session": session, "nodes": nodes},
        sort_keys=True,
        separators=(",", ":"),
    ) == stable


def test_common_factorization_preserves_positive_node_closure() -> None:
    session = {
        "selectors": [],
        "fallback_files": ["conftest.py"],
        "absent_files": [],
    }
    nodes = {
        nodeid: {
            "reviewable": True,
            "fresh_required": False,
            "selectors": ["shared.py::only_symbol"],
            "fallback_files": [],
            "absent_files": ["shared-missing.py"],
        }
        for nodeid in ("test_mod.py::test_a", "test_mod.py::test_b")
    }

    pytest_qualify._hoist_common_reviewed_closure(session, nodes)

    assert "shared.py::only_symbol" not in session["selectors"]
    assert all(row["selectors"] == ["shared.py::only_symbol"] for row in nodes.values())
    assert session["absent_files"] == ["shared-missing.py"]
    assert all(row["absent_files"] == [] for row in nodes.values())


def test_positive_source_review_drift_remains_node_local(tmp_path: Path) -> None:
    for relative in (
        "session.py",
        "all-common.py",
        "partial-common.py",
        "only-a.py",
        "only-b.py",
        "only-c.py",
    ):
        (tmp_path / relative).write_text(
            f"VALUE = {relative!r}\n",
            encoding="utf-8",
        )
    session = {
        "selectors": [],
        "fallback_files": ["session.py"],
        "absent_files": [],
    }
    nodes = {
        "test_mod.py::test_a": {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [],
            "fallback_files": [
                "all-common.py",
                "partial-common.py",
                "only-a.py",
            ],
            "absent_files": ["common-missing.py"],
        },
        "test_mod.py::test_b": {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [],
            "fallback_files": [
                "all-common.py",
                "partial-common.py",
                "only-b.py",
            ],
            "absent_files": ["common-missing.py"],
        },
        "test_mod.py::test_c": {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [],
            "fallback_files": ["all-common.py", "only-c.py"],
            "absent_files": ["common-missing.py"],
        },
    }
    before_nodes = json.loads(json.dumps(nodes))
    pytest_qualify._hoist_common_reviewed_closure(session, nodes)

    assert session["fallback_files"] == ["session.py"]
    assert all(
        row["fallback_files"] == before_nodes[nodeid]["fallback_files"]
        for nodeid, row in nodes.items()
    )
    assert session["absent_files"] == ["common-missing.py"]
    assert all(row["absent_files"] == [] for row in nodes.values())

    expected = pytest_qualify.build_pytest_source_review(
        tmp_path,
        static_inputs=(),
        session_closure=session,
        nodes=nodes,
        profiler_sha256="a" * 64,
        collection_plugin_sha256="b" * 64,
    )
    (tmp_path / "partial-common.py").write_text(
        "VALUE = 'changed after activation'\n",
        encoding="utf-8",
    )
    current = pytest_qualify.build_pytest_source_review(
        tmp_path,
        static_inputs=(),
        session_closure=session,
        nodes=nodes,
        profiler_sha256="a" * 64,
        collection_plugin_sha256="b" * 64,
        fail_on_node_error=False,
    )

    assert current["session_closure_sha256"] == expected["session_closure_sha256"]
    expected_nodes = expected["node_closure_sha256"]
    current_nodes = current["node_closure_sha256"]
    assert current_nodes["test_mod.py::test_a"] != expected_nodes["test_mod.py::test_a"]
    assert current_nodes["test_mod.py::test_b"] != expected_nodes["test_mod.py::test_b"]
    assert current_nodes["test_mod.py::test_c"] == expected_nodes["test_mod.py::test_c"]


@pytest.mark.parametrize(
    "malformed_absences",
    [None, ("missing.py",), ["missing.py", "missing.py"], [1]],
)
def test_common_factorization_rejects_malformed_reviewable_components(
    malformed_absences: object,
) -> None:
    session = {
        "selectors": [],
        "fallback_files": ["conftest.py"],
        "absent_files": [],
    }
    nodes = {
        f"test_mod.py::test_{index}": {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [f"test_mod.py::test_{index}"],
            "fallback_files": [],
            "absent_files": malformed_absences,
        }
        for index in range(2)
    }

    with pytest.raises(ConfigurationError, match="canonical string array"):
        pytest_qualify._hoist_common_reviewed_closure(session, nodes)


def test_click_shape_common_absence_factorization_fits_existing_limit() -> None:
    absences = [
        f"shadow/{index:04d}/candidate.py"
        for index in range(3_521)
    ]
    session = {
        "selectors": [],
        "fallback_files": ["conftest.py"],
        "absent_files": [],
    }
    nodes = {
        f"tests/test_arguments.py::test_case_{index}": {
            "reviewable": True,
            "fresh_required": False,
            "selectors": [f"tests/test_arguments.py::test_case_{index}"],
            "fallback_files": [],
            "absent_files": list(absences),
        }
        for index in range(109)
    }
    before = len(
        json.dumps(
            {"session_closure": session, "nodes": nodes},
            indent=2,
            sort_keys=True,
        ).encode("utf-8")
    )

    pytest_qualify._hoist_common_reviewed_closure(session, nodes)
    after = len(
        json.dumps(
            {"session_closure": session, "nodes": nodes},
            indent=2,
            sort_keys=True,
        ).encode("utf-8")
    )

    assert before > pytest_qualify._MAX_CANDIDATE_BYTES
    assert after < pytest_qualify._MAX_CANDIDATE_BYTES
    assert after * 50 < before
    assert len(session["absent_files"]) == 3_521
    assert all(row["absent_files"] == [] for row in nodes.values())


def test_factored_candidate_activation_and_source_guards_remain_exact(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    nodeids = (
        "tests/test_calc.py::test_add[left]",
        "tests/test_calc.py::test_add[right]",
    )
    collection = _exact_collection(nodeids)
    profile = {
        "loaded": True,
        "buckets": {
            "__session__": [["conftest.py", 1, "<module>", [], False]],
            **{
                nodeid: [
                    ["src/calc.py", 3, "add", ["OFFSET"], False],
                    ["tests/test_calc.py", 3, "test_add", ["add"], False],
                ]
                for nodeid in nodeids
            },
        },
    }
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_qualify,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *_args, **_kwargs: (
            _with_fused_collection(profile, collection),
            2.0,
            0,
            "2 passed",
        ),
    )
    candidate_path = tmp_path / ".zerorun-pytest.candidate.json"
    candidate = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=candidate_path,
    )

    assert "src.py" in candidate["session_closure"]["absent_files"]
    assert all(
        "src.py" not in row["absent_files"]
        for row in candidate["nodes"].values()
    )
    profile_path = tmp_path / ".zerorun-pytest.json"
    pytest_qualify.activate_pytest_candidate(
        candidate_path,
        expected_candidate_sha256=candidate["candidate_sha256"],
        independence_review_sha256="5" * 64,
        output=profile_path,
    )
    loaded = load_pytest_profile(profile_path, manifest)
    recomputed = pytest_qualify.build_pytest_source_review(
        tmp_path,
        static_inputs=loaded.static_inputs,
        session_closure=loaded.session_closure,
        nodes=loaded.nodes,
        profiler_sha256=pytest_qualify.profiler_sha256(),
        collection_plugin_sha256=pytest_qualify.collection_plugin_sha256(),
    )
    assert recomputed == loaded.source_review

    (tmp_path / "src" / "calc.py").write_text(
        "OFFSET = 2\n\ndef add(a, b):\n    return a + b + OFFSET\n",
        encoding="utf-8",
    )
    changed_positive = pytest_qualify.build_pytest_source_review(
        tmp_path,
        static_inputs=loaded.static_inputs,
        session_closure=loaded.session_closure,
        nodes=loaded.nodes,
        profiler_sha256=pytest_qualify.profiler_sha256(),
        collection_plugin_sha256=pytest_qualify.collection_plugin_sha256(),
        fail_on_node_error=False,
    )
    assert (
        changed_positive["session_closure_sha256"]
        == loaded.source_review["session_closure_sha256"]
    )
    assert all(
        changed_positive["node_closure_sha256"][nodeid]
        != loaded.source_review["node_closure_sha256"][nodeid]
        for nodeid in nodeids
    )

    (tmp_path / "src.py").write_text(
        "raise RuntimeError('new project shadow')\n",
        encoding="utf-8",
    )
    with pytest.raises(
        ConfigurationError,
        match="negative import candidate became available",
    ):
        pytest_qualify.build_pytest_source_review(
            tmp_path,
            static_inputs=loaded.static_inputs,
            session_closure=loaded.session_closure,
            nodes=loaded.nodes,
            profiler_sha256=pytest_qualify.profiler_sha256(),
            collection_plugin_sha256=pytest_qualify.collection_plugin_sha256(),
        )

    (tmp_path / "src.py").unlink()
    (tmp_path / "conftest.py").unlink()
    with pytest.raises(ConfigurationError):
        pytest_qualify.build_pytest_source_review(
            tmp_path,
            static_inputs=loaded.static_inputs,
            session_closure=loaded.session_closure,
            nodes=loaded.nodes,
            profiler_sha256=pytest_qualify.profiler_sha256(),
            collection_plugin_sha256=pytest_qualify.collection_plugin_sha256(),
        )


def test_ambiguous_or_custom_collection_item_stays_fresh(
    tmp_path: Path,
) -> None:
    relative = "test_custom_item.py"
    (tmp_path / relative).write_text(
        "def test_selected():\n    assert True\n",
        encoding="utf-8",
    )
    item = _ordinary_collection_item(
        relative,
        relative + "::generated-name",
        name="generated-name",
    )

    files, absent, reason = pytest_qualify._static_import_fallback(
        tmp_path,
        relative,
        collection_item=item,
    )

    assert files == ()
    assert absent == ()
    assert reason is not None and "Python identifiers" in reason


def test_profiler_runtime_executes_only_exact_clean_sibling_selection(
    tmp_path: Path,
) -> None:
    support = tmp_path / "support"
    support.mkdir()
    (support / pytest_qualify._CONTEXT_FILE).write_text(
        pytest_qualify._CONTEXT_SOURCE,
        encoding="utf-8",
    )
    (support / pytest_qualify._PLUGIN_FILE).write_text(
        pytest_qualify._PLUGIN_SOURCE,
        encoding="utf-8",
    )
    root_text = tmp_path.as_posix()
    support_text = support.as_posix()
    site = pytest_qualify._SITE_SOURCE.replace(
        '_ROOT = "/workspace"',
        f"_ROOT = {root_text!r}",
    ).replace(
        '_OUT_DIR = "/zerorun-pytest-qualify-output"',
        f"_OUT_DIR = {support_text!r}",
    )
    (support / pytest_qualify._SITE_FILE).write_text(site, encoding="utf-8")
    nodeids = (
        "test_selection_target.py::test_unsafe",
        "test_selection_target.py::test_clean",
    )
    selection = support / pytest_qualify._SELECTION_FILE
    selection.write_text(
        json.dumps(
            {
                "expected_nodeids": list(nodeids),
                "selected_nodeids": [nodeids[1]],
            }
        ),
        encoding="utf-8",
    )
    (tmp_path / "test_selection_target.py").write_text(
        "def test_unsafe():\n    raise AssertionError('must stay deselected')\n\n"
        "def test_clean():\n    assert True\n",
        encoding="utf-8",
    )
    environment = dict(os.environ)
    environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    environment["PYTHONPATH"] = str(support)
    environment["ZERORUN_PROFILE_SELECTION"] = str(selection)
    process = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-q",
            "-p",
            "zerorun_qualify_plugin",
            "test_selection_target.py",
        ],
        cwd=tmp_path,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    plugin_payloads = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in support.glob("profile-*.json")
        if json.loads(path.read_text(encoding="utf-8")).get("pytest_plugin_loaded")
        is True
    ]
    assert plugin_payloads
    assert all(payload["collection_nodeids"] == list(nodeids) for payload in plugin_payloads)
    assert all(payload["selected_nodeids"] == [nodeids[1]] for payload in plugin_payloads)
    assert {
        nodeid
        for payload in plugin_payloads
        for nodeid in payload["started_nodeids"]
    } == {nodeids[1]}
    assert {
        nodeid
        for payload in plugin_payloads
        for nodeid in payload["completed_nodeids"]
    } == {nodeids[1]}


def _run_local_collection_contract(
    root: Path,
    support: Path,
    *,
    profiled: bool,
) -> tuple[bytes, list[dict]]:
    support.mkdir()
    output = support / "output"
    output.mkdir()
    (support / pytest_qualify._COLLECTION_PLUGIN_FILE).write_text(
        pytest_qualify._COLLECTION_PLUGIN,
        encoding="utf-8",
    )
    if profiled:
        (support / pytest_qualify._CONTEXT_FILE).write_text(
            pytest_qualify._CONTEXT_SOURCE,
            encoding="utf-8",
        )
        (support / pytest_qualify._PLUGIN_FILE).write_text(
            pytest_qualify._PLUGIN_SOURCE,
            encoding="utf-8",
        )
        site = pytest_qualify._SITE_SOURCE.replace(
            '_ROOT = "/workspace"',
            f"_ROOT = {root.as_posix()!r}",
        ).replace(
            '_OUT_DIR = "/zerorun-pytest-qualify-output"',
            f"_OUT_DIR = {output.as_posix()!r}",
        )
        (support / pytest_qualify._SITE_FILE).write_text(site, encoding="utf-8")
    collection_output = output / pytest_qualify._COLLECTION_OUTPUT_FILE
    environment = dict(os.environ)
    environment.update(
        {
            "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONPATH": str(support),
            "ZERORUN_COLLECTION_OUTPUT": str(collection_output),
        }
    )
    command = [sys.executable, "-m", "pytest"]
    if profiled:
        command.extend(["-p", "zerorun_qualify_plugin"])
    command.extend(["-p", "zerorun_collection_plugin"])
    if not profiled:
        command.append("--collect-only")
    command.append("tests")
    process = subprocess.run(
        command,
        cwd=root,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    profiles = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in output.glob("profile-*.json")
    ]
    return collection_output.read_bytes(), profiles


def test_fused_profile_collection_is_byte_exact_to_standalone_collection(
    tmp_path: Path,
) -> None:
    """Instrumentation must not create a second collection semantics."""

    tests = tmp_path / "tests"
    tests.mkdir()
    (tmp_path / "pyproject.toml").write_text(
        "[tool.pytest.ini_options]\n"
        "addopts = ['-p', 'no:cacheprovider', '--strict-markers']\n"
        "markers = ['contract: collection-contract fixture']\n",
        encoding="utf-8",
    )
    (tests / "conftest.py").write_text(
        "from pathlib import Path\n"
        "import pytest\n\n"
        "class CaseItem(pytest.Item):\n"
        "    def runtest(self):\n"
        "        return None\n\n"
        "class CaseFile(pytest.File):\n"
        "    def collect(self):\n"
        "        yield CaseItem.from_parent(self, name='custom-case')\n\n"
        "def pytest_collect_file(file_path: Path, parent):\n"
        "    if file_path.suffix == '.case':\n"
        "        return CaseFile.from_parent(parent, path=file_path)\n\n"
        "@pytest.hookimpl(tryfirst=True)\n"
        "def pytest_collection_modifyitems(items):\n"
        "    items[:] = list(reversed(items))\n",
        encoding="utf-8",
    )
    (tests / "test_matrix.py").write_text(
        "import pytest\n\n"
        "@pytest.mark.contract\n"
        "@pytest.mark.parametrize('value', [0, 0], ids=['duplicate-a', 'duplicate-b'])\n"
        "def test_duplicate_values(value):\n"
        "    assert value == 0\n",
        encoding="utf-8",
    )
    (tests / "sample.case").write_text("custom\n", encoding="utf-8")

    standalone, _ = _run_local_collection_contract(
        tmp_path,
        tmp_path / "standalone-support",
        profiled=False,
    )
    fused, profiles = _run_local_collection_contract(
        tmp_path,
        tmp_path / "fused-support",
        profiled=True,
    )

    assert fused == standalone
    collection = json.loads(fused)
    assert len(collection["nodeids"]) == 3
    assert collection["invocation"]["rootpath"] == "."
    assert collection["invocation"]["args"] == ["tests"]
    assert collection["invocation"]["addopts"] == [
        "-p",
        "no:cacheprovider",
        "--strict-markers",
    ]
    plugin_profiles = [row for row in profiles if row["pytest_plugin_loaded"]]
    assert plugin_profiles
    assert all(
        row["collection_nodeids"] == collection["nodeids"]
        and row["selected_nodeids"] == collection["nodeids"]
        and row["started_nodeids"] == sorted(collection["nodeids"])
        and row["completed_nodeids"] == sorted(collection["nodeids"])
        for row in plugin_profiles
    )


@pytest.mark.parametrize(
    ("case", "message"),
    [
        ("missing", "no exact collection evidence"),
        ("digest", "digest mismatch"),
        ("attestation", "disagrees with profiler attestation"),
        ("incomplete", "did not execute the exact collected nodes"),
    ],
)
def test_docker_profiler_fused_collection_fails_closed(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    case: str,
    message: str,
) -> None:
    manifest = _repo(tmp_path)
    monkeypatch.setattr(pytest_qualify, "_docker_path", lambda _root: "/usr/bin/docker")
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda *_args, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(pytest_qualify, "hermetic_environment", lambda _task: ({}, {}))

    def fake_created(command, **_kwargs):
        output = _profile_output_source(command)
        process_profile = _valid_process_profile()
        if case == "attestation":
            process_profile["collection_nodeids"] = ["tests/test_calc.py::other"]
            process_profile["selected_nodeids"] = ["tests/test_calc.py::other"]
        elif case == "incomplete":
            process_profile["completed_nodeids"] = []
        (output / "profile-123.json").write_text(
            json.dumps(process_profile),
            encoding="utf-8",
        )
        if case != "missing":
            collection = _exact_collection()
            if case == "digest":
                collection["collection_sha256"] = "0" * 64
            (output / pytest_qualify._COLLECTION_OUTPUT_FILE).write_text(
                json.dumps(collection),
                encoding="utf-8",
            )
        return subprocess.CompletedProcess(command, 0, b"ok", b"")

    monkeypatch.setattr(pytest_qualify, "_run_created_container", fake_created)
    with pytest.raises(ConfigurationError, match=message):
        pytest_qualify._docker_profile(
            manifest,
            manifest.tasks["pytest"],
            targets=("tests",),
        )
