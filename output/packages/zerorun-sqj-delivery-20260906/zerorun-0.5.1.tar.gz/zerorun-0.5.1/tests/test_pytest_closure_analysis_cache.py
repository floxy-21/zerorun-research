from __future__ import annotations

from collections import Counter
import json
from pathlib import Path

import pytest

from zerorun import pytest_closure, pytest_qualify
from zerorun.manifest import load_manifest
from zerorun.model import ConfigurationError


IMAGE = "python@sha256:" + "1" * 64


def _repo(root: Path):
    (root / ".git").mkdir()
    (root / "src").mkdir()
    (root / "tests").mkdir()
    (root / "src" / "calc.py").write_text(
        "OFFSET = 1\n\ndef add(a, b):\n    return a + b + OFFSET\n",
        encoding="utf-8",
    )
    (root / "tests" / "test_calc.py").write_text(
        "from src.calc import add\n\ndef test_add():\n    assert add(1, 1) == 3\n",
        encoding="utf-8",
    )
    (root / "conftest.py").write_text("# session\n", encoding="utf-8")
    (root / "pyproject.toml").write_text(
        "[tool.pytest.ini_options]\n",
        encoding="utf-8",
    )
    manifest_path = root / ".zerorun.json"
    manifest_path.write_text(
        json.dumps(
            {
                "version": 2,
                "tasks": {
                    "pytest": {
                        "command": ["python", "-m", "pytest"],
                        "inputs": [
                            "src",
                            "tests",
                            "conftest.py",
                            "pyproject.toml",
                        ],
                        "outputs": [],
                        "env": [],
                        "cacheable": True,
                        "unsafe_effects": [],
                        "cache_streams": False,
                        "image": IMAGE,
                        "platform": "linux/amd64",
                        "result_only": True,
                        "closure_reviewed": True,
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    return load_manifest(manifest_path)


def _mock_qualification(monkeypatch, manifest, *, node_count: int = 32) -> None:
    nodeids = tuple(
        f"tests/test_calc.py::test_add[case-{index}]" for index in range(node_count)
    )
    collection = {
        "invocation": {
            "rootpath": ".",
            "args": ["tests"],
            "pyargs": False,
            "addopts": [],
        },
        "items": [
            {
                "nodeid": nodeid,
                "identity_sha256": f"{index + 1:064x}",
                "item_type": "_pytest.python.Function",
                "name": nodeid.rsplit("::", 1)[-1],
                "fixturenames": [],
                "callspec_params": {
                    "case": {"supported": True, "value": ["int", index]}
                },
                "parameter_identity_supported": True,
                "parameter_identity_uncertainty": [],
                "path": "tests/test_calc.py",
            }
            for index, nodeid in enumerate(nodeids)
        ],
        "nodeids": list(nodeids),
        "collection_sha256": "4" * 64,
    }
    buckets = {
        "__session__": [["conftest.py", 1, "<module>", [], False]],
        **{
            nodeid: [
                ["src/calc.py", 3, "add", ["OFFSET"], False],
                ["tests/test_calc.py", 3, "test_add", ["add"], False],
            ]
            for nodeid in nodeids
        },
    }
    monkeypatch.setattr(
        pytest_qualify,
        "inspect_runtime",
        lambda _task, **_kwargs: {"requested_image": IMAGE},
    )
    monkeypatch.setattr(
        pytest_qualify,
        "hermetic_environment",
        lambda _task: ({}, {}),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "collect_pytest",
        lambda *_args, **_kwargs: (collection, 11.0),
    )
    monkeypatch.setattr(
        pytest_qualify,
        "_docker_profile",
        lambda *_args, **_kwargs: (
            {
                "loaded": True,
                "collection": collection,
                "buckets": buckets,
            },
            25.0,
            0,
            f"{node_count} passed",
        ),
    )


def test_qualification_parses_each_unique_closure_source_once(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    _mock_qualification(monkeypatch, manifest, node_count=64)
    original_index = pytest_closure._index_symbols
    parse_counts: dict[str, int] = {}

    def counted_index(source: str, filename: str):
        parse_counts[filename] = parse_counts.get(filename, 0) + 1
        return original_index(source, filename)

    monkeypatch.setattr(pytest_closure, "_index_symbols", counted_index)
    first_path = tmp_path / "candidate-one.json"
    first = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=first_path,
    )

    assert parse_counts == {
        "conftest.py": 1,
        "src/calc.py": 1,
        "tests/test_calc.py": 1,
    }

    parse_counts.clear()
    second_path = tmp_path / "candidate-two.json"
    second = pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=second_path,
    )
    assert parse_counts == {
        "conftest.py": 1,
        "src/calc.py": 1,
        "tests/test_calc.py": 1,
    }
    assert second == first
    assert second_path.read_bytes() == first_path.read_bytes()


def test_qualification_resolves_each_import_surface_once_per_request(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    _mock_qualification(monkeypatch, manifest, node_count=64)
    original_resolve = pytest_closure.resolve_local_import_surface
    calls: list[tuple[str, tuple[str, ...]]] = []

    def counted_resolve(root: Path, module: str, *, search_roots=None):
        normalized = tuple(search_roots or (".", "src"))
        calls.append((module, normalized))
        return original_resolve(root, module, search_roots=search_roots)

    monkeypatch.setattr(
        pytest_closure,
        "resolve_local_import_surface",
        counted_resolve,
    )
    pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / "candidate-one.json",
    )
    first_counts = Counter(calls)

    assert first_counts
    assert set(first_counts.values()) == {1}

    pytest_qualify.qualify_pytest_candidate(
        manifest,
        task_name="pytest",
        targets=("tests",),
        output=tmp_path / "candidate-two.json",
    )
    # A new qualification deliberately creates a new analysis request and
    # re-observes each surface exactly once; no authority crosses requests.
    assert set(Counter(calls).values()) == {2}


def test_import_surface_cache_key_includes_exact_search_roots(
    monkeypatch,
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    original_resolve = pytest_closure.resolve_local_import_surface
    calls: list[tuple[str, ...]] = []

    def counted_resolve(root: Path, module: str, *, search_roots=None):
        calls.append(tuple(search_roots or (".", "src")))
        return original_resolve(root, module, search_roots=search_roots)

    monkeypatch.setattr(
        pytest_closure,
        "resolve_local_import_surface",
        counted_resolve,
    )
    cache = pytest_closure.SymbolClosureAnalysisCache(tmp_path)
    first = cache.import_surface("src.calc", search_roots=(".", "src"))
    assert cache.import_surface("src.calc", search_roots=(".", "src")) == first
    cache.import_surface("src.calc", search_roots=("src",))

    assert calls == [(".", "src"), ("src",)]
    other = tmp_path / "other-root"
    other.mkdir()
    with pytest.raises(ConfigurationError, match="cannot be shared across project roots"):
        cache.validate_root(other)


def test_cached_negative_import_surface_is_rejected_after_shadow_creation(
    tmp_path: Path,
) -> None:
    _repo(tmp_path)
    cache = pytest_closure.SymbolClosureAnalysisCache(tmp_path)
    surface = cache.import_surface("external_dep", search_roots=(".", "src"))
    assert surface.resolved_locally is False
    assert "external_dep.py" in surface.absent_files

    (tmp_path / "external_dep.py").write_text("VALUE = 1\n", encoding="utf-8")
    with pytest.raises(
        ConfigurationError,
        match="negative local import candidate changed",
    ):
        pytest_closure.validate_absent_import_paths(tmp_path, surface.absent_files)

    fresh = pytest_closure.SymbolClosureAnalysisCache(tmp_path).import_surface(
        "external_dep",
        search_roots=(".", "src"),
    )
    assert fresh.resolved_locally is True
    assert "external_dep.py" in fresh.existing_files


@pytest.mark.parametrize("mutation", ["truncate", "grow", "same-size"])
def test_qualification_rejects_source_mutation_after_review(
    monkeypatch,
    tmp_path: Path,
    mutation: str,
) -> None:
    manifest = _repo(tmp_path)
    _mock_qualification(monkeypatch, manifest)
    source_path = tmp_path / "src" / "calc.py"
    original_review = pytest_qualify.build_pytest_source_review

    def review_then_mutate(*args, **kwargs):
        review = original_review(*args, **kwargs)
        original = source_path.read_bytes()
        if mutation == "truncate":
            replacement = original[: len(original) // 2]
        elif mutation == "grow":
            replacement = original + b"# changed after review\n"
        else:
            replacement = original.replace(b"OFFSET = 1", b"OFFSET = 2")
            assert len(replacement) == len(original)
        source_path.write_bytes(replacement)
        return review

    monkeypatch.setattr(
        pytest_qualify,
        "build_pytest_source_review",
        review_then_mutate,
    )
    output = tmp_path / "candidate.json"
    with pytest.raises(
        ConfigurationError,
        match="symbol-closure source changed during qualification: src/calc.py",
    ):
        pytest_qualify.qualify_pytest_candidate(
            manifest,
            task_name="pytest",
            targets=("tests",),
            output=output,
        )
    assert not output.exists()


def test_qualification_revalidates_immediately_before_candidate_write(
    monkeypatch,
    tmp_path: Path,
) -> None:
    manifest = _repo(tmp_path)
    _mock_qualification(monkeypatch, manifest)
    source_path = tmp_path / "src" / "calc.py"
    original_validator = pytest_qualify.validate_repository_file_path
    validation_count = 0

    def validate_then_mutate(*args, **kwargs):
        nonlocal validation_count
        validated = original_validator(*args, **kwargs)
        validation_count += 1
        if validation_count == 2:
            original = source_path.read_bytes()
            replacement = original.replace(b"OFFSET = 1", b"OFFSET = 2")
            assert len(replacement) == len(original)
            source_path.write_bytes(replacement)
        return validated

    monkeypatch.setattr(
        pytest_qualify,
        "validate_repository_file_path",
        validate_then_mutate,
    )
    output = tmp_path / "candidate.json"
    with pytest.raises(
        ConfigurationError,
        match="symbol-closure source changed during qualification: src/calc.py",
    ):
        pytest_qualify.qualify_pytest_candidate(
            manifest,
            task_name="pytest",
            targets=("tests",),
            output=output,
        )
    assert validation_count == 2
    assert not output.exists()
