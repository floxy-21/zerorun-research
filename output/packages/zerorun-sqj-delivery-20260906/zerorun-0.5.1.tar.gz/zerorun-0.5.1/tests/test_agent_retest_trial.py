from __future__ import annotations

import copy
import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from tools.agent_retest_trial import (
    CLOSURE_BASIS,
    DIRECT_CONDITION,
    EXPECTED_BASE_COMMIT,
    EXPECTED_INTERPRETER_VERSION,
    EXPECTED_REVISIONS,
    EXPECTED_RUNTIME_IMAGE,
    FRESH_STATUS,
    HIT_STATUS,
    PUBLIC_CPYTHON_ORIGIN,
    TARGET_PLATFORM,
    ZERORUN_CONDITION,
    TrialConfigurationError,
    _cache_namespaces_disjoint,
    _counterbalance_complete,
    _ensure_report_outside_repository,
    _git_environment,
    _task_manifest_record,
    _trajectory_summary,
    changed_targets,
    condition_order,
    engine_source_identity,
    load_trial_scenario,
    trajectory_tasks,
    validate_interpreter_attestation,
)


ROOT = Path(__file__).resolve().parents[1]
SCENARIO = ROOT / "experiments" / "cpython-agent-retest" / "scenario.json"


def _scenario_dict() -> dict:
    return json.loads(SCENARIO.read_text(encoding="utf-8"))


def _runtime_payload(*, version: list[int] | None = None) -> dict:
    selected = version or [3, 12, 14]
    return {
        "implementation": "CPython",
        "version_info": selected,
        "version_text": ".".join(str(item) for item in selected),
        "releaselevel": "final",
        "serial": 0,
        "executable": "/usr/local/bin/python3",
    }


def _passing_iteration(index: int) -> dict:
    return {
        "condition_order": list(condition_order(0, index)),
        "direct": {"suite_wall_ms": 100.0},
        "zerorun": {
            "suite_wall_ms": 50.0,
            "targets": [
                {"status": HIT_STATUS},
                {"status": FRESH_STATUS},
            ],
        },
        "shadow": {"claimed_hit_count": 1, "shadow_count": 1},
        "direct_failures": [],
        "zerorun_failures": [],
        "expected_status_mismatches": [],
        "shadow_mismatches": [],
    }


class AgentRetestTrialTests(unittest.TestCase):
    def test_engine_source_identity_is_ordered_and_byte_sensitive(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            package = Path(directory) / "zerorun"
            (package / "nested").mkdir(parents=True)
            (package / "z.py").write_text("VALUE = 1\n", encoding="utf-8")
            (package / "nested" / "a.py").write_text(
                "VALUE = 2\n", encoding="utf-8"
            )
            (package / "ignored.txt").write_text("not code\n", encoding="utf-8")

            first = engine_source_identity(package)
            self.assertEqual(first["file_count"], 2)
            self.assertEqual(
                [record["path"] for record in first["files"]],
                ["zerorun/nested/a.py", "zerorun/z.py"],
            )

            (package / "nested" / "a.py").write_text(
                "VALUE = 3\n", encoding="utf-8"
            )
            second = engine_source_identity(package)
            self.assertNotEqual(first["sha256"], second["sha256"])

    def test_frozen_scenario_loads_as_v2_author_declared_trial(self) -> None:
        scenario = load_trial_scenario(SCENARIO)

        self.assertEqual(scenario.source_remote, PUBLIC_CPYTHON_ORIGIN)
        self.assertEqual(scenario.base_commit, EXPECTED_BASE_COMMIT)
        self.assertEqual(scenario.revisions, EXPECTED_REVISIONS)
        self.assertEqual(len(scenario.revisions), 20)
        self.assertEqual(scenario.runtime_platform, TARGET_PLATFORM)
        self.assertEqual(
            scenario.interpreter_version, EXPECTED_INTERPRETER_VERSION
        )
        self.assertTrue(
            scenario.runtime_image.startswith("docker.io/library/python@sha256:")
        )
        self.assertEqual(scenario.runtime_image, EXPECTED_RUNTIME_IMAGE)
        self.assertEqual(len(scenario.runtime_image.rsplit(":", 1)[1]), 64)
        self.assertEqual(scenario.closure_basis, CLOSURE_BASIS)
        self.assertFalse(scenario.closure_independently_audited)
        self.assertEqual(scenario.trajectory_count, 2)

        for task in scenario.tasks:
            self.assertTrue(task.cacheable)
            self.assertTrue(task.result_only)
            self.assertTrue(task.closure_reviewed)
            self.assertFalse(task.cache_streams)
            self.assertEqual(task.outputs, ())
            self.assertEqual(task.env, ())
            self.assertEqual(task.image, scenario.runtime_image)
            self.assertEqual(task.platform, TARGET_PLATFORM)
            self.assertIn("/workspace/Lib", task.command[-1])

    def test_scenario_mutations_fail_closed(self) -> None:
        mutations = (
            (
                lambda raw: raw["source"].__setitem__(
                    "remote", "https://github.com/python/cpython"
                ),
                "exactly https://github.com/python/cpython.git",
            ),
            (
                lambda raw: raw["revisions"].pop(),
                "exact ordered 20-revision",
            ),
            (
                lambda raw: raw["runtime"].__setitem__(
                    "image", "docker.io/library/python:3.12.14"
                ),
                "exact frozen Python 3.12.14 platform digest",
            ),
            (
                lambda raw: raw["runtime"].__setitem__(
                    "interpreter_version", [3, 11, 9]
                ),
                r"exactly \[3, 12, 14\]",
            ),
            (
                lambda raw: raw["tasks"][0].__setitem__(
                    "closure_basis", "inferred"
                ),
                "author-declared",
            ),
            (
                lambda raw: raw["tasks"][0].__setitem__("command", ["true"]),
                "command does not match the frozen workload",
            ),
            (
                lambda raw: raw["tasks"][1]["inputs"].append("Lib/os.py"),
                "inputs do not match the frozen author-declared closure",
            ),
            (
                lambda raw: raw["design"].__setitem__(
                    "closure_independently_audited", True
                ),
                "must be false",
            ),
        )
        for mutation, message in mutations:
            with self.subTest(message=message):
                raw = _scenario_dict()
                mutation(raw)
                with patch(
                    "tools.agent_retest_trial._read_scenario",
                    return_value=(raw, "a" * 64),
                ):
                    with self.assertRaisesRegex(TrialConfigurationError, message):
                        load_trial_scenario(Path("unused-by-mock.json"))

    def test_changed_targets_respects_file_and_directory_boundaries(self) -> None:
        scenario = load_trial_scenario(SCENARIO)

        self.assertEqual(
            changed_targets(
                scenario.tasks,
                (
                    "Lib/configparser.py",
                    "Lib/test/test_email/data/msg_01.txt",
                    "Lib/datetime.py-extra",
                ),
            ),
            ("data-config", "messaging"),
        )
        self.assertEqual(changed_targets(scenario.tasks, ("Lib/tarfile.py",)), ())

    def test_condition_order_is_paired_and_balanced(self) -> None:
        ab = (DIRECT_CONDITION, ZERORUN_CONDITION)
        ba = (ZERORUN_CONDITION, DIRECT_CONDITION)

        for revision_index in range(20):
            self.assertEqual(
                {
                    condition_order(trajectory_index, revision_index)
                    for trajectory_index in range(2)
                },
                {ab, ba},
            )
        for trajectory_index in range(2):
            orders = [
                condition_order(trajectory_index, index) for index in range(20)
            ]
            self.assertEqual(orders.count(ab), 10)
            self.assertEqual(orders.count(ba), 10)

    def test_trajectory_task_names_create_disjoint_v2_namespaces(self) -> None:
        tasks = load_trial_scenario(SCENARIO).tasks
        first = trajectory_tasks(tasks, 0)
        second = trajectory_tasks(tasks, 1)

        self.assertTrue(
            {task.name for task in first}.isdisjoint(task.name for task in second)
        )
        for logical, first_task, second_task in zip(
            tasks, first, second, strict=True
        ):
            self.assertTrue(first_task.name.endswith(logical.name))
            self.assertTrue(second_task.name.endswith(logical.name))
            self.assertEqual(replace(first_task, name=logical.name), logical)
            self.assertEqual(replace(second_task, name=logical.name), logical)

    def test_generated_manifest_records_round_trip_exact_v2_tasks(self) -> None:
        scenario = load_trial_scenario(SCENARIO)

        for trajectory_index in range(scenario.trajectory_count):
            for expected in trajectory_tasks(scenario.tasks, trajectory_index):
                parsed = type(expected).from_dict(
                    expected.name,
                    _task_manifest_record(expected),
                    version=2,
                )
                self.assertEqual(parsed, expected)

    def test_report_path_must_resolve_outside_source_checkout(self) -> None:
        with self.assertRaisesRegex(
            TrialConfigurationError, "outside the disposable CPython worktree"
        ):
            _ensure_report_outside_repository(ROOT / "receipt.json", ROOT)

        outside = _ensure_report_outside_repository(
            ROOT.parent / "cpython-trial-receipt.json", ROOT
        )
        self.assertEqual(outside, (ROOT.parent / "cpython-trial-receipt.json").resolve())

    def test_trial_git_environment_forbids_network_and_credentials(self) -> None:
        environment = _git_environment()

        self.assertEqual(environment["GIT_ALLOW_PROTOCOL"], "file")
        self.assertEqual(environment["GIT_PROTOCOL_FROM_USER"], "0")
        self.assertEqual(environment["GIT_NO_LAZY_FETCH"], "1")
        self.assertEqual(environment["GIT_TERMINAL_PROMPT"], "0")
        self.assertEqual(environment["GCM_INTERACTIVE"], "Never")
        self.assertNotIn("GIT_ASKPASS", environment)
        self.assertNotIn("SSH_ASKPASS", environment)

    def test_runtime_attestation_requires_exact_cpython_patch_release(self) -> None:
        scenario = load_trial_scenario(SCENARIO)

        self.assertEqual(
            validate_interpreter_attestation(_runtime_payload(), scenario)[
                "version_info"
            ],
            [3, 12, 14],
        )
        for version in ([3, 11, 9], [3, 12, 13], [3, 13, 0]):
            with self.subTest(version=version):
                with self.assertRaisesRegex(
                    TrialConfigurationError, "expected exactly 3.12.14"
                ):
                    validate_interpreter_attestation(
                        _runtime_payload(version=list(version)), scenario
                    )

    def test_trajectory_gate_requires_one_fresh_shadow_per_hit(self) -> None:
        scenario = load_trial_scenario(SCENARIO)
        iterations = [_passing_iteration(index) for index in range(20)]

        self.assertTrue(_trajectory_summary(iterations, scenario)["pass"])
        incomplete = copy.deepcopy(iterations)
        incomplete[0]["shadow"]["shadow_count"] = 0
        self.assertFalse(_trajectory_summary(incomplete, scenario)["pass"])

    def test_global_design_checks_counterbalance_and_cache_disjointness(self) -> None:
        first = {
            "seed": {"targets": [{"cache_key": "first-seed"}]},
            "iterations": [
                {
                    "condition_order": list(condition_order(0, index)),
                    "zerorun": {"targets": [{"cache_key": f"first-{index}"}]},
                }
                for index in range(20)
            ],
        }
        second = {
            "seed": {"targets": [{"cache_key": "second-seed"}]},
            "iterations": [
                {
                    "condition_order": list(condition_order(1, index)),
                    "zerorun": {"targets": [{"cache_key": f"second-{index}"}]},
                }
                for index in range(20)
            ],
        }

        self.assertTrue(_counterbalance_complete((first, second), 20))
        self.assertTrue(_cache_namespaces_disjoint((first, second)))
        second["iterations"][0]["zerorun"]["targets"][0][
            "cache_key"
        ] = "first-0"
        self.assertFalse(_cache_namespaces_disjoint((first, second)))


if __name__ == "__main__":
    unittest.main()
