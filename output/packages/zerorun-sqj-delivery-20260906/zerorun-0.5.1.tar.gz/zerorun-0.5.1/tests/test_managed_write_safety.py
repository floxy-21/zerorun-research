from __future__ import annotations

import ast
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest

from zerorun import store as store_module
from zerorun import trust
from zerorun.model import ConfigurationError
from zerorun.oci import _TRUNCATION_MARKER
from zerorun.oci import _decode_docker_json
from zerorun.oci import _docker_bind_mount
from zerorun.path_safety import atomic_replace_bytes
from zerorun.pytest_setup import _exclude_managed_env_from_git
from zerorun.runner import read_events
from zerorun.store import Store


ROOT = Path(__file__).resolve().parents[1]


def _hard_link(source: Path, destination: Path) -> None:
    try:
        os.link(source, destination)
    except OSError as exc:
        pytest.skip(f"hard links are unavailable on this filesystem: {exc}")


def _store(root: Path) -> Store:
    root.mkdir()
    (root / ".git").mkdir()
    store = Store(root)
    store.ensure()
    return store


def test_atomic_replace_does_not_write_through_existing_hard_link(
    tmp_path: Path,
) -> None:
    managed = tmp_path / "managed"
    managed.mkdir()
    victim = tmp_path / "victim.txt"
    victim.write_bytes(b"do not modify\n")
    destination = managed / "result.json"
    _hard_link(victim, destination)

    atomic_replace_bytes(destination, b'{"safe":true}\n')

    assert victim.read_bytes() == b"do not modify\n"
    assert destination.read_bytes() == b'{"safe":true}\n'
    assert not os.path.samefile(victim, destination)


def test_quarantine_publication_replaces_attacker_hard_links(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    store = _store(tmp_path / "repository")
    key = "a" * 64
    entry = store.entry(key)
    entry.mkdir()
    monkeypatch.setattr(store_module.time, "time", lambda: 1234.5)

    marker_victim = tmp_path / "marker-victim.txt"
    report_victim = tmp_path / "report-victim.txt"
    marker_victim.write_bytes(b"marker must survive\n")
    report_victim.write_bytes(b"report must survive\n")
    marker = entry / "QUARANTINED"
    report = store.quarantine / f"{key}-1234.json"
    _hard_link(marker_victim, marker)
    _hard_link(report_victim, report)

    published = store.quarantine_entry(key, {"reason": "invalid metadata"})

    assert published == report
    assert marker_victim.read_bytes() == b"marker must survive\n"
    assert report_victim.read_bytes() == b"report must survive\n"
    assert json.loads(marker.read_text(encoding="utf-8")) == {
        "reason": "invalid metadata"
    }
    assert json.loads(report.read_text(encoding="utf-8")) == {
        "reason": "invalid metadata"
    }
    assert not os.path.samefile(marker_victim, marker)
    assert not os.path.samefile(report_victim, report)


def test_event_publication_replaces_hard_link_and_bounds_disk_usage(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    store = _store(tmp_path / "repository")
    victim = tmp_path / "event-victim.txt"
    original = b'{"status":"VICTIM","wall_ms":1}\n'
    victim.write_bytes(original)
    _hard_link(victim, store.events)
    monkeypatch.setattr(store_module, "_MAX_EVENT_LOG_BYTES", 512)
    monkeypatch.setattr(store_module, "_MAX_EVENT_RECORD_BYTES", 256)

    for index in range(30):
        store.append_event(
            {
                "status": "HIT_REPLAYED",
                "wall_ms": float(index),
                "execution_ms": 10.0,
                "saved_ms": 5.0,
                "reason": "x" * 10_000,
            }
        )

    assert victim.read_bytes() == original
    assert not os.path.samefile(victim, store.events)
    assert store.events.stat().st_size <= 512
    assert store.events.read_bytes().endswith(b"\n")
    decoded = [json.loads(line) for line in store.events.read_text().splitlines()]
    assert decoded
    assert all(row["event_truncated"] is True for row in decoded)
    assert read_events(store)


def test_managed_setup_git_exclude_does_not_write_through_hard_link(
    tmp_path: Path,
) -> None:
    root = tmp_path / "repository"
    info = root / ".git" / "info"
    info.mkdir(parents=True)
    victim = tmp_path / "exclude-victim.txt"
    victim.write_bytes(b"victim bytes must survive\n")
    exclude = info / "exclude"
    _hard_link(victim, exclude)

    _exclude_managed_env_from_git(root)

    assert victim.read_bytes() == b"victim bytes must survive\n"
    assert not os.path.samefile(victim, exclude)
    rendered = exclude.read_text(encoding="utf-8")
    assert rendered.startswith("victim bytes must survive\n")
    assert "/.zerorun/" in rendered
    assert "/.zerorun-env/" in rendered


def test_security_sensitive_runtime_paths_use_cross_version_link_check() -> None:
    offenders: list[str] = []
    for name in (
        "hermetic_key.py",
        "oci.py",
        "pytest_qualify.py",
        "runner.py",
        "store.py",
        "workspace.py",
    ):
        source = ROOT / "zerorun" / name
        tree = ast.parse(source.read_text(encoding="utf-8"), filename=str(source))
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "is_symlink"
            ):
                offenders.append(f"{name}:{node.lineno}")

    assert offenders == []


def test_candidate_publication_uses_non_following_atomic_replacement() -> None:
    source = (ROOT / "zerorun" / "pytest_qualify.py").read_text(
        encoding="utf-8"
    )
    function = next(
        node
        for node in ast.parse(source).body
        if isinstance(node, ast.FunctionDef)
        and node.name == "qualify_pytest_candidate"
    )
    calls = [
        node
        for node in ast.walk(function)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "atomic_replace_bytes"
    ]
    assert len(calls) == 1


def test_git_trust_inspection_rejects_bounded_output_overflow(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    root = tmp_path / "repository"
    root.mkdir()
    (root / ".git").mkdir()
    (root / ".git" / "HEAD").write_text("ref: refs/heads/main\n", encoding="utf-8")
    monkeypatch.setattr(trust.shutil, "which", lambda _name: sys.executable)
    calls = 0

    def bounded_git(*_args, **_kwargs):
        nonlocal calls
        calls += 1
        if calls == 1:
            return SimpleNamespace(
                returncode=0,
                stdout=str(root.resolve()).encode("utf-8"),
                stderr=b"",
            ), False
        return SimpleNamespace(
            returncode=0,
            stdout=_TRUNCATION_MARKER + b".zerorun/cache/forged\0",
            stderr=b"",
        ), False

    monkeypatch.setattr(trust, "_run_bounded_process", bounded_git)

    with pytest.raises(ConfigurationError, match="bounded Git output limit"):
        trust.tracked_zerorun_paths(root)
    assert calls == 2


def test_docker_bind_mount_rejects_csv_option_injection(tmp_path: Path) -> None:
    safe = tmp_path.resolve()
    assert _docker_bind_mount(safe, "/workspace", readonly=True) == (
        f"type=bind,src={safe},dst=/workspace,readonly"
    )
    with pytest.raises(ConfigurationError, match="unsafe for --mount"):
        _docker_bind_mount(
            safe.with_name(safe.name + ",readonly=false"),
            "/workspace",
            readonly=True,
        )
    with pytest.raises(ConfigurationError, match="destination is malformed"):
        _docker_bind_mount(safe, "/workspace,readonly=false")


def test_docker_metadata_json_is_structurally_bounded_and_unambiguous() -> None:
    with pytest.raises(ConfigurationError, match="duplicate JSON member"):
        _decode_docker_json(b'{"Id":"one","Id":"two"}', label="Docker metadata")
    with pytest.raises(ConfigurationError, match="JSON depth limit"):
        _decode_docker_json(
            (b"[" * 33) + b"0" + (b"]" * 33),
            label="Docker metadata",
        )
