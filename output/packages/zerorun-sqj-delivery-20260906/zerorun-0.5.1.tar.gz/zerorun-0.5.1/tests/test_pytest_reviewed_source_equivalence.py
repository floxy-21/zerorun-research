from __future__ import annotations

from tools.pytest_reviewed_source_equivalence import apply_reviewed_equivalence


PR_9624_PATCH = "42ce2ac8fd537830181ec231d31f6a2e94aed250e4805dca8a53d738efaec76a"
PR_10051_PATCH = "f3a8ca89d952a2fd0be9deffa6cd7fb3133827e43f8016fb10014c7da3c746d3"
PR_9875_PATCH = "757308ad5c498b0f3095f941e0ffd90a04c6947ec12d09cf81057510d2321a5f"
PR_9915_PATCH = "6bd3179c86469f0a393a798001bb1462396fccfdc75da4aa0ef3a78f4ef41e1a"


def test_9624_suppresses_coarse_testcasefunction_churn_for_ordinary_function_path() -> None:
    selectors = (
        "src/_pytest/unittest.py::@module-state",
        "src/_pytest/unittest.py::@binding:TestCaseFunction",
        "src/_pytest/unittest.py::TestCaseFunction.@class-state",
        # PyobjMixin.obj is used by ordinary pytest Function nodes throughout
        # the corpus; its presence alone must not turn this into unittest
        # execution for the exact PR 9624 review.
        "src/_pytest/python.py::PyobjMixin.obj",
        "src/_pytest/unittest.py::pytest_runtest_makereport",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=9624,
        patch_sha256=PR_9624_PATCH,
        selectors=selectors,
        observed_receiver_mro=("_pytest.python.Function", "_pytest.python.PyobjMixin"),
    )
    assert review is not None
    assert narrowed == (
        "src/_pytest/python.py::PyobjMixin.obj",
        "src/_pytest/unittest.py::pytest_runtest_makereport",
    )


def test_9624_keeps_testcasefunction_receiver_dispatch_fail_closed() -> None:
    selectors = (
        "src/_pytest/unittest.py::@module-state",
        "src/_pytest/unittest.py::@binding:TestCaseFunction",
        "src/_pytest/unittest.py::TestCaseFunction.@class-state",
        "src/_pytest/python.py::PyobjMixin.obj",
        "src/_pytest/python.py::PyobjMixin._getobj",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=9624,
        patch_sha256=PR_9624_PATCH,
        selectors=selectors,
        observed_receiver_mro=(
            "_pytest.unittest.TestCaseFunction",
            "_pytest.python.Function",
            "_pytest.python.PyobjMixin",
        ),
    )
    assert review is None
    assert narrowed == selectors


def test_9624_missing_receiver_evidence_fails_closed() -> None:
    selectors = (
        "src/_pytest/unittest.py::@module-state",
        "src/_pytest/unittest.py::@binding:TestCaseFunction",
        "src/_pytest/unittest.py::TestCaseFunction.@class-state",
        "src/_pytest/python.py::PyobjMixin.obj",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=9624,
        patch_sha256=PR_9624_PATCH,
        selectors=selectors,
    )
    assert review is None
    assert narrowed == selectors


def test_9624_concrete_testcasefunction_method_stays_fresh_with_receiver_proof() -> None:
    selectors = (
        "src/_pytest/unittest.py::@module-state",
        "src/_pytest/unittest.py::@binding:TestCaseFunction",
        "src/_pytest/unittest.py::TestCaseFunction.@class-state",
        "src/_pytest/unittest.py::TestCaseFunction.runtest",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=9624,
        patch_sha256=PR_9624_PATCH,
        selectors=selectors,
        observed_receiver_mro=("_pytest.python.Function",),
    )
    assert review is None
    assert narrowed == selectors


def test_9624_does_not_ignore_unittest_target_module_state() -> None:
    selectors = (
        "src/_pytest/unittest.py::@module-state",
        "src/_pytest/unittest.py::@binding:TestCaseFunction",
        "testing/test_unittest.py::@module-state",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=9624,
        patch_sha256=PR_9624_PATCH,
        selectors=selectors,
        observed_receiver_mro=("_pytest.python.Function",),
    )
    assert review is not None
    assert narrowed == ("testing/test_unittest.py::@module-state",)


def test_10051_suppresses_handler_class_churn_for_unchanged_reset_path() -> None:
    selectors = (
        "src/_pytest/logging.py::@module-state",
        "src/_pytest/logging.py::@binding:LogCaptureHandler",
        "src/_pytest/logging.py::LogCaptureHandler.@class-state",
        "src/_pytest/logging.py::LogCaptureHandler.reset",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=10051,
        patch_sha256=PR_10051_PATCH,
        selectors=selectors,
    )
    assert review is not None
    assert narrowed == ("src/_pytest/logging.py::LogCaptureHandler.reset",)


def test_10051_keeps_changed_clear_path_fail_closed() -> None:
    selectors = (
        "src/_pytest/logging.py::@module-state",
        "src/_pytest/logging.py::@binding:LogCaptureHandler",
        "src/_pytest/logging.py::LogCaptureHandler.@class-state",
        "src/_pytest/logging.py::LogCaptureFixture.clear",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=10051,
        patch_sha256=PR_10051_PATCH,
        selectors=selectors,
    )
    assert review is None
    assert narrowed == selectors


def test_9875_ignores_only_reviewed_result_only_terminal_sinks() -> None:
    selectors = (
        "src/_pytest/terminal.py::@module-state",
        "src/_pytest/terminal.py::TerminalReporter.short_test_summary",
        "src/_pytest/terminal.py::_get_line_with_reprcrash_message",
        "src/_pytest/config/__init__.py::pytest_configure",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=9875,
        patch_sha256=PR_9875_PATCH,
        selectors=selectors,
    )
    assert review is not None
    assert narrowed == ("src/_pytest/config/__init__.py::pytest_configure",)


def test_9875_changed_output_assertion_node_stays_fresh() -> None:
    selectors = (
        "testing/test_terminal.py::@module-state",
        "testing/test_terminal.py::test_line_with_reprcrash",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=9875,
        patch_sha256=PR_9875_PATCH,
        selectors=selectors,
    )
    assert review is None
    assert narrowed == selectors


def test_9915_requires_measured_utf8_default_text_io() -> None:
    selectors = (
        "src/_pytest/cacheprovider.py::@module-state",
        "src/_pytest/cacheprovider.py::Cache.get",
    )
    for runtime in (
        None,
        {"default_text_write_utf8": False, "default_text_bytes_hex": "e9"},
    ):
        narrowed, review = apply_reviewed_equivalence(
            pr=9915,
            patch_sha256=PR_9915_PATCH,
            selectors=selectors,
            runtime_text_encoding=runtime,
        )
        assert review is None
        assert narrowed == selectors

    narrowed, review = apply_reviewed_equivalence(
        pr=9915,
        patch_sha256=PR_9915_PATCH,
        selectors=selectors,
        runtime_text_encoding={
            "default_text_write_utf8": True,
            "default_text_bytes_hex": "c3a9",
        },
    )
    assert review is not None
    assert narrowed == ()


def test_9915_cacheprovider_observer_target_stays_fresh() -> None:
    selectors = (
        "src/_pytest/cacheprovider.py::Cache.set",
        "testing/test_cacheprovider.py::@module-state",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=9915,
        patch_sha256=PR_9915_PATCH,
        selectors=selectors,
        runtime_text_encoding={
            "default_text_write_utf8": True,
            "default_text_bytes_hex": "c3a9",
        },
    )
    assert review is None
    assert narrowed == selectors


def test_review_never_applies_to_wrong_patch_identity() -> None:
    selectors = (
        "src/_pytest/logging.py::@module-state",
        "src/_pytest/logging.py::@binding:LogCaptureHandler",
        "src/_pytest/logging.py::LogCaptureHandler.@class-state",
        "src/_pytest/logging.py::LogCaptureHandler.reset",
    )
    narrowed, review = apply_reviewed_equivalence(
        pr=10051,
        patch_sha256="0" * 64,
        selectors=selectors,
    )
    assert review is None
    assert narrowed == selectors
