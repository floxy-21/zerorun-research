from __future__ import annotations

import json
from pathlib import Path

from zerorun import mcp


def test_stats_compute_only_repository_local_verified_savings(tmp_path: Path):
    (tmp_path / ".git").mkdir()
    state = tmp_path / ".zerorun"
    state.mkdir()
    events = [
        {
            "status": "PYTEST_INCREMENTAL_PASS",
            "wall_ms": 100.0,
            "execution_ms": 80.0,
            "saved_ms": 900.0,
            "reused_nodes": 9,
            "fresh_nodes": 1,
            "total_nodes": 10,
        },
        {
            "status": "OBSERVED_EXECUTED",
            "wall_ms": 500.0,
            "execution_ms": 500.0,
            "saved_ms": 0.0,
        },
    ]
    (state / "events.jsonl").write_text(
        "".join(json.dumps(row) + "\n" for row in events),
        encoding="utf-8",
    )

    response = mcp.handle_request(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "stats", "arguments": {"root": str(tmp_path)}},
        }
    )
    payload = response["result"]["structuredContent"]

    assert payload["mode"] == "observe-only"
    assert payload["reuse_ready"] is False
    assert payload["events"] == 2
    assert payload["verified_saved_seconds"] == 0.9
    assert payload["actual_seconds"] == 0.6
    assert payload["conservative_no_zerorun_seconds"] == 1.5
    assert payload["effective_speedup"] == 2.5
    assert payload["saved_percent"] == 60.0
    assert payload["reused_nodes"] == 9
    assert payload["fresh_nodes"] == 1
    assert payload["total_nodes"] == 10
    assert payload["reuse_percent"] == 90.0
    assert payload["observed_execution_seconds"] == 0.5


def test_stats_do_not_turn_observation_into_savings(tmp_path: Path):
    (tmp_path / ".git").mkdir()
    state = tmp_path / ".zerorun"
    state.mkdir()
    (state / "events.jsonl").write_text(
        json.dumps(
            {
                "status": "OBSERVED_EXECUTED",
                "wall_ms": 750.0,
                "execution_ms": 750.0,
                "saved_ms": 0.0,
            }
        )
        + "\n",
        encoding="utf-8",
    )

    payload = mcp.handle_request(
        {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {"name": "stats", "arguments": {"root": str(tmp_path)}},
        }
    )["result"]["structuredContent"]

    assert payload["verified_saved_seconds"] == 0.0
    assert payload["actual_seconds"] == 0.75
    assert payload["conservative_no_zerorun_seconds"] == 0.75
    assert payload["effective_speedup"] == 1.0
    assert payload["saved_percent"] == 0.0
