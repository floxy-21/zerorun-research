from __future__ import annotations

from collections import Counter
from datetime import date
import hashlib
import json
from pathlib import Path
from typing import Mapping
from urllib.parse import parse_qs, urlsplit

import pytest

from research.artifact import validation
from tools import research_github_frame as frame_tool


ROOT = Path(__file__).resolve().parents[1]


def _render(value: object) -> bytes:
    return (
        json.dumps(value, allow_nan=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode("utf-8")


def _write_json(path: Path, value: object) -> None:
    path.write_bytes(
        (
            json.dumps(value, allow_nan=False, indent=2, sort_keys=True) + "\n"
        ).encode("utf-8")
    )


def _candidate(repository_id: int, stars: int) -> dict[str, object]:
    name = f"owner-{repository_id}/repo-{repository_id}"
    return {
        "id": repository_id,
        "full_name": name,
        "html_url": f"https://github.com/{name}",
        "stargazers_count": stars,
        "language": "Python",
        "fork": False,
        "archived": False,
        "private": False,
        "pushed_at": "2026-08-31T00:00:00Z",
        "license": {"spdx_id": "MIT"},
        "size": 100 + repository_id,
        "default_branch": "main",
    }


STRATUM_CANDIDATES = {
    "100..499": _candidate(1, 100),
    "500..1999": _candidate(2, 500),
    "2000..9999": _candidate(3, 2_000),
    ">=10000": _candidate(4, 10_000),
}


class FakeGitHub:
    def __init__(self, mode: str = "stable") -> None:
        self.mode = mode
        self.urls: list[str] = []
        self.url_calls: Counter[str] = Counter()

    def _search(self, url: str) -> tuple[int, object]:
        query = parse_qs(urlsplit(url).query)["q"][0]
        star_key = next(key for key in STRATUM_CANDIDATES if f"stars:{key}" in query)
        item = dict(STRATUM_CANDIDATES[star_key])
        if self.mode == "drift" and star_key == ">=10000" and self.url_calls[url] >= 2:
            item = _candidate(44, 10_001)

        if star_key == "100..499" and "size:" not in query:
            return 200, {"total_count": 901, "incomplete_results": False, "items": []}
        if "size:>=5000001" in query:
            return 200, {"total_count": 0, "incomplete_results": False, "items": []}
        if self.mode == "overflow" and star_key == "100..499":
            if "size:" in query:
                size_value = query.split("size:", 1)[1].split(" ", 1)[0]
                if size_value == "0" or size_value.startswith("0.."):
                    return 200, {
                        "total_count": 901,
                        "incomplete_results": False,
                        "items": [item] if parse_qs(urlsplit(url).query)["page"] == ["1"] else [],
                    }
                return 200, {"total_count": 0, "incomplete_results": False, "items": []}
        total = 2 if self.mode == "changed_count" and star_key == "500..1999" else 1
        return 200, {"total_count": total, "incomplete_results": False, "items": [item]}

    def get(
        self, url: str, headers: Mapping[str, str]
    ) -> frame_tool.HttpResponse:
        del headers
        self.urls.append(url)
        self.url_calls[url] += 1
        parsed = urlsplit(url)
        status = 200
        if parsed.path == "/search/repositories":
            status, payload = self._search(url)
        elif parsed.path.startswith("/repositories/"):
            repository_id = int(parsed.path.rsplit("/", 1)[1])
            if self.mode == "metadata_404" and repository_id == 1:
                status, payload = 404, {"message": "Not Found"}
            else:
                source = next(
                    (
                        candidate
                        for candidate in STRATUM_CANDIDATES.values()
                        if candidate["id"] == repository_id
                    ),
                    _candidate(repository_id, 10_001),
                )
                payload = dict(source)
        elif "/commits/" in parsed.path:
            repository_id = int(parsed.path.split("/", 3)[2].split("-", 1)[1])
            payload = {"sha": f"{repository_id:040x}"}
        else:  # pragma: no cover - a new endpoint must be added deliberately
            raise AssertionError(f"unexpected request {url}")
        body = _render(payload)
        if self.mode == "duplicate_json" and len(self.urls) == 1:
            body = b'{"total_count":1,"total_count":2,"incomplete_results":false,"items":[]}\n'
        response_url = url
        if self.mode == "redirect" and len(self.urls) == 1:
            response_url = "https://evil.example/redirected"
        return frame_tool.HttpResponse(
            status=status,
            headers={
                "ETag": f'"etag-{len(self.urls)}"',
                "Link": "",
                "X-RateLimit-Remaining": "4999",
                "Authorization": "must-not-be-archived",
            },
            body=body,
            received_at_utc="2026-09-01T12:00:00Z",
            url=response_url,
        )


def _inputs(tmp_path: Path, *, same_day_cutoff: bool = False) -> tuple[Path, Path]:
    exclusions = tmp_path / "development-contact-exclusions.txt"
    exclusions.write_text("# frozen\n", encoding="utf-8", newline="\n")
    exclusion_sha = hashlib.sha256(exclusions.read_bytes()).hexdigest()
    plan = {
        "schema": frame_tool.PLAN_SCHEMA,
        "artifact_role": "candidate_frame_collection_plan_only",
        "protocol_commit": "a" * 40,
        "retrieval_client_commit": "b" * 40,
        "retrieval_client_source_sha256": hashlib.sha256(
            Path(frame_tool.__file__).read_bytes()
        ).hexdigest(),
        "created_at_utc": "2026-09-02T00:00:00Z",
        "window_start_utc": "2026-09-01T00:00:00Z",
        "window_end_utc": "2026-09-01T23:59:59Z",
        "maintenance_cutoff_utc": (
            "2026-09-01T00:00:00Z" if same_day_cutoff else "2024-09-01T00:00:00Z"
        ),
        "created_partition_start_date": "2026-09-01",
        "created_partition_end_date": "2026-09-01",
        "seed": "future-public-seed-0001",
        "seed_source": "synthetic future beacon",
        "seed_source_payload_sha256": "c" * 64,
        "github_api_version": "2022-11-28",
        "development_contact_exclusion_sha256": exclusion_sha,
        "terminal_cell_max_results": 900,
        "snapshot_count": 2,
        "snapshot_stability_max_symmetric_difference_ratio": 0.01,
    }
    plan_path = tmp_path / "frame-plan.json"
    _write_json(plan_path, plan)
    return plan_path, exclusions


def _collect(
    tmp_path: Path, transport: FakeGitHub, *, same_day_cutoff: bool = False
) -> tuple[dict, dict]:
    plan, exclusions = _inputs(tmp_path, same_day_cutoff=same_day_cutoff)
    return frame_tool.collect_candidate_frame(
        research_root=ROOT / "research",
        plan_path=plan,
        exclusion_file=exclusions,
        raw_archive=tmp_path / "raw",
        output=tmp_path / "candidate-frame.json",
        receipt_path=tmp_path / "candidate-frame-receipt.json",
        transport=transport,
    )


def test_two_snapshot_frame_is_schema_valid_partitioned_archived_and_non_authorizing(
    tmp_path: Path,
) -> None:
    transport = FakeGitHub()
    frame, receipt = _collect(tmp_path, transport)

    assert len(frame["candidates"]) == 4
    assert frame["collection"]["snapshot_count"] == 2
    assert frame["collection"]["overall_symmetric_difference_ratio"] == 0
    assert frame["collection"]["stable"] is True
    assert len(frame["sampling"]["query_cells"]) == 5
    assert all(
        cell["completeness_status"] == "complete"
        for cell in frame["sampling"]["query_cells"]
    )
    assert any("size%3A0..5000000" in url for url in transport.urls)
    assert all("is%3Apublic" in url for url in transport.urls if "/search/" in url)
    assert receipt["confirmatory_execution_authorized"] is False
    assert receipt["final_corpus_created"] is False
    assert receipt["metadata_complete"] == 4

    index_path = tmp_path / "raw/response-index.json"
    index = json.loads(index_path.read_text(encoding="utf-8"))
    assert index["entry_count"] == len(index["entries"]) == receipt["request_count"]
    assert index["confirmatory_execution_authorized"] is False
    assert all("authorization" not in entry["response_headers"] for entry in index["entries"])
    for entry in index["entries"]:
        body = (tmp_path / "raw" / entry["response_body_path"]).read_bytes()
        assert hashlib.sha256(body).hexdigest() == entry["response_body_sha256"]
    assert hashlib.sha256(index_path.read_bytes()).hexdigest() == frame[
        "raw_response_index_sha256"
    ]

    replay_transport = frame_tool.ArchivedReplayTransport(
        index_path, research_root=ROOT / "research"
    )
    replay_frame, replay_receipt = frame_tool.collect_candidate_frame(
        research_root=ROOT / "research",
        plan_path=tmp_path / "frame-plan.json",
        exclusion_file=tmp_path / "development-contact-exclusions.txt",
        raw_archive=tmp_path / "replay-raw",
        output=tmp_path / "replayed-candidate-frame.json",
        receipt_path=tmp_path / "replayed-candidate-frame-receipt.json",
        transport=replay_transport,
    )
    assert replay_frame == frame
    assert replay_receipt["candidate_frame_sha256"] == receipt["candidate_frame_sha256"]
    assert (tmp_path / "replay-raw/response-index.json").read_bytes() == index_path.read_bytes()

    first_body = tmp_path / "replay-raw" / index["entries"][0]["response_body_path"]
    first_body.write_bytes(first_body.read_bytes() + b" ")
    with pytest.raises(frame_tool.FrameCollectionRefused, match="digest or size changed"):
        frame_tool.ArchivedReplayTransport(
            tmp_path / "replay-raw/response-index.json",
            research_root=ROOT / "research",
        )


def test_metadata_disappearance_remains_in_frame_as_screening_failure(
    tmp_path: Path,
) -> None:
    frame, receipt = _collect(tmp_path, FakeGitHub("metadata_404"))
    candidate = next(row for row in frame["candidates"] if row["github_repository_id"] == 1)
    assert candidate["metadata_status"] == "repository_metadata_unavailable"
    assert candidate["frozen_head_sha"] is None
    assert receipt["metadata_incomplete"] == 1
    assert len(frame["candidates"]) == 4


def test_composition_drift_over_one_percent_refuses_frame(tmp_path: Path) -> None:
    plan, exclusions = _inputs(tmp_path)
    with pytest.raises(frame_tool.FrameCollectionRefused, match="composition drift"):
        frame_tool.collect_candidate_frame(
            research_root=ROOT / "research",
            plan_path=plan,
            exclusion_file=exclusions,
            raw_archive=tmp_path / "raw",
            output=tmp_path / "candidate-frame.json",
            receipt_path=tmp_path / "candidate-frame-receipt.json",
            transport=FakeGitHub("drift"),
        )
    assert not (tmp_path / "candidate-frame.json").exists()
    refusal = json.loads((tmp_path / "candidate-frame-receipt.json").read_text("utf-8"))
    assert refusal["status"] == "REFUSED"
    assert refusal["confirmatory_execution_authorized"] is False
    raw_index = json.loads((tmp_path / "raw/response-index.json").read_text("utf-8"))
    assert raw_index["collection_status"] == "refused"
    assert "composition drift" in raw_index["refusal_reason"]


def test_changed_terminal_count_is_not_mistaken_for_a_complete_snapshot(
    tmp_path: Path,
) -> None:
    plan, exclusions = _inputs(tmp_path)
    with pytest.raises(frame_tool.FrameCollectionRefused, match="incomplete result"):
        frame_tool.collect_candidate_frame(
            research_root=ROOT / "research",
            plan_path=plan,
            exclusion_file=exclusions,
            raw_archive=tmp_path / "raw",
            output=tmp_path / "candidate-frame.json",
            receipt_path=tmp_path / "candidate-frame-receipt.json",
            transport=FakeGitHub("changed_count"),
        )
    raw_index = json.loads((tmp_path / "raw/response-index.json").read_text("utf-8"))
    assert raw_index["collection_status"] == "refused"


def test_unresolvable_exact_day_size_overflow_refuses_frame(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(frame_tool, "INITIAL_SIZE_SPLIT", 0)
    plan, exclusions = _inputs(tmp_path, same_day_cutoff=True)
    with pytest.raises(frame_tool.FrameCollectionRefused, match="unresolved overflow"):
        frame_tool.collect_candidate_frame(
            research_root=ROOT / "research",
            plan_path=plan,
            exclusion_file=exclusions,
            raw_archive=tmp_path / "raw",
            output=tmp_path / "candidate-frame.json",
            receipt_path=tmp_path / "candidate-frame-receipt.json",
            transport=FakeGitHub("overflow"),
        )


def test_partition_order_is_created_then_size_then_pushed(tmp_path: Path) -> None:
    plan_path, exclusions = _inputs(tmp_path)
    raw_plan = json.loads(plan_path.read_text("utf-8"))
    raw_plan["created_partition_start_date"] = "2026-08-31"
    _write_json(plan_path, raw_plan)
    plan = frame_tool.load_collection_plan(
        plan_path, research_root=ROOT / "research", exclusion_file=exclusions
    )
    archive = frame_tool.RawArchive(tmp_path / "partition-raw", plan=plan)
    collector = frame_tool.FrameCollector(
        research_root=ROOT / "research",
        plan=plan,
        archive=archive,
        transport=FakeGitHub(),
    )
    root_cell = frame_tool.SearchCell("S1", date(2026, 8, 31), date(2026, 9, 1))
    created_children = collector._split_cell(root_cell)
    assert created_children is not None
    assert [(cell.created_start, cell.created_end) for cell in created_children] == [
        (date(2026, 8, 31), date(2026, 8, 31)),
        (date(2026, 9, 1), date(2026, 9, 1)),
    ]
    size_children = collector._split_cell(created_children[0])
    assert size_children is not None
    assert (size_children[0].size_start, size_children[0].size_end) == (
        0,
        frame_tool.INITIAL_SIZE_SPLIT,
    )


@pytest.mark.parametrize("mode", ["duplicate_json", "redirect"])
def test_ambiguous_or_redirected_api_response_is_rejected(
    tmp_path: Path, mode: str
) -> None:
    plan, exclusions = _inputs(tmp_path)
    with pytest.raises(frame_tool.FrameCollectionRefused):
        frame_tool.collect_candidate_frame(
            research_root=ROOT / "research",
            plan_path=plan,
            exclusion_file=exclusions,
            raw_archive=tmp_path / "raw",
            output=tmp_path / "candidate-frame.json",
            receipt_path=tmp_path / "candidate-frame-receipt.json",
            transport=FakeGitHub(mode),
        )
    refusal = json.loads((tmp_path / "candidate-frame-receipt.json").read_text("utf-8"))
    assert refusal["status"] == "REFUSED"


def test_plan_binds_exclusions_and_publication_never_overwrites(tmp_path: Path) -> None:
    plan, exclusions = _inputs(tmp_path)
    exclusions.write_text("changed/repository\n", encoding="utf-8", newline="\n")
    with pytest.raises(frame_tool.FrameCollectionRefused, match="does not bind"):
        frame_tool.collect_candidate_frame(
            research_root=ROOT / "research",
            plan_path=plan,
            exclusion_file=exclusions,
            raw_archive=tmp_path / "raw",
            output=tmp_path / "candidate-frame.json",
            receipt_path=tmp_path / "candidate-frame-receipt.json",
            transport=FakeGitHub(),
        )

    other = tmp_path / "overwrite"
    other.mkdir()
    plan, exclusions = _inputs(other)
    (other / "candidate-frame.json").write_text("{}\n", encoding="utf-8")
    with pytest.raises(frame_tool.FrameCollectionRefused, match="overwrite"):
        frame_tool.collect_candidate_frame(
            research_root=ROOT / "research",
            plan_path=plan,
            exclusion_file=exclusions,
            raw_archive=other / "raw",
            output=other / "candidate-frame.json",
            receipt_path=other / "candidate-frame-receipt.json",
            transport=FakeGitHub(),
        )
    assert not (other / "raw").exists()

    source_case = tmp_path / "source-binding"
    source_case.mkdir()
    plan, exclusions = _inputs(source_case)
    value = json.loads(plan.read_text("utf-8"))
    value["retrieval_client_source_sha256"] = "0" * 64
    _write_json(plan, value)
    with pytest.raises(frame_tool.FrameCollectionRefused, match="collector source bytes"):
        frame_tool.collect_candidate_frame(
            research_root=ROOT / "research",
            plan_path=plan,
            exclusion_file=exclusions,
            raw_archive=source_case / "raw",
            output=source_case / "candidate-frame.json",
            receipt_path=source_case / "candidate-frame-receipt.json",
            transport=FakeGitHub(),
        )


def test_new_schemas_are_in_the_checked_catalog() -> None:
    report = validation.ValidationReport()
    catalog = validation.load_schema_catalog(ROOT / "research/schemas", report)
    assert report.errors == []
    assert frame_tool.PLAN_SCHEMA in catalog
    assert frame_tool.RAW_INDEX_SCHEMA in catalog


def test_live_cli_refuses_before_io_without_authenticated_token(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.delenv("ZERORUN_TEST_GITHUB_TOKEN", raising=False)
    result = frame_tool.main(
        [
            "--plan",
            str(tmp_path / "missing-plan.json"),
            "--development-contact-exclusions",
            str(tmp_path / "missing-exclusions.txt"),
            "--raw-archive",
            str(tmp_path / "raw"),
            "--output",
            str(tmp_path / "frame.json"),
            "--receipt",
            str(tmp_path / "receipt.json"),
            "--github-token-env",
            "ZERORUN_TEST_GITHUB_TOKEN",
        ]
    )
    assert result == 2
    assert "must contain a GitHub token" in capsys.readouterr().err
    assert not (tmp_path / "raw").exists()


def test_live_transport_paces_before_request_and_never_exposes_token(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    waits: list[float] = []
    monkeypatch.setattr(frame_tool.time, "time", lambda: 100.0)
    monkeypatch.setattr(frame_tool.time, "sleep", waits.append)

    class Response:
        status = 200
        headers = {
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": "200",
        }

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def read(self, maximum: int) -> bytes:
            assert maximum == frame_tool.MAX_RESPONSE_BYTES + 1
            return b"{}"

        def geturl(self) -> str:
            return "https://api.github.com/rate_limit"

    class Opener:
        request_headers: dict[str, str] = {}

        def open(self, request, timeout: int):
            assert timeout == 60
            self.request_headers = dict(request.header_items())
            return Response()

    transport = frame_tool.GitHubHttpTransport("top-secret-token")
    opener = Opener()
    transport._opener = opener
    transport._next_request_epoch = 105.0
    response = transport.get("https://api.github.com/rate_limit", {"Accept": "x"})

    assert waits == [5.0]
    assert response.status == 200
    assert transport._next_request_epoch == 201.0
    assert opener.request_headers["Authorization"] == "Bearer top-secret-token"
    assert "top-secret-token" not in repr(response)
