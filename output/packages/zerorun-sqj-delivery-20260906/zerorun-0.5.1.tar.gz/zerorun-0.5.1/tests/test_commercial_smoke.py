from __future__ import annotations

import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import pytest

from tools import aggregate_commercial_smoke as aggregate_tool
from tools import commercial_repo_smoke as smoke
from zerorun import mcp


ROOT = Path(__file__).resolve().parents[1]
SELECTION = ROOT / "commercial" / "corpus" / "selection-v1.json"


def _rehash(payload: dict) -> None:
    unhashed = dict(payload)
    unhashed.pop("corpus_sha256", None)
    payload["corpus_sha256"] = hashlib.sha256(smoke._canonical(unhashed)).hexdigest()


def _valid_selection(tmp_path: Path) -> dict:
    payload = json.loads(SELECTION.read_text(encoding="utf-8"))
    for row in payload["repositories"]:
        row["pushed_at"] = "2025-01-01T00:00:00Z"
    _rehash(payload)
    path = tmp_path / "valid-selection.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    return smoke.load_selection(path)


def test_valid_selection_is_exactly_100_distinct_repositories(tmp_path: Path) -> None:
    payload = _valid_selection(tmp_path)
    assert payload["artifact_role"] == "engineering_smoke_selection_only"
    assert len(payload["repositories"]) == 100
    assert len({row["repository"].casefold() for row in payload["repositories"]}) == 100
    assert all(len(row["commit"]) == 40 for row in payload["repositories"])


def test_checked_in_selection_is_digest_valid_and_inside_frozen_window() -> None:
    payload = smoke.load_selection(SELECTION)
    assert payload["corpus_sha256"] == (
        "c3ecd05a6a5432c55bac1ba3eff3f448e10b778572b1b11ab2760709d0509061"
    )
    assert payload["repository_count"] == 100


def test_selection_digest_tampering_is_rejected(tmp_path: Path) -> None:
    payload = json.loads(SELECTION.read_text(encoding="utf-8"))
    payload["repositories"][0]["commit"] = "0" * 40
    altered = tmp_path / "altered.json"
    altered.write_text(json.dumps(payload), encoding="utf-8")
    with pytest.raises(ValueError, match="digest mismatch"):
        smoke.load_selection(altered)


def test_selection_and_receipt_resource_limits_precede_json_decode(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    selection = tmp_path / "oversized-selection.json"
    selection.write_bytes(b" " * 65)
    monkeypatch.setattr(smoke, "SELECTION_FILE_LIMIT_BYTES", 64)
    monkeypatch.setattr(
        smoke.json,
        "loads",
        lambda *_args, **_kwargs: pytest.fail("unsafe JSON reached decoder"),
    )
    with pytest.raises(ValueError, match="64-byte safety limit"):
        smoke.load_selection(selection)

    receipt = tmp_path / "oversized-receipt.json"
    receipt.write_bytes(b" " * 129)
    monkeypatch.setattr(smoke, "RECEIPT_FILE_LIMIT_BYTES", 128)
    with pytest.raises(ValueError, match="128-byte safety limit"):
        smoke.load_receipt(receipt)

    nested = tmp_path / "nested-receipt.json"
    nested.write_bytes((b"[" * (smoke._JSON_MAX_DEPTH + 1)) + b"0")
    monkeypatch.setattr(smoke, "RECEIPT_FILE_LIMIT_BYTES", 1024)
    with pytest.raises(ValueError, match="JSON depth limit"):
        smoke.load_receipt(nested)

    wide = tmp_path / "wide-receipt.json"
    wide.write_text("[" + ",".join("0" for _ in range(100)) + "]", encoding="utf-8")
    monkeypatch.setattr(smoke, "_RECEIPT_MAX_MEMBERS", 1)
    with pytest.raises(ValueError, match="structural-member limit"):
        smoke.load_receipt(wide)


@pytest.mark.parametrize(
    ("pushed_at", "expected_message"),
    (
        ("2024-09-03T23:59:59Z", "outside the declared maintenance window"),
        ("2026-09-04T00:00:00Z", "outside the declared maintenance window"),
        ("2025-01-01T00:00:00+00:00", "outside the declared maintenance window"),
        (None, "outside the declared maintenance window"),
    ),
)
def test_selection_timestamp_violation_is_rejected_with_valid_digest(
    tmp_path: Path,
    pushed_at: object,
    expected_message: str,
) -> None:
    payload = json.loads(SELECTION.read_text(encoding="utf-8"))
    for row in payload["repositories"]:
        row["pushed_at"] = "2025-01-01T00:00:00Z"
    payload["repositories"][17]["pushed_at"] = pushed_at
    _rehash(payload)
    altered = tmp_path / "semantic-tampering.json"
    altered.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(ValueError, match=expected_message):
        smoke.load_selection(altered)


@pytest.mark.parametrize(
    ("mutation", "expected_message"),
    (
        (lambda payload: payload.update(artifact_role="research_result"), "artifact role"),
        (
            lambda payload: payload["frames"][0].update(stars="500..1999"),
            "declared stratum",
        ),
        (
            lambda payload: payload["frames"][0].update(query="stars:any"),
            "unexpected query",
        ),
        (
            lambda payload: payload["repositories"][0].update(
                stars_at_selection=500
            ),
            "stars do not match",
        ),
        (
            lambda payload: payload["repositories"][0].update(
                sample_rank_sha256="0" * 64
            ),
            "invalid sample rank",
        ),
        (
            lambda payload: payload["repositories"][0].update(
                planned_outcome="executed upstream tests"
            ),
            "invalid planned outcome",
        ),
    ),
)
def test_selection_semantic_tampering_is_rejected_even_with_valid_digest(
    tmp_path: Path,
    mutation,
    expected_message: str,
) -> None:
    payload = json.loads(SELECTION.read_text(encoding="utf-8"))
    mutation(payload)
    _rehash(payload)
    altered = tmp_path / "semantic-selection.json"
    altered.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(ValueError, match=expected_message):
        smoke.load_selection(altered)


def _receipts(selection: dict, *, failure_index: int | None = None) -> list[dict]:
    receipts = []
    for batch in range(10):
        rows = []
        for index, repository in enumerate(selection["repositories"]):
            if index % 10 != batch:
                continue
            row = {
                "selection_index": index,
                "repository": repository["repository"],
                "commit": repository["commit"],
                "status": "failure" if index == failure_index else "pass",
                "phase": "complete",
            }
            if index == failure_index:
                row["reason"] = "synthetic diagnostic failure"
            else:
                row.update(
                    {
                        "installed_skill_sha256": hashlib.sha256(
                            smoke._SKILL.encode("utf-8")
                        ).hexdigest(),
                        "install": {
                            "schema": "zerorun-codex-install-v5",
                            "integration_ready": True,
                            "skill": {"installed": True, "conflict": False},
                            "mcp": {"registered": True},
                        },
                        "mcp": {
                            "server": {"name": "zerorun", "version": "0.5.1"},
                            "tool_count": len(smoke._EXPECTED_TOOLS),
                            "escape_rejected": True,
                            "legacy_observe_test_rejected": True,
                            "doctor_mode": "observe-only",
                            "stats_mode": "observe-only",
                        },
                    }
                )
            rows.append(row)
        receipts.append(
            {
                "schema": smoke.RESULT_SCHEMA,
                "selection_sha256": selection["corpus_sha256"],
                "engine_version": "0.5.1",
                "engine_commit": "a" * 40,
                "codex_version": "codex-cli 0.153.3",
                "batch_index": batch,
                "batch_count": 10,
                "attempted": len(rows),
                "counts": {
                    status: sum(row["status"] == status for row in rows)
                    for status in ("pass", "safe_refusal", "failure")
                },
                "upstream_code_executed": False,
                "rows": rows,
            }
        )
    return receipts


def test_aggregate_requires_every_repository_exactly_once(tmp_path: Path) -> None:
    selection = _valid_selection(tmp_path)
    result = aggregate_tool.aggregate(selection, _receipts(selection))
    assert result["attempted_repositories"] == 100
    assert result["distinct_repositories"] == 100
    assert result["counts"] == {"pass": 100, "safe_refusal": 0, "failure": 0}
    assert result["gate_pass"] is True
    assert result["upstream_code_executed"] is False
    assert result["legacy_observe_test_rejections"] == 100
    assert result["engine_commit"] == "a" * 40

    missing = _receipts(selection)
    missing.pop()
    with pytest.raises(ValueError, match="missing batches"):
        aggregate_tool.aggregate(selection, missing)


def test_aggregate_refuses_a_self_declared_shortened_batch_protocol(
    tmp_path: Path,
) -> None:
    selection = _valid_selection(tmp_path)
    receipts = _receipts(selection)
    shortened = copy.deepcopy(receipts[0])
    shortened["batch_count"] = 1
    shortened["batch_index"] = 0
    shortened["rows"] = [
        row for receipt in receipts for row in receipt["rows"]
    ]
    shortened["attempted"] = len(shortened["rows"])
    shortened["counts"] = {
        status: sum(row["status"] == status for row in shortened["rows"])
        for status in ("pass", "safe_refusal", "failure")
    }

    with pytest.raises(ValueError, match="frozen ten-batch protocol"):
        aggregate_tool.aggregate(selection, [shortened])


def test_aggregate_preserves_failures_and_identity_checks(tmp_path: Path) -> None:
    selection = _valid_selection(tmp_path)
    failed = aggregate_tool.aggregate(selection, _receipts(selection, failure_index=7))
    assert failed["counts"]["failure"] == 1
    assert failed["gate_pass"] is False

    altered = _receipts(selection)
    altered[0] = copy.deepcopy(altered[0])
    altered[0]["rows"][0]["commit"] = "0" * 40
    with pytest.raises(ValueError, match="identity mismatch"):
        aggregate_tool.aggregate(selection, altered)


def test_aggregate_rejects_bool_aliases_for_integer_evidence(
    tmp_path: Path,
) -> None:
    selection = _valid_selection(tmp_path)

    bool_batch = _receipts(selection)
    bool_batch[0]["batch_index"] = False
    with pytest.raises(ValueError, match="batch index"):
        aggregate_tool.aggregate(selection, bool_batch)

    bool_selection = _receipts(selection)
    bool_selection[0]["rows"][0]["selection_index"] = False
    with pytest.raises(ValueError, match="selection index|wrong batch"):
        aggregate_tool.aggregate(selection, bool_selection)

    bool_attempted = _receipts(selection)
    bool_attempted[0]["attempted"] = True
    with pytest.raises(ValueError, match="attempted count"):
        aggregate_tool.aggregate(selection, bool_attempted)

    bool_counts = _receipts(selection)
    bool_counts[0]["counts"]["safe_refusal"] = False
    bool_counts[0]["counts"]["failure"] = False
    with pytest.raises(ValueError, match="outcome counts"):
        aggregate_tool.aggregate(selection, bool_counts)


def test_aggregate_requires_at_least_90_complete_integrations(tmp_path: Path) -> None:
    selection = _valid_selection(tmp_path)
    receipts = _receipts(selection)
    for receipt in receipts:
        for row in receipt["rows"]:
            if row["selection_index"] >= 89:
                row.update(
                    {
                        "status": "safe_refusal",
                        "reason": "pre-existing unmanaged skill",
                        "install": {
                            "integration_ready": False,
                            "skill": {"installed": False, "conflict": True},
                        },
                        "refusal_proof": {
                            "skill_conflict": True,
                            "unchanged": True,
                            "before": {
                                "kind": "regular_file",
                                "size": 7,
                                "sha256": "b" * 64,
                            },
                            "after": {
                                "kind": "regular_file",
                                "size": 7,
                                "sha256": "b" * 64,
                            },
                        },
                    }
                )
                row.pop("installed_skill_sha256", None)
                row.pop("mcp", None)
        receipt["counts"] = {
            status: sum(row["status"] == status for row in receipt["rows"])
            for status in ("pass", "safe_refusal", "failure")
        }

    result = aggregate_tool.aggregate(selection, receipts)
    assert result["counts"] == {"pass": 89, "safe_refusal": 11, "failure": 0}
    assert result["minimum_successful_integrations"] == 90
    assert result["gate_pass"] is False


def test_aggregate_rejects_tampered_completion_and_refusal_proofs(
    tmp_path: Path,
) -> None:
    selection = _valid_selection(tmp_path)
    pass_tampering = _receipts(selection)
    pass_tampering[0]["rows"][0]["mcp"]["escape_rejected"] = False
    with pytest.raises(ValueError, match="lacks complete Codex/MCP proof"):
        aggregate_tool.aggregate(selection, pass_tampering)

    legacy_tampering = _receipts(selection)
    legacy_tampering[0]["rows"][0]["mcp"][
        "legacy_observe_test_rejected"
    ] = False
    with pytest.raises(ValueError, match="lacks complete Codex/MCP proof"):
        aggregate_tool.aggregate(selection, legacy_tampering)

    refusal_tampering = _receipts(selection)
    row = refusal_tampering[0]["rows"][0]
    row.update(
        {
            "status": "safe_refusal",
            "reason": "pre-existing unmanaged skill",
            "install": {
                "integration_ready": False,
                "skill": {"installed": False, "conflict": True},
            },
            "refusal_proof": {
                "skill_conflict": True,
                "unchanged": True,
                "before": {"kind": "regular_file", "sha256": "b" * 64},
                "after": {"kind": "regular_file", "sha256": "c" * 64},
            },
        }
    )
    refusal_tampering[0]["counts"] = {
        status: sum(item["status"] == status for item in refusal_tampering[0]["rows"])
        for status in ("pass", "safe_refusal", "failure")
    }
    with pytest.raises(ValueError, match="lacks unchanged-conflict proof"):
        aggregate_tool.aggregate(selection, refusal_tampering)


def test_aggregate_rejects_execution_claim_and_product_identity_tampering(
    tmp_path: Path,
) -> None:
    selection = _valid_selection(tmp_path)

    executed = _receipts(selection)
    executed[0]["upstream_code_executed"] = True
    with pytest.raises(ValueError, match="remained unexecuted"):
        aggregate_tool.aggregate(selection, executed)

    mismatched = _receipts(selection)
    mismatched[4]["engine_commit"] = "b" * 40
    with pytest.raises(ValueError, match="product identity"):
        aggregate_tool.aggregate(selection, mismatched)

    reassigned = _receipts(selection)
    reassigned[0]["rows"][0]["selection_index"] = 1
    with pytest.raises(ValueError, match="wrong batch"):
        aggregate_tool.aggregate(selection, reassigned)


def test_mcp_transport_is_verified_before_any_registered_command_runs(
    monkeypatch, tmp_path: Path
) -> None:
    calls = []
    monkeypatch.setattr(
        smoke,
        "_run",
        lambda *args, **kwargs: calls.append((args, kwargs)),
    )
    registration = {
        "transport": {
            "command": str(tmp_path / "repository-controlled-zerorun"),
            "args": ["mcp-server"],
        }
    }

    with pytest.raises(ValueError, match="trusted installed ZeroRun launcher"):
        smoke._validate_mcp(
            registration,
            root=tmp_path,
            escape_root=tmp_path / "outside",
            environment={},
            expected_command=sys.executable,
        )

    assert calls == []


def _valid_mcp_response_rows(root: Path) -> list[dict]:
    return [
        {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "serverInfo": {"name": "zerorun", "version": smoke.__version__}
            },
        },
        {
            "jsonrpc": "2.0",
            "id": 2,
            "result": {
                "tools": [{"name": name} for name in sorted(smoke._EXPECTED_TOOLS)]
            },
        },
        {
            "jsonrpc": "2.0",
            "id": 3,
            "result": {
                "isError": False,
                "structuredContent": {
                    "ok": True,
                    "root": str(root.resolve()),
                    "mode": "observe-only",
                },
            },
        },
        {
            "jsonrpc": "2.0",
            "id": 4,
            "result": {
                "isError": False,
                "structuredContent": {
                    "root": str(root.resolve()),
                    "mode": "observe-only",
                },
            },
        },
        {
            "jsonrpc": "2.0",
            "id": 5,
            "result": {
                "isError": True,
                "structuredContent": {
                    "status": "ERROR",
                    "error": "refusing access outside repository",
                },
            },
        },
        {
            "jsonrpc": "2.0",
            "id": 6,
            "result": {
                "isError": True,
                "structuredContent": {
                    "status": "ERROR",
                    "error": "unknown MCP tool 'observe_test'",
                },
            },
        },
    ]


def _validate_synthetic_mcp(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    rows: list[dict],
) -> dict:
    expected_command = str(Path(sys.executable).resolve())
    monkeypatch.setattr(
        smoke,
        "_run",
        lambda *_args, **_kwargs: smoke.CommandResult(
            returncode=0,
            stdout="".join(json.dumps(row) + "\n" for row in rows),
            stderr="",
            timed_out=False,
            elapsed_ms=1.0,
        ),
    )
    return smoke._validate_mcp(
        {
            "transport": {
                "command": expected_command,
                "args": ["mcp-server"],
            }
        },
        root=tmp_path,
        escape_root=tmp_path / "outside",
        environment={},
        expected_command=expected_command,
    )


@pytest.mark.parametrize("response_id", (3, 4))
def test_mcp_success_calls_reject_is_error_true(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    response_id: int,
) -> None:
    rows = _valid_mcp_response_rows(tmp_path)
    rows[response_id - 1]["result"]["isError"] = True

    with pytest.raises(ValueError, match="reported a tool error"):
        _validate_synthetic_mcp(monkeypatch, tmp_path, rows)


def test_mcp_rejects_json_rpc_error_even_with_forged_success_result(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    rows = _valid_mcp_response_rows(tmp_path)
    rows[2]["error"] = {"code": -32000, "message": "failed"}

    with pytest.raises(ValueError, match="envelopes are malformed"):
        _validate_synthetic_mcp(monkeypatch, tmp_path, rows)


@pytest.mark.parametrize("surface_mutation", ("duplicate", "missing", "unexpected"))
def test_mcp_rejects_non_exact_tool_identity_surface(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    surface_mutation: str,
) -> None:
    rows = _valid_mcp_response_rows(tmp_path)
    tools = rows[1]["result"]["tools"]
    if surface_mutation == "duplicate":
        tools.append(dict(tools[0]))
    elif surface_mutation == "missing":
        tools.pop()
    else:
        tools[-1] = {"name": "unexpected_tool"}

    with pytest.raises(ValueError, match="tool surface"):
        _validate_synthetic_mcp(monkeypatch, tmp_path, rows)


def test_mcp_response_id_rejects_bool_alias(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    rows = _valid_mcp_response_rows(tmp_path)
    rows[0]["id"] = True

    with pytest.raises(ValueError, match="envelopes are malformed"):
        _validate_synthetic_mcp(monkeypatch, tmp_path, rows)


def test_commercial_subprocess_output_is_bounded_and_stdin_is_explicit() -> None:
    output_script = (
        "import sys\n"
        "sys.stdout.buffer.write(b'A' * 400000 + b'OUT-END')\n"
        "sys.stderr.buffer.write(b'B' * 400000 + b'ERR-END')\n"
    )
    bounded = smoke._run([sys.executable, "-c", output_script], timeout=10)
    assert bounded.returncode == 0
    assert bounded.timed_out is False
    assert len(bounded.stdout.encode("utf-8")) <= smoke.COMMERCIAL_OUTPUT_LIMIT_BYTES
    assert len(bounded.stderr.encode("utf-8")) <= smoke.COMMERCIAL_OUTPUT_LIMIT_BYTES
    assert "output truncated" in bounded.stdout
    assert "output truncated" in bounded.stderr
    assert bounded.stdout.endswith("OUT-END")
    assert bounded.stderr.endswith("ERR-END")

    request = '{"jsonrpc":"2.0","id":1}\n'
    stdin_script = "import sys; sys.stdout.buffer.write(sys.stdin.buffer.read())"
    echoed = smoke._run(
        [sys.executable, "-c", stdin_script],
        input_text=request,
        timeout=10,
    )
    assert echoed.returncode == 0
    assert echoed.stdout == request

    with pytest.raises(ValueError, match="stdin payload exceeds"):
        smoke._run(
            [sys.executable, "-c", stdin_script],
            input_text="x" * (smoke.COMMERCIAL_STDIN_LIMIT_BYTES + 1),
            timeout=10,
        )


def test_commercial_subprocess_surfaces_bounded_timeout_tail(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    completed = subprocess.CompletedProcess(
        ["command"],
        124,
        b"bounded stdout tail",
        b"bounded stderr tail",
    )
    seen: dict[str, object] = {}

    def fake_bounded(command, **kwargs):
        seen.update(command=command, **kwargs)
        return completed, True

    monkeypatch.setattr(smoke, "_run_bounded_process", fake_bounded)
    result = smoke._run(
        ["command"],
        input_text="{}\n",
        timeout=7,
        env={"SAFE": "1"},
    )

    assert result.returncode == 124
    assert result.timed_out is True
    assert result.stdout == "bounded stdout tail"
    assert result.stderr == "bounded stderr tail"
    assert seen["timeout_seconds"] == 7
    assert seen["output_limit_bytes"] == smoke.COMMERCIAL_OUTPUT_LIMIT_BYTES
    assert seen["input_bytes"] == b"{}\n"


def test_mcp_boundary_receipt_matches_real_structured_tool_error(
    monkeypatch, tmp_path: Path
) -> None:
    repository = tmp_path / "repository"
    escape = tmp_path / "escape"
    for root in (repository, escape):
        initialized = subprocess.run(
            ["git", "init", "-q", str(root)],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            timeout=10,
        )
        assert initialized.returncode == 0, initialized.stderr.decode(
            "utf-8", errors="replace"
        )
    expected_command = str(Path(sys.executable).resolve())
    registration = {
        "transport": {"command": expected_command, "args": ["mcp-server"]}
    }

    def in_process_transport(argv, *, input_text, **_kwargs):
        assert argv == [expected_command, "mcp-server"]
        previous = mcp._SERVER_ROOT
        mcp._SERVER_ROOT = repository.resolve()
        try:
            responses = [
                mcp.handle_request(json.loads(line))
                for line in input_text.splitlines()
                if line.strip()
            ]
        finally:
            mcp._SERVER_ROOT = previous
        return smoke.CommandResult(
            returncode=0,
            stdout="".join(json.dumps(row) + "\n" for row in responses),
            stderr="",
            timed_out=False,
            elapsed_ms=1.0,
        )

    monkeypatch.setattr(smoke, "_run", in_process_transport)
    result = smoke._validate_mcp(
        registration,
        root=repository,
        escape_root=escape,
        environment={},
        expected_command=expected_command,
    )

    assert result["escape_rejected"] is True
    assert result["legacy_observe_test_rejected"] is True
