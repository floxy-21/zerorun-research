from __future__ import annotations

from tools import hermetic_pytest_experiment as experiment
from tools.pytest_node_runtime_qualification import conservative_fresh_nodes


def _rows() -> dict[str, object]:
    partitions = []
    for partition in experiment.PARTITIONS:
        partitions.append(
            {
                "partition": partition.name,
                "session_changed": False,
                "session_uncertain": False,
                "candidate_source_fresh_nodes": [
                    {
                        "nodeid": f"{partition.targets[0]}::test_one",
                        "reason": "changed",
                    }
                ],
            }
        )
    return {"partitions": partitions}


def test_unchanged_collection_uses_exact_source_fresh_nodes() -> None:
    fresh, full = conservative_fresh_nodes(
        _rows(), changed_paths={"src/_pytest/example.py"}
    )
    assert full == []
    assert all(len(nodes) == 1 for nodes in fresh.values())


def test_changed_target_executes_complete_partition_fresh() -> None:
    case = _rows()
    target = experiment.PARTITIONS[0].targets[0]
    fresh, full = conservative_fresh_nodes(case, changed_paths={target})
    name = experiment.PARTITIONS[0].name
    assert name in full
    assert fresh[name] == list(experiment.PARTITIONS[0].targets)


def test_changed_static_collection_input_executes_all_partitions_fresh() -> None:
    fresh, full = conservative_fresh_nodes(
        case_row=_rows(), changed_paths={"testing/conftest.py"}
    )
    assert set(full) == {partition.name for partition in experiment.PARTITIONS}
    for partition in experiment.PARTITIONS:
        assert fresh[partition.name] == list(partition.targets)


def test_changed_shared_session_executes_partition_fresh() -> None:
    case = _rows()
    case["partitions"][1]["session_changed"] = True
    fresh, full = conservative_fresh_nodes(case, changed_paths=set())
    partition = experiment.PARTITIONS[1]
    assert partition.name in full
    assert fresh[partition.name] == list(partition.targets)
