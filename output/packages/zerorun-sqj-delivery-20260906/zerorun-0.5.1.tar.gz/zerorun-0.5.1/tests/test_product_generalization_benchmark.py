from __future__ import annotations

import copy
import hashlib
import os
import stat
import subprocess
from pathlib import Path

import pytest

from tools import product_generalization_benchmark as benchmark
from zerorun.model import ConfigurationError


def test_candidate_refusal_summary_retains_complete_counted_causes() -> None:
    payload = {
        "nodes": {
            "a": {"fresh_required": True, "reason": "session import unresolved"},
            "b": {"fresh_required": True, "reason": "dynamic import"},
            "c": {"fresh_required": True, "reason": "session import unresolved"},
            "d": {"fresh_required": False, "reviewable": True},
        }
    }
    original = copy.deepcopy(payload)

    result = benchmark._candidate_fresh_reason_summary(payload)

    assert result["fresh_required_nodes"] == benchmark._candidate_counts(payload)[2] == 3
    assert result["complete_reason_labels"] is True
    assert result["nodes_with_unspecified_reason"] == 0
    assert result["histogram"] == [
        {"count": 2, "reason": "session import unresolved"},
        {"count": 1, "reason": "dynamic import"},
    ]
    assert payload == original


def test_candidate_refusal_summary_exposes_missing_labels_without_losing_nodes() -> None:
    result = benchmark._candidate_fresh_reason_summary(
        {"nodes": {"a": {"fresh_required": True}, "b": {"fresh_required": True, "reason": ""}}}
    )
    assert result["fresh_required_nodes"] == 2
    assert result["nodes_with_unspecified_reason"] == 2
    assert result["complete_reason_labels"] is False
    assert result["histogram"] == [{"count": 2, "reason": "<reason not recorded>"}]


@pytest.mark.parametrize(
    "payload",
    [
        {"nodes": []},
        {"nodes": {"a": None}},
        {"nodes": {"a": {"fresh_required": True, "reason": 7}}},
        {"nodes": {"a": {"fresh_required": True, "reason": "x" * 8193}}},
    ],
)
def test_candidate_refusal_summary_rejects_malformed_evidence(payload: dict) -> None:
    with pytest.raises(ConfigurationError, match="candidate refusal"):
        benchmark._candidate_fresh_reason_summary(payload)


def test_live_generalization_runtime_is_exact_cpython_31214() -> None:
    assert benchmark.GENERALIZATION_RUNTIME_IMAGE == (
        "docker.io/library/python@sha256:"
        "9c47360a2a0355e2da18516d0b1c2126ec22c195d2185e97347c9d98398c5bef"
    )
    assert benchmark.GENERALIZATION_RUNTIME_IMPLEMENTATION == "CPython"
    assert benchmark.GENERALIZATION_RUNTIME_PYTHON_VERSION == "3.12.14"


def test_live_generalization_rejects_any_other_runtime_digest(tmp_path: Path) -> None:
    (tmp_path / ".git").mkdir()

    with pytest.raises(ConfigurationError, match="exact official CPython 3.12.14"):
        benchmark._benchmark_once(
            tmp_path,
            workload="fixture",
            upstream_repo="example/fixture",
            frozen_sha="1" * 40,
            targets=("tests/test_fixture.py",),
            extra_requirements=(),
            runtime_image="docker.io/library/python@sha256:" + "0" * 64,
            case_count=20,
            min_compute=5.0,
            min_p95_reduction=50.0,
            engine_sha="3" * 40,
            holdout_class="old-regression",
        )


def _shadow_payload(*, outcome: str = "passed") -> dict[str, object]:
    nodeids = ["tests/test_fixture.py::test_one"]
    canonical = benchmark.json.dumps(
        {"nodeids": nodeids},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    return {
        "schema": "zerorun.benchmark-independent-pytest-shadow.v1",
        "exit_code": 0 if outcome != "failed" else 1,
        "nodeids": nodeids,
        "nodeid_sha256": benchmark.hashlib.sha256(canonical).hexdigest(),
        "outcomes": [
            {
                "setup": "passed",
                "call": outcome,
                "teardown": "passed",
                "wasxfail": False,
            }
        ],
    }


def _collection_snapshot_payload(
    *,
    profile_sha256: str = "1" * 64,
) -> dict[str, object]:
    nodeids = ["tests/test_fixture.py::test_one"]
    items = [{"nodeid": nodeids[0], "identity_sha256": "2" * 64}]
    invocation = {
        "rootpath": ".",
        "args": ["tests/test_fixture.py"],
        "pyargs": False,
        "addopts": ["-p", "no:cacheprovider"],
    }
    canonical = benchmark.json.dumps(
        {"invocation": invocation, "items": items, "nodeids": nodeids},
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return {
        "schema": 2,
        "profile_sha256": profile_sha256,
        "collection": {
            "invocation": invocation,
            "items": items,
            "nodeids": nodeids,
            "collection_sha256": benchmark.hashlib.sha256(canonical).hexdigest(),
        },
        "collection_guard_sha256": "3" * 64,
        "provenance": {"mac": "4" * 64},
    }


def test_product_collection_snapshot_accepts_current_signed_schema_two(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    state = tmp_path / ".zerorun"
    state.mkdir()
    snapshot = _collection_snapshot_payload()
    (state / "pytest-collection-v1.json").write_text(
        benchmark.json.dumps(snapshot), encoding="utf-8"
    )
    manifest = object()
    monkeypatch.setattr(benchmark, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(benchmark, "manifest_sha256", lambda value: "5" * 64)
    trusted_calls: list[dict[str, object]] = []

    def trusted(_root: Path, payload: dict[str, object], **bindings: object) -> bool:
        trusted_calls.append({"payload": payload, **bindings})
        return True

    monkeypatch.setattr(benchmark, "cache_payload_is_trusted", trusted)

    assert benchmark._product_collection_snapshot(
        tmp_path, "1" * 64, ("tests/test_fixture.py",)
    ) == {
        "nodeids": ["tests/test_fixture.py::test_one"],
        "collection_sha256": snapshot["collection"]["collection_sha256"],
    }
    assert trusted_calls == [
        {
            "payload": snapshot,
            "manifest_digest": "5" * 64,
            "profile_digest": "1" * 64,
        }
    ]


def test_product_collection_snapshot_rejects_untrusted_or_tampered_schema_two(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    state = tmp_path / ".zerorun"
    state.mkdir()
    path = state / "pytest-collection-v1.json"
    manifest = object()
    monkeypatch.setattr(benchmark, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(benchmark, "manifest_sha256", lambda value: "5" * 64)
    monkeypatch.setattr(benchmark, "cache_payload_is_trusted", lambda *a, **k: False)
    path.write_text(
        benchmark.json.dumps(_collection_snapshot_payload()), encoding="utf-8"
    )
    with pytest.raises(ConfigurationError, match="invalid provenance"):
        benchmark._product_collection_snapshot(
            tmp_path, "1" * 64, ("tests/test_fixture.py",)
        )

    monkeypatch.setattr(benchmark, "cache_payload_is_trusted", lambda *a, **k: True)
    tampered = _collection_snapshot_payload()
    tampered["collection"]["nodeids"] = ["tests/test_fixture.py::test_other"]
    tampered["collection"]["items"][0]["nodeid"] = (
        "tests/test_fixture.py::test_other"
    )
    path.write_text(benchmark.json.dumps(tampered), encoding="utf-8")
    with pytest.raises(ConfigurationError, match="digest mismatch"):
        benchmark._product_collection_snapshot(
            tmp_path, "1" * 64, ("tests/test_fixture.py",)
        )


def test_counterbalanced_schedule_is_deterministic_and_complete() -> None:
    first = benchmark._trajectory_schedule(
        workload="fixture",
        frozen_sha="1" * 40,
        targets=("tests/test_fixture.py",),
    )
    second = benchmark._trajectory_schedule(
        workload="fixture",
        frozen_sha="1" * 40,
        targets=("tests/test_fixture.py",),
    )

    assert first == second
    assert first["counterbalance_complete"] is True
    assert set(first["execution_order"]) == {
        "plain-then-zerorun",
        "zerorun-then-plain",
    }
    assert len(first["seed_sha256"]) == 64


def test_shadow_evidence_validates_each_node_and_rejects_forged_digest() -> None:
    payload = _shadow_payload()
    validated = benchmark._validate_shadow_evidence(payload)
    assert validated["complete_per_node_outcomes"] is True
    assert validated["all_nodes_non_failing"] is True
    assert validated["failing_nodeids"] == []

    forged = copy.deepcopy(payload)
    forged["nodeid_sha256"] = "0" * 64
    with pytest.raises(ConfigurationError, match="digest mismatch"):
        benchmark._validate_shadow_evidence(forged)


def test_shadow_failure_invalidates_every_reuse_bearing_comparison() -> None:
    payload = benchmark._validate_shadow_evidence(_shadow_payload(outcome="failed"))
    shadow = {
        **payload,
        "node_count": 1,
    }
    comparison = benchmark._comparison_evidence(
        direct={"exit_code": 1},
        product={
            "exit_code": 1,
            "reused_nodes": 1,
            "total_nodes": 1,
            "collection_sha256": "2" * 64,
        },
        shadow=shadow,
        snapshot={
            "nodeids": ["tests/test_fixture.py::test_one"],
            "collection_sha256": "2" * 64,
        },
        snapshot_error=None,
    )

    assert comparison["all_exit_codes_match"] is True
    assert comparison["exact_node_sequence_match"] is True
    assert comparison["reuse_shadow_valid"] is False
    assert comparison["reused_node_fresh_shadow_coverage"] == 0
    assert comparison["reused_node_fresh_shadow_denominator"] == 1
    assert comparison["comparison_pass"] is False


@pytest.mark.parametrize(
    "product",
    [
        {
            "profile_refresh_required": True,
            "reused_nodes": 1,
            "published_nodes": 0,
        },
        {
            "profile_refresh_required": True,
            "reused_nodes": 0,
            "published_nodes": 1,
        },
    ],
)
def test_refresh_required_must_be_fresh_and_publish_nothing(
    product: dict[str, object],
) -> None:
    assert benchmark._refresh_signal_fail_closed(product) is False
    assert (
        benchmark._refresh_signal_fail_closed(
            {
                "profile_refresh_required": True,
                "reused_nodes": 0,
                "published_nodes": 0,
            }
        )
        is True
    )


@pytest.mark.parametrize(
    "product",
    [
        {
            "reused_nodes": -1,
            "fresh_nodes": 2,
            "unknown_nodes": 0,
            "total_nodes": 1,
            "published_nodes": 0,
        },
        {
            "reused_nodes": 1,
            "fresh_nodes": 1,
            "unknown_nodes": 0,
            "total_nodes": 3,
            "published_nodes": 0,
        },
        {
            "reused_nodes": 0,
            "fresh_nodes": 1,
            "unknown_nodes": 2,
            "total_nodes": 1,
            "published_nodes": 0,
        },
        {
            "reused_nodes": 0,
            "fresh_nodes": 1,
            "unknown_nodes": 0,
            "total_nodes": 1,
            "published_nodes": 2,
        },
    ],
)
def test_product_node_counts_must_be_nonnegative_and_reconcile(
    product: dict[str, object],
) -> None:
    with pytest.raises(ConfigurationError, match="nodes|node counts|nonnegative"):
        benchmark._validated_product_node_counts(product)


def test_plain_pytest_arm_uses_no_zerorun_execution_or_selection_plugin(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    (tmp_path / ".git").mkdir()
    container_id = "a" * 64
    runtime_image = "python@sha256:" + "b" * 64
    commands: list[list[str]] = []
    inspections = iter(
        (
            (
                container_id,
                "/zerorun-independent-pytest-fixed",
                runtime_image,
                {"Status": "created", "Running": False},
            ),
            (
                container_id,
                "/zerorun-independent-pytest-fixed",
                runtime_image,
                {"Status": "exited", "Running": False, "ExitCode": 0},
            ),
        )
    )

    def run(root, argv, **kwargs):
        command = list(argv)
        commands.append(command)
        if command[1] == "create":
            return subprocess.CompletedProcess(command, 0, container_id + "\n", "")
        return subprocess.CompletedProcess(command, 0, "", "")

    monkeypatch.setattr(benchmark, "_host_executable", lambda *args: "/usr/bin/docker")
    monkeypatch.setattr(benchmark, "_plain_exact_container_ids", lambda *args: [])
    monkeypatch.setattr(benchmark.secrets, "token_hex", lambda size: "fixed")
    monkeypatch.setattr(benchmark, "_plain_run", run)
    monkeypatch.setattr(
        benchmark, "_plain_inspect_container", lambda *args: next(inspections)
    )
    monkeypatch.setattr(
        benchmark, "_plain_confirm_container_absent", lambda *args: True
    )

    result = benchmark._direct_once(
        tmp_path,
        targets=("tests/test_fixture.py",),
        runtime_image=runtime_image,
    )

    create = next(command for command in commands if command[1] == "create")
    image_index = create.index(runtime_image)
    assert create[image_index + 1 :] == [
        "/usr/local/bin/python",
        "-m",
        "pytest",
        "-p",
        "no:cacheprovider",
        "tests/test_fixture.py",
    ]
    assert "benchmark_shadow_plugin" not in create
    assert "zerorun_single_pass_plugin" not in create
    assert (tmp_path / ".zerorun").is_dir()
    assert result["runner"] == "independent-docker-plain-pytest"
    assert result["instrumented"] is False


def test_plain_pytest_state_mountpoint_rejects_file_or_link(
    tmp_path: Path,
) -> None:
    state = tmp_path / ".zerorun"
    state.write_text("not a directory", encoding="utf-8")
    with pytest.raises(ConfigurationError, match="not an exact ordinary directory"):
        benchmark._ensure_plain_state_mountpoint(tmp_path)
    state.unlink()

    outside = tmp_path / "outside"
    outside.mkdir()
    try:
        state.symlink_to(outside, target_is_directory=True)
    except OSError as exc:
        pytest.skip(f"directory symlinks are unavailable: {exc}")
    with pytest.raises(ConfigurationError, match="not an exact ordinary directory"):
        benchmark._ensure_plain_state_mountpoint(tmp_path)
    assert state.is_symlink()


def test_adverse_changed_source_stale_success_fails_closed(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    target = tmp_path / "tests" / "test_fixture.py"
    target.parent.mkdir()
    original = b"def test_ok():\n    assert True\n"
    target.write_bytes(original)
    monkeypatch.setattr(
        benchmark,
        "_safe_direct_once",
        lambda *args, **kwargs: {"exit_code": 2, "wall_ms": 1.0},
    )
    monkeypatch.setattr(
        benchmark,
        "_safe_product_once",
        lambda *args, **kwargs: {
            "exit_code": 0,
            "benchmark_outer_wall_ms": 1.0,
        },
    )
    monkeypatch.setattr(
        benchmark,
        "_safe_shadow_once",
        lambda *args, **kwargs: {"exit_code": 2, "wall_ms": 1.0},
    )

    def restore(*args, **kwargs):
        target.write_bytes(original)

    monkeypatch.setattr(benchmark, "_checkout", restore)

    result = benchmark._adverse_collection_failure_audit(
        tmp_path,
        git="/usr/bin/git",
        frozen_sha="1" * 40,
        targets=("tests/test_fixture.py",),
        runtime_image="python@sha256:" + "2" * 64,
        order="plain-then-zerorun",
    )

    assert result["pass"] is False
    assert result["zerorun_stale_success"] is True
    assert result["source_restored_to_frozen_bytes"] is True
    assert target.read_bytes() == original


def test_adverse_collection_failure_requires_zero_reuse_publication_and_unchanged_cache(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    target = tmp_path / "tests" / "test_fixture.py"
    target.parent.mkdir()
    original = b"def test_ok():\n    assert True\n"
    target.write_bytes(original)
    monkeypatch.setattr(
        benchmark,
        "_safe_direct_once",
        lambda *args, **kwargs: {"exit_code": 2, "wall_ms": 1.0},
    )
    product = {
        "exit_code": 2,
        "benchmark_outer_wall_ms": 1.0,
        "status": "PYTEST_INCREMENTAL_FAIL",
        "reused_nodes": 0,
        "fresh_nodes": 0,
        "unknown_nodes": 0,
        "total_nodes": 0,
        "published_nodes": 0,
        "reuse_authorized": False,
        "profile_refresh_required": False,
        "profile_refresh_reasons": [],
    }
    monkeypatch.setattr(
        benchmark, "_safe_product_once", lambda *args, **kwargs: dict(product)
    )
    monkeypatch.setattr(
        benchmark,
        "_safe_shadow_once",
        lambda *args, **kwargs: {"exit_code": 2, "wall_ms": 1.0},
    )

    def restore(*args, **kwargs):
        target.write_bytes(original)

    monkeypatch.setattr(benchmark, "_checkout", restore)
    result = benchmark._adverse_collection_failure_audit(
        tmp_path,
        git="/usr/bin/git",
        frozen_sha="1" * 40,
        targets=("tests/test_fixture.py",),
        runtime_image="python@sha256:" + "2" * 64,
        order="zerorun-then-plain",
    )

    assert result["pass"] is True
    assert result["fail_closed_refusal_semantics"] is True
    assert result["cache_publication_state_unchanged"] is True
    assert result["zerorun_reused_nodes"] == 0
    assert result["zerorun_published_nodes"] == 0


@pytest.mark.parametrize(
    ("case_count", "min_compute", "min_p95", "message"),
    [
        (19, 5.0, 50.0, "exactly 20 transitions"),
        (20, 4.999, 50.0, "cannot be lowered"),
        (20, 5.0, 49.999, "cannot be lowered"),
    ],
)
def test_frozen_protocol_rejects_smaller_horizon_or_lower_gate(
    tmp_path: Path,
    case_count: int,
    min_compute: float,
    min_p95: float,
    message: str,
) -> None:
    (tmp_path / ".git").mkdir()
    with pytest.raises(ConfigurationError, match=message):
        benchmark._benchmark_once(
            tmp_path,
            workload="fixture",
            upstream_repo="example/fixture",
            frozen_sha="1" * 40,
            targets=("tests/test_fixture.py",),
            extra_requirements=(),
            runtime_image="python@sha256:" + "2" * 64,
            case_count=case_count,
            min_compute=min_compute,
            min_p95_reduction=min_p95,
            engine_sha="3" * 40,
            holdout_class="old-regression",
        )


def test_benchmark_rejects_plain_and_zerorun_resource_envelope_drift(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    (tmp_path / ".git").mkdir()
    monkeypatch.setattr(benchmark, "DOCKER_RESOURCE_ARGS", ("--cpus", "99"))

    with pytest.raises(ConfigurationError, match="resource envelopes differ"):
        benchmark._benchmark_once(
            tmp_path,
            workload="fixture",
            upstream_repo="example/fixture",
            frozen_sha="1" * 40,
            targets=("tests/test_fixture.py",),
            extra_requirements=(),
            runtime_image="python@sha256:" + "2" * 64,
            case_count=20,
            min_compute=5.0,
            min_p95_reduction=50.0,
            engine_sha="3" * 40,
            holdout_class="old-regression",
        )


def test_primary_cost_ledger_is_complete_finite_nonnegative_and_reconciled() -> None:
    ledger: dict[str, object] = {
        "symmetric_environment_bootstrap_charged_to_each_arm": 100.0,
        "direct_seed_charged_to_direct": 20.0,
        "zerorun_qualification_charged_to_zerorun": 30.0,
        "zerorun_activation_charged_to_zerorun": 4.0,
        "zerorun_seed_charged_to_zerorun": 10.0,
        "automatic_refresh_charged_to_zerorun": 0.0,
    }

    validated, direct_overhead, zerorun_overhead = (
        benchmark._validate_primary_cost_ledger(ledger)
    )

    assert tuple(validated) == benchmark._PRIMARY_COST_LEDGER_KEYS
    assert direct_overhead == 120.0
    assert zerorun_overhead == 144.0


@pytest.mark.parametrize("missing_key", benchmark._PRIMARY_COST_LEDGER_KEYS)
def test_primary_cost_ledger_fails_closed_if_any_charge_is_omitted(
    missing_key: str,
) -> None:
    ledger: dict[str, object] = {
        "symmetric_environment_bootstrap_charged_to_each_arm": 100.0,
        "direct_seed_charged_to_direct": 20.0,
        "zerorun_qualification_charged_to_zerorun": 30.0,
        "zerorun_activation_charged_to_zerorun": 4.0,
        "zerorun_seed_charged_to_zerorun": 10.0,
        "automatic_refresh_charged_to_zerorun": 0.0,
    }
    del ledger[missing_key]

    with pytest.raises(ConfigurationError, match="wrong components"):
        benchmark._validate_primary_cost_ledger(ledger)


@pytest.mark.parametrize(
    ("key", "invalid", "message"),
    [
        ("symmetric_environment_bootstrap_charged_to_each_arm", -1.0, "invalid"),
        ("zerorun_qualification_charged_to_zerorun", -0.001, "invalid"),
        ("zerorun_activation_charged_to_zerorun", float("nan"), "invalid"),
        ("direct_seed_charged_to_direct", float("inf"), "invalid"),
        ("zerorun_seed_charged_to_zerorun", -1.0, "invalid"),
        ("automatic_refresh_charged_to_zerorun", float("inf"), "invalid"),
        ("automatic_refresh_charged_to_zerorun", False, "not numeric"),
    ],
)
def test_primary_cost_ledger_fails_closed_on_invalid_charge(
    key: str,
    invalid: object,
    message: str,
) -> None:
    ledger: dict[str, object] = {
        "symmetric_environment_bootstrap_charged_to_each_arm": 100.0,
        "direct_seed_charged_to_direct": 20.0,
        "zerorun_qualification_charged_to_zerorun": 30.0,
        "zerorun_activation_charged_to_zerorun": 4.0,
        "zerorun_seed_charged_to_zerorun": 10.0,
        "automatic_refresh_charged_to_zerorun": 0.0,
    }
    ledger[key] = invalid

    with pytest.raises(ConfigurationError, match=message):
        benchmark._validate_primary_cost_ledger(ledger)


def test_layer_cleanup_charge_recomputes_rows_p95_and_gate_without_bias() -> None:
    rows = [
        {
            "direct_ms": 100.0,
            "zerorun_ms": 19.0,
            "primary_end_to_end_plain_pytest_ms": 100.0,
            "primary_end_to_end_zerorun_ms": 19.0,
            "direct_phase_ms": {
                "amortized_environment_and_direct_seed": 0.0,
                "primary_end_to_end_paired_total": 100.0,
            },
            "zerorun_timing_ms": {
                "amortized_environment_qualification_activation_and_seed": 0.0,
                "primary_end_to_end_paired_total": 19.0,
            },
        }
        for _ in range(20)
    ]
    result = {
        "case_count": 20,
        "rows": rows,
        "cost_ledger_ms": {
            "symmetric_environment_bootstrap_charged_to_each_arm": 0.0,
            "direct_seed_charged_to_direct": 0.0,
            "zerorun_qualification_charged_to_zerorun": 0.0,
            "zerorun_activation_charged_to_zerorun": 0.0,
            "zerorun_seed_charged_to_zerorun": 0.0,
            "automatic_refresh_charged_to_zerorun": 0.0,
        },
        "primary_cost_accounting": {},
        "frozen_dependency_layer": {
            "build_once_ms": 0.0,
            "timing_ms": {
                "build_once": 0.0,
                "total_charged_symmetrically_to_each_arm": 0.0,
            },
        },
        "safety_pass": True,
        "reference_gate": {
            "min_compute_efficiency": 5.0,
            "min_p95_reduction_percent": 50.0,
        },
        "performance_gate_pass": True,
    }

    charged = benchmark._charge_dependency_layer_post_use_cleanup(
        result,
        {
            "schema": "zerorun.dependency-layer-post-use-cleanup.v1",
            "final_integrity_verification_ms": 40.0,
            "private_layer_teardown_ms": 60.0,
            "total_ms": 100.0,
            "final_integrity_verified": True,
            "cleanup_confirmed": True,
        },
    )

    assert charged["rows"][0]["direct_ms"] == 105.0
    assert charged["rows"][0]["zerorun_ms"] == 24.0
    assert charged["direct_total_ms"] == 2100.0
    assert charged["zerorun_total_ms"] == 480.0
    assert charged["direct_p95_ms"] == 105.0
    assert charged["zerorun_p95_ms"] == 24.0
    assert charged["cost_ledger_ms"][
        "symmetric_environment_bootstrap_charged_to_each_arm"
    ] == 100.0
    assert charged["end_to_end_plain_pytest_to_zerorun_speedup"] == 4.375
    assert charged["performance_gate_pass"] is False


def test_dependency_layer_identity_binds_every_construction_input(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    requirements = {"size": 17, "sha256": "1" * 64}

    def identity(*, image: str, extras: tuple[str, ...] = ()) -> str:
        return str(
            benchmark._dependency_layer_construction_identity(
                runtime_image=image,
                extra_requirements=extras,
                runtime_requirements=requirements,
            )["construction_identity_sha256"]
        )

    baseline = identity(image="python@sha256:" + "2" * 64)
    assert identity(image="python@sha256:" + "3" * 64) != baseline
    assert identity(
        image="python@sha256:" + "2" * 64,
        extras=("pretend",),
    ) != baseline
    changed_requirements = dict(requirements, sha256="4" * 64)
    assert (
        benchmark._dependency_layer_construction_identity(
            runtime_image="python@sha256:" + "2" * 64,
            extra_requirements=(),
            runtime_requirements=changed_requirements,
        )["construction_identity_sha256"]
        != baseline
    )
    monkeypatch.setattr(
        benchmark,
        "_RUNTIME_INSTALL_BOOTSTRAP",
        benchmark._RUNTIME_INSTALL_BOOTSTRAP + ";pass",
    )
    assert identity(image="python@sha256:" + "2" * 64) != baseline


def test_dependency_tree_rejects_links_hardlinks_and_special_files(
    tmp_path: Path,
) -> None:
    tree = tmp_path / "layer"
    tree.mkdir()
    ordinary = tree / "ordinary.py"
    ordinary.write_bytes(b"value = 1\n")

    hardlink = tree / "hardlink.py"
    try:
        os.link(ordinary, hardlink)
    except OSError as exc:
        pytest.skip(f"hardlinks unavailable on this filesystem: {exc}")
    with pytest.raises(ConfigurationError, match="singly linked|multiply referenced"):
        benchmark._dependency_tree_snapshot(tree, require_read_only=False)
    hardlink.unlink()

    link = tree / "linked.py"
    try:
        link.symlink_to(ordinary)
    except OSError as exc:
        pytest.skip(f"symlinks unavailable on this filesystem: {exc}")
    with pytest.raises(ConfigurationError, match="links or reparse points"):
        benchmark._dependency_tree_snapshot(tree, require_read_only=False)
    link.unlink()

    if os.name != "nt":
        fifo = tree / "fifo"
        os.mkfifo(fifo)
        with pytest.raises(ConfigurationError, match="nonregular"):
            benchmark._dependency_tree_snapshot(tree, require_read_only=False)


def test_dependency_two_pass_barrier_detects_content_race(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    tree = tmp_path / "layer"
    tree.mkdir()
    target = tree / "package.py"
    target.write_bytes(b"before\n")
    original = benchmark._dependency_tree_snapshot
    calls = 0

    def racing_snapshot(*args, **kwargs):
        nonlocal calls
        snapshot = original(*args, **kwargs)
        calls += 1
        if calls == 1:
            target.write_bytes(b"after!\n")
        return snapshot

    monkeypatch.setattr(benchmark, "_dependency_tree_snapshot", racing_snapshot)
    with pytest.raises(ConfigurationError, match="two-pass race barrier.*mismatch"):
        benchmark._stable_dependency_tree_snapshot(
            tree,
            require_read_only=False,
        )


def test_frozen_layer_builds_once_and_materializes_two_private_verified_copies(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    runtime_image = "python@sha256:" + "a" * 64
    requirements = benchmark.GENERALIZATION_RUNTIME_REQUIREMENTS.read_bytes()
    requirements_sha256 = hashlib.sha256(requirements).hexdigest()
    build_calls = 0

    def fake_build(
        builder: Path,
        *,
        runtime_image: str,
        extra_requirements: tuple[str, ...],
    ) -> str:
        nonlocal build_calls
        build_calls += 1
        environment = builder / ".zerorun-env"
        (environment / "site-packages" / "fixture").mkdir(parents=True)
        (environment / "bin").mkdir()
        (environment / "runtime-requirements.txt").write_bytes(requirements)
        (environment / "site-packages" / "fixture" / "__init__.py").write_bytes(
            b"VERSION = '1'\n"
        )
        (environment / "bin" / "python").write_bytes(
            benchmark._RUNTIME_WRAPPER_BYTES
        )
        os.chmod(environment / "bin" / "python", 0o755)
        (builder / ".zerorun.json").write_text("{}\n", encoding="utf-8")
        return requirements_sha256

    monkeypatch.setattr(benchmark, "_build_frozen_pytest_environment", fake_build)
    materializations: list[dict[str, object]] = []
    layer_workspace: Path | None = None
    layer_file_ids: set[tuple[int, int]] = set()
    copy_file_ids: list[set[tuple[int, int]]] = []

    with benchmark._frozen_dependency_layer(
        tmp_path,
        runtime_image=runtime_image,
        extra_requirements=(),
    ) as layer:
        layer_root = Path(layer["root"])
        layer_workspace = layer_root.parent
        assert layer_root.name == layer["snapshot"]["tree_sha256"]
        assert layer["provenance"]["build_count"] == 1
        layer_file_ids = set(layer["snapshot"]["_file_identities"].values())
        for index in (1, 2):
            trajectory = tmp_path / f"trajectory-{index}"
            trajectory.mkdir()
            result = benchmark._materialize_frozen_pytest_environment(
                trajectory,
                dependency_layer=layer,
                runtime_image=runtime_image,
                extra_requirements=(),
            )
            materializations.append(result)
            copied = benchmark._stable_dependency_tree_snapshot(
                trajectory / ".zerorun-env",
                require_read_only=True,
            )
            copy_file_ids.append(set(copied["_file_identities"].values()))
            assert copied["tree_sha256"] == layer["snapshot"]["tree_sha256"]
            assert result["private_byte_copy"] is True
            assert result["shared_hardlinks"] is False
            assert result["read_only_mode_and_content_verified"] is True

    assert build_calls == 1
    assert len(materializations) == 2
    assert layer_file_ids.isdisjoint(copy_file_ids[0])
    assert layer_file_ids.isdisjoint(copy_file_ids[1])
    assert copy_file_ids[0].isdisjoint(copy_file_ids[1])
    assert layer_workspace is not None and not layer_workspace.exists()
    assert layer["post_use_cleanup"]["final_integrity_verified"] is True
    assert layer["post_use_cleanup"]["cleanup_confirmed"] is True
    assert layer["post_use_cleanup"]["total_ms"] >= 0.0

    for index in (1, 2):
        trajectory = tmp_path / f"trajectory-{index}"
        snapshot = benchmark._dependency_tree_snapshot(
            trajectory / ".zerorun-env",
            require_read_only=True,
        )
        assert all(int(row["mode"]) & 0o222 == 0 for row in snapshot["files"])
        assert all(
            int(row["mode"]) & 0o222 == 0 for row in snapshot["directories"]
        )
        benchmark._clean_zerorun_state(trajectory)
        assert not (trajectory / ".zerorun-env").exists()


def test_private_materialization_fails_closed_on_digest_or_mode_drift(
    tmp_path: Path,
) -> None:
    source = tmp_path / "source"
    source.mkdir()
    package = source / "package.py"
    package.write_bytes(b"before\n")
    expected = benchmark._freeze_dependency_tree(source)
    mode = stat.S_IMODE(package.lstat().st_mode)
    os.chmod(package, mode | stat.S_IWUSR)
    package.write_bytes(b"after!\n")
    os.chmod(package, mode)

    with pytest.raises(ConfigurationError, match="mode/content digest mismatch"):
        benchmark._copy_frozen_dependency_tree(
            source,
            tmp_path / "destination",
            expected=expected,
        )
    assert not (tmp_path / "destination").exists()

    os.chmod(package, mode | stat.S_IWUSR)
    with pytest.raises(ConfigurationError, match="file is writable"):
        benchmark._copy_frozen_dependency_tree(
            source,
            tmp_path / "mode-drift-destination",
            expected=expected,
        )
    assert not (tmp_path / "mode-drift-destination").exists()


def test_private_dependency_cleanup_requires_confirmed_absence(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    workspace = tmp_path / "private-layer"
    workspace.mkdir()
    (workspace / "ordinary").write_bytes(b"content")
    real_remove = benchmark._remove_plain_path_secure
    try:
        monkeypatch.setattr(
            benchmark,
            "_remove_plain_path_secure",
            lambda *args, **kwargs: None,
        )
        with pytest.raises(ConfigurationError, match="cleanup was not confirmed"):
            benchmark._remove_private_dependency_workspace(workspace)
    finally:
        monkeypatch.setattr(benchmark, "_remove_plain_path_secure", real_remove)
        real_remove(workspace)


def test_private_dependency_cleanup_rejects_hardlinks_without_touching_source(
    tmp_path: Path,
) -> None:
    outside = tmp_path / "outside"
    outside.write_bytes(b"must survive")
    workspace = tmp_path / "private-layer"
    workspace.mkdir()
    linked = workspace / "linked"
    try:
        os.link(outside, linked)
    except OSError as exc:
        pytest.skip(f"hardlinks unavailable on this filesystem: {exc}")

    with pytest.raises(ConfigurationError, match="multiply linked"):
        benchmark._remove_private_dependency_workspace(workspace)

    assert outside.read_bytes() == b"must survive"
    assert linked.exists()
    linked.unlink()
    workspace.rmdir()


@pytest.mark.skipif(
    not benchmark._posix_fd_cleanup_supported(),
    reason="descriptor-relative cleanup is POSIX-only",
)
def test_descriptor_relative_cleanup_detects_last_moment_file_swap(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    workspace = tmp_path / "private-layer"
    workspace.mkdir()
    victim = workspace / "victim"
    victim.write_bytes(b"validated inode")
    real_unlink = os.unlink
    raced = False

    def swap_then_unlink(path, *args, dir_fd=None, **kwargs):
        nonlocal raced
        if dir_fd is not None and path == "victim" and not raced:
            raced = True
            os.rename(
                "victim",
                "moved",
                src_dir_fd=dir_fd,
                dst_dir_fd=dir_fd,
            )
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
            descriptor = os.open("victim", flags, 0o600, dir_fd=dir_fd)
            try:
                os.write(descriptor, b"replacement")
            finally:
                os.close(descriptor)
        return real_unlink(path, *args, dir_fd=dir_fd, **kwargs)

    monkeypatch.setattr(benchmark.os, "unlink", swap_then_unlink)
    with pytest.raises(ConfigurationError, match="replacement raced cleanup"):
        benchmark._remove_private_dependency_workspace(workspace)

    assert raced is True
    assert (workspace / "moved").read_bytes() == b"validated inode"
    monkeypatch.setattr(benchmark.os, "unlink", real_unlink)
    benchmark._remove_private_dependency_workspace(workspace)


def test_isolated_worktree_rejects_post_run_dependency_mutation(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    source = tmp_path / "source"
    source.mkdir()
    (source / ".git").mkdir()
    layer = tmp_path / "layer"
    layer.mkdir()
    package = layer / "package.py"
    package.write_bytes(b"before\n")
    expected = benchmark._freeze_dependency_tree(layer)
    seed = "1" * 40
    destination: Path | None = None

    def fake_run(root, argv, **kwargs):
        nonlocal destination
        command = list(argv)
        if command[1:4] == ["worktree", "add", "--detach"]:
            destination = Path(command[-2])
            destination.mkdir()
            (destination / ".git").write_text("gitdir: fixture\n", encoding="utf-8")
            benchmark._copy_frozen_dependency_tree(
                layer,
                destination / ".zerorun-env",
                expected=expected,
            )
            return subprocess.CompletedProcess(command, 0, "", "")
        if command[1:3] == ["rev-parse", "--verify"]:
            return subprocess.CompletedProcess(command, 0, seed + "\n", "")
        if command[1:4] == ["worktree", "remove", "--force"]:
            assert destination is not None
            benchmark.shutil.rmtree(destination)
            return subprocess.CompletedProcess(command, 0, "", "")
        if command[1:3] == ["worktree", "prune"]:
            return subprocess.CompletedProcess(command, 0, "", "")
        raise AssertionError(command)

    monkeypatch.setattr(benchmark, "_run", fake_run)
    lifecycle: dict[str, object] = {}
    try:
        with pytest.raises(
            ConfigurationError,
            match="post-run integrity was not confirmed",
        ):
            with benchmark._isolated_worktree(
                source,
                git="git",
                seed_sha=seed,
                trajectory_index=1,
                expected_dependency_snapshot=expected,
                dependency_cleanup_record=lifecycle,
            ) as trajectory:
                copied = trajectory / ".zerorun-env" / "package.py"
                mode = stat.S_IMODE(copied.lstat().st_mode)
                os.chmod(copied, mode | stat.S_IWUSR)
                copied.write_bytes(b"after!\n")
                os.chmod(copied, mode)
        assert lifecycle == {}
        assert destination is not None and not destination.exists()
    finally:
        benchmark._remove_private_dependency_workspace(layer)
