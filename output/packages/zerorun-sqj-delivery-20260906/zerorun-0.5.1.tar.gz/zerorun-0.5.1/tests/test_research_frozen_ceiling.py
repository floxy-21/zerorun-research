from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from tools import research_frozen_ceiling as ceiling
from zerorun.model import ConfigurationError


def _runtime_identity() -> dict[str, object]:
    digest = ceiling.LOCKED_RUNTIME_IMAGE.rsplit("@", 1)[1]
    return {
        "runtime": "docker",
        "requested_image": ceiling.LOCKED_RUNTIME_IMAGE,
        "requested_digest": digest,
        "platform": "linux/amd64",
        "image_id": "sha256:" + "1" * 64,
        "repo_digests": ["docker.io/library/python@" + digest],
        "rootfs": {"type": "layers", "layers": ["sha256:" + "2" * 64]},
        "config_sha256": "3" * 64,
    }


def _candidate(*, unsafe_count: int = 8) -> dict[str, object]:
    assert 0 < unsafe_count < ceiling.FROZEN_COLLECTION_NODE_COUNT
    nodes: dict[str, dict[str, object]] = {}
    uncertainty: dict[str, list[str]] = {}
    unsafe: list[str] = []
    for index in range(ceiling.FROZEN_COLLECTION_NODE_COUNT):
        nodeid = f"tests/test_more.py::test_case_{index:03d}"
        if index < unsafe_count:
            reasons = ["thread-start"]
            nodes[nodeid] = {
                "reviewable": False,
                "fresh_required": True,
                "reason": "thread attribution incomplete",
                "selectors": [],
                "fallback_files": [],
                "profiling_uncertainties": reasons,
            }
            uncertainty[nodeid] = reasons
            unsafe.append(nodeid)
        else:
            nodes[nodeid] = {
                "reviewable": True,
                "fresh_required": False,
                "reason": None,
                "selectors": [],
                "fallback_files": ["tests/test_more.py"],
            }
    fixed_fingerprint = {
        name: {
            "present": True,
            "sha256": hashlib.sha256(value.encode("utf-8")).hexdigest(),
        }
        for name, value in sorted(ceiling._CONTAINER_ENVIRONMENT.items())
        if name != "PYTHONPATH"
    }
    payload: dict[str, object] = {
        "schema": "zerorun-pytest-candidate-v1",
        "authorizes_reuse": False,
        "candidate_only": True,
        "generated_from_observation": True,
        "task": "pytest-generalization",
        "base_args": [],
        "targets": list(ceiling.FULL_TARGETS),
        "static_inputs": ["pyproject.toml"],
        "session_closure": {},
        "nodes": nodes,
        "source_review": {},
        "baseline": {
            "exit_code": 0,
            "collection_node_count": ceiling.FROZEN_COLLECTION_NODE_COUNT,
            "collection_sha256": "4" * 64,
        },
        "runtime_identity": _runtime_identity(),
        "environment_fingerprint": fixed_fingerprint,
        "profiler_sha256": "5" * 64,
        "profiling_uncertainties": uncertainty,
        "uncertainty_isolation": {
            "attempted": True,
            "result": "clean-siblings-reprofiled",
            "exit_code": 0,
            "isolated_fresh_nodeids": unsafe,
            "sibling_node_count": ceiling.FROZEN_COLLECTION_NODE_COUNT - unsafe_count,
            "uncertainties": {},
        },
        "review": {"required": True},
    }
    payload["candidate_sha256"] = ceiling._canonical_sha256(payload)
    return payload


def _write_candidate(path: Path, payload: dict[str, object]) -> None:
    path.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")


def _validated_unsafe(payload: dict[str, object]) -> tuple[str, ...]:
    return ceiling._candidate_unsafe_nodeids(
        payload,
        expected_candidate_sha256=str(payload["candidate_sha256"]),
        runtime_identity=_runtime_identity(),
    )


def test_candidate_discovers_observed_count_instead_of_hardcoding_nine() -> None:
    payload = _candidate(unsafe_count=8)
    unsafe = _validated_unsafe(payload)
    assert len(unsafe) == 8
    assert unsafe == tuple(payload["uncertainty_isolation"]["isolated_fresh_nodeids"])


def test_candidate_can_derive_a_different_nonzero_count() -> None:
    payload = _candidate(unsafe_count=5)
    assert len(_validated_unsafe(payload)) == 5


@pytest.mark.parametrize(
    "mutate",
    [
        lambda value: value.update(authorizes_reuse=True),
        lambda value: value.update(targets=["tests"]),
        lambda value: value["baseline"].update(exit_code=1),
        lambda value: value["uncertainty_isolation"].update(uncertainties={"__session__": ["thread-start"]}),
        lambda value: value["uncertainty_isolation"].update(result="uncertain-failed-closed"),
        lambda value: value["profiling_uncertainties"].update({"__session__": ["thread-start"]}),
    ],
)
def test_candidate_refuses_unsafe_or_unresolved_contracts(mutate) -> None:
    payload = _candidate()
    mutate(payload)
    payload["candidate_sha256"] = ceiling._canonical_sha256(
        {key: value for key, value in payload.items() if key != "candidate_sha256"}
    )
    with pytest.raises(ConfigurationError):
        _validated_unsafe(payload)


def test_candidate_refuses_fresh_node_without_matching_uncertainty() -> None:
    payload = _candidate()
    nodeid = next(iter(payload["profiling_uncertainties"]))
    del payload["profiling_uncertainties"][nodeid]
    payload["candidate_sha256"] = ceiling._canonical_sha256(
        {key: value for key, value in payload.items() if key != "candidate_sha256"}
    )
    with pytest.raises(ConfigurationError, match="lacks initial uncertainty|differ"):
        _validated_unsafe(payload)


def test_candidate_refuses_nodeid_outside_frozen_target() -> None:
    payload = _candidate()
    old = next(iter(payload["nodes"]))
    row = payload["nodes"].pop(old)
    injected = "--override-ini=addopts=-x"
    payload["nodes"][injected] = row
    reasons = payload["profiling_uncertainties"].pop(old)
    payload["profiling_uncertainties"][injected] = reasons
    payload["uncertainty_isolation"]["isolated_fresh_nodeids"][0] = injected
    payload["candidate_sha256"] = ceiling._canonical_sha256(
        {key: value for key, value in payload.items() if key != "candidate_sha256"}
    )
    with pytest.raises(ConfigurationError, match="out-of-target"):
        _validated_unsafe(payload)


def test_candidate_self_digest_and_caller_pin_are_both_required(tmp_path: Path) -> None:
    path = tmp_path / "candidate.json"
    payload = _candidate()
    _write_candidate(path, payload)
    loaded, digest, _ = ceiling._read_candidate(path)
    loaded["candidate_only"] = False
    _write_candidate(path, loaded)
    with pytest.raises(ConfigurationError, match="self-digest"):
        ceiling._read_candidate(path)
    _write_candidate(path, payload)
    with pytest.raises(ConfigurationError, match="caller-pinned"):
        ceiling._candidate_unsafe_nodeids(
            payload,
            expected_candidate_sha256="f" * 64,
            runtime_identity=_runtime_identity(),
        )
    assert digest == payload["candidate_sha256"]


def test_candidate_reader_rejects_duplicate_json_members(tmp_path: Path) -> None:
    path = tmp_path / "candidate.json"
    path.write_text(
        '{"candidate_sha256":"' + "a" * 64 + '","candidate_sha256":"' + "b" * 64 + '"}',
        encoding="utf-8",
    )
    with pytest.raises(ConfigurationError, match="duplicate JSON member"):
        ceiling._read_candidate(path)


@pytest.mark.parametrize("repetitions", [0, 1, 3, 21, True])
def test_schedule_refuses_unbalanced_or_out_of_bounds_repetitions(repetitions) -> None:
    with pytest.raises(ConfigurationError):
        ceiling._schedule(repetitions)


def test_schedule_is_exactly_counterbalanced() -> None:
    schedule = ceiling._schedule(4)
    assert [row["arm"] for row in schedule] == [
        "full", "unsafe", "unsafe", "full", "full", "unsafe", "unsafe", "full"
    ]
    assert [row["sequence_position"] for row in schedule] == list(range(1, 9))


def _mock_attestations(
    monkeypatch: pytest.MonkeyPatch,
    *,
    mutate_post_git: bool = False,
) -> list[str]:
    docker = {
        "runtime_identity": _runtime_identity(),
        "docker_version": {"client": {"Version": "29"}, "server": {"Version": "29"}},
        "docker_launcher": {"resolved_path": "/usr/bin/docker", "size": 1, "sha256": "6" * 64},
    }
    monkeypatch.setattr(ceiling, "_attest_docker", lambda *_args, **_kwargs: docker)
    git_calls = 0

    def git(*_args, **_kwargs):
        nonlocal git_calls
        git_calls += 1
        return {
            "repository": ceiling.FROZEN_REPOSITORY,
            "root": "/repo",
            "origin": "https://github.com/more-itertools/more-itertools.git",
            "head": ceiling.FROZEN_SEED_SHA if not (mutate_post_git and git_calls > 1) else "0" * 40,
            "tree": ceiling.FROZEN_SEED_TREE,
            "tracked_clean": True,
            "allowed_generated_untracked": [],
            "submodules": [],
            "git_launcher": {"resolved_path": "/usr/bin/git", "size": 1, "sha256": "7" * 64},
        }

    monkeypatch.setattr(ceiling, "_attest_git", git)
    environment = {
        "runtime_requirements_sha256": ceiling.LOCKED_REQUIREMENTS_SHA256,
        "file_count": 10,
        "total_bytes": 100,
        "file_tree_sha256": "8" * 64,
        "controlled_container_environment": ceiling._CONTAINER_ENVIRONMENT,
        "docker_resource_args": list(ceiling._benchmark._PLAIN_DOCKER_RESOURCE_ARGS),
        "network": "none",
        "root_filesystem": "read-only",
        "platform": "linux/amd64",
    }
    monkeypatch.setattr(ceiling, "_attest_environment", lambda _root: environment)
    monkeypatch.setattr(
        ceiling,
        "_tool_identity",
        lambda: {"schema": "tool", "files": [], "sha256": "9" * 64},
    )
    quiescence_phases: list[str] = []

    def quiescent(_root: Path, *, phase: str):
        quiescence_phases.append(phase)
        return {
            "phase": phase,
            "checked_at_utc": "2026-09-05T00:00:00.000Z",
            "running_container_count": 0,
            "running_container_ids_sha256": ceiling._canonical_sha256([]),
        }

    monkeypatch.setattr(ceiling, "_assert_docker_quiescent", quiescent)
    return quiescence_phases


def test_measure_warms_each_arm_counterbalances_and_self_digests(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    root = tmp_path / "repo"
    root.mkdir()
    (root / ".git").mkdir()
    candidate_path = tmp_path / "candidate.json"
    candidate = _candidate(unsafe_count=8)
    _write_candidate(candidate_path, candidate)
    output = tmp_path / "ceiling.json"
    quiescence_phases = _mock_attestations(monkeypatch)
    full_times = iter([101.0, 100.0, 110.0, 90.0, 100.0])
    unsafe_times = iter([81.0, 80.0, 90.0, 70.0, 80.0])
    calls: list[tuple[str, ...]] = []

    def direct(_root: Path, *, targets, runtime_image):
        assert runtime_image == ceiling.LOCKED_RUNTIME_IMAGE
        target_tuple = tuple(targets)
        calls.append(target_tuple)
        arm = "full" if target_tuple == ceiling.FULL_TARGETS else "unsafe"
        wall_ms = next(full_times if arm == "full" else unsafe_times)
        return {
            "exit_code": 0,
            "wall_ms": wall_ms,
            "stdout_tail": f"{arm} passed",
            "stderr_tail": "",
            "runner": "independent-docker-plain-pytest",
            "instrumented": False,
            "node_count": None,
            "collection_sha256": None,
        }

    monkeypatch.setattr(ceiling._benchmark, "_direct_once", direct)
    result = ceiling.measure(
        repo_root=root,
        candidate_path=candidate_path,
        expected_candidate_sha256=str(candidate["candidate_sha256"]),
        output=output,
        repetitions=4,
    )
    assert output.is_file()
    assert len(calls) == 10
    assert len(quiescence_phases) == 21
    assert result["docker_isolation"]["check_count"] == 21
    assert all(
        row["running_container_count"] == 0
        for row in result["docker_isolation"]["checks"]
    )
    assert quiescence_phases[0] == "before-warmup-1-full"
    assert quiescence_phases[-1] == "post-attestation"
    assert calls[0] == ceiling.FULL_TARGETS
    assert len(calls[1]) == 8
    assert result["summary"]["median_full_wall_ms"] == 100.0
    assert result["summary"]["median_mandatory_unsafe_wall_ms"] == 80.0
    assert result["summary"]["observed_theoretical_zero_cost_clean_ceiling_multiple"] == 1.25
    assert result["summary"]["strict_gate_asserted"] is False
    assert result["release_gate_evidence"] is False
    unsigned = dict(result)
    claimed = unsigned.pop("record_sha256")
    assert claimed == ceiling._canonical_sha256(unsigned)
    on_disk = json.loads(output.read_text(encoding="utf-8"))
    assert on_disk == result
    assert all(row["stdout"]["tail_utf8_sha256"] for row in result["observations"])


def test_measure_refuses_any_nonzero_run_without_publishing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    root = tmp_path / "repo"
    root.mkdir()
    (root / ".git").mkdir()
    candidate_path = tmp_path / "candidate.json"
    candidate = _candidate()
    _write_candidate(candidate_path, candidate)
    output = tmp_path / "ceiling.json"
    _mock_attestations(monkeypatch)
    monkeypatch.setattr(
        ceiling._benchmark,
        "_direct_once",
        lambda *_args, **_kwargs: {
            "exit_code": 1,
            "wall_ms": 1.0,
            "stdout_tail": "failed",
            "stderr_tail": "",
            "runner": "independent-docker-plain-pytest",
            "instrumented": False,
        },
    )
    with pytest.raises(ConfigurationError, match="did not pass"):
        ceiling.measure(
            repo_root=root,
            candidate_path=candidate_path,
            expected_candidate_sha256=str(candidate["candidate_sha256"]),
            output=output,
            repetitions=2,
        )
    assert not output.exists()


def test_measure_refuses_identity_drift_without_publishing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    root = tmp_path / "repo"
    root.mkdir()
    (root / ".git").mkdir()
    candidate_path = tmp_path / "candidate.json"
    candidate = _candidate()
    _write_candidate(candidate_path, candidate)
    output = tmp_path / "ceiling.json"
    _mock_attestations(monkeypatch, mutate_post_git=True)
    monkeypatch.setattr(
        ceiling._benchmark,
        "_direct_once",
        lambda *_args, **_kwargs: {
            "exit_code": 0,
            "wall_ms": 1.0,
            "stdout_tail": "passed",
            "stderr_tail": "",
            "runner": "independent-docker-plain-pytest",
            "instrumented": False,
        },
    )
    with pytest.raises(ConfigurationError, match="Git identity"):
        ceiling.measure(
            repo_root=root,
            candidate_path=candidate_path,
            expected_candidate_sha256=str(candidate["candidate_sha256"]),
            output=output,
            repetitions=2,
        )
    assert not output.exists()


def test_measure_refuses_competing_container_between_observations(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    root = tmp_path / "repo"
    root.mkdir()
    (root / ".git").mkdir()
    candidate_path = tmp_path / "candidate.json"
    candidate = _candidate()
    _write_candidate(candidate_path, candidate)
    output = tmp_path / "ceiling.json"
    _mock_attestations(monkeypatch)
    direct_calls = 0

    def direct(*_args, **_kwargs):
        nonlocal direct_calls
        direct_calls += 1
        return {
            "exit_code": 0,
            "wall_ms": 1.0,
            "stdout_tail": "passed",
            "stderr_tail": "",
            "runner": "independent-docker-plain-pytest",
            "instrumented": False,
        }

    def quiescent(_root: Path, *, phase: str):
        if phase == "before-measured-1-full":
            raise ConfigurationError(
                "Docker isolation violated: 1 competing container running"
            )
        return {
            "phase": phase,
            "checked_at_utc": "2026-09-05T00:00:00.000Z",
            "running_container_count": 0,
            "running_container_ids_sha256": ceiling._canonical_sha256([]),
        }

    monkeypatch.setattr(ceiling._benchmark, "_direct_once", direct)
    monkeypatch.setattr(ceiling, "_assert_docker_quiescent", quiescent)
    with pytest.raises(ConfigurationError, match="competing container"):
        ceiling.measure(
            repo_root=root,
            candidate_path=candidate_path,
            expected_candidate_sha256=str(candidate["candidate_sha256"]),
            output=output,
            repetitions=2,
        )
    assert direct_calls == 2  # Both excluded warmups completed before contention.
    assert not output.exists()


def test_quiescence_attestation_records_exact_empty_daemon(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        ceiling._benchmark,
        "_host_executable",
        lambda _root, _name: "/usr/bin/docker",
    )
    monkeypatch.setattr(ceiling, "_run_text", lambda *_args, **_kwargs: "")
    row = ceiling._assert_docker_quiescent(tmp_path, phase="before-test")
    assert row["running_container_count"] == 0
    assert row["running_container_ids_sha256"] == ceiling._canonical_sha256([])


@pytest.mark.parametrize("raw", ["a" * 64, "not-a-container-id"])
def test_quiescence_attestation_refuses_competing_or_malformed_daemon_state(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, raw: str
) -> None:
    monkeypatch.setattr(
        ceiling._benchmark,
        "_host_executable",
        lambda _root, _name: "/usr/bin/docker",
    )
    monkeypatch.setattr(ceiling, "_run_text", lambda *_args, **_kwargs: raw)
    with pytest.raises(ConfigurationError, match="Docker"):
        ceiling._assert_docker_quiescent(tmp_path, phase="before-test")


def test_atomic_writer_never_overwrites_existing_output(tmp_path: Path) -> None:
    output = tmp_path / "receipt.json"
    output.write_text("owner data", encoding="utf-8")
    with pytest.raises(ConfigurationError, match="overwrite"):
        ceiling._atomic_durable_write(output, {"schema": "test"})
    assert output.read_text(encoding="utf-8") == "owner data"


@pytest.mark.parametrize(
    "image",
    ["python:3.12", "python@sha256:abc", "--privileged", ceiling.LOCKED_RUNTIME_IMAGE + " "]
)
def test_docker_attestation_refuses_unpinned_or_changed_image(tmp_path: Path, image: str) -> None:
    with pytest.raises(ConfigurationError, match="runtime image"):
        ceiling._attest_docker(tmp_path, image)
