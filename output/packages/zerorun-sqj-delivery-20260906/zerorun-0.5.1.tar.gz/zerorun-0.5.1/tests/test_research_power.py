from __future__ import annotations

import json
import math
from pathlib import Path
import random
import statistics

from research.artifact import validation
from tools import research_power_simulation as power


ROOT = Path(__file__).resolve().parents[1]


def _scenario(**changes: float) -> power.Scenario:
    values = {
        "compatibility_rate": 0.90,
        "log_effect": math.log(1.50),
        "between_log_sd": 0.40,
        "selector_missing_rate": 0.05,
        "direct_missing_rate": 0.0,
        "shared_missing_rate": 0.0,
        "reuse_rate": 0.70,
        "no_reuse_overhead": 0.02,
        "between_overhead_sd": 0.02,
        "semantic_applicability_rate": 0.90,
        "semantic_effectiveness_rate": 0.90,
        "boundary_validity_rate": 0.90,
        "safety_mismatch_rate": 0.0,
    }
    values.update(changes)
    return power.Scenario(**values)


def _output(scenarios: list[power.Scenario]) -> dict[str, object]:
    return power.build_output(
        scenarios,
        seed="deterministic-test-seed",
        simulations=3,
        bootstrap_draws=19,
        within_log_sd=0.05,
        owner_log_sd=0.05,
        owner_compatibility_sd=0.0,
        within_overhead_sd=0.01,
        failure_cap=10.0,
    )


def test_full_primary_simulation_is_deterministic_and_schema_valid() -> None:
    scenarios = [_scenario(), _scenario(compatibility_rate=0.0)]
    first = _output(scenarios)
    second = _output(list(reversed(scenarios)))
    assert first == second
    assert first["planning_only"] is True
    assert first["observed_confirmatory_data_used"] is False
    assert first["scope"] == "FULL_PRIMARY_FAMILY"
    assert first["design"]["simulation_algorithm"] == power.SIMULATION_ALGORITHM
    assert first["design"]["holm_family_simulated"] is True
    assert first["design"]["owner_clusters_per_stratum"] == 13
    assert first["design"]["owner_pair_clusters_per_stratum"] == 12
    assert first["design"]["owner_singleton_clusters_per_stratum"] == 1
    assert first["design"]["owners_cross_strata"] is False
    operating = first["scenarios"][1]["operating_characteristics"]
    truth = first["scenarios"][1]["data_generating_truth"]
    assert abs(
        truth["compatibility_analytic_marginal_probability"]
        - truth["compatibility_target_marginal_probability"]
    ) <= power.COMPATIBILITY_CALIBRATION_TOLERANCE
    assert set(operating["H1_M_category_coverage_probability"]) == set(
        power.MUTATION_CATEGORIES
    )
    assert set(operating["H1_M_evaluable_trials_by_category"]) == set(
        power.MUTATION_CATEGORIES
    )

    report = validation.ValidationReport()
    catalog = validation.load_schema_catalog(ROOT / "research" / "schemas", report)
    validation.validate_instance(
        first,
        "zerorun.primary-family-power-simulation.v1",
        catalog,
        report,
        "simulation",
    )
    assert report.errors == []


def test_owner_compatibility_calibration_matches_reported_marginal_truth() -> None:
    for target in (0.0, 0.01, 0.50, 0.90, 0.99, 1.0):
        location, achieved, method = power._calibrate_owner_compatibility_location(
            target, 0.08
        )
        assert abs(achieved - target) <= power.COMPATIBILITY_CALIBRATION_TOLERANCE
        if target in (0.0, 1.0):
            assert location is None
            assert method == "deterministic_probability_endpoint"
        else:
            assert location is not None
            assert method == "calibrated_clipped_normal"
            assert abs(power._clipped_normal_mean(location, 0.08) - target) <= 1e-12
    location, _, _ = power._calibrate_owner_compatibility_location(0.90, 0.08)
    assert location is not None
    rng = random.Random(20260905)
    empirical_mean = sum(
        power._clamp_probability(location + rng.gauss(0.0, 0.08))
        for _ in range(200_000)
    ) / 200_000
    assert abs(empirical_mean - 0.90) < 0.001


def test_generated_owner_layout_is_fixed_and_never_crosses_strata() -> None:
    scenario = _scenario()
    location, _, _ = power._calibrate_owner_compatibility_location(
        scenario.compatibility_rate, 0.08
    )
    study = power._generate_study(
        random.Random(11),
        scenario,
        within_log_sd=0.05,
        owner_log_sd=0.05,
        owner_compatibility_sd=0.08,
        owner_compatibility_location=location,
        within_overhead_sd=0.01,
        failure_cap=10.0,
    )
    owner_strata: dict[str, set[str]] = {}
    for row in study.repositories:
        owner_strata.setdefault(row.owner_id, set()).add(row.stratum)
    assert all(len(strata) == 1 for strata in owner_strata.values())
    for stratum in power.STRATA:
        counts: dict[str, int] = {}
        for row in study.repositories:
            if row.stratum == stratum:
                counts[row.owner_id] = counts.get(row.owner_id, 0) + 1
        assert sorted(counts.values()) == [1] + [2] * 12


def test_h2_failure_bound_coverage_uses_analytic_zero_missingness_truth() -> None:
    scenario = _scenario(
        compatibility_rate=1.0,
        log_effect=math.log(1.5),
        between_log_sd=0.0,
        selector_missing_rate=0.0,
        direct_missing_rate=0.0,
        shared_missing_rate=0.0,
        between_overhead_sd=0.0,
    )
    output = power.build_output(
        [scenario],
        seed="analytic-h2-f",
        simulations=2,
        bootstrap_draws=19,
        within_log_sd=0.0,
        owner_log_sd=0.0,
        owner_compatibility_sd=0.08,
        within_overhead_sd=0.0,
        failure_cap=10.0,
    )
    result = output["scenarios"][0]
    truth = result["data_generating_truth"]
    operating = result["operating_characteristics"]
    assert truth["H2_failure_penalized_true_median_speedup"] == 1.5
    assert (
        truth["H2_failure_penalized_truth_status"]
        == "ANALYTIC_ZERO_MISSINGNESS_UNIQUE_MEDIAN"
    )
    assert operating["H2_failure_penalized_interval_coverage"] == 1.0
    assert operating["H2_failure_penalized_interval_coverage_eligible_simulations"] == 2


def test_h2_failure_truth_is_the_zero_missingness_mixture_median() -> None:
    scenario = _scenario(
        compatibility_rate=0.90,
        selector_missing_rate=0.0,
        direct_missing_rate=0.0,
        shared_missing_rate=0.0,
    )
    observed, status = power._zero_missing_failure_true_median(
        scenario,
        within_log_sd=0.05,
        failure_cap=10.0,
    )
    log_sd = math.sqrt(scenario.between_log_sd**2 + 0.05**2 / power.TRANSITIONS)
    mixture_quantile = (0.5 - (1.0 - scenario.compatibility_rate)) / scenario.compatibility_rate
    expected = math.exp(
        scenario.log_effect
        + log_sd * statistics.NormalDist().inv_cdf(mixture_quantile)
    )
    assert status == "ANALYTIC_ZERO_MISSINGNESS_UNIQUE_MEDIAN"
    assert observed is not None
    assert math.isclose(observed, expected, rel_tol=0, abs_tol=1e-12)


def test_h2_failure_coverage_refuses_unidentified_missingness_truth() -> None:
    result = _output([_scenario()])["scenarios"][0]
    truth = result["data_generating_truth"]
    operating = result["operating_characteristics"]
    assert truth["H2_failure_penalized_true_median_speedup"] is None
    assert truth["H2_failure_penalized_truth_status"] == "NOT_ELIGIBLE_NONZERO_MISSINGNESS"
    assert operating["H2_failure_penalized_interval_coverage"] is None
    assert operating["H2_failure_penalized_interval_coverage_eligible_simulations"] == 0


def test_null_type_i_outputs_have_explicit_eligibility_denominators() -> None:
    scenario = _scenario(
        compatibility_rate=0.70,
        log_effect=0.0,
        between_log_sd=0.0,
        selector_missing_rate=0.0,
        direct_missing_rate=0.0,
        shared_missing_rate=0.0,
        no_reuse_overhead=0.10,
        between_overhead_sd=0.0,
        safety_mismatch_rate=0.01,
    )
    output = power.build_output(
        [scenario],
        seed="joint-null",
        simulations=2,
        bootstrap_draws=19,
        within_log_sd=0.0,
        owner_log_sd=0.0,
        owner_compatibility_sd=0.0,
        within_overhead_sd=0.0,
        failure_cap=10.0,
    )
    result = output["scenarios"][0]
    assert result["data_generating_truth"]["H2_hypothesis_truth_status"] == "NULL"
    assert result["data_generating_truth"]["H3_hypothesis_truth_status"] == "NULL"
    assert result["data_generating_truth"]["H4_hypothesis_truth_status"] == "NULL"
    assert result["data_generating_truth"]["known_null_hypotheses"] == [
        "H2",
        "H3",
        "H4",
    ]
    operating = result["operating_characteristics"]
    for prefix in ("H2", "H3", "H4"):
        assert operating[f"{prefix}_type_I_error_eligible_simulations"] == 2
        assert 0.0 <= operating[f"{prefix}_holm_type_I_error_probability"] <= 1.0
    assert operating["known_null_familywise_error_eligible_simulations"] == 2
    assert 0.0 <= operating["known_null_familywise_error_probability"] <= 1.0
    assert operating["H1_false_safety_eligible_simulations"] == 2
    assert 0.0 <= operating["H1_false_safety_probability"] <= 1.0


def test_protocol_grid_includes_nonzero_h1_mismatch_alternative() -> None:
    args = power.parse_args(["--protocol-grid"])
    power._configure_protocol_grid(args)
    scenarios = power._apply_protocol_h1_mismatch_fraction(
        power._scenarios_from_args(args)
    )
    assert len(scenarios) == power.PROTOCOL_GRID_SCENARIO_COUNT == 1_944
    assert {scenario.safety_mismatch_rate for scenario in scenarios} == {0.0, 0.005}
    assert sum(scenario.safety_mismatch_rate > 0 for scenario in scenarios) == 648


def test_zero_compatibility_cannot_meet_h1_h2_or_h3_coverage() -> None:
    output = _output([_scenario(compatibility_rate=0.0)])
    operating = output["scenarios"][0]["operating_characteristics"]
    assert operating["H1_N_coverage_probability"] == 0
    assert operating["H1_M_all_category_coverage_probability"] == 0
    assert operating["H2_coverage_probability"] == 0
    assert operating["H3_coverage_probability"] == 0
    assert operating["H2_bootstrap_domain_probability"] == 0
    assert operating["H3_bootstrap_domain_probability"] == 0
    assert operating["conditional_interval_coverage"] is None
    assert operating["conditional_interval_coverage_eligible_simulations"] == 0
    assert operating["H3_interval_coverage"] is None
    assert operating["H3_interval_coverage_eligible_simulations"] == 0
    assert operating["all_confirmatory_gates_probability"] == 0


def test_direct_condition_missingness_removes_conditional_pairs() -> None:
    output = _output([_scenario(direct_missing_rate=1.0)])
    operating = output["scenarios"][0]["operating_characteristics"]
    assert operating["H2_coverage_probability"] == 0
    assert operating["H3_coverage_probability"] == 0


def test_equal_stratum_weighted_median_does_not_let_large_stratum_dominate() -> None:
    groups = {
        "S1": [1.0] * 100,
        "S2": [2.0],
        "S3": [3.0],
        "S4": [4.0],
    }
    assert power.equal_stratum_weighted_median(groups) == 2.5


def test_holm_adjustment_is_monotone_and_uses_all_three_hypotheses() -> None:
    adjusted = power.holm_adjust({"H2": 0.01, "H3": 0.02, "H4": 0.5})
    assert adjusted == {"H2": 0.03, "H3": 0.04, "H4": 0.5}


def test_sparse_compatibility_interval_is_truncated_to_parameter_space() -> None:
    lower, p_value = power._probability_greater_inversion(
        0.01, [0.03, 0.03], 0.70
    )
    assert lower == 0.0
    assert p_value == 1.0


def test_planning_cluster_pairs_bootstrap_never_splits_or_size_conditions() -> None:
    rows = [
        power.RepositoryOutcome("S1", "pair", True, 1.0, 1.0, 0.0, 1, 0),
        power.RepositoryOutcome("S1", "pair", True, 1.0, 1.0, 0.0, 1, 0),
        *[
            power.RepositoryOutcome(
                "S1", f"single-{index}", True, 1.0, 1.0, 0.0, 1, 0
            )
            for index in range(23)
        ],
    ]
    clusters = tuple(tuple(value) for value in power._owner_clusters(rows).values())
    for seed in range(10):
        sampled = power._sample_owner_clusters(random.Random(seed), clusters)
        pair_counts = [row.owner_id for row in sampled].count("pair")
        assert pair_counts % 2 == 0
        assert pair_counts // 2 + sum(
            [row.owner_id for row in sampled].count(f"single-{index}")
            for index in range(23)
        ) == 24


def test_planning_bootstrap_resamples_fixed_eligible_endpoint_population() -> None:
    rows = [
        power.RepositoryOutcome(
            stratum,
            f"{stratum}-owner-{offset}",
            True,
            2.0 if offset == 0 else None,
            2.0,
            0.01 if offset == 0 else None,
            1,
            0,
        )
        for stratum in power.STRATA
        for offset in range(25)
    ]
    draws = power._bootstrap(random.Random(7), rows, draws=100)
    assert draws["conditional"] == [2.0] * 100
    assert draws["h3"] == [0.01] * 100
    assert all(value is not None for value in draws["failure"])
    assert all(value is not None for value in draws["h4"])


def test_cli_writes_byte_identical_machine_readable_output(tmp_path: Path) -> None:
    first = tmp_path / "first.json"
    second = tmp_path / "second.json"
    arguments = [
        "--seed",
        "cli-test-seed",
        "--simulations",
        "1",
        "--bootstrap-draws",
        "3",
        "--compatibility-rates",
        "0.9",
        "--log-effects",
        str(math.log(1.5)),
        "--between-sds",
        "0.4",
        "--selector-missing-rates",
        "0.05",
        "--owner-log-sd",
        "0.05",
    ]
    assert power.main([*arguments, "--output", str(first)]) == 0
    assert power.main([*arguments, "--output", str(second)]) == 0
    assert first.read_bytes() == second.read_bytes()
    parsed = json.loads(first.read_text(encoding="utf-8"))
    assert parsed["status"] == "SIMULATION_ONLY"


def test_compact_full_grid_evidence_is_explicitly_not_power_adequacy() -> None:
    scenarios = [
        {
            "scenario_id": f"{index:016x}",
            "assumptions": {
                "safety_mismatch_probability": 0.005 if index % 3 == 0 else 0.0
            },
            "operating_characteristics": {
                "H2_holm_pass_probability": float(index % 2),
                "H2_holm_type_I_error_probability": (
                    None if index == 0 else float(index % 2)
                ),
            },
        }
        for index in range(power.PROTOCOL_GRID_SCENARIO_COUNT)
    ]
    output = {
        "seed": "synthetic",
        "design": {
            "simulation_algorithm": power.SIMULATION_ALGORITHM,
            "simulation_repetitions": 2,
            "bootstrap_draws": 19,
            "bootstrap_resampling": "endpoint_specific_stratified_owner_cluster_pairs_bootstrap_variable_repository_count",
        },
        "scenarios": scenarios,
    }
    rendered = power._render(output)
    evidence = power._compact_evidence(
        output,
        command=["python3", "tools/research_power_simulation.py"],
        runtime_seconds=1.0,
        full_rendered=rendered,
        source_sha256="a" * 64,
    )
    assert evidence["scenario_count"] == power.PROTOCOL_GRID_SCENARIO_COUNT
    assert evidence["power_adequacy_claimed"] is False
    assert evidence["source_sha256"] == "a" * 64
    assert evidence["full_output_retained"] is False
    assert evidence["configuration"]["H1_safety_mismatch_scenario_counts"] == {
        "0.0": 1296,
        "0.005": 648,
    }
    assert "H2_holm_type_I_error_probability" in evidence["probability_extrema"]
    assert (
        evidence["probability_reported_scenario_counts"][
            "H2_holm_type_I_error_probability"
        ]
        == power.PROTOCOL_GRID_SCENARIO_COUNT - 1
    )
    assert evidence["zero_probability_scenario_counts"] == {
        "H2_holm_pass_probability": 972,
        "H2_holm_type_I_error_probability": 971,
    }

    report = validation.ValidationReport()
    catalog = validation.load_schema_catalog(ROOT / "research/schemas", report)
    validation.validate_instance(
        evidence,
        "zerorun.power-grid-harness-evidence.v1",
        catalog,
        report,
        "compact planning evidence",
    )
    assert report.errors == []


def test_cli_refuses_evidence_when_simulator_source_drifts(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    snapshots = iter((b"stable source before", b"changed source after"))
    monkeypatch.setattr(power, "_read_source_bytes", lambda: next(snapshots))
    output = tmp_path / "must-not-exist.json"
    assert power.main(
        [
            "--simulations",
            "1",
            "--bootstrap-draws",
            "3",
            "--output",
            str(output),
        ]
    ) == 2
    assert not output.exists()


def test_invalid_probability_and_owner_variance_fail_closed() -> None:
    invalid_missingness = _scenario(selector_missing_rate=1.1)
    try:
        _output([invalid_missingness])
    except ValueError as exc:
        assert "within [0, 1]" in str(exc)
    else:
        raise AssertionError("invalid missingness probabilities were accepted")

    impossible_owner_sd = _scenario(between_log_sd=0.01)
    try:
        _output([impossible_owner_sd])
    except ValueError as exc:
        assert "owner-log-sd" in str(exc)
    else:
        raise AssertionError("owner variance larger than total variance was accepted")
