from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
from unittest.mock import patch

import pytest

from zerorun import trust
import zerorun.hermetic_store as hermetic_store
import zerorun.pytest_node_cache as node_cache_module
from zerorun.hermetic_batch_key import FingerprintSession
from zerorun.hermetic_store import _load_result_entry, _save_result_entry
from zerorun.model import ConfigurationError, TaskSpec
from zerorun.pytest_node_cache import (
    NodeCacheContext,
    prepare_node_cache,
    verify_node_cache_snapshot,
)
from zerorun.pytest_node_identity import (
    PYTEST_NODE_ACTION_DOMAIN,
    PYTEST_NODE_ACTION_SCHEMA,
    PytestNodeResultIdentity,
    pytest_node_action_key,
    pytest_node_component_reference,
    validate_pytest_node_action_identity,
)
from zerorun.pytest_node_key import node_action_fingerprint
from zerorun.store import Store


HEX_A = "a" * 64
HEX_B = "b" * 64
HEX_C = "c" * 64
HEX_D = "d" * 64
NODEID = "tests/test_calc.py::test_add"


def _root(tmp_path: Path) -> Path:
    root = tmp_path / "repository"
    root.mkdir()
    (root / ".zerorun.json").write_text(
        '{"tasks":{},"version":2}\n', encoding="utf-8"
    )
    (root / "static.txt").write_text("stable\n", encoding="utf-8")
    (root / "session.py").write_text(
        "def session_helper():\n    return 1\n", encoding="utf-8"
    )
    (root / "calc.py").write_text(
        "def add(a, b):\n    return a + b\n", encoding="utf-8"
    )
    return root


def _task() -> TaskSpec:
    return TaskSpec(
        name="pytest",
        command=("python", "-m", "pytest"),
        inputs=(),
        outputs=(),
        env=(),
        cacheable=False,
        unsafe_effects=(),
        cache_streams=False,
        image="python@sha256:" + "e" * 64,
        platform="linux/amd64",
        result_only=True,
        closure_reviewed=True,
    )


def _item(
    nodeid: str = NODEID,
    *,
    identity: str = HEX_A,
) -> dict[str, object]:
    return {
        "nodeid": nodeid,
        "identity_sha256": identity,
        "parameter_identity_supported": True,
    }


def _node_closure(*, absent_count: int = 0) -> dict[str, object]:
    return {
        "selectors": ["calc.py::add"],
        "fallback_files": [],
        "absent_files": [f"optional/pkg_{index}.py" for index in range(absent_count)],
    }


def _session_closure() -> dict[str, object]:
    return {
        "selectors": ["session.py::session_helper"],
        "fallback_files": [],
        "absent_files": [],
    }


def _context() -> NodeCacheContext:
    return NodeCacheContext(
        runtime_identity={
            "requested_image": "python@sha256:" + "e" * 64,
            "resolved_image": "sha256:" + "f" * 64,
        },
        environment_fingerprint={
            "PYTHONDONTWRITEBYTECODE": {"present": True, "value": "1"}
        },
        collection_contract_sha256=HEX_B,
        collection_plugin_sha256=HEX_C,
        independence_review_sha256=HEX_D,
        profile_sha256="9" * 64,
    )


def _action(
    root: Path,
    *,
    absent_count: int = 0,
    context: NodeCacheContext | None = None,
):
    context = context or _context()
    return node_action_fingerprint(
        root,
        _task(),
        nodeid=NODEID,
        collection_item=_item(),
        collection_contract_sha256=context.collection_contract_sha256,
        collection_plugin_sha256=context.collection_plugin_sha256,
        node_closure=_node_closure(absent_count=absent_count),
        session_closure=_session_closure(),
        static_inputs=("static.txt",),
        runtime_identity=context.runtime_identity,
        environment_fingerprint=context.environment_fingerprint,
        independence_review_sha256=context.independence_review_sha256,
        profile_sha256=context.profile_sha256,
        session=FingerprintSession(root),
    )


def _resign(root: Path, metadata: dict[str, object]) -> dict[str, object]:
    manifest_digest = trust.manifest_sha256_for_root(root)
    session = trust.CacheTrustSession.open(
        root,
        manifest_digest=manifest_digest,
        profile_digest="9" * 64,
    )
    unsigned = dict(metadata)
    unsigned.pop("provenance", None)
    signed = {
        **unsigned,
        "provenance": session.sign_payload(
            unsigned,
            manifest_digest=manifest_digest,
            profile_digest="9" * 64,
        ),
    }
    session.verify_unchanged()
    return signed


def test_schema_nine_is_compact_and_full_source_equivalent(tmp_path: Path) -> None:
    root = _root(tmp_path)
    cache_task, key, fingerprint = _action(root, absent_count=512)
    repeated = _action(root, absent_count=512)

    assert repeated == (cache_task, key, fingerprint)
    assert fingerprint["schema"] == PYTEST_NODE_ACTION_SCHEMA
    assert fingerprint["action_domain"] == PYTEST_NODE_ACTION_DOMAIN
    assert pytest_node_action_key(fingerprint) == key
    assert len(json.dumps(fingerprint, sort_keys=True).encode("utf-8")) < 4_000
    assert fingerprint["components"]["node_closure"]["counts"] == {
        "absent_files": 512,
        "fallback_files": 0,
        "selectors": 1,
    }
    serialized = json.dumps(fingerprint, sort_keys=True)
    assert "optional/pkg_0.py" not in serialized


def test_node_source_mutation_changes_only_its_merkle_leaf_and_root(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    _, first_key, first = _action(root)
    (root / "calc.py").write_text(
        "def add(a, b):\n    return a + b + 1\n", encoding="utf-8"
    )
    _, second_key, second = _action(root)

    assert second_key != first_key
    changed = {
        label
        for label in first["components"]
        if first["components"][label] != second["components"][label]
    }
    assert changed == {"node_closure"}


def test_merkle_components_are_domain_and_count_separated() -> None:
    evidence = {"closure_sha256": HEX_A}
    node = pytest_node_component_reference(
        "node_closure",
        evidence,
        counts={"selectors": 1, "fallback_files": 0, "absent_files": 0},
    )
    session = pytest_node_component_reference(
        "session_closure",
        evidence,
        counts={"selectors": 1, "fallback_files": 0, "absent_files": 0},
    )
    more = pytest_node_component_reference(
        "node_closure",
        evidence,
        counts={"selectors": 2, "fallback_files": 0, "absent_files": 0},
    )

    assert node["sha256"] != session["sha256"]
    assert node["sha256"] != more["sha256"]


def test_recomputed_key_cannot_bypass_fixed_domains_or_component_shape(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    task, _, fingerprint = _action(root)

    wrong_domain = {**fingerprint, "action_domain": "foreign-action-v1"}
    wrong_domain_key = pytest_node_action_key(wrong_domain)
    try:
        validate_pytest_node_action_identity(
            task_name=task.name,
            key=wrong_domain_key,
            fingerprint=wrong_domain,
        )
    except ConfigurationError as exc:
        assert "action domain" in str(exc)
    else:  # pragma: no cover - fail loudly without weakening the assertion
        raise AssertionError("foreign action domain was accepted")

    swapped = json.loads(json.dumps(fingerprint))
    swapped["components"]["node_closure"]["label"] = "session_closure"
    swapped_key = pytest_node_action_key(swapped)
    try:
        validate_pytest_node_action_identity(
            task_name=task.name,
            key=swapped_key,
            fingerprint=swapped,
        )
    except ConfigurationError as exc:
        assert "node_closure reference" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("cross-domain component reference was accepted")


@pytest.mark.parametrize("case", ["boolean-policy", "boolean-count", "extra-component"])
def test_schema_nine_rejects_type_confusion_and_unknown_components(
    tmp_path: Path,
    case: str,
) -> None:
    root = _root(tmp_path)
    task, _, fingerprint = _action(root)
    malformed = json.loads(json.dumps(fingerprint))
    if case == "boolean-policy":
        malformed["policy"]["cacheable"] = 1
    elif case == "boolean-count":
        malformed["components"]["node_closure"]["counts"]["selectors"] = True
    else:
        malformed["components"]["foreign"] = malformed["components"]["command"]
    with pytest.raises(ConfigurationError, match="compact Merkle"):
        validate_pytest_node_action_identity(
            task_name=task.name,
            key=pytest_node_action_key(malformed),
            fingerprint=malformed,
        )


def test_schema_nine_round_trip_uses_signed_storage_schema_two(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    task, key, fingerprint = _action(root)
    identity = validate_pytest_node_action_identity(
        task_name=task.name,
        key=key,
        fingerprint=fingerprint,
    )
    metadata = _save_result_entry(
        Store(root),
        task,
        key,
        fingerprint,
        result_identity=identity,
        execution_ms=3.5,
    )

    assert metadata["schema"] == 9
    assert metadata["storage_schema"] == 2
    assert metadata["fingerprint_sha256"] == key
    assert metadata["runtime_identity_sha256"] == fingerprint["components"][
        "runtime_identity"
    ]["sha256"]
    assert "fingerprint" not in metadata
    assert _load_result_entry(
        Store(root),
        task,
        key,
        fingerprint,
        result_identity=identity,
    ) == metadata


def test_schema_nine_store_path_never_calls_legacy_full_preimage_serializer(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    store = Store(root)
    task, key, fingerprint = _action(root, absent_count=128)
    identity = validate_pytest_node_action_identity(
        task_name=task.name,
        key=key,
        fingerprint=fingerprint,
    )
    with patch.object(
        hermetic_store,
        "_schema_six_identity",
        side_effect=AssertionError("legacy full-preimage serializer reached"),
    ):
        _save_result_entry(
            store,
            task,
            key,
            fingerprint,
            result_identity=identity,
            execution_ms=1.0,
        )
        assert _load_result_entry(
            store,
            task,
            key,
            fingerprint,
            result_identity=identity,
        ) is not None


def test_forged_carried_identity_is_a_safe_miss_without_quarantine(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    task, key, fingerprint = _action(root)
    identity = validate_pytest_node_action_identity(
        task_name=task.name,
        key=key,
        fingerprint=fingerprint,
    )
    _save_result_entry(
        Store(root),
        task,
        key,
        fingerprint,
        result_identity=identity,
        execution_ms=1.0,
    )
    forged = replace(identity, runtime_identity_sha256="0" * 64)

    assert _load_result_entry(
        Store(root),
        task,
        key,
        fingerprint,
        result_identity=forged,
    ) is None
    assert not (Store(root).entry(key) / "QUARANTINED").exists()
    assert _load_result_entry(
        Store(root), task, key, fingerprint, result_identity=identity
    ) is not None


def test_fingerprint_tamper_and_resigned_metadata_tamper_fail_closed(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    store = Store(root)
    task, key, fingerprint = _action(root)
    identity = validate_pytest_node_action_identity(
        task_name=task.name,
        key=key,
        fingerprint=fingerprint,
    )
    metadata = _save_result_entry(
        store,
        task,
        key,
        fingerprint,
        result_identity=identity,
        execution_ms=1.0,
    )

    tampered_fingerprint = json.loads(json.dumps(fingerprint))
    tampered_fingerprint["components"]["static_inputs"]["sha256"] = "0" * 64
    assert _load_result_entry(
        store,
        task,
        key,
        tampered_fingerprint,
        result_identity=identity,
    ) is None
    assert not (store.entry(key) / "QUARANTINED").exists()

    tampered_metadata = _resign(
        root,
        {**metadata, "runtime_identity_sha256": "1" * 64},
    )
    (store.entry(key) / "metadata.json").write_text(
        json.dumps(tampered_metadata, sort_keys=True), encoding="utf-8"
    )
    assert _load_result_entry(
        store, task, key, fingerprint, result_identity=identity
    ) is None
    assert (store.entry(key) / "QUARANTINED").is_file()


def test_final_snapshot_recomputes_full_sources_independently(tmp_path: Path) -> None:
    root = _root(tmp_path)
    context = _context()
    row = {
        "nodeid": NODEID,
        "reviewable": True,
        "fresh_required": False,
        **_node_closure(),
    }
    decisions = prepare_node_cache(
        root,
        _task(),
        node_rows=[row],
        session_closure=_session_closure(),
        static_inputs=("static.txt",),
        collection_items=[_item()],
        context=context,
        allow_cache_lookup=False,
    )
    assert decisions[0].status == "MISS_KEYED"
    assert isinstance(decisions[0].result_identity, PytestNodeResultIdentity)

    (root / "calc.py").write_text(
        "def add(a, b):\n    return a - b\n", encoding="utf-8"
    )
    verified = verify_node_cache_snapshot(
        root,
        _task(),
        decisions=decisions,
        node_rows=[row],
        session_closure=_session_closure(),
        static_inputs=("static.txt",),
        collection_items=[_item()],
        final_context=context,
    )
    assert verified[0].status == "REJECTED_INPUT_RACE"
    assert verified[0].reason == "node action identity changed during request"


def test_shared_leaves_are_built_once_per_independent_snapshot_pass(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    (root / "calc.py").write_text(
        "def add(a, b):\n    return a + b\n\n"
        "def sub(a, b):\n    return a - b\n",
        encoding="utf-8",
    )
    second = "tests/test_calc.py::test_sub"
    rows = [
        {
            "nodeid": NODEID,
            "reviewable": True,
            "fresh_required": False,
            "selectors": ["calc.py::add"],
            "fallback_files": [],
            "absent_files": [],
        },
        {
            "nodeid": second,
            "reviewable": True,
            "fresh_required": False,
            "selectors": ["calc.py::sub"],
            "fallback_files": [],
            "absent_files": [],
        },
    ]
    items = [_item(), _item(second, identity="8" * 64)]
    built = []
    real_build = node_cache_module.build_pytest_node_shared_action_identity

    def capture_build(*args, **kwargs):
        result = real_build(*args, **kwargs)
        built.append(result)
        return result

    monkeypatch.setattr(
        node_cache_module,
        "build_pytest_node_shared_action_identity",
        capture_build,
    )
    decisions = prepare_node_cache(
        root,
        _task(),
        node_rows=rows,
        session_closure=_session_closure(),
        static_inputs=("static.txt",),
        collection_items=items,
        context=_context(),
        allow_cache_lookup=False,
    )
    verified = verify_node_cache_snapshot(
        root,
        _task(),
        decisions=decisions,
        node_rows=rows,
        session_closure=_session_closure(),
        static_inputs=("static.txt",),
        collection_items=items,
        final_context=_context(),
    )

    assert [decision.status for decision in verified] == [
        "MISS_VERIFIED",
        "MISS_VERIFIED",
    ]
    assert len(built) == 2
    assert built[0] == built[1]
    assert built[0] is not built[1]
