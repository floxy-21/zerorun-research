from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from zerorun import pytest_profile
from zerorun.manifest import load_manifest
from zerorun.model import ConfigurationError


IMAGE = "example.invalid/python@sha256:" + ("a" * 64)


def _manifest(root: Path):
    (root / ".git").mkdir()
    path = root / ".zerorun.json"
    path.write_text(
        json.dumps(
            {
                "version": 2,
                "tasks": {
                    "tests": {
                        "command": ["python", "-m", "pytest"],
                        "inputs": ["tests"],
                        "outputs": [],
                        "env": [],
                        "cacheable": True,
                        "unsafe_effects": [],
                        "cache_streams": False,
                        "result_only": True,
                        "closure_reviewed": True,
                        "image": IMAGE,
                        "platform": "linux/amd64",
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    return load_manifest(path)


def _profile_payload() -> dict:
    return {
        "schema": 1,
        "task": "tests",
        "base_args": [],
        "targets": ["tests"],
        "static_inputs": ["pyproject.toml"],
        "session_closure": {
            "selectors": [],
            "fallback_files": ["conftest.py"],
        },
        "nodes": {
            "tests/test_sample.py::test_sample": {
                "reviewable": True,
                "fresh_required": False,
                "reason": None,
                "selectors": ["src/sample.py::run"],
                "fallback_files": [],
            }
        },
        "independence_review_sha256": "b" * 64,
    }


def _write_profile(root: Path, payload: object) -> Path:
    path = root / ".zerorun-pytest.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def test_profile_byte_and_depth_limits_reject_before_json_decode(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    manifest = _manifest(tmp_path)
    profile = tmp_path / ".zerorun-pytest.json"
    profile.write_bytes(b" " * 65)
    monkeypatch.setattr(pytest_profile, "_MAX_PROFILE_BYTES", 64)
    monkeypatch.setattr(
        pytest_profile.json,
        "loads",
        lambda *_args, **_kwargs: pytest.fail("oversized profile reached JSON decode"),
    )

    with pytest.raises(ConfigurationError, match="safety limit"):
        pytest_profile.load_pytest_profile(profile, manifest)

    profile.write_bytes((b"[" * (pytest_profile._MAX_JSON_DEPTH + 1)) + b"0")
    monkeypatch.setattr(pytest_profile, "_MAX_PROFILE_BYTES", 1024)
    with pytest.raises(ConfigurationError, match="JSON depth limit"):
        pytest_profile.load_pytest_profile(profile, manifest)


def test_profile_schema_bounds_nodes_lists_strings_and_members(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    manifest = _manifest(tmp_path)

    too_many_nodes = _profile_payload()
    too_many_nodes["nodes"]["tests/test_other.py::test_other"] = dict(
        too_many_nodes["nodes"]["tests/test_sample.py::test_sample"]
    )
    monkeypatch.setattr(pytest_profile, "_MAX_PROFILE_NODES", 1)
    with pytest.raises(ConfigurationError, match="node limit"):
        pytest_profile.load_pytest_profile(
            _write_profile(tmp_path, too_many_nodes), manifest
        )

    monkeypatch.setattr(pytest_profile, "_MAX_PROFILE_NODES", 25_000)
    profile = _profile_payload()
    profile["nodes"]["tests/test_sample.py::test_sample"]["selectors"] = [
        "src/sample.py::one",
        "src/sample.py::two",
    ]
    monkeypatch.setattr(pytest_profile, "_MAX_CLOSURE_ITEMS", 1)
    with pytest.raises(ConfigurationError, match="1-item limit"):
        pytest_profile.load_pytest_profile(_write_profile(tmp_path, profile), manifest)

    monkeypatch.setattr(pytest_profile, "_MAX_CLOSURE_ITEMS", 25_000)
    profile = _profile_payload()
    profile["nodes"]["tests/test_sample.py::test_sample"]["unexpected"] = []
    with pytest.raises(ConfigurationError, match="unsupported members"):
        pytest_profile.load_pytest_profile(_write_profile(tmp_path, profile), manifest)

    profile = _profile_payload()
    profile["targets"] = ["x" * (pytest_profile._MAX_STRING_CHARS + 1)]
    with pytest.raises(ConfigurationError, match="overlong string"):
        pytest_profile.load_pytest_profile(_write_profile(tmp_path, profile), manifest)


def test_profile_rejects_ambiguous_flags_and_ignored_closure(
    tmp_path: Path,
) -> None:
    manifest = _manifest(tmp_path)
    profile = _profile_payload()
    node = profile["nodes"]["tests/test_sample.py::test_sample"]
    node["reviewable"] = "yes"
    with pytest.raises(ConfigurationError, match="review flags must be booleans"):
        pytest_profile.load_pytest_profile(_write_profile(tmp_path, profile), manifest)

    profile = _profile_payload()
    node = profile["nodes"]["tests/test_sample.py::test_sample"]
    node.update(reviewable=False, fresh_required=True)
    with pytest.raises(ConfigurationError, match="ignored closure members"):
        pytest_profile.load_pytest_profile(_write_profile(tmp_path, profile), manifest)


@pytest.mark.parametrize(
    "arguments",
    (
        ["-q"],
        ["tests/extra.py"],
        ["--"],
        ["@pytest.args"],
        ["-c", "custom.ini"],
        ["-ccustom.ini"],
        ["-c=custom.ini"],
        ["--config-file", "custom.ini"],
        ["--config-file=custom.ini"],
    ),
)
def test_profile_requires_exactly_empty_base_args(
    tmp_path: Path,
    arguments: list[str],
) -> None:
    manifest = _manifest(tmp_path)
    profile = _profile_payload()
    profile["base_args"] = arguments

    with pytest.raises(
        ConfigurationError,
        match="empty profile base_args",
    ):
        pytest_profile.load_pytest_profile(_write_profile(tmp_path, profile), manifest)


@pytest.mark.parametrize(
    "suffix",
    (
        ["-q"],
        ["tests/extra.py"],
        ["--"],
        ["@pytest.args"],
        ["-c", "custom.ini"],
        ["-ccustom.ini"],
        ["-c=custom.ini"],
        ["--config-file", "custom.ini"],
        ["--config-file=custom.ini"],
        ["-p", "unreviewed_plugin"],
    ),
)
def test_profile_rejects_every_unreviewed_task_command_suffix(
    tmp_path: Path,
    suffix: list[str],
) -> None:
    manifest = _manifest(tmp_path)
    raw_manifest = json.loads(manifest.path.read_text(encoding="utf-8"))
    raw_manifest["tasks"]["tests"]["command"].extend(suffix)
    manifest.path.write_text(json.dumps(raw_manifest), encoding="utf-8")
    changed_manifest = load_manifest(manifest.path)

    with pytest.raises(
        ConfigurationError,
        match="unsupported pytest command arguments",
    ):
        pytest_profile.load_pytest_profile(
            _write_profile(tmp_path, _profile_payload()),
            changed_manifest,
        )


@pytest.mark.parametrize("name", ("PYTEST_ADDOPTS", "PYTEST_PLUGINS"))
def test_profile_rejects_pytest_control_environment(
    tmp_path: Path,
    name: str,
) -> None:
    manifest = _manifest(tmp_path)
    raw_manifest = json.loads(manifest.path.read_text(encoding="utf-8"))
    raw_manifest["tasks"]["tests"]["env"] = [name]
    manifest.path.write_text(json.dumps(raw_manifest), encoding="utf-8")
    changed_manifest = load_manifest(manifest.path)

    with pytest.raises(
        ConfigurationError,
        match="unsupported pytest control environment",
    ):
        pytest_profile.load_pytest_profile(
            _write_profile(tmp_path, _profile_payload()),
            changed_manifest,
        )


def test_generated_managed_task_is_the_only_supported_extended_command() -> None:
    from zerorun.oci import FIXED_CONTAINER_ENV
    from zerorun.pytest_setup import managed_task

    task = managed_task(IMAGE, {})
    assert pytest_profile.validate_pytest_execution_contract(
        task,
        base_args=(),
        field="generated managed task",
    ) == (
        "sh",
        ".zerorun-env/bin/python",
        "-m",
        "pytest",
        "-p",
        "no:cacheprovider",
    )
    assert pytest_profile.PYTEST_RESERVED_ENV_NAMES.isdisjoint(
        FIXED_CONTAINER_ENV
    )


def test_profile_accepts_complete_explicit_review_metadata(tmp_path: Path) -> None:
    manifest = _manifest(tmp_path)
    profile = _profile_payload()
    profile.update(
        {
            "candidate_sha256": "c" * 64,
            "review_record_sha256": "b" * 64,
            "review_schema": "zerorun-pytest-review-v1",
            "review_scope": {
                "candidate_node_count": 1,
                "candidate_reviewable_nodes": 1,
                "fresh_required_nodes": 0,
            },
        }
    )

    loaded = pytest_profile.load_pytest_profile(
        _write_profile(tmp_path, profile), manifest
    )
    assert tuple(loaded.nodes) == ("tests/test_sample.py::test_sample",)


def test_profile_parse_cache_reuses_exact_stable_bytes_as_immutable_value(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest = _manifest(tmp_path)
    path = _write_profile(tmp_path, _profile_payload())
    pytest_profile.clear_pytest_profile_cache()
    first = pytest_profile.load_pytest_profile(path, manifest)
    with pytest.raises(TypeError, match="immutable"):
        first.nodes["tests/test_sample.py::test_sample"]["reviewable"] = False
    with pytest.raises(AttributeError):
        first.nodes["tests/test_sample.py::test_sample"]["selectors"].append(
            "src/attacker.py::mutated"
        )

    monkeypatch.setattr(
        pytest_profile,
        "_preflight_json_bytes",
        lambda _raw: pytest.fail("byte-identical cached profile was reparsed"),
    )
    second = pytest_profile.load_pytest_profile(path, manifest)

    assert second is first
    assert second.profile_sha256 == first.profile_sha256
    assert second.nodes["tests/test_sample.py::test_sample"]["selectors"] == (
        "src/sample.py::run",
    )


def test_profile_parse_cache_is_thread_safe_and_deeply_immutable(
    tmp_path: Path,
) -> None:
    from concurrent.futures import ThreadPoolExecutor

    manifest = _manifest(tmp_path)
    path = _write_profile(tmp_path, _profile_payload())
    pytest_profile.clear_pytest_profile_cache()
    expected = pytest_profile.load_pytest_profile(path, manifest)

    with ThreadPoolExecutor(max_workers=8) as executor:
        loaded = list(
            executor.map(
                lambda _index: pytest_profile.load_pytest_profile(path, manifest),
                range(32),
            )
        )

    assert all(item is expected for item in loaded)
    with pytest.raises(TypeError, match="immutable"):
        expected.session_closure["selectors"] = ()


def test_profile_mapping_cannot_be_mutated_through_dict_base_api_and_hashes_canonically(
    tmp_path: Path,
) -> None:
    from zerorun import pytest_runtime

    manifest = _manifest(tmp_path)
    path = _write_profile(tmp_path, _profile_payload())
    pytest_profile.clear_pytest_profile_cache()
    loaded = pytest_profile.load_pytest_profile(path, manifest)
    row = loaded.nodes["tests/test_sample.py::test_sample"]

    # A dict subclass is not immutable: dict.__setitem__ bypasses overridden
    # mutators. Validated profiles use a non-dict Mapping backed by a read-only
    # proxy, so that base-class escape hatch is structurally unavailable.
    assert not isinstance(row, dict)
    with pytest.raises(TypeError):
        dict.__setitem__(row, "reviewable", False)
    with pytest.raises(TypeError, match="immutable"):
        row["reviewable"] = False
    assert row["reviewable"] is True

    plain = {
        "node": {
            "selectors": ["src/sample.py::run"],
            "reviewable": True,
        }
    }
    frozen = pytest_profile._freeze_json(plain)
    assert frozen == plain
    assert pytest_runtime._canonical_sha256(
        frozen, label="frozen profile value"
    ) == pytest_runtime._canonical_sha256(plain, label="plain profile value")


def test_profile_parse_cache_rejects_same_size_restored_mtime_rewrite(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    manifest = _manifest(tmp_path)
    payload = _profile_payload()
    path = _write_profile(tmp_path, payload)
    pytest_profile.clear_pytest_profile_cache()
    original = pytest_profile.load_pytest_profile(path, manifest)
    before = path.stat()

    payload["independence_review_sha256"] = "c" * 64
    replacement = json.dumps(payload)
    assert len(replacement.encode("utf-8")) == before.st_size
    path.write_text(replacement, encoding="utf-8")
    os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns))
    preflight_calls = 0
    real_preflight = pytest_profile._preflight_json_bytes

    def counted_preflight(raw: bytes) -> None:
        nonlocal preflight_calls
        preflight_calls += 1
        real_preflight(raw)

    monkeypatch.setattr(pytest_profile, "_preflight_json_bytes", counted_preflight)
    changed = pytest_profile.load_pytest_profile(path, manifest)

    assert changed.profile_sha256 != original.profile_sha256
    assert changed.independence_review_sha256 == "c" * 64
    assert preflight_calls == 1


def test_profile_source_review_requires_exact_reviewable_node_anchors(
    tmp_path: Path,
) -> None:
    manifest = _manifest(tmp_path)
    profile = _profile_payload()
    profile["source_review"] = {
        "schema": pytest_profile.PYTEST_SOURCE_REVIEW_SCHEMA,
        "profiler_sha256": "1" * 64,
        "collection_plugin_sha256": "2" * 64,
        "static_inputs_sha256": "3" * 64,
        "session_closure_sha256": "4" * 64,
        "node_closure_sha256": {
            "tests/test_sample.py::test_sample": "5" * 64,
        },
    }
    loaded = pytest_profile.load_pytest_profile(
        _write_profile(tmp_path, profile), manifest
    )
    assert loaded.source_review == profile["source_review"]

    profile["source_review"]["node_closure_sha256"] = {}
    with pytest.raises(ConfigurationError, match="do not match reviewable nodes"):
        pytest_profile.load_pytest_profile(
            _write_profile(tmp_path, profile), manifest
        )


@pytest.mark.parametrize("mutation", ["truncate", "grow", "rewrite"])
def test_profile_rejects_in_place_mutation_during_read(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    mutation: str,
) -> None:
    manifest = _manifest(tmp_path)
    path = tmp_path / ".zerorun-pytest.json"
    original_bytes = json.dumps(_profile_payload()).encode("utf-8")
    path.write_bytes(original_bytes)
    real_read = pytest_profile.os.read
    mutated = False

    def racing_read(descriptor: int, size: int) -> bytes:
        nonlocal mutated
        if not mutated:
            mutated = True
            before = path.stat()
            if mutation == "truncate":
                replacement = original_bytes[:-1]
            elif mutation == "grow":
                replacement = original_bytes + b" "
            else:
                replacement = b"[" + original_bytes[1:]
            path.write_bytes(replacement)
            os.utime(
                path,
                ns=(before.st_atime_ns, before.st_mtime_ns + 1_000_000_000),
            )
        return real_read(descriptor, size)

    monkeypatch.setattr(pytest_profile.os, "read", racing_read)
    with pytest.raises(ConfigurationError, match="changed while it was being read"):
        pytest_profile.load_pytest_profile(path, manifest)
