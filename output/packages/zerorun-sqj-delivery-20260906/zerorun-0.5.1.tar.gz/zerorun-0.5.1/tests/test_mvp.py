from __future__ import annotations

import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from zerorun.manifest import load_manifest
from zerorun.fingerprint import task_fingerprint
from zerorun.model import ConfigurationError
from zerorun.runner import run_task
from zerorun.store import Store


class ZeroRunMvpTests(unittest.TestCase):
    def make_project(
        self,
        script: str,
        *,
        unsafe_effects: list[str] | None = None,
        inputs: list[str] | None = None,
        outputs: list[str] | None = None,
        env: list[str] | None = None,
        cache_streams: bool = True,
        result_normalizer: str | None = None,
        command: list[str] | None = None,
    ):
        temporary = tempfile.TemporaryDirectory()
        root = Path(temporary.name)
        (root / "task.py").write_text(script, encoding="utf-8")
        (root / "input.txt").write_text("alpha\n", encoding="utf-8")
        manifest_data = {
            "version": 1,
            "tasks": {
                "work": {
                    "command": command or [sys.executable, "task.py"],
                    "inputs": inputs or ["task.py", "input.txt"],
                    "outputs": outputs or ["out.txt"],
                    "cacheable": True,
                    "unsafe_effects": unsafe_effects or [],
                    "env": env or [],
                    "cache_streams": cache_streams,
                    **({"result_normalizer": result_normalizer} if result_normalizer else {}),
                }
            },
        }
        path = root / ".zerorun.json"
        path.write_text(json.dumps(manifest_data), encoding="utf-8")
        manifest = load_manifest(path)
        return temporary, manifest, manifest.tasks["work"]

    def execute(self, manifest, task, **kwargs):
        return run_task(manifest, task, stdout=io.BytesIO(), stderr=io.BytesIO(), **kwargs)

    def test_miss_then_hit_restores_output(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "data=Path('input.txt').read_text()\n"
            "Path('out.txt').write_text(data.upper())\n"
            "print('built')\n"
        )
        self.addCleanup(temporary.cleanup)

        first = self.execute(manifest, task)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual((manifest.root / "out.txt").read_text(), "ALPHA\n")

        (manifest.root / "out.txt").unlink()
        second = self.execute(manifest, task)
        self.assertEqual(second.status, "HIT_REPLAYED")
        self.assertEqual((manifest.root / "out.txt").read_text(), "ALPHA\n")
        # Very small tasks can complete faster than cache lookup and output
        # restoration.  The public metric is intentionally clamped at zero,
        # so a successful replay must be non-negative rather than strictly
        # positive.
        self.assertGreaterEqual(second.saved_ms, 0)

    def test_input_change_invalidates_key(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('out.txt').write_text(Path('input.txt').read_text())\n"
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        (manifest.root / "input.txt").write_text("beta\n", encoding="utf-8")
        second = self.execute(manifest, task)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "MISS_EXECUTED")
        self.assertNotEqual(first.cache_key, second.cache_key)
        self.assertEqual((manifest.root / "out.txt").read_text(), "beta\n")

    def test_unsafe_effect_forces_execution(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('out.txt').write_text('network-like')\n",
            unsafe_effects=["network"],
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        second = self.execute(manifest, task)
        self.assertEqual(first.status, "BYPASS_UNSAFE")
        self.assertEqual(second.status, "BYPASS_UNSAFE")
        self.assertIn("network", first.reason or "")

    def test_verify_quarantines_nondeterministic_output(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "import secrets\n"
            "Path('out.txt').write_text(secrets.token_hex())\n"
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        verified = self.execute(manifest, task, verify=True)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(verified.status, "VERIFY_MISMATCH")
        self.assertEqual(verified.exit_code, 86)
        self.assertTrue((manifest.root / ".zerorun" / "cache" / first.cache_key / "QUARANTINED").is_file())

    def test_pytest_junit_normalizer_stabilizes_only_report_timing_metadata(self):
        temporary, manifest, task = self.make_project(
            "import time\n"
            "from pathlib import Path\n"
            "duration = f'{time.time() % 10:.6f}'\n"
            "Path('report.xml').write_text("
            "f'<testsuites time=\\\"{duration}\\\" timestamp=\\\"2026-08-27T00:00:00\\\">'"
            "f'<testsuite time=\\\"{duration}\\\"><testcase time=\\\"{duration}\\\"><skipped>{Path.cwd()}</skipped></testcase></testsuite></testsuites>'"
            ")\n"
            "print(f'1 passed in {duration}s')\n",
            outputs=["report.xml"],
            result_normalizer="pytest-junit-v1",
        )
        self.addCleanup(temporary.cleanup)
        first_stdout = io.BytesIO()
        first = run_task(manifest, task, stdout=first_stdout, stderr=io.BytesIO())
        verified_stdout = io.BytesIO()
        verified = run_task(manifest, task, verify=True, stdout=verified_stdout, stderr=io.BytesIO())
        report = (manifest.root / "report.xml").read_text(encoding="utf-8")
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(verified.status, "VERIFY_MATCH")
        self.assertEqual(first_stdout.getvalue(), b"1 passed in <duration>" + os.linesep.encode())
        self.assertEqual(verified_stdout.getvalue(), first_stdout.getvalue())
        self.assertNotIn("time=", report)
        self.assertNotIn("timestamp=", report)
        self.assertIn("&lt;workspace&gt;", report)

    def test_pytest_junit_normalizer_rejects_a_non_junit_output(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('report.txt').write_text('not XML')\n",
            outputs=["report.txt"],
            result_normalizer="pytest-junit-v1",
        )
        self.addCleanup(temporary.cleanup)
        result = self.execute(manifest, task)
        self.assertEqual(result.status, "REJECTED_NORMALIZATION")
        self.assertEqual(result.exit_code, 79)
        self.assertFalse((manifest.root / "report.txt").exists())

    def test_output_escape_is_rejected(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('out.txt').write_text('x')\n"
        )
        self.addCleanup(temporary.cleanup)
        raw = json.loads(manifest.path.read_text(encoding="utf-8"))
        raw["tasks"]["work"]["outputs"] = ["../escape.txt"]
        manifest.path.write_text(json.dumps(raw), encoding="utf-8")
        invalid = load_manifest(manifest.path)
        with self.assertRaises(ConfigurationError):
            self.execute(invalid, invalid.tasks["work"])

    def test_environment_value_is_never_persisted_raw(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('out.txt').write_text('x')\n"
        )
        self.addCleanup(temporary.cleanup)
        raw = json.loads(manifest.path.read_text(encoding="utf-8"))
        raw["tasks"]["work"]["env"] = ["ZERORUN_TEST_SECRET"]
        raw["tasks"]["work"]["command"].append("argv-secret-do-not-store")
        manifest.path.write_text(json.dumps(raw), encoding="utf-8")
        with patch.dict("os.environ", {"ZERORUN_TEST_SECRET": "do-not-store-this"}):
            updated = load_manifest(manifest.path)
            key, fingerprint = task_fingerprint(updated, updated.tasks["work"])
            encoded = json.dumps(fingerprint)
            self.assertNotIn("do-not-store-this", encoded)
            self.assertIn("sha256", encoded)
            result = self.execute(updated, updated.tasks["work"])
            metadata = (updated.root / ".zerorun" / "cache" / key / "metadata.json").read_text(encoding="utf-8")
            self.assertEqual(result.status, "MISS_EXECUTED")
            self.assertNotIn("do-not-store-this", metadata)
            self.assertNotIn("argv-secret-do-not-store", metadata)

    def test_hit_replays_stdout_and_stderr_byte_for_byte(self):
        temporary, manifest, task = self.make_project(
            "import sys\n"
            "from pathlib import Path\n"
            "Path('out.txt').write_text('ok')\n"
            "sys.stdout.buffer.write(b'out\\x00bytes')\n"
            "sys.stderr.buffer.write(b'err\\xffbytes')\n"
        )
        self.addCleanup(temporary.cleanup)
        first_stdout, first_stderr = io.BytesIO(), io.BytesIO()
        first = run_task(manifest, task, stdout=first_stdout, stderr=first_stderr)
        (manifest.root / "out.txt").unlink()
        hit_stdout, hit_stderr = io.BytesIO(), io.BytesIO()
        second = run_task(manifest, task, stdout=hit_stdout, stderr=hit_stderr)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "HIT_REPLAYED")
        self.assertEqual(hit_stdout.getvalue(), first_stdout.getvalue())
        self.assertEqual(hit_stderr.getvalue(), first_stderr.getvalue())

    def test_cacheable_task_requires_stream_capture(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "task.py").write_text("", encoding="utf-8")
        (root / "input.txt").write_text("x", encoding="utf-8")
        (root / ".zerorun.json").write_text(
            json.dumps(
                {
                    "version": 1,
                    "tasks": {
                        "work": {
                            "command": [sys.executable, "task.py"],
                            "inputs": ["input.txt"],
                            "outputs": ["out.txt"],
                            "cacheable": True,
                            "cache_streams": False,
                        }
                    },
                }
            ),
            encoding="utf-8",
        )
        with self.assertRaises(ConfigurationError):
            load_manifest(root / ".zerorun.json")

    def test_result_normalizer_is_part_of_the_cache_identity(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('out.txt').write_text('clean')\n"
        )
        self.addCleanup(temporary.cleanup)
        plain_key, _ = task_fingerprint(manifest, task)
        raw = json.loads(manifest.path.read_text(encoding="utf-8"))
        raw["tasks"]["work"]["result_normalizer"] = "pytest-junit-v1"
        manifest.path.write_text(json.dumps(raw), encoding="utf-8")
        normalized = load_manifest(manifest.path)
        normalized_key, _ = task_fingerprint(normalized, normalized.tasks["work"])
        self.assertNotEqual(plain_key, normalized_key)

    def test_direct_directory_input_hashes_descendants(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "Path('out.txt').write_text(Path('assets/nested/value.txt').read_text())\n",
            inputs=["assets"],
        )
        self.addCleanup(temporary.cleanup)
        asset = manifest.root / "assets" / "nested"
        asset.mkdir(parents=True)
        (asset / "value.txt").write_text("one", encoding="utf-8")
        first = self.execute(manifest, task)
        (asset / "value.txt").write_text("two", encoding="utf-8")
        second = self.execute(manifest, task)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "MISS_EXECUTED")
        self.assertNotEqual(first.cache_key, second.cache_key)
        self.assertEqual((manifest.root / "out.txt").read_text(encoding="utf-8"), "two")
        (asset / "added.txt").write_text("new dependency", encoding="utf-8")
        third = self.execute(manifest, task)
        self.assertEqual(third.status, "MISS_EXECUTED")
        self.assertNotEqual(second.cache_key, third.cache_key)

    def test_project_local_command_source_is_fingerprinted_even_if_omitted_from_inputs(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('out.txt').write_text('one')\n",
            inputs=["input.txt"],
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        (manifest.root / "task.py").write_text(
            "from pathlib import Path\nPath('out.txt').write_text('two')\n", encoding="utf-8"
        )
        second = self.execute(manifest, task)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "MISS_EXECUTED")
        self.assertNotEqual(first.cache_key, second.cache_key)
        self.assertEqual((manifest.root / "out.txt").read_text(encoding="utf-8"), "two")

    def test_command_output_argument_never_becomes_an_input(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "import sys\n"
            "Path(sys.argv[1]).write_text('stable')\n",
            command=[sys.executable, "task.py", "out.txt"],
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        second = self.execute(manifest, task)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "HIT_REPLAYED")
        self.assertEqual(first.cache_key, second.cache_key)

    def test_undeclared_environment_is_not_inherited(self):
        temporary, manifest, task = self.make_project(
            "import os\nfrom pathlib import Path\n"
            "Path('out.txt').write_text(os.environ.get('ZERORUN_UNDECLARED', 'missing'))\n"
        )
        self.addCleanup(temporary.cleanup)
        with patch.dict("os.environ", {"ZERORUN_UNDECLARED": "alpha"}, clear=False):
            first = self.execute(manifest, task)
        (manifest.root / "out.txt").unlink()
        with patch.dict("os.environ", {"ZERORUN_UNDECLARED": "beta"}, clear=False):
            second = self.execute(manifest, task)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "HIT_REPLAYED")
        self.assertEqual((manifest.root / "out.txt").read_text(encoding="utf-8"), "missing")

    def test_declared_environment_change_invalidates_key(self):
        temporary, manifest, task = self.make_project(
            "import os\nfrom pathlib import Path\nPath('out.txt').write_text(os.environ['ZERORUN_MODE'])\n",
            env=["ZERORUN_MODE"],
        )
        self.addCleanup(temporary.cleanup)
        with patch.dict("os.environ", {"ZERORUN_MODE": "alpha"}, clear=False):
            first = self.execute(manifest, task)
        with patch.dict("os.environ", {"ZERORUN_MODE": "beta"}, clear=False):
            second = self.execute(manifest, task)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "MISS_EXECUTED")
        self.assertNotEqual(first.cache_key, second.cache_key)
        self.assertEqual((manifest.root / "out.txt").read_text(encoding="utf-8"), "beta")

    def test_missing_or_failed_output_restores_preexisting_output_and_never_caches_it(self):
        temporary, manifest, task = self.make_project("# successful but deliberately produces no output\n")
        self.addCleanup(temporary.cleanup)
        output = manifest.root / "out.txt"
        output.write_text("old", encoding="utf-8")
        missing = self.execute(manifest, task)
        self.assertEqual(missing.status, "BYPASS_UNSUPPORTED_OUTPUT")
        self.assertEqual(output.read_text(encoding="utf-8"), "old")
        self.assertFalse((manifest.root / ".zerorun" / "cache" / missing.cache_key).exists())

        (manifest.root / "task.py").write_text(
            "from pathlib import Path\nPath('out.txt').write_text('new')\nraise SystemExit(7)\n", encoding="utf-8"
        )
        failed = self.execute(manifest, task)
        self.assertEqual(failed.status, "MISS_FAILED")
        self.assertEqual(failed.exit_code, 7)
        self.assertEqual(output.read_text(encoding="utf-8"), "old")

    def test_undeclared_project_write_bypasses_cache(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "p=Path('side.txt')\n"
            "n=int(p.read_text()) + 1 if p.exists() else 1\n"
            "p.write_text(str(n))\n"
            "Path('out.txt').write_text('ok')\n"
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        second = self.execute(manifest, task)
        self.assertEqual(first.status, "REJECTED_UNDECLARED_WRITES")
        self.assertEqual(second.status, "REJECTED_UNDECLARED_WRITES")
        self.assertEqual(first.exit_code, 78)
        self.assertFalse((manifest.root / "side.txt").exists())
        self.assertFalse((manifest.root / "out.txt").exists())

    def test_input_change_during_staged_execution_is_rejected_without_publish(self):
        temporary, manifest, task = self.make_project("from pathlib import Path\nPath('out.txt').write_text('seed')\n")
        self.addCleanup(temporary.cleanup)
        source_input = manifest.root / "input.txt"
        (manifest.root / "task.py").write_text(
            "from pathlib import Path\n"
            f"Path({str(source_input)!r}).write_text('changed during run')\n"
            "Path('out.txt').write_text('staged result')\n",
            encoding="utf-8",
        )
        result = self.execute(manifest, task)
        self.assertEqual(result.status, "REJECTED_INPUT_RACE")
        self.assertEqual(result.exit_code, 75)
        self.assertEqual(source_input.read_text(encoding="utf-8"), "changed during run")
        self.assertFalse((manifest.root / "out.txt").exists())
        self.assertFalse((manifest.root / ".zerorun" / "cache" / result.cache_key).exists())

    def test_project_lock_refuses_concurrent_cacheable_publication(self):
        temporary, manifest, task = self.make_project("from pathlib import Path\nPath('out.txt').write_text('ok')\n")
        self.addCleanup(temporary.cleanup)
        with Store(manifest.root).project_lock(timeout_seconds=0):
            result = self.execute(manifest, task, lock_timeout_seconds=0)
        self.assertEqual(result.status, "BYPASS_PROJECT_BUSY")
        self.assertEqual(result.exit_code, 75)
        self.assertFalse((manifest.root / "out.txt").exists())

    def test_declared_input_mutation_is_rejected_and_original_is_preserved(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "Path('input.txt').write_text('mutated')\n"
            "Path('out.txt').write_text('staged output')\n"
        )
        self.addCleanup(temporary.cleanup)
        result = self.execute(manifest, task)
        self.assertEqual(result.status, "REJECTED_UNDECLARED_WRITES")
        self.assertEqual(result.exit_code, 78)
        self.assertEqual((manifest.root / "input.txt").read_text(encoding="utf-8"), "alpha\n")
        self.assertFalse((manifest.root / "out.txt").exists())
        self.assertFalse((manifest.root / ".zerorun" / "cache" / result.cache_key).exists())

    def test_declared_input_deletion_is_rejected_and_original_is_preserved(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "Path('input.txt').unlink()\n"
            "Path('out.txt').write_text('staged output')\n"
        )
        self.addCleanup(temporary.cleanup)
        result = self.execute(manifest, task)
        self.assertEqual(result.status, "REJECTED_UNDECLARED_WRITES")
        self.assertEqual(result.exit_code, 78)
        self.assertEqual((manifest.root / "input.txt").read_text(encoding="utf-8"), "alpha\n")
        self.assertFalse((manifest.root / "out.txt").exists())

    def test_equals_style_project_input_and_output_arguments_are_staged(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "import sys\n"
            "args = dict(value.split('=', 1) for value in sys.argv[1:])\n"
            "Path(args['--output']).write_text(Path(args['--input']).read_text())\n",
            command=[sys.executable, "task.py", "--input=input.txt", "--output=out.txt"],
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        (manifest.root / "out.txt").unlink()
        second = self.execute(manifest, task)
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "HIT_REPLAYED")
        self.assertEqual((manifest.root / "out.txt").read_text(encoding="utf-8"), "alpha\n")

    def test_missing_cached_stream_is_quarantined_and_fresh_output_is_published(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('out.txt').write_text('clean')\n"
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        stream_path = manifest.root / ".zerorun" / "cache" / first.cache_key / "stderr.bin"
        stream_path.unlink()
        (manifest.root / "out.txt").unlink()
        second = self.execute(manifest, task)
        self.assertEqual(second.status, "BYPASS_INVALID_CACHE")
        self.assertEqual((manifest.root / "out.txt").read_text(encoding="utf-8"), "clean")
        self.assertTrue((manifest.root / ".zerorun" / "cache" / first.cache_key / "QUARANTINED").is_file())

    def test_concurrent_processes_serialize_one_miss_then_one_replay(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\n"
            "import hashlib\n"
            "value = Path('input.txt').read_bytes()\n"
            "for _ in range(600_000):\n"
            "    value = hashlib.sha256(value).digest()\n"
            "Path('out.txt').write_bytes(value)\n"
        )
        self.addCleanup(temporary.cleanup)
        driver = manifest.root / "driver.py"
        driver.write_text(
            "import io\n"
            "import json\n"
            "from zerorun.manifest import load_manifest\n"
            "from zerorun.runner import run_task\n"
            "manifest = load_manifest(__import__('pathlib').Path('.zerorun.json'))\n"
            "result = run_task(manifest, manifest.tasks['work'], stdout=io.BytesIO(), stderr=io.BytesIO())\n"
            "print(json.dumps(result.as_dict()))\n",
            encoding="utf-8",
        )
        source_root = Path(__file__).resolve().parents[1]
        environment = os.environ.copy()
        existing_path = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = str(source_root) + (os.pathsep + existing_path if existing_path else "")
        first = subprocess.Popen(
            [sys.executable, "driver.py"],
            cwd=manifest.root,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        time.sleep(0.05)
        second = subprocess.Popen(
            [sys.executable, "driver.py"],
            cwd=manifest.root,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        first_stdout, first_stderr = first.communicate(timeout=30)
        second_stdout, second_stderr = second.communicate(timeout=30)
        self.assertEqual(first.returncode, 0, first_stderr)
        self.assertEqual(second.returncode, 0, second_stderr)
        results = [json.loads(first_stdout), json.loads(second_stdout)]
        self.assertEqual(sorted(result["status"] for result in results), ["HIT_REPLAYED", "MISS_EXECUTED"])
        self.assertTrue((manifest.root / "out.txt").is_file())

    def test_force_conflict_quarantines_old_cache_entry(self):
        temporary, manifest, task = self.make_project("from pathlib import Path\nPath('out.txt').write_text('seed')\n")
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        def divergent(_task, cwd, *_args):
            (cwd / "out.txt").write_text("changed", encoding="utf-8")
            return 0, 1.0, b"", b""

        # Keep the same fingerprint while simulating a nondeterministic fresh result.
        with patch("zerorun.runner._execute", side_effect=divergent):
            forced = self.execute(manifest, task, force=True)
        self.assertEqual(forced.status, "FORCE_CONFLICT")
        self.assertEqual(forced.exit_code, 86)
        self.assertEqual((manifest.root / "out.txt").read_text(encoding="utf-8"), "changed")
        self.assertTrue((manifest.root / ".zerorun" / "cache" / first.cache_key / "QUARANTINED").is_file())

    def test_tampered_metadata_is_quarantined_and_never_replayed(self):
        temporary, manifest, task = self.make_project(
            "from pathlib import Path\nPath('out.txt').write_text('clean')\n"
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        metadata_path = manifest.root / ".zerorun" / "cache" / first.cache_key / "metadata.json"
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        metadata["outputs"] = []
        metadata_path.write_text(json.dumps(metadata), encoding="utf-8")
        (manifest.root / "out.txt").unlink()
        second = self.execute(manifest, task)
        self.assertNotEqual(second.status, "HIT_REPLAYED")
        self.assertEqual(second.status, "BYPASS_INVALID_CACHE")
        self.assertTrue((manifest.root / ".zerorun" / "cache" / first.cache_key / "QUARANTINED").is_file())

    def test_tampered_stream_is_quarantined_and_never_replayed(self):
        temporary, manifest, task = self.make_project(
            "import sys\nfrom pathlib import Path\nPath('out.txt').write_text('clean')\nsys.stdout.write('clean-stream')\n"
        )
        self.addCleanup(temporary.cleanup)
        first = self.execute(manifest, task)
        stream_path = manifest.root / ".zerorun" / "cache" / first.cache_key / "stdout.bin"
        stream_path.write_bytes(b"tampered")
        (manifest.root / "out.txt").unlink()
        second = self.execute(manifest, task)
        self.assertEqual(second.status, "BYPASS_INVALID_CACHE")
        self.assertTrue((manifest.root / ".zerorun" / "cache" / first.cache_key / "QUARANTINED").is_file())


if __name__ == "__main__":
    unittest.main()
