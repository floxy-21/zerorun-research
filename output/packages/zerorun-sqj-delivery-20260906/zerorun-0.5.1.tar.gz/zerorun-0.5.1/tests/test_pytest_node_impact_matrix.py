from __future__ import annotations

import json

import pytest

from tools import hermetic_pytest_experiment as experiment
from tools import pytest_node_impact_matrix as matrix
from tools.pytest_node_impact_matrix import classify_identity, _validate_closure_report


def test_classify_identity_reuses_only_exact_two_snapshot_match() -> None:
    fresh, reason = classify_identity("a" * 64, None, "a" * 64, None)
    assert fresh is False
    assert reason is None


def test_classify_identity_fails_closed_on_change_or_uncertainty() -> None:
    changed, changed_reason = classify_identity("a" * 64, None, "b" * 64, None)
    assert changed is True
    assert changed_reason == "reviewed node/session source identity changed"

    initial_uncertain, initial_reason = classify_identity(
        None,
        "initial selector missing",
        "b" * 64,
        None,
    )
    assert initial_uncertain is True
    assert initial_reason == "initial selector missing"

    final_uncertain, final_reason = classify_identity(
        "a" * 64,
        None,
        None,
        "post-edit selector missing",
    )
    assert final_uncertain is True
    assert final_reason == "post-edit selector missing"


def test_matrix_requires_exact_session_closure() -> None:
    base = {
        "pass": True,
        "source_identity_verified": True,
        "authorizes_reuse": False,
        "result_phase_project_closure": True,
        "session_project_closure": True,
        "partitions": [
            {
                "partition": "terminal-core",
                "nodes": [],
                "session_result_closure": {
                    "selectors": [],
                    "fallback_files": [],
                },
            }
        ],
    }
    assert _validate_closure_report(base) == base["partitions"]

    missing = {
        **base,
        "partitions": [{"partition": "terminal-core", "nodes": []}],
    }
    with pytest.raises(RuntimeError, match="session_result_closure"):
        _validate_closure_report(missing)


def test_matrix_rejects_authorizing_or_unverified_input() -> None:
    with pytest.raises(RuntimeError, match="source identity verification"):
        _validate_closure_report(
            {
                "pass": False,
                "source_identity_verified": False,
                "authorizes_reuse": False,
            }
        )

    with pytest.raises(RuntimeError, match="unexpectedly authorizes reuse"):
        _validate_closure_report(
            {
                "pass": True,
                "source_identity_verified": True,
                "authorizes_reuse": True,
                "result_phase_project_closure": True,
                "session_project_closure": True,
                "partitions": [],
            }
        )


def test_historical_profile_does_not_load_canonical_reviewed_manifest(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    target = tmp_path / "testing" / "test_example.py"
    target.parent.mkdir(parents=True)
    target.write_text("def test_example():\n    assert True\n", encoding="utf-8")
    partition = experiment.Partition(
        "candidate",
        ("testing/test_example.py",),
        frozenset(),
    )

    monkeypatch.setattr(matrix.experiment, "PARTITIONS", (partition,))
    monkeypatch.setattr(
        matrix.experiment,
        "_task_command",
        lambda _partition: ["bash", "-c", "true"],
    )

    def fail_if_manifest_is_used(_root) -> None:
        raise AssertionError("historical profile must not load canonical reviewed manifest")

    monkeypatch.setattr(matrix.experiment, "write_manifest", fail_if_manifest_is_used)
    monkeypatch.setattr(matrix, "hermetic_environment", lambda _task: ({}, {}))
    monkeypatch.setattr(
        matrix.scoped_probe,
        "run_result_profile",
        lambda _root, _partition, _environment: ([], {}, 1.25),
    )
    monkeypatch.setattr(
        matrix.result_probe,
        "_result_partition_summary",
        lambda _partition, _collected, _calls, _elapsed: {"partition": "candidate"},
    )
    monkeypatch.setattr(
        matrix.closure_audit,
        "_partition_closures",
        lambda _root, _row: {
            "partition": "candidate",
            "nodes": [],
            "session_result_closure": {"selectors": [], "fallback_files": []},
        },
    )

    rows, total_profile_ms = matrix._profile_case_partitions(tmp_path)

    assert total_profile_ms == 1.25
    assert rows[0]["partition"] == "candidate"
    assert rows[0]["profile_wall_ms"] == 1.25


def test_historical_profile_fails_closed_when_partition_target_is_missing(tmp_path) -> None:
    partition = experiment.Partition(
        "candidate",
        ("testing/does_not_exist.py",),
        frozenset(),
    )
    with pytest.raises(RuntimeError, match="historical pytest targets missing"):
        matrix._profiling_task(tmp_path, partition)


def test_select_cases_is_exact_ordered_and_duplicate_free() -> None:
    selected = matrix.select_cases([10190, 8749])
    assert [case.pr for case in selected] == [8749, 10190]

    with pytest.raises(RuntimeError, match="duplicates"):
        matrix.select_cases([8749, 8749])
    with pytest.raises(RuntimeError, match="unknown"):
        matrix.select_cases([1])


def _case_row(case: experiment.PatchCase) -> dict[str, object]:
    return {
        "pr": case.pr,
        "area": case.area,
        "merge_sha": case.merge_sha,
        "pre_merge_sha": "a" * 40,
        "source_tree_sha": "b" * 40,
        "patch_sha256": "c" * 64,
        "head_sha": "d" * 40,
        "baseline_profile_wall_ms": 1.0,
        "baseline_closure_source": "same-case-pre-merge-tree",
        "candidate_source_fresh_nodes": 1,
        "candidate_source_reusable_nodes": 9,
        "candidate_source_reuse_percent": 90.0,
        "session_uncertain_partitions": 0,
        "session_changed_partitions": 0,
        "forced_fresh_nodes": 0,
        "total_nodes": 10,
        "partitions": [],
    }


def test_aggregate_requires_and_preserves_exact_frozen_corpus(tmp_path) -> None:
    reference = {"pr": experiment.PATCH_CASES[0].pr, "patch_sha256": "e" * 64}
    for case in experiment.PATCH_CASES:
        shard = matrix._build_report(
            reference_case=reference,
            cases=[_case_row(case)],
        )
        (tmp_path / f"zerorun-pytest-node-impact-case-{case.pr}.json").write_text(
            json.dumps(shard),
            encoding="utf-8",
        )

    output = tmp_path / "aggregate.json"
    assert matrix.aggregate_matrix(tmp_path, output) == 0
    aggregate = json.loads(output.read_text(encoding="utf-8"))
    assert aggregate["pass"] is True
    assert aggregate["complete_frozen_corpus"] is True
    assert aggregate["case_count"] == len(experiment.PATCH_CASES)
    assert aggregate["selected_prs"] == [case.pr for case in experiment.PATCH_CASES]
    assert aggregate["summary"]["candidate_source_reuse_percent"] == 90.0


def test_aggregate_fails_closed_when_any_frozen_case_is_missing(tmp_path) -> None:
    case = experiment.PATCH_CASES[0]
    shard = matrix._build_report(
        reference_case={"pr": case.pr},
        cases=[_case_row(case)],
    )
    (tmp_path / f"zerorun-pytest-node-impact-case-{case.pr}.json").write_text(
        json.dumps(shard),
        encoding="utf-8",
    )

    output = tmp_path / "aggregate.json"
    assert matrix.aggregate_matrix(tmp_path, output) == 1
    aggregate = json.loads(output.read_text(encoding="utf-8"))
    assert aggregate["pass"] is False
    assert "corpus mismatch" in aggregate["error"]
