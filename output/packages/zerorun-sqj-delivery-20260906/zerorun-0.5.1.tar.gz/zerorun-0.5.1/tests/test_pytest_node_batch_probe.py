from __future__ import annotations

import pytest

from tools.pytest_node_batch_probe import fresh_nodes_from_evidence


_PATCH = "a" * 64


def _impact() -> dict[str, object]:
    return {
        "pass": True,
        "case": {"pr": 8749, "patch_sha256": _PATCH},
        "partitions": [
            {
                "partition": "logging",
                "candidate_result_fresh_nodes": [
                    {"nodeid": "testing/logging/test_fixture.py::test_source"}
                ],
            },
            {
                "partition": "terminal-core",
                "candidate_result_fresh_nodes": [],
            },
        ],
    }


def _collection() -> dict[str, object]:
    return {
        "pass": True,
        "case": {"pr": 8749, "patch_sha256": _PATCH},
        "partitions": [
            {
                "partition": "logging",
                "post_edit_validation": {
                    "node_order_equal": True,
                    "added_nodes": [],
                    "removed_nodes": [],
                    "changed_identity_nodes": [],
                    "unsupported_parameter_nodes": [],
                },
            },
            {
                "partition": "terminal-core",
                "post_edit_validation": {
                    "node_order_equal": True,
                    "added_nodes": [],
                    "removed_nodes": [],
                    "changed_identity_nodes": [],
                    "unsupported_parameter_nodes": [
                        "testing/test_terminal.py::test_param[x]"
                    ],
                },
            },
        ],
    }


def test_fresh_union_includes_source_changes_and_unsupported_parameters() -> None:
    assert fresh_nodes_from_evidence(_impact(), _collection()) == {
        "logging": ["testing/logging/test_fixture.py::test_source"],
        "terminal-core": ["testing/test_terminal.py::test_param[x]"],
    }


def test_actual_collection_drift_fails_closed() -> None:
    collection = _collection()
    collection["partitions"][0]["post_edit_validation"]["changed_identity_nodes"] = [
        "testing/logging/test_fixture.py::test_source"
    ]
    with pytest.raises(RuntimeError, match="changed_identity_nodes"):
        fresh_nodes_from_evidence(_impact(), collection)


def test_evidence_must_match_exact_patch() -> None:
    collection = _collection()
    collection["case"]["patch_sha256"] = "b" * 64
    with pytest.raises(RuntimeError, match="different patch bytes"):
        fresh_nodes_from_evidence(_impact(), collection)
