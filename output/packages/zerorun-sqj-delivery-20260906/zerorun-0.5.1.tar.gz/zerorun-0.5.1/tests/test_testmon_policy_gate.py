import pytest

from research.novelty_checks.gate1h.testmon_policy_gate import compare, group_files


def test_grouping_preserves_native_order_and_rejects_interleaving():
    assert group_files(["a.py::x", "a.py::y", "b.py::z"]) == [["a.py::x", "a.py::y"], ["b.py::z"]]
    assert group_files([]) == []
    with pytest.raises(ValueError, match="noncontiguous"):
        group_files(["a.py::x", "b.py::y", "a.py::z"])


def test_missing_nodes_are_not_a_complete_false_green_claim():
    result = compare({"a": "passed"}, {"a": "passed", "b": "failed"})
    assert result["comparable"] and not result["inventory_equal"]
    assert result["missing_nodes"] == ["b"]
    assert not result["false_green"] and not result["outcomes_equal"]


def test_verdict_polarity_and_invalid_observations():
    assert compare({"a": "passed"}, {"a": "failed"})["false_green"]
    assert compare({"a": "error"}, {"a": "passed"})["false_negative"]
    assert compare(None, {"a": "passed"}) == {"comparable": False}
    assert compare({"a": "skipped"}, {"a": "passed"})["changed_nodes"] == ["a"]
