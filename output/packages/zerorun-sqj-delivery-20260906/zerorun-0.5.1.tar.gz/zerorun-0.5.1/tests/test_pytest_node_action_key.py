from __future__ import annotations

from pathlib import Path
import tempfile

import pytest

from tools.pytest_node_action_key import node_action_fingerprint
from zerorun.model import ConfigurationError, TaskSpec


_DIGEST = "a" * 64
_REVIEW = "b" * 64


def _root() -> tuple[tempfile.TemporaryDirectory, Path]:
    temporary = tempfile.TemporaryDirectory()
    root = Path(temporary.name)
    package = root / "src" / "_pytest"
    package.mkdir(parents=True)
    (package / "example.py").write_text(
        "NODE = 1\nSESSION = 1\n\n"
        "def node_helper():\n    return NODE\n\n"
        "def session_helper():\n    return SESSION\n",
        encoding="utf-8",
    )
    testing = root / "testing"
    testing.mkdir()
    (testing / "conftest.py").write_text("VALUE = 1\n", encoding="utf-8")
    return temporary, root


def _task() -> TaskSpec:
    return TaskSpec(
        name="terminal-core",
        command=("bash", "-c", "python -m pytest testing/test_terminal.py"),
        inputs=("testing/conftest.py",),
        outputs=(),
        env=(),
        cacheable=True,
        unsafe_effects=(),
        cache_streams=False,
        image="example.invalid/pytest@sha256:" + "c" * 64,
        platform="linux/amd64",
        result_only=True,
        closure_reviewed=True,
    )


def _collection(identity: str = _DIGEST) -> dict[str, object]:
    return {
        "nodeid": "testing/test_terminal.py::test_one",
        "identity_sha256": identity,
        "parameter_identity_supported": True,
    }


def _node_closure() -> dict[str, object]:
    return {
        "selectors": [
            "src/_pytest/example.py::@binding:NODE",
            "src/_pytest/example.py::node_helper",
        ],
        "fallback_files": [],
    }


def _session_closure() -> dict[str, object]:
    return {
        "selectors": [
            "src/_pytest/example.py::@binding:SESSION",
            "src/_pytest/example.py::session_helper",
        ],
        "fallback_files": [],
    }


def _fingerprint(root: Path, **overrides):
    kwargs = {
        "nodeid": "testing/test_terminal.py::test_one",
        "collection_item": _collection(),
        "collection_contract_sha256": "d" * 64,
        "node_closure": _node_closure(),
        "session_closure": _session_closure(),
        "runtime_identity": {"resolved_image": "sha256:" + "e" * 64},
        "environment_fingerprint": {},
        "independence_review_sha256": _REVIEW,
        "profile_sha256": "9" * 64,
    }
    kwargs.update(overrides)
    return node_action_fingerprint(root, _task(), **kwargs)


def test_node_action_key_is_stable_and_uses_synthetic_cache_task() -> None:
    temporary, root = _root()
    try:
        task_a, key_a, payload_a = _fingerprint(root)
        task_b, key_b, payload_b = _fingerprint(root)
    finally:
        temporary.cleanup()

    assert task_a.name.startswith("terminal-core::node::")
    assert task_a == task_b
    assert key_a == key_b
    assert payload_a == payload_b
    assert payload_a["policy"]["node_independence"] == "immutable-reviewed"
    assert "collection_contract_sha256" not in payload_a["collection"]


def test_node_action_key_changes_with_node_collection_identity_or_shared_static_input() -> None:
    temporary, root = _root()
    try:
        _, before, _ = _fingerprint(root)
        _, collection_changed, _ = _fingerprint(
            root,
            collection_item=_collection("f" * 64),
        )
        assert collection_changed != before

        (root / "testing" / "conftest.py").write_text("VALUE = 2\n", encoding="utf-8")
        _, static_changed, _ = _fingerprint(root)
        assert static_changed != before
    finally:
        temporary.cleanup()


def test_node_action_key_ignores_whole_collection_digest_when_node_identity_is_same() -> None:
    temporary, root = _root()
    try:
        _, before, payload_before = _fingerprint(
            root,
            collection_contract_sha256="d" * 64,
        )
        _, after, payload_after = _fingerprint(
            root,
            collection_contract_sha256="f" * 64,
        )
        assert after == before
        assert payload_after == payload_before
    finally:
        temporary.cleanup()


def test_node_action_key_changes_with_shared_session_source() -> None:
    temporary, root = _root()
    try:
        _, before, _ = _fingerprint(root)
        path = root / "src" / "_pytest" / "example.py"
        path.write_text(
            path.read_text(encoding="utf-8").replace("SESSION = 1", "SESSION = 2"),
            encoding="utf-8",
        )
        _, after, _ = _fingerprint(root)
        assert after != before
    finally:
        temporary.cleanup()


def test_node_action_key_refuses_missing_independence_review() -> None:
    temporary, root = _root()
    try:
        with pytest.raises(ConfigurationError, match="node-independence review identity"):
            _fingerprint(root, independence_review_sha256="")
    finally:
        temporary.cleanup()


def test_node_action_key_binds_exact_reviewed_profile() -> None:
    temporary, root = _root()
    try:
        _, before, _ = _fingerprint(root, profile_sha256="9" * 64)
        _, after, _ = _fingerprint(root, profile_sha256="8" * 64)
        assert after != before
        with pytest.raises(ConfigurationError, match="profile SHA-256"):
            _fingerprint(root, profile_sha256="")
    finally:
        temporary.cleanup()


def test_node_action_key_refuses_unsupported_parameter_identity() -> None:
    temporary, root = _root()
    try:
        collection = _collection()
        collection["parameter_identity_supported"] = False
        with pytest.raises(ConfigurationError, match="parameter identity is unsupported"):
            _fingerprint(root, collection_item=collection)
    finally:
        temporary.cleanup()
