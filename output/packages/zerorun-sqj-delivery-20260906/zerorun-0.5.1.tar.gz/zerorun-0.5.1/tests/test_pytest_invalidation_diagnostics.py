from __future__ import annotations

import unittest

from tools.pytest_invalidation_diagnostics import _case_summary


class PytestInvalidationDiagnosticsTests(unittest.TestCase):
    def test_summary_surfaces_source_projection_uncertainty(self) -> None:
        rows = {
            "terminal-core": {
                "invalidated": True,
                "source_projection_uncertainty": "reviewed module binding not found: _get_pos",
                "changed_input_files": [],
                "changed_input_symbols": [],
                "non_source_fingerprint_changes": [],
            },
            "unittest-only": {
                "invalidated": False,
                "changed_input_files": [],
                "changed_input_symbols": [],
                "non_source_fingerprint_changes": [],
            },
        }

        summary = _case_summary(9875, rows)

        self.assertEqual(summary["pr"], 9875)
        self.assertEqual(summary["invalidated"], ["terminal-core"])
        self.assertEqual(summary["changed_files"], 0)
        self.assertEqual(summary["changed_symbols"], 0)
        self.assertEqual(summary["projection_uncertainty_count"], 1)
        self.assertEqual(
            summary["projection_uncertainty"],
            {"terminal-core": "reviewed module binding not found: _get_pos"},
        )

    def test_summary_keeps_normal_source_changes_separate(self) -> None:
        rows = {
            "logging": {
                "invalidated": True,
                "changed_input_files": [{"path": "src/_pytest/logging.py"}],
                "changed_input_symbols": [
                    {"selector": "src/_pytest/logging.py::LogCaptureFixture.@class-state"}
                ],
                "non_source_fingerprint_changes": [],
            },
            "stable-python-api": {
                "invalidated": False,
                "changed_input_files": [],
                "changed_input_symbols": [],
                "non_source_fingerprint_changes": [],
            },
        }

        summary = _case_summary(8749, rows)

        self.assertEqual(summary["invalidated"], ["logging"])
        self.assertEqual(summary["changed_files"], 1)
        self.assertEqual(summary["changed_symbols"], 1)
        self.assertEqual(summary["projection_uncertainty_count"], 0)
        self.assertEqual(summary["projection_uncertainty"], {})


if __name__ == "__main__":
    unittest.main()
