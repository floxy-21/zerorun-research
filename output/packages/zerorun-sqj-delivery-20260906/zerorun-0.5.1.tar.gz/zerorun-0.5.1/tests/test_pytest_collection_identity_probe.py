from __future__ import annotations

from tools.pytest_collection_identity_probe import canonical_parameter, compare_collection


def _item(nodeid: str, digest: str, *, supported: bool = True) -> dict[str, object]:
    return {
        "nodeid": nodeid,
        "identity_sha256": digest,
        "parameter_identity_supported": supported,
    }


def test_canonical_parameter_accepts_only_explicit_deterministic_shapes() -> None:
    assert canonical_parameter(None) == {"supported": True, "value": ["none", None]}
    assert canonical_parameter(True) == {"supported": True, "value": ["bool", True]}
    assert canonical_parameter((1, "x"))["supported"] is True
    assert canonical_parameter({"b": 2, "a": [1, 2]})["value"] == [
        "dict",
        [["a", ["list", [["int", 1], ["int", 2]]]], ["b", ["int", 2]]],
    ]

    unsupported = canonical_parameter({1, 2})
    assert unsupported["supported"] is False
    assert "explicit deterministic canonicalizer" in str(unsupported["reason"])


def test_collection_comparison_requires_order_and_identity_equality() -> None:
    before = {
        "collection_sha256": "before",
        "items": [_item("a", "1"), _item("b", "2")],
    }
    after = {
        "collection_sha256": "after",
        "items": [_item("b", "2"), _item("a", "1")],
    }

    comparison = compare_collection(before, after)

    assert comparison["node_order_equal"] is False
    assert comparison["added_nodes"] == []
    assert comparison["removed_nodes"] == []
    assert comparison["changed_identity_nodes"] == []
    assert comparison["exact_collection_equal"] is False


def test_collection_comparison_marks_unsupported_parameters_uncertain() -> None:
    before = {
        "collection_sha256": "same",
        "items": [_item("a", "1")],
    }
    after = {
        "collection_sha256": "same",
        "items": [_item("a", "1", supported=False)],
    }

    comparison = compare_collection(before, after)

    assert comparison["unsupported_parameter_nodes"] == ["a"]
    assert comparison["stable_supported_nodes"] == []
    assert comparison["exact_collection_equal"] is False


def test_collection_comparison_reports_added_removed_and_changed_nodes() -> None:
    before = {
        "items": [_item("a", "1"), _item("b", "2")],
    }
    after = {
        "items": [_item("a", "9"), _item("c", "3")],
    }

    comparison = compare_collection(before, after)

    assert comparison["changed_identity_nodes"] == ["a"]
    assert comparison["removed_nodes"] == ["b"]
    assert comparison["added_nodes"] == ["c"]
    assert comparison["exact_collection_equal"] is False
