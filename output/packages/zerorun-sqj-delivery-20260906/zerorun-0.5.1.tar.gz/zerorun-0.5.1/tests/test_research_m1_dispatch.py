from __future__ import annotations

from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import shutil

import pytest

from research.artifact import validation
from tests.test_research_artifact import _manifest
from tools import research_m1_dispatch as dispatch


ROOT = Path(__file__).resolve().parents[1]


def _sha(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, allow_nan=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def _state(index: int) -> dict[str, object]:
    commit = _sha(f"commit-{index}")[:40]
    previous = _sha(f"commit-{index - 1}")[:40] if index else None
    return {
        "index": index,
        "commit_sha": commit,
        "tree_sha": _sha(f"tree-{index}")[:40],
        "first_parent_sha": previous,
        "committed_at_utc": f"2026-01-{index + 1:02d}T00:00:00Z",
        "test_target": {
            "argv": ["python", "-m", "pytest"],
            "source": "root",
            "source_sha256": _sha("target"),
        },
        "dependency_descriptor_sha256": _sha(f"dependency-{index}"),
        "runtime_image": f"example.invalid/python@sha256:{_sha(f'image-{index}')}",
        "runtime_recipe_sha256": _sha(f"recipe-{index}"),
    }


def _fixture_inputs(tmp_path: Path) -> tuple[Path, Path, Path]:
    manifest = {
        "schema": "zerorun.research-corpus.test-fixture.v1",
        "protocol_commit": "UNSET",
        "sampling": {"seed": "test-only-public-seed"},
        "repositories": [
            {
                "github_repository_id": 101,
                "canonical_full_name": "fixture/repository",
                "stratum": "S1",
                "selected_slot": 1,
                "states": [_state(0), _state(1), _state(2)],
            }
        ],
    }
    freeze = {
        "schema": "zerorun.protocol-freeze.test-fixture.v1",
        "status": "UNSET",
        "protocol_commit": "UNSET",
        "engine_commit": "UNSET",
        "test_only_fixture": True,
    }
    status = {
        "status": "NOT_RUN",
        "confirmatory_claims_authorized": False,
    }
    corpus_path = tmp_path / "corpus.json"
    freeze_path = tmp_path / "freeze.json"
    status_path = tmp_path / "STATUS.json"
    _write_json(corpus_path, manifest)
    _write_json(freeze_path, freeze)
    _write_json(status_path, status)
    return corpus_path, freeze_path, status_path


class Controller:
    def __init__(self, *, mismatch_condition: str | None = None) -> None:
        self.calls: list[str] = []
        self.oracle_calls: list[str] = []
        self.mismatch_condition = mismatch_condition
        self.mismatch_emitted = False


def _outcome(
    collection: list[str],
    executed: list[tuple[str, str]],
    reused: list[tuple[str, str]],
    *,
    overall_status: str = "passed",
) -> dict[str, object]:
    without_digests = {
        "schema": "zerorun.pytest-canonical-outcome.v1",
        "collection_node_ids": collection,
        "node_outcomes": [
            {"node_id": node_id, "outcome": outcome}
            for node_id, outcome in executed
        ],
        "reuse_claims": [
            {"node_id": node_id, "outcome": outcome}
            for node_id, outcome in reused
        ],
        "overall_status": overall_status,
    }
    collection_sha = hashlib.sha256(
        b"zerorun-pytest-collection-v1\0"
        + json.dumps(
            collection,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    outcome_sha = hashlib.sha256(
        b"zerorun-pytest-outcome-v1\0"
        + json.dumps(
            without_digests,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()
    return {
        **without_digests,
        "collection_sha256": collection_sha,
        "outcome_sha256": outcome_sha,
    }


class FakeAdapter:
    def __init__(self, condition: str, controller: Controller) -> None:
        self.condition = condition
        self.controller = controller
        self.adapter_id = f"fixture-{condition}-adapter-v1"

    def observe(self, request: dispatch.M1Request) -> dict[str, object]:
        assert request.condition == self.condition
        self.controller.calls.append(self.condition)
        root = request.evidence_root
        prefix = request.evidence_prefix
        stdout = root.joinpath(*Path(prefix, "stdout.bin").parts)
        stderr = root.joinpath(*Path(prefix, "stderr.bin").parts)
        stdout.parent.mkdir(parents=True, exist_ok=True)
        stdout_bytes = f"observed:{request.request_sha256}:stdout\n".encode()
        stderr_bytes = f"observed:{request.request_sha256}:stderr\n".encode()
        if stdout.exists():
            assert stdout.read_bytes() == stdout_bytes
        else:
            stdout.write_bytes(stdout_bytes)
        if stderr.exists():
            assert stderr.read_bytes() == stderr_bytes
        else:
            stderr.write_bytes(stderr_bytes)
        selector = self.condition != "direct"
        reused = 1 if selector else 0
        artifact_rows = [
            {
                "role": "stdout",
                "path": f"{prefix}stdout.bin",
                "sha256": hashlib.sha256(stdout_bytes).hexdigest(),
                "bytes": len(stdout_bytes),
            },
            {
                "role": "stderr",
                "path": f"{prefix}stderr.bin",
                "sha256": hashlib.sha256(stderr_bytes).hexdigest(),
                "bytes": len(stderr_bytes),
            },
        ]
        collection = ["tests/test_sample.py::test_a", "tests/test_sample.py::test_b"]
        outcome = _outcome(
            collection,
            [(collection[0], "passed")]
            if selector
            else [(node_id, "passed") for node_id in collection],
            [(collection[1], "passed")] if selector else [],
        )
        return {
            "schema": "zerorun.m1-adapter-observation.v1",
            "request_sha256": request.request_sha256,
            "adapter_id": self.adapter_id,
            "condition": self.condition,
            "repository_id": request.payload["repository"]["github_repository_id"],
            "transition": request.payload["transition"],
            "started_at_utc": "2026-09-05T00:00:00Z",
            "completed_at_utc": "2026-09-05T00:00:01Z",
            "status": "completed",
            "exit_code": 0,
            "telemetry": {
                "wall_ns": 1_000_000,
                "user_cpu_ns": 400_000,
                "system_cpu_ns": 100_000,
                "peak_rss_bytes": 10_000_000,
                "selection_ns": 100_000 if selector else 0,
                "collection_ns": 200_000,
                "execution_ns": 600_000,
                "bytes_read": 100,
                "bytes_written": 50,
                "cache_bytes": 1_000 if selector else 0,
            },
            "node_accounting": {
                "total_nodes": 2,
                "executed_nodes": 2 - reused,
                "reused_nodes": reused,
                "unknown_nodes": 0,
                "forced_fresh_nodes": 0,
            },
            "artifacts": artifact_rows,
            "outcome": outcome,
            "safety": None,
        }


class FakeOracleAdapter:
    adapter_id = "fixture-independent-oracle-v1"

    def __init__(self, controller: Controller) -> None:
        self.controller = controller

    def observe(self, request: dispatch.M1OracleRequest) -> dict[str, object]:
        condition = str(request.payload["selector_condition"])
        self.controller.oracle_calls.append(condition)
        mismatch = (
            condition == self.controller.mismatch_condition
            and not self.controller.mismatch_emitted
        )
        if mismatch:
            self.controller.mismatch_emitted = True
        collection = ["tests/test_sample.py::test_a", "tests/test_sample.py::test_b"]
        if mismatch:
            collection.append("tests/test_sample.py::test_oracle_only")
        outcome = _outcome(
            collection,
            [(node_id, "passed") for node_id in collection],
            [],
        )
        root = request.evidence_root
        prefix = request.evidence_prefix
        artifacts: list[dict[str, object]] = []
        for role in ("stdout", "stderr"):
            data = f"oracle:{role}:{request.request_sha256}\n".encode()
            path = root.joinpath(*Path(prefix, f"{role}.bin").parts)
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists():
                assert path.read_bytes() == data
            else:
                path.write_bytes(data)
            artifacts.append(
                {
                    "role": role,
                    "path": f"{prefix}{role}.bin",
                    "sha256": hashlib.sha256(data).hexdigest(),
                    "bytes": len(data),
                }
            )
        return {
            "schema": "zerorun.m1-oracle-observation.v1",
            "oracle_request_sha256": request.request_sha256,
            "adapter_id": self.adapter_id,
            "oracle_run_id": request.payload["oracle_run_id"],
            "oracle_for_run_id": request.payload["selector_run_id"],
            "repository_id": request.payload["repository"]["github_repository_id"],
            "transition": request.payload["transition"],
            "started_at_utc": "2026-09-05T00:00:01Z",
            "completed_at_utc": "2026-09-05T00:00:02Z",
            "status": "completed",
            "exit_code": 0,
            "outcome": outcome,
            "artifacts": artifacts,
            "provenance": {
                "source_identity": request.payload["source_identity"],
                "environment_identity": request.payload["environment_identity"],
                "target_sha256": request.payload["target_sha256"],
                "worktree_namespace": request.payload["worktree_namespace"],
                "cache_namespace": request.payload["cache_namespace"],
                "network_mode": "none",
                "condition_worktree_mounted": False,
                "condition_cache_mounted": False,
            },
        }


class AdapterRegistry(dict[str, FakeAdapter]):
    oracle_adapter: FakeOracleAdapter


def _adapters(controller: Controller | None = None) -> AdapterRegistry:
    controller = controller or Controller()
    result = AdapterRegistry({
        condition: FakeAdapter(condition, controller)
        for condition in dispatch.CONDITIONS
    })
    result.oracle_adapter = FakeOracleAdapter(controller)
    return result


def test_williams_schedule_is_deterministic_and_fully_balanced() -> None:
    first = dispatch.balanced_condition_orders("frozen-seed", 1234, 20)
    second = dispatch.balanced_condition_orders("frozen-seed", 1234, 20)
    assert first == second
    assert len(first) == 20
    position_counts = Counter(
        (condition, position)
        for row in first
        for position, condition in enumerate(row, 1)
    )
    assert set(position_counts.values()) == {4}
    carryover_counts = Counter(
        pair for row in first for pair in zip(row, row[1:])
    )
    expected_pairs = {
        (left, right)
        for left in dispatch.CONDITIONS
        for right in dispatch.CONDITIONS
        if left != right
    }
    assert set(carryover_counts) == expected_pairs
    assert set(carryover_counts.values()) == {4}


def test_unset_inputs_require_explicit_test_fixture_gate(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    output = tmp_path / "dispatch"
    with pytest.raises(dispatch.DispatchRefused, match="explicit test-only fixture"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=output,
            adapters=_adapters(),
        )
    assert not output.exists()

    before = status.read_bytes()
    result = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(),
        test_only_fixture=True,
        max_new_records=0,
    )
    assert result["status"] == "CHECKPOINTED"
    assert result["records_completed"] == 0
    assert result["records_planned"] == 10
    assert result["evidence_eligible"] is False
    assert status.read_bytes() == before


def test_strict_input_loader_rejects_duplicate_members_and_template_is_unique(
    tmp_path: Path,
) -> None:
    template = ROOT / "research/templates/protocol-freeze.template.json"
    loaded = dispatch._load_snapshot(template, label="protocol freeze template")
    assert loaded.value["sampling_seed"] == "UNSET"
    assert loaded.value["sampling_seed_source"] == "UNSET"
    assert loaded.value["oracle_policy_id"] == dispatch.ORACLE_POLICY_ID
    assert loaded.value["oracle_adapter_id"] == "UNSET"
    assert loaded.value["outcome_normalizer_id"] == dispatch.OUTCOME_NORMALIZER_ID
    assert loaded.value["oracle_execution"] == {
        "network_mode": "none",
        "worktree_policy": "dedicated-inode-disjoint-per-selector",
        "cache_policy": "empty-dedicated-per-selector",
        "condition_worktree_mounted": False,
        "condition_cache_mounted": False,
    }

    duplicate = tmp_path / "duplicate-freeze.json"
    duplicate.write_text(
        '{"schema":"first","schema":"second","status":"UNSET"}\n',
        encoding="utf-8",
        newline="\n",
    )
    with pytest.raises(dispatch.DispatchRefused, match="duplicate JSON object key: schema"):
        dispatch._load_snapshot(duplicate, label="duplicate protocol freeze")


def test_m1_observation_schemas_resolve_cross_schema_refs_offline(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    output = tmp_path / "schema-resolution"
    dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(),
        test_only_fixture=True,
        max_new_records=5,
    )
    selector = json.loads(
        next((output / "oracle-journal").rglob("01-selector.json")).read_text(
            encoding="utf-8"
        )
    )
    oracle = json.loads(
        next((output / "oracle-journal").rglob("02-oracle.json")).read_text(
            encoding="utf-8"
        )
    )
    report = validation.ValidationReport()
    catalog = validation.load_schema_catalog(ROOT / "research/schemas", report)
    for label, value, marker in (
        (
            "condition observation",
            selector["observation"],
            "zerorun.m1-adapter-observation.v1",
        ),
        (
            "condition outcome",
            selector["observation"]["outcome"],
            "zerorun.pytest-canonical-outcome.v1",
        ),
        (
            "oracle observation",
            oracle["observation"],
            "zerorun.m1-oracle-observation.v1",
        ),
        (
            "oracle outcome",
            oracle["observation"]["outcome"],
            "zerorun.pytest-canonical-outcome.v1",
        ),
    ):
        validation.validate_instance(value, marker, catalog, report, label)
    assert report.errors == []


def test_unavailable_stub_cannot_create_an_outcome(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    adapters = _adapters()
    adapters["zerorun"] = dispatch.UnavailableAdapter("zerorun")
    output = tmp_path / "dispatch"
    with pytest.raises(dispatch.AdapterUnavailable, match="unavailable stub"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=output,
            adapters=adapters,
            test_only_fixture=True,
        )
    assert not output.exists()


def test_dispatch_refuses_a_prepositioned_managed_namespace_file(
    tmp_path: Path,
) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    output = tmp_path / "dispatch"
    output.mkdir()
    checkpoint_trap = output / "checkpoints"
    checkpoint_trap.write_text("outside redirection trap\n", encoding="utf-8")

    with pytest.raises(dispatch.DispatchRefused, match="must be a real directory"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=output,
            adapters=_adapters(),
            test_only_fixture=True,
        )
    assert checkpoint_trap.read_text(encoding="utf-8") == "outside redirection trap\n"
    assert not (output / "RUN_IDENTITY.json").exists()


def test_append_only_resume_and_no_overwrite(tmp_path: Path) -> None:
    output = tmp_path / "dispatch"
    controller = Controller()
    corpus, freeze, status = _fixture_inputs(tmp_path)
    status_before = status.read_bytes()
    first = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(controller),
        test_only_fixture=True,
        max_new_records=3,
    )
    records = sorted((output / "records").rglob("*.json"))
    checkpoints = sorted((output / "checkpoints").glob("*.json"))
    immutable = {path.relative_to(output): path.read_bytes() for path in records + checkpoints}
    assert first["records_completed"] == 3
    assert len(controller.calls) == 3

    resumed_controller = Controller()
    second = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(resumed_controller),
        test_only_fixture=True,
        max_new_records=2,
    )
    assert second["records_completed"] == 5
    assert len(resumed_controller.calls) == 2
    assert second["adapter_calls_this_invocation"] == (
        len(resumed_controller.calls) + len(resumed_controller.oracle_calls)
    )
    for relative, content in immutable.items():
        assert (output / relative).read_bytes() == content
    assert status.read_bytes() == status_before


class SimulatedPowerLoss(BaseException):
    pass


def test_crash_after_record_before_checkpoint_recovers_without_reexecution(
    tmp_path: Path,
) -> None:
    output = tmp_path / "dispatch"
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller()

    def crash(_path: Path, _record: object) -> None:
        raise SimulatedPowerLoss

    with pytest.raises(SimulatedPowerLoss):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=output,
            adapters=_adapters(controller),
            test_only_fixture=True,
            after_record_published=crash,
    )
    assert len(list((output / "records").rglob("*.json"))) == 1
    assert list((output / "checkpoints").glob("*.json")) == []

    resumed = Controller()
    result = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(resumed),
        test_only_fixture=True,
        max_new_records=1,
    )
    assert result["records_completed"] == 2
    assert len(resumed.calls) == 1
    assert result["adapter_calls_this_invocation"] == (
        len(resumed.calls) + len(resumed.oracle_calls)
    )
    assert len(list((output / "checkpoints").glob("*.json"))) == 2


def test_crash_after_selector_journal_resumes_with_oracle_only(tmp_path: Path) -> None:
    output = tmp_path / "selector-crash"
    corpus, freeze, status = _fixture_inputs(tmp_path)
    first = Controller()

    def crash(_path: Path, _record: object) -> None:
        raise SimulatedPowerLoss

    with pytest.raises(SimulatedPowerLoss):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=output,
            adapters=_adapters(first),
            test_only_fixture=True,
            after_selector_published=crash,
        )
    assert first.calls == ["pytest-testmon"]
    assert first.oracle_calls == []
    assert len(list((output / "oracle-journal").rglob("01-selector.json"))) == 1
    assert list((output / "oracle-journal").rglob("02-oracle.json")) == []
    assert list((output / "records").rglob("*.json")) == []

    resumed = Controller()
    result = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(resumed),
        test_only_fixture=True,
        max_new_records=1,
    )
    assert resumed.calls == []
    assert resumed.oracle_calls == ["pytest-testmon"]
    assert result["records_completed"] == 1
    assert result["adapter_calls_this_invocation"] == 1


def test_crash_after_oracle_journal_resumes_without_reexecution(tmp_path: Path) -> None:
    output = tmp_path / "oracle-crash"
    corpus, freeze, status = _fixture_inputs(tmp_path)
    first = Controller()

    def crash(_path: Path, _record: object) -> None:
        raise SimulatedPowerLoss

    with pytest.raises(SimulatedPowerLoss):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=output,
            adapters=_adapters(first),
            test_only_fixture=True,
            after_oracle_published=crash,
        )
    assert first.calls == ["pytest-testmon"]
    assert first.oracle_calls == ["pytest-testmon"]
    assert len(list((output / "oracle-journal").rglob("01-selector.json"))) == 1
    assert len(list((output / "oracle-journal").rglob("02-oracle.json"))) == 1
    assert list((output / "records").rglob("*.json")) == []

    resumed = Controller()
    result = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(resumed),
        test_only_fixture=True,
        max_new_records=1,
    )
    assert resumed.calls == []
    assert resumed.oracle_calls == []
    assert result["records_completed"] == 1
    assert result["adapter_calls_this_invocation"] == 0


def test_first_safety_mismatch_stops_before_next_adapter_and_is_sticky(
    tmp_path: Path,
) -> None:
    output = tmp_path / "dispatch"
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller(mismatch_condition="zerorun")
    result = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(controller),
        test_only_fixture=True,
    )
    assert result["status"] == "SAFETY_STOP"
    assert result["safety_stop_reasons"] == ["collection_mismatch"]
    assert 1 <= len(controller.calls) <= 5
    assert len(list((output / "records").rglob("*.json"))) == len(controller.calls)
    assert (output / "SAFETY_STOP.json").is_file()

    resume_controller = Controller()
    resumed = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(resume_controller),
        test_only_fixture=True,
    )
    assert resumed["status"] == "SAFETY_STOP"
    assert resumed["adapter_calls_this_invocation"] == 0
    assert resume_controller.calls == []


class SelfGradingAdapter(FakeAdapter):
    def observe(self, request: dispatch.M1Request) -> dict[str, object]:
        observation = super().observe(request)
        observation["safety"] = {"oracle_valid": True}
        return observation


class DirectReusingAdapter(FakeAdapter):
    def observe(self, request: dispatch.M1Request) -> dict[str, object]:
        observation = super().observe(request)
        collection = ["tests/test_sample.py::test_a", "tests/test_sample.py::test_b"]
        observation["outcome"] = _outcome(
            collection,
            [(collection[0], "passed")],
            [(collection[1], "passed")],
        )
        observation["node_accounting"] = {
            "total_nodes": 2,
            "executed_nodes": 1,
            "reused_nodes": 1,
            "unknown_nodes": 0,
            "forced_fresh_nodes": 0,
        }
        return observation


class OracleNamespaceWritingAdapter(FakeAdapter):
    def observe(self, request: dispatch.M1Request) -> dict[str, object]:
        observation = super().observe(request)
        forbidden = request.evidence_root.joinpath(
            *Path(f"{request.evidence_prefix}oracle/condition-owned.bin").parts
        )
        forbidden.parent.mkdir(parents=True, exist_ok=True)
        forbidden.write_bytes(b"condition cannot own oracle evidence\n")
        return observation


class SharedOracleAdapter(FakeOracleAdapter):
    def observe(self, request: dispatch.M1OracleRequest) -> dict[str, object]:
        observation = super().observe(request)
        observation["oracle_run_id"] = "shared-oracle-run"
        return observation


class OracleBeforeSelectorAdapter(FakeOracleAdapter):
    def observe(self, request: dispatch.M1OracleRequest) -> dict[str, object]:
        observation = super().observe(request)
        observation["started_at_utc"] = "2026-09-04T23:59:59Z"
        return observation


class MalformedOutcomeOracle(FakeOracleAdapter):
    def observe(self, request: dispatch.M1OracleRequest) -> dict[str, object]:
        observation = super().observe(request)
        outcome = observation["outcome"]
        assert isinstance(outcome, dict)
        outcome["collection_node_ids"] = [
            "tests/test_sample.py::test_a",
            "tests/test_sample.py::test_a",
        ]
        return observation


class TraversalArtifactOracle(FakeOracleAdapter):
    def observe(self, request: dispatch.M1OracleRequest) -> dict[str, object]:
        observation = super().observe(request)
        artifacts = observation["artifacts"]
        assert isinstance(artifacts, list)
        artifacts[0]["path"] = f"{request.evidence_prefix}../stdout.bin"
        return observation


class ProvenanceMismatchOracle(FakeOracleAdapter):
    def __init__(self, controller: Controller, field: str) -> None:
        super().__init__(controller)
        self.field = field

    def observe(self, request: dispatch.M1OracleRequest) -> dict[str, object]:
        observation = super().observe(request)
        provenance = observation["provenance"]
        assert isinstance(provenance, dict)
        if self.field == "source_identity":
            source = dict(provenance["source_identity"])
            source["current_commit_sha"] = "0" * 40
            provenance["source_identity"] = source
        elif self.field == "environment_identity":
            environment = dict(provenance["environment_identity"])
            environment["runtime_recipe_sha256"] = "0" * 64
            provenance["environment_identity"] = environment
        elif self.field == "network_mode":
            provenance["network_mode"] = "bridge"
        elif self.field == "target_sha256":
            provenance["target_sha256"] = "0" * 64
        elif self.field == "worktree_namespace":
            provenance["worktree_namespace"] = request.payload[
                "condition_worktree_namespace"
            ]
        elif self.field == "cache_namespace":
            provenance["cache_namespace"] = request.payload["condition_cache_namespace"]
        elif self.field == "condition_worktree_mounted":
            provenance["condition_worktree_mounted"] = True
        elif self.field == "condition_cache_mounted":
            provenance["condition_cache_mounted"] = True
        else:  # pragma: no cover - protects fixture maintenance
            raise AssertionError(self.field)
        return observation


class SymlinkArtifactOracle(FakeOracleAdapter):
    def observe(self, request: dispatch.M1OracleRequest) -> dict[str, object]:
        observation = super().observe(request)
        artifacts = observation["artifacts"]
        assert isinstance(artifacts, list)
        stdout = request.evidence_root.joinpath(*Path(artifacts[0]["path"]).parts)
        target = stdout.with_name("actual-stdout.bin")
        stdout.replace(target)
        try:
            os.symlink(target.name, stdout)
        except OSError:
            target.replace(stdout)
            pytest.skip("file symlinks are unavailable on this platform")
        return observation


class DeletingProtectedInputAdapter(FakeAdapter):
    def __init__(
        self,
        condition: str,
        controller: Controller,
        protected_path: Path,
    ) -> None:
        super().__init__(condition, controller)
        self.protected_path = protected_path

    def observe(self, request: dispatch.M1Request) -> dict[str, object]:
        observation = super().observe(request)
        if self.protected_path.exists():
            self.protected_path.unlink()
        return observation


def test_protected_input_deletion_after_adapter_call_creates_sticky_stop(
    tmp_path: Path,
) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    status_bytes = status.read_bytes()
    controller = Controller()
    adapters = {
        condition: DeletingProtectedInputAdapter(condition, controller, status)
        for condition in dispatch.CONDITIONS
    }
    output = tmp_path / "protected-drift"
    result = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=adapters,
        oracle_adapter=FakeOracleAdapter(controller),
        test_only_fixture=True,
    )

    assert result["status"] == "SAFETY_STOP"
    assert result["safety_stop_reasons"] == ["protected_identity_drift"]
    assert result["records_completed"] == 0
    assert len(controller.calls) == 1
    assert list((output / "records").rglob("*.json")) == []
    stop = json.loads((output / "SAFETY_STOP.json").read_text(encoding="utf-8"))
    assert stop["trigger_record_path"] is None
    assert stop["trigger_record_sha256"] is None
    assert stop["reasons"] == ["protected_identity_drift"]

    status.write_bytes(status_bytes)
    resume_controller = Controller()
    resumed = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=_adapters(resume_controller),
        test_only_fixture=True,
    )
    assert resumed["status"] == "SAFETY_STOP"
    assert resumed["adapter_calls_this_invocation"] == 0
    assert resume_controller.calls == []


def test_condition_adapter_cannot_self_grade(
    tmp_path: Path,
) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller()
    adapters = _adapters(controller)
    adapters["zerorun"] = SelfGradingAdapter("zerorun", controller)
    with pytest.raises(dispatch.DispatchRefused, match="cannot self-grade"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "lying-adapter",
            adapters=adapters,
            test_only_fixture=True,
        )


def test_direct_condition_cannot_claim_reuse(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller()
    adapters = _adapters(controller)
    adapters["direct"] = DirectReusingAdapter("direct", controller)
    with pytest.raises(dispatch.DispatchRefused, match="direct full-suite condition"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "direct-reuse",
            adapters=adapters,
            test_only_fixture=True,
        )


def test_condition_adapter_cannot_prepopulate_oracle_namespace(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller()
    adapters = _adapters(controller)
    adapters["pytest-testmon"] = OracleNamespaceWritingAdapter(
        "pytest-testmon", controller
    )
    with pytest.raises(dispatch.DispatchRefused, match="reserved independent-oracle"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "oracle-namespace",
            adapters=adapters,
            test_only_fixture=True,
        )


def test_dispatcher_rejects_shared_oracle_identity(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller()
    with pytest.raises(dispatch.DispatchRefused, match="does not bind the exact selector request"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "shared-oracle",
            adapters=_adapters(controller),
            oracle_adapter=SharedOracleAdapter(controller),
            test_only_fixture=True,
        )


def test_dispatcher_rejects_oracle_started_before_selector_completion(
    tmp_path: Path,
) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller()
    with pytest.raises(dispatch.DispatchRefused, match="starts before selector completion"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "oracle-before-selector",
            adapters=_adapters(controller),
            oracle_adapter=OracleBeforeSelectorAdapter(controller),
            test_only_fixture=True,
        )


def test_independent_oracle_registry_and_normalizer_are_mandatory(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller()
    plain_registry = {
        condition: FakeAdapter(condition, controller)
        for condition in dispatch.CONDITIONS
    }
    with pytest.raises(dispatch.AdapterUnavailable, match="independent fresh oracle"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "missing-oracle",
            adapters=plain_registry,
            test_only_fixture=True,
        )

    class WrongNormalizer(dispatch.CanonicalOutcomeNormalizer):
        normalizer_id = "fixture-unfrozen-normalizer"

    with pytest.raises(dispatch.DispatchRefused, match="frozen canonical algorithm"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "wrong-normalizer",
            adapters=_adapters(controller),
            normalizer=WrongNormalizer(),
            test_only_fixture=True,
        )


def test_oracle_rejects_malformed_and_oversize_observations(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    malformed_controller = Controller()
    with pytest.raises(dispatch.DispatchRefused, match="duplicate node IDs"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "malformed-oracle",
            adapters=_adapters(malformed_controller),
            oracle_adapter=MalformedOutcomeOracle(malformed_controller),
            test_only_fixture=True,
        )

    oversize_controller = Controller()

    def lower_bound(_path: Path, _record: object) -> None:
        monkeypatch.setattr(dispatch, "MAX_INPUT_BYTES", 64)
        monkeypatch.setattr(dispatch, "_protected_unchanged", lambda *_args: True)

    with pytest.raises(dispatch.DispatchRefused, match="oracle observation exceeds"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "oversize-oracle",
            adapters=_adapters(oversize_controller),
            oracle_adapter=FakeOracleAdapter(oversize_controller),
            test_only_fixture=True,
            after_selector_published=lower_bound,
        )


def test_oracle_rejects_traversal_and_symlink_artifacts(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    traversal_controller = Controller()
    with pytest.raises(dispatch.DispatchRefused, match="safe POSIX relative path"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "traversal-oracle",
            adapters=_adapters(traversal_controller),
            oracle_adapter=TraversalArtifactOracle(traversal_controller),
            test_only_fixture=True,
        )

    symlink_controller = Controller()
    with pytest.raises(dispatch.DispatchRefused, match="must be a regular file"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / "symlink-oracle",
            adapters=_adapters(symlink_controller),
            oracle_adapter=SymlinkArtifactOracle(symlink_controller),
            test_only_fixture=True,
        )


@pytest.mark.parametrize(
    "field",
    [
        "source_identity",
        "environment_identity",
        "target_sha256",
        "network_mode",
        "worktree_namespace",
        "cache_namespace",
        "condition_worktree_mounted",
        "condition_cache_mounted",
    ],
)
def test_oracle_rejects_source_runtime_network_and_namespace_mismatch(
    tmp_path: Path,
    field: str,
) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    controller = Controller()
    with pytest.raises(dispatch.DispatchRefused, match="provenance does not prove"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=tmp_path / f"provenance-{field}",
            adapters=_adapters(controller),
            oracle_adapter=ProvenanceMismatchOracle(controller, field),
            test_only_fixture=True,
        )


def test_resume_rejects_tampered_record(tmp_path: Path) -> None:
    output = tmp_path / "dispatch"
    corpus, freeze, status = _fixture_inputs(tmp_path)
    adapters = _adapters()
    dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=output,
        adapters=adapters,
        test_only_fixture=True,
        max_new_records=1,
    )
    record_path = next((output / "records").rglob("*.json"))
    record = json.loads(record_path.read_text(encoding="utf-8"))
    record["observation"]["telemetry"]["wall_ns"] += 1
    _write_json(record_path, record)
    with pytest.raises(dispatch.DispatchRefused, match="self-digest mismatch"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=output,
            adapters=_adapters(),
            test_only_fixture=True,
        )


def test_resume_rejects_rehashed_checkpoint_and_stop_semantic_tampering(
    tmp_path: Path,
) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    checkpoint_root = tmp_path / "checkpoint-tamper"
    dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=checkpoint_root,
        adapters=_adapters(),
        test_only_fixture=True,
        max_new_records=1,
    )
    checkpoint_path = checkpoint_root / "checkpoints/00000001.json"
    checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
    checkpoint.pop("checkpoint_sha256")
    checkpoint["unsealed_note"] = "attacker-controlled"
    checkpoint["checkpoint_sha256"] = validation.canonical_json_sha256(checkpoint)
    _write_json(checkpoint_path, checkpoint)
    with pytest.raises(dispatch.DispatchRefused, match="fields differ"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=checkpoint_root,
            adapters=_adapters(),
            test_only_fixture=True,
        )

    type_root = tmp_path / "checkpoint-type-tamper"
    dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=type_root,
        adapters=_adapters(),
        test_only_fixture=True,
        max_new_records=1,
    )
    type_path = type_root / "checkpoints/00000001.json"
    type_checkpoint = json.loads(type_path.read_text(encoding="utf-8"))
    type_checkpoint.pop("checkpoint_sha256")
    type_checkpoint["sequence"] = True
    type_checkpoint["checkpoint_sha256"] = validation.canonical_json_sha256(
        type_checkpoint
    )
    _write_json(type_path, type_checkpoint)
    with pytest.raises(dispatch.DispatchRefused, match="sequence must be an integer"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=type_root,
            adapters=_adapters(),
            test_only_fixture=True,
        )

    stop_root = tmp_path / "stop-tamper"
    controller = Controller(mismatch_condition="zerorun")
    dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=stop_root,
        adapters=_adapters(controller),
        test_only_fixture=True,
    )
    stop_path = stop_root / "SAFETY_STOP.json"
    stop = json.loads(stop_path.read_text(encoding="utf-8"))
    stop.pop("stop_sha256")
    stop["reasons"] = ["boundary_violation"]
    stop["stop_sha256"] = validation.canonical_json_sha256(stop)
    _write_json(stop_path, stop)
    with pytest.raises(dispatch.DispatchRefused, match="reasons contradict"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=stop_root,
            adapters=_adapters(),
            test_only_fixture=True,
        )


def test_resume_rejects_duplicate_slot_and_out_of_order_record(tmp_path: Path) -> None:
    corpus, freeze, status = _fixture_inputs(tmp_path)
    duplicate_root = tmp_path / "duplicate"
    dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=duplicate_root,
        adapters=_adapters(),
        test_only_fixture=True,
        max_new_records=1,
    )
    first_record = next((duplicate_root / "records").rglob("*.json"))
    shutil.copyfile(first_record, duplicate_root / "records/duplicate.json")
    with pytest.raises(dispatch.DispatchRefused, match="unexpected or duplicate"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=duplicate_root,
            adapters=_adapters(),
            test_only_fixture=True,
        )

    prefix_root = tmp_path / "prefix"
    future_root = tmp_path / "future"
    common_adapters = _adapters()
    dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=prefix_root,
        adapters=common_adapters,
        test_only_fixture=True,
        max_new_records=1,
    )
    dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus,
        protocol_freeze=freeze,
        study_status=status,
        output_root=future_root,
        adapters=_adapters(),
        test_only_fixture=True,
        max_new_records=3,
    )
    future_records = sorted((future_root / "records").rglob("*.json"))
    future = future_records[2]
    future_relative = future.relative_to(future_root)
    (prefix_root / future_relative).parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(future, prefix_root / future_relative)
    future_value = json.loads(future.read_text(encoding="utf-8"))
    for artifact in future_value["observation"]["artifacts"]:
        relative = Path(*_posix_parts(artifact["path"]))
        source = future_root / "evidence" / relative
        target = prefix_root / "evidence" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    with pytest.raises(dispatch.DispatchRefused, match="exact scheduled prefix"):
        dispatch.dispatch(
            research_root=ROOT / "research",
            corpus_manifest=corpus,
            protocol_freeze=freeze,
            study_status=status,
            output_root=prefix_root,
            adapters=_adapters(),
            test_only_fixture=True,
        )


def _posix_parts(value: str) -> tuple[str, ...]:
    return tuple(value.split("/"))


def test_production_preflight_builds_exact_ten_thousand_request_plan(
    tmp_path: Path,
) -> None:
    manifest = _manifest()
    corpus_path = tmp_path / "corpus.json"
    _write_json(corpus_path, manifest)
    corpus_sha = validation.sha256_file(corpus_path)
    freeze = {
        "schema": "zerorun.protocol-freeze.v1",
        "status": "FROZEN",
        "frozen_at_utc": "2026-09-05T00:00:00Z",
        "protocol_commit": manifest["protocol_commit"],
        "engine_commit": "c" * 40,
        "engine_package_sha256": _sha("engine-package"),
        "corpus_manifest_sha256": corpus_sha,
        "screening_log_sha256": manifest["sampling"]["screening_log_sha256"],
        "development_contact_exclusions_sha256": manifest[
            "development_contact_exclusion_sha256"
        ],
        "candidate_frame_plan_sha256": _sha("candidate-frame-plan"),
        "candidate_frame_sha256": _sha("candidate-frame"),
        "candidate_frame_raw_index_sha256": _sha("candidate-frame-raw-index"),
        "analysis_commit": "d" * 40,
        "sampling_seed": manifest["sampling"]["seed"],
        "sampling_seed_source": "frozen public beacon payload",
        "condition_order_algorithm": dispatch.ORDER_ALGORITHM,
        "oracle_policy_id": dispatch.ORACLE_POLICY_ID,
        "oracle_adapter_id": "fixture-independent-oracle-v1",
        "outcome_normalizer_id": dispatch.OUTCOME_NORMALIZER_ID,
        "oracle_execution": {
            "network_mode": "none",
            "worktree_policy": "dedicated-inode-disjoint-per-selector",
            "cache_policy": "empty-dedicated-per-selector",
            "condition_worktree_mounted": False,
            "condition_cache_mounted": False,
        },
        "candidate_frame_collection": {
            "algorithm": "github-rest-two-snapshot-created-size-pushed-v1",
            "collector_source_sha256": _sha("candidate-collector"),
            "created_partition_start_date": "2008-01-01",
            "created_partition_end_date": "2026-09-05",
            "terminal_cell_max_results": 900,
            "snapshot_count": 2,
            "selected_snapshot": 2,
            "snapshot_stability_max_symmetric_difference_ratio": 0.01,
        },
        "condition_adapters": {
            condition: f"fixture-{condition}-adapter-v1"
            for condition in dispatch.CONDITIONS
        },
        "baseline_versions": {
            "python": "3.12.14",
            "pytest_testmon": "2.1.3",
            "namerts_source_commit": "e" * 40,
            "namerts_package_sha256": _sha("namerts"),
            "babelrts_source_commit": "f" * 40,
            "babelrts_package_sha256": _sha("babelrts"),
            "oci_engine": f"example.invalid/engine@sha256:{_sha('oci-engine')}",
            "codex_model": "NOT_APPLICABLE_M1",
            "codex_client": "NOT_APPLICABLE_M1",
        },
        "resource_limits": {
            "environment_build_seconds": 3600,
            "full_test_seconds": 1800,
            "incremental_test_seconds": 1800,
            "repository_disk_bytes": 10_000_000_000,
            "container_memory_bytes": 8_000_000_000,
            "container_pids": 512,
        },
        "reviewers": ["reviewer-a", "reviewer-b"],
    }
    freeze_path = tmp_path / "freeze.json"
    _write_json(freeze_path, freeze)
    status_path = tmp_path / "STATUS.json"
    status_path.write_bytes((ROOT / "research/results/STATUS.json").read_bytes())
    status_before = status_path.read_bytes()
    controller = Controller()
    result = dispatch.dispatch(
        research_root=ROOT / "research",
        corpus_manifest=corpus_path,
        protocol_freeze=freeze_path,
        study_status=status_path,
        output_root=tmp_path / "production-plan",
        adapters=_adapters(controller),
        max_new_records=0,
    )
    assert result["records_planned"] == 10_000
    assert result["records_completed"] == 0
    assert result["status"] == "CHECKPOINTED"
    assert result["test_only_fixture"] is False
    assert result["confirmatory_claims_authorized"] is False
    assert controller.calls == []
    assert status_path.read_bytes() == status_before
