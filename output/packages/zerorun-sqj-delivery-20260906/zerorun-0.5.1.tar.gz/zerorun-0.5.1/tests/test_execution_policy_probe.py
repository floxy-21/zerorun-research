from pathlib import Path
import sys

import pytest

from research.novelty_checks import execution_policy_probe as probe


@pytest.mark.parametrize("name,native_false_green", [
    ("negative-state-pollution", True), ("independent-control", False),
])
def test_policy_reference_does_not_erase_native_mismatch(tmp_path, monkeypatch, name, native_false_green):
    monkeypatch.setattr(probe, "CASES", {name: probe.CASES[name]})
    result = probe.run(tmp_path / "evidence", Path(sys.executable))
    assert result["pytest_invocations"] == 11
    assert result["all_repeats_stable"] and result["all_sources_unchanged"]
    assert result["producer_bytes_stable"]
    assert not result["authorizes_reuse"] and not result["actual_tool_replication"]
    for row in result["cases"][0]["cells"]:
        if row["omit_first"] and row["policy"] == "separate-files":
            assert row["policy_reference"]["matches"]
            assert row["native_reference"]["false_green"] is native_false_green


def test_refuses_existing_evidence(tmp_path):
    with pytest.raises(ValueError, match="output already exists"):
        probe.run(tmp_path, Path(sys.executable))
