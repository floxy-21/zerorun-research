from __future__ import annotations

from collections import Counter
from copy import deepcopy
from dataclasses import replace
import hashlib
import json
import platform
from pathlib import Path
import shutil

import pytest

from research.artifact import validation
from tests.test_research_artifact import (
    GIT40,
    _finalize_record,
    _git_sha,
    _journal_records,
    _manifest,
    _oracle_repetition,
    _setup_record,
)
from tools import research_confirmatory_analysis as confirm


ROOT = Path(__file__).resolve().parents[1]
ENGINE40 = "c" * 40
ANALYSIS40 = "d" * 40


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, allow_nan=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def _environment() -> dict[str, object]:
    generator_sha = validation.sha256_file(ROOT / "tools/research_confirmatory_analysis.py")
    return {
        "schema": "zerorun.analysis-environment.v1",
        "algorithm": confirm.ALGORITHM,
        "python_implementation": "CPython",
        "python_version": platform.python_version(),
        "stdlib_only": True,
        "hash_prng": confirm.PRNG,
        "floating_point_model": "IEEE-754-binary64-via-CPython-math",
        "generator_sha256": generator_sha,
        **confirm._runtime_identity(),
    }


def _transition_rows(
    manifest: dict[str, object], corpus_sha: str, evidence_sha: str
) -> tuple[list[dict], list[dict]]:
    transitions: list[dict] = []
    slots: list[dict] = []
    for repository_row in manifest["repositories"]:
        repository = {
            "github_repository_id": repository_row["github_repository_id"],
            "canonical_full_name": repository_row["canonical_full_name"],
            "stratum": repository_row["stratum"],
        }
        states = repository_row["states"]
        frozen_orders = validation._balanced_condition_orders(
            manifest["sampling"]["seed"],
            repository_row["github_repository_id"],
            20,
        )
        for transition in range(1, 21):
            frozen_order = frozen_orders[transition - 1]
            condition_orders = {
                condition: position
                for position, condition in enumerate(frozen_order, 1)
            }
            source = {
                "before_sha": states[transition - 1]["commit_sha"],
                "after_sha": states[transition]["commit_sha"],
                "tree_sha": states[transition]["tree_sha"],
                "worktree_digest": evidence_sha,
            }
            environment = {
                "oci_image": f"example.invalid/python@sha256:{evidence_sha}",
                "oci_image_id": "synthetic",
                "rootfs_sha256": evidence_sha,
                "python_version": platform.python_version(),
                "pytest_version": "synthetic",
                "tool_version": "synthetic",
                "host_id": "synthetic",
                "cpu_set": "0",
                "network_disabled": True,
            }
            direct_id = f"direct-{repository_row['github_repository_id']}-{transition}"
            zerorun_id = f"zerorun-{repository_row['github_repository_id']}-{transition}"
            reused = 0 if transition <= 5 else 1
            reused_outcomes = (
                []
                if reused == 0
                else [
                    {
                        "node_id_sha256": hashlib.sha256(
                            f"{zerorun_id}:node".encode()
                        ).hexdigest(),
                        "selector_outcome": "passed",
                        "oracle_outcome": "passed",
                        "matches": True,
                    }
                ]
            )
            common = {
                "schema": "zerorun.transition-result.v1",
                "protocol_commit": GIT40,
                "engine_commit": ENGINE40,
                "corpus_sha256": corpus_sha,
                "repository": repository,
                "transition": transition,
                "replicate": 1,
                "attempt_ordinal": 1,
                "run_role": "measured_primary",
                "primary_run_id": None,
                "oracle_for_run_id": None,
                "oracle_policy_id": validation.ORACLE_POLICY_ID,
                "started_at_utc": "2026-02-02T00:00:00Z",
                "completed_at_utc": "2026-02-02T00:00:01Z",
                "source_identity": source,
                "environment_identity": environment,
                "target_argv": ["python", "-m", "pytest"],
                "collection_sha256": evidence_sha,
            }
            direct = _finalize_record(
                {
                    **deepcopy(common),
                    "environment_identity": {
                        **deepcopy(environment),
                        "tool_version": "direct-synthetic",
                    },
                    "run_id": direct_id,
                    "condition": "direct",
                    "condition_order": condition_orders["direct"],
                    "timing": {
                        "wall_ns": 200,
                        "user_cpu_ns": 150,
                        "system_cpu_ns": 10,
                        "peak_rss_bytes": 1,
                        "execution_ns": 180,
                    },
                    "outcome": {
                        "completed": True,
                        "exit_code": 0,
                        "status": "passed",
                        "failure_class": "none",
                        "timed_out": False,
                        "node_outcome_sha256": evidence_sha,
                    },
                    "selection": {
                        "total_nodes": 1,
                        "executed_nodes": 1,
                        "reused_nodes": 0,
                        "unknown_nodes": 0,
                        "cache_bytes": 0,
                    },
                    "oracle": None,
                    "artifacts": {
                        "stdout_sha256": evidence_sha,
                        "stderr_sha256": evidence_sha,
                        "junit_sha256": evidence_sha,
                        "record_sha256": "",
                    },
                }
            )
            baseline_records: list[dict] = []
            baseline_specs = (
                ("pytest-testmon", 160),
                ("namerts", 150),
                ("babelrts", 180),
            )
            for condition, wall_ns in baseline_specs:
                condition_order = condition_orders[condition]
                run_id = (
                    f"{condition}-{repository_row['github_repository_id']}-{transition}"
                )
                baseline_records.append(
                    _finalize_record(
                        {
                            **deepcopy(common),
                            "environment_identity": {
                                **deepcopy(environment),
                                "tool_version": f"{condition}-synthetic",
                            },
                            "run_id": run_id,
                            "condition": condition,
                            "condition_order": condition_order,
                            "timing": {
                                "wall_ns": wall_ns,
                                "user_cpu_ns": wall_ns - 20,
                                "system_cpu_ns": 5,
                                "peak_rss_bytes": 1,
                                "execution_ns": wall_ns - 20,
                            },
                            "outcome": {
                                "completed": True,
                                "exit_code": 0,
                                "status": "passed",
                                "failure_class": "none",
                                "timed_out": False,
                                "node_outcome_sha256": evidence_sha,
                            },
                            "selection": {
                                "total_nodes": 1,
                                "executed_nodes": 1,
                                "reused_nodes": 0,
                                "unknown_nodes": 0,
                                "cache_bytes": {
                                    "pytest-testmon": 20,
                                    "namerts": 30,
                                    "babelrts": 40,
                                }[condition],
                            },
                            "oracle": {
                                "run_id": "SET_AFTER_PRIMARY_CREATION",
                                "source": "fresh_oracle_record",
                                "valid": True,
                                "exit_code": 0,
                                "node_outcome_sha256": evidence_sha,
                                "collection_sha256": evidence_sha,
                                "reused_node_outcomes": [],
                                "collection_mismatch": False,
                                "reused_node_mismatch": False,
                                "overall_status_mismatch": False,
                                "false_green": False,
                                "potential_safety_mismatch": False,
                                "confirmed_safety_mismatch": None,
                                "repetition_set_id": None,
                            },
                            "artifacts": {
                                "stdout_sha256": evidence_sha,
                                "stderr_sha256": evidence_sha,
                                "junit_sha256": evidence_sha,
                                "record_sha256": "",
                            },
                        }
                    )
                )
            zerorun = _finalize_record(
                {
                    **deepcopy(common),
                    "environment_identity": {
                        **deepcopy(environment),
                        "tool_version": "zerorun-synthetic",
                    },
                    "run_id": zerorun_id,
                    "condition": "zerorun",
                    "condition_order": condition_orders["zerorun"],
                    "timing": {
                        "wall_ns": 100,
                        "user_cpu_ns": 75,
                        "system_cpu_ns": 5,
                        "peak_rss_bytes": 1,
                        "execution_ns": 80,
                    },
                    "outcome": {
                        "completed": True,
                        "exit_code": 0,
                        "status": "passed",
                        "failure_class": "none",
                        "timed_out": False,
                        "node_outcome_sha256": evidence_sha,
                    },
                    "selection": {
                        "total_nodes": 1,
                        "executed_nodes": 1 - reused,
                        "reused_nodes": reused,
                        "unknown_nodes": 0,
                        "cache_bytes": 50,
                    },
                    "oracle": {
                        "run_id": "SET_AFTER_PRIMARY_CREATION",
                        "source": "fresh_oracle_record",
                        "valid": True,
                        "exit_code": 0,
                        "node_outcome_sha256": evidence_sha,
                        "collection_sha256": evidence_sha,
                        "reused_node_outcomes": reused_outcomes,
                        "collection_mismatch": False,
                        "reused_node_mismatch": False,
                        "overall_status_mismatch": False,
                        "false_green": False,
                        "potential_safety_mismatch": False,
                        "confirmed_safety_mismatch": None,
                        "repetition_set_id": None,
                    },
                    "artifacts": {
                        "stdout_sha256": evidence_sha,
                        "stderr_sha256": evidence_sha,
                        "junit_sha256": evidence_sha,
                        "record_sha256": "",
                    },
                }
            )
            selector_records = {
                str(record["condition"]): record
                for record in (*baseline_records, zerorun)
            }
            measured_records = {"direct": direct, **selector_records}
            explicit_oracles: dict[str, dict] = {}
            for condition, selector_record in selector_records.items():
                selector_run_id = str(selector_record["run_id"])
                linked = selector_record["oracle"]
                assert isinstance(linked, dict)
                oracle_run_id = (
                    f"oracle-{condition}-{repository_row['github_repository_id']}-{transition}"
                )
                linked["run_id"] = oracle_run_id
                linked["source"] = "fresh_oracle_record"
                explicit_oracles[condition] = _finalize_record(
                    {
                        **deepcopy(common),
                        "run_id": oracle_run_id,
                        "condition": "oracle",
                        "condition_order": condition_orders[condition],
                        "run_role": "fresh_oracle_primary",
                        "oracle_for_run_id": selector_run_id,
                        "started_at_utc": "2026-02-02T00:00:01Z",
                        "completed_at_utc": "2026-02-02T00:00:02Z",
                        "environment_identity": {
                            **deepcopy(environment),
                            "tool_version": "fresh-oracle-synthetic",
                        },
                        "timing": {
                            "wall_ns": 200,
                            "user_cpu_ns": 150,
                            "system_cpu_ns": 10,
                            "peak_rss_bytes": 1,
                            "execution_ns": 180,
                        },
                        "outcome": {
                            "completed": True,
                            "exit_code": 0,
                            "status": "passed",
                            "failure_class": "none",
                            "timed_out": False,
                            "node_outcome_sha256": evidence_sha,
                        },
                        "selection": {
                            "total_nodes": 1,
                            "executed_nodes": 1,
                            "reused_nodes": 0,
                            "unknown_nodes": 0,
                            "cache_bytes": 0,
                        },
                        "oracle": None,
                        "artifacts": {
                            "stdout_sha256": evidence_sha,
                            "stderr_sha256": evidence_sha,
                            "junit_sha256": evidence_sha,
                            "record_sha256": "",
                        },
                    }
                )
            for condition in frozen_order:
                transitions.append(measured_records[condition])
                if condition in explicit_oracles:
                    transitions.append(explicit_oracles[condition])
            slots.append(
                _finalize_record(
                    {
                        "schema": "zerorun.transition-slot-disposition.v1",
                        "record_id": f"slot-{repository_row['github_repository_id']}-{transition}",
                        "protocol_commit": GIT40,
                        "engine_commit": ENGINE40,
                        "corpus_sha256": corpus_sha,
                        "repository": repository,
                        "transition": transition,
                        "source_identity": {
                            "before_sha": source["before_sha"],
                            "after_sha": source["after_sha"],
                            "tree_sha": source["tree_sha"],
                        },
                        "timeout_cap_ns": 2_000,
                        "direct": {
                            "condition_order": condition_orders["direct"],
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "observed",
                            "run_id": direct_id,
                            "observed_wall_ns": 200,
                            "penalized_wall_ns": 200,
                            "failure_class": "none",
                        },
                        "pytest-testmon": {
                            "condition_order": condition_orders["pytest-testmon"],
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "observed",
                            "run_id": baseline_records[0]["run_id"],
                            "observed_wall_ns": 160,
                            "penalized_wall_ns": 160,
                            "failure_class": "none",
                        },
                        "namerts": {
                            "condition_order": condition_orders["namerts"],
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "observed",
                            "run_id": baseline_records[1]["run_id"],
                            "observed_wall_ns": 150,
                            "penalized_wall_ns": 150,
                            "failure_class": "none",
                        },
                        "babelrts": {
                            "condition_order": condition_orders["babelrts"],
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "observed",
                            "run_id": baseline_records[2]["run_id"],
                            "observed_wall_ns": 180,
                            "penalized_wall_ns": 180,
                            "failure_class": "none",
                        },
                        "zerorun": {
                            "condition_order": condition_orders["zerorun"],
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "observed",
                            "run_id": zerorun_id,
                            "observed_wall_ns": 100,
                            "penalized_wall_ns": 100,
                            "failure_class": "none",
                        },
                        "artifacts": {"record_sha256": ""},
                    }
                )
            )
    _journal_records(transitions)
    return transitions, slots


def _mutation_rows(
    manifest: dict[str, object], corpus_sha: str, evidence_sha: str
) -> list[dict]:
    rows: list[dict] = []
    for repository_row in manifest["repositories"]:
        repository = {
            "github_repository_id": repository_row["github_repository_id"],
            "canonical_full_name": repository_row["canonical_full_name"],
            "stratum": repository_row["stratum"],
        }
        for category in confirm.MUTATION_CATEGORIES:
            semantic = category in confirm.SEMANTIC_CATEGORIES
            mutation_id = f"mutation-{repository_row['github_repository_id']}-{category}"
            reused = [
                {
                    "node_id_sha256": hashlib.sha256(
                        f"{mutation_id}:node".encode()
                    ).hexdigest(),
                    "selector_outcome": "failed" if semantic else "passed",
                    "oracle_outcome": "failed" if semantic else "passed",
                    "matches": True,
                }
            ]
            reused_sha = validation.canonical_json_sha256(reused)
            baseline_nodes = hashlib.sha256(f"{mutation_id}:baseline".encode()).hexdigest()
            mutated_nodes = (
                hashlib.sha256(f"{mutation_id}:mutated".encode()).hexdigest()
                if semantic
                else baseline_nodes
            )
            selector_status = "failed" if semantic else "passed"
            rows.append(
                _finalize_record(
                    {
                        "schema": "zerorun.mutation-result.v1",
                        "mutation_id": mutation_id,
                        "protocol_commit": GIT40,
                        "engine_commit": ENGINE40,
                        "corpus_sha256": corpus_sha,
                        "repository": repository,
                        "category": category,
                        "catalog": {
                            "version": "synthetic-v1",
                            "sha256": evidence_sha,
                            "operator_id": category,
                        },
                        "selection": {
                            "rank_algorithm": "sha256-zerorun-mutation-v1",
                            "candidate_count": 1,
                            "selected_rank": 1,
                            "selected_path_sha256": evidence_sha,
                        },
                        "source_identity": {
                            "frozen_sha": repository_row["frozen_sha"],
                            "unmutated_tree_sha": repository_row["states"][-1]["tree_sha"],
                            "mutated_tree_sha": _git_sha(f"{mutation_id}:tree"),
                            "runtime_rootfs_sha256": evidence_sha,
                        },
                        "applicability": "attempted",
                        "selector": {
                            "run_id": f"{mutation_id}:selector",
                            "status": "reuse",
                            "exit_code": 1 if semantic else 0,
                            "overall_status": selector_status,
                            "collection_vector_sha256": evidence_sha,
                            "reused_nodes": 1,
                            "reused_node_outcomes_sha256": reused_sha,
                            "detected_identity_change": True,
                        },
                        "oracle": {
                            "run_id": f"{mutation_id}:oracle",
                            "valid": True,
                            "baseline_exit_code": 0,
                            "mutated_exit_code": 1 if semantic else 0,
                            "baseline_collection_vector_sha256": evidence_sha,
                            "mutated_collection_vector_sha256": evidence_sha,
                            "baseline_node_outcome_sha256": baseline_nodes,
                            "mutated_node_outcome_sha256": mutated_nodes,
                            "reused_node_outcomes": reused,
                            "reused_node_outcomes_sha256": reused_sha,
                            "overall_status": selector_status,
                        },
                        "boundary_assertion": (
                            None
                            if semantic
                            else {
                                "injector_verified": True,
                                "observation_points_verified": True,
                                "category_assertion_passed": True,
                                "evidence_sha256": evidence_sha,
                            }
                        ),
                        "classification": {
                            "trial_class": "semantic_mutation" if semantic else "boundary_assertion",
                            "evaluable": True,
                            "effective_semantic_mutation": True if semantic else None,
                            "valid_boundary_assertion": None if semantic else True,
                            "collection_mismatch": False,
                            "reused_node_mismatch": False,
                            "overall_status_mismatch": False,
                            "false_green": False,
                            "potential_safety_mismatch": False,
                            "confirmed_safety_mismatch": None,
                            "oracle_repetition_set_id": None,
                            "failure_class": "none",
                        },
                        "artifacts": {
                            "patch_sha256": evidence_sha,
                            "selector_log_sha256": evidence_sha,
                            "oracle_log_sha256": evidence_sha,
                            "record_sha256": "",
                        },
                    }
                )
            )
    return rows


def _build_bundle(root: Path) -> Path:
    manifest = _manifest()
    corpus_path = root / "design/corpus.json"
    _write_json(corpus_path, manifest)
    corpus_sha = validation.sha256_file(corpus_path)
    evidence_path = root / "raw/evidence/shared.bin"
    evidence_path.parent.mkdir(parents=True, exist_ok=True)
    evidence_path.write_bytes(b"synthetic sealed evidence\n")
    evidence_sha = validation.sha256_file(evidence_path)

    setup = [_setup_record(row, corpus_sha) for row in manifest["repositories"]]
    for record in setup:
        record["engine_commit"] = ENGINE40
        record["resource_limits_sha256"] = evidence_sha
        record["runtime"]["recipe_sha256"] = evidence_sha
        record["runtime"]["rootfs_sha256"] = evidence_sha
        record["runtime"]["oci_image"] = f"example.invalid/python@sha256:{evidence_sha}"
        record["artifacts"]["setup_log_sha256"] = evidence_sha
        record["artifacts"]["review_record_sha256"] = evidence_sha
        _finalize_record(record)
    transitions, slots = _transition_rows(manifest, corpus_sha, evidence_sha)
    mutations = _mutation_rows(manifest, corpus_sha, evidence_sha)
    oracles = []
    for repository_row in manifest["repositories"]:
        single_manifest = deepcopy(manifest)
        single_manifest["repositories"] = [repository_row]
        record = _oracle_repetition(single_manifest, corpus_sha)
        record["repetition_set_id"] = f"seed-repeat-{repository_row['github_repository_id']}"
        record["engine_commit"] = ENGINE40
        record["environment_identity"]["oci_image"] = f"example.invalid/python@sha256:{evidence_sha}"
        record["environment_identity"]["rootfs_sha256"] = evidence_sha
        for repetition in record["repetitions"]:
            repetition["stdout_sha256"] = evidence_sha
            repetition["stderr_sha256"] = evidence_sha
        _finalize_record(record)
        oracles.append(record)

    record_sets = {
        "setup_compatibility": setup,
        "transition": transitions,
        "transition_slot_disposition": slots,
        "mutation": mutations,
        "oracle_repetition": oracles,
    }
    raw_entries = []
    for kind, records in record_sets.items():
        path = root / f"raw/{kind}.json"
        _write_json(path, records)
        raw_entries.append(
            {
                "kind": kind,
                "path": path.relative_to(root).as_posix(),
                "sha256": validation.sha256_file(path),
                "schema": confirm.RAW_SCHEMA_BY_KIND[kind],
                "record_count": len(records),
            }
        )
    raw_index = {
        "schema": "zerorun.raw-bundle-index.v1",
        "protocol_commit": GIT40,
        "engine_commit": ENGINE40,
        "corpus_manifest_sha256": corpus_sha,
        "created_at_utc": "2026-02-03T00:00:00Z",
        "records": raw_entries,
        "records_aggregate_sha256": validation.canonical_json_sha256(
            sorted(raw_entries, key=lambda row: row["path"])
        ),
    }
    raw_index_path = root / "raw/index.json"
    _write_json(raw_index_path, raw_index)

    generator_path = root / "analysis/source/research_confirmatory_analysis.py"
    generator_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / "tools/research_confirmatory_analysis.py", generator_path)
    validator_path = root / "analysis/source/validation.py"
    shutil.copyfile(ROOT / "research/artifact/validation.py", validator_path)
    environment_path = root / "analysis/environment.json"
    _write_json(environment_path, _environment())
    receipt_path = root / "analysis/input-validation.json"
    sealed_validator = confirm._load_sealed_validator(validator_path)
    validation_report = sealed_validator.validate_raw_analysis_inputs(
        ROOT / "research",
        root,
        corpus_relative=corpus_path.relative_to(root).as_posix(),
        raw_index_relative=raw_index_path.relative_to(root).as_posix(),
    )
    assert validation_report.errors == []
    receipt = validation_report.as_dict()
    _write_json(receipt_path, receipt)
    validation_environment_path = root / "analysis/validation-environment.json"
    _write_json(validation_environment_path, receipt["validator"])

    role_paths = {
        "corpus_manifest": corpus_path,
        "raw_bundle_index": raw_index_path,
        "analysis_source": generator_path,
        "analysis_environment": environment_path,
        "validation_receipt": receipt_path,
        "validator_source": validator_path,
        "validation_environment": validation_environment_path,
        "raw_evidence": evidence_path,
    }
    file_rows = [
        {
            "path": path.relative_to(root).as_posix(),
            "sha256": validation.sha256_file(path),
            "role": role,
            "bytes": path.stat().st_size,
        }
        for role, path in role_paths.items()
    ]
    file_rows.extend(
        {
            "path": entry["path"],
            "sha256": entry["sha256"],
            "role": "raw_record",
            "bytes": (root / entry["path"]).stat().st_size,
        }
        for entry in raw_entries
    )
    by_role = {row["role"]: row for row in file_rows if row["role"] != "raw_record"}
    seal = {
        "schema": "zerorun.analysis-input-seal.v1",
        "status": "SEALED",
        "sealed_at_utc": "2026-02-04T00:00:00Z",
        "protocol_commit": GIT40,
        "engine_commit": ENGINE40,
        "analysis_commit": ANALYSIS40,
        "analysis_seed": "synthetic-public-analysis-seed",
        "links": {
            "corpus_manifest": {
                "path": by_role["corpus_manifest"]["path"],
                "sha256": by_role["corpus_manifest"]["sha256"],
            },
            "raw_bundle_index": {
                "path": by_role["raw_bundle_index"]["path"],
                "sha256": by_role["raw_bundle_index"]["sha256"],
            },
            "generator_source": {
                "path": by_role["analysis_source"]["path"],
                "sha256": by_role["analysis_source"]["sha256"],
            },
            "analysis_environment": {
                "path": by_role["analysis_environment"]["path"],
                "sha256": by_role["analysis_environment"]["sha256"],
            },
            "validation_receipt": {
                "path": by_role["validation_receipt"]["path"],
                "sha256": by_role["validation_receipt"]["sha256"],
            },
            "validator_source": {
                "path": by_role["validator_source"]["path"],
                "sha256": by_role["validator_source"]["sha256"],
            },
            "validation_environment": {
                "path": by_role["validation_environment"]["path"],
                "sha256": by_role["validation_environment"]["sha256"],
            },
        },
        "files": sorted(file_rows, key=lambda row: row["path"]),
    }
    seal_path = root / "analysis-input-seal.json"
    _write_json(seal_path, seal)
    return seal_path


@pytest.fixture(scope="module")
def sealed_bundle(tmp_path_factory: pytest.TempPathFactory) -> tuple[Path, Path]:
    root = tmp_path_factory.mktemp("confirmatory-bundle")
    return root, _build_bundle(root)


@pytest.fixture(scope="module")
def sealed_inputs(sealed_bundle: tuple[Path, Path]) -> confirm.SealedInputs:
    root, seal_path = sealed_bundle
    return confirm.load_sealed_inputs(
        root,
        seal_path,
        running_source=ROOT / "tools/research_confirmatory_analysis.py",
    )


def test_confirmatory_generator_golden_and_schema_valid(
    sealed_bundle: tuple[Path, Path], sealed_inputs: confirm.SealedInputs, tmp_path: Path
) -> None:
    root, seal_path = sealed_bundle
    analysis, latex = confirm.generate_analysis(sealed_inputs)
    h2 = analysis["primary_estimates"]["H2"]
    assert h2["conditional"]["point_weighted_median_speedup"] == 2.0
    assert h2["conditional"]["one_sided_95_lower"] == 2.0
    assert h2["failure_penalized"]["one_sided_95_lower"] == 2.0
    assert h2["intersection_union_p_value"] == 1 / 10_001
    assert h2["holm_adjusted_p_value"] == 3 / 10_001
    assert h2["decision"] == "PASS"
    assert analysis["primary_estimates"]["H1"]["decision"] == "PASS"
    assert analysis["primary_estimates"]["H3"]["decision"] == "PASS"
    assert analysis["primary_estimates"]["H4"]["decision"] == "PASS"
    secondary = analysis["secondary_estimates"]
    assert secondary["status"] == "DESCRIPTIVE_NOT_IN_PRIMARY_HYPOTHESIS_GATES"
    assert secondary["multiplicity_role"] == "excluded_from_H2_H3_H4_Holm_family"
    diagnostics = secondary["condition_diagnostics"]
    assert diagnostics["direct"]["executed_node_fraction"]["pooled_fraction"] == 1.0
    assert diagnostics["pytest-testmon"]["non_execution_overhead"]["median_ns"] == 20.0
    assert diagnostics["namerts"]["cache_storage"]["maximum_bytes"] == 30
    assert diagnostics["zerorun"]["executed_node_fraction"]["pooled_fraction"] == 0.25
    assert diagnostics["zerorun"]["safety_events"] == {
        "applicability": "SELECTOR_ORACLE",
        "oracle_valid_requests": 2000,
        "oracle_invalid_or_missing_requests": 0,
        "collection_mismatches": 0,
        "reused_node_mismatches": 0,
        "overall_status_mismatches": 0,
        "false_greens": 0,
        "potential_safety_mismatches": 0,
        "confirmed_safety_mismatches": 0,
        "confirmed_classification_missing": 0,
    }
    testmon = secondary["selector_baselines"]["pytest-testmon"]["comparisons"]
    assert (
        testmon["selector_vs_direct"]["conditional_complete_case"]
        ["point_weighted_median_speedup"]
        == pytest.approx(1.25)
    )
    assert testmon["selector_vs_direct"]["asymmetric_repository_support"][
        "both_supported"
    ]["repository_count"] == 100
    assert testmon["zerorun_vs_selector"]["asymmetric_repository_support"][
        "numerator_only"
    ]["repository_count"] == 0
    assert (
        testmon["zerorun_vs_selector"]["failure_penalized_all_selected"]
        ["point_weighted_median_speedup"]
        == pytest.approx(1.6)
    )
    namerts = secondary["selector_baselines"]["namerts"]["comparisons"]
    assert (
        namerts["selector_vs_direct"]["conditional_complete_case"]
        ["point_weighted_median_speedup"]
        == pytest.approx(4 / 3)
    )
    babelrts = secondary["selector_baselines"]["babelrts"]["comparisons"]
    assert (
        babelrts["zerorun_vs_selector"]["failure_penalized_all_selected"]
        ["point_weighted_median_speedup"]
        == pytest.approx(1.8)
    )
    assert analysis["exploratory_status"]["M3"]["status"].endswith("NOT_RUN")
    assert hashlib.sha256(latex.encode()).hexdigest() == analysis["generated_results_sha256"]

    report = validation.ValidationReport()
    catalog = validation.load_schema_catalog(ROOT / "research/schemas", report)
    validation.validate_instance(
        analysis,
        "zerorun.analysis-output.v1",
        catalog,
        report,
        "synthetic analysis",
    )
    validation.validate_instance(
        json.loads(seal_path.read_text(encoding="utf-8")),
        "zerorun.analysis-input-seal.v1",
        catalog,
        report,
        "synthetic analysis-input seal",
    )
    assert report.errors == []

    first_json = tmp_path / "first.json"
    first_tex = tmp_path / "first.tex"
    second_json = tmp_path / "second.json"
    second_tex = tmp_path / "second.tex"
    common = ["--artifact-root", str(root), "--input-seal", str(seal_path)]
    assert confirm.main([*common, "--output", str(first_json), "--generated-results-output", str(first_tex)]) == 0
    assert confirm.main([*common, "--output", str(second_json), "--generated-results-output", str(second_tex)]) == 0
    assert first_json.read_bytes() == second_json.read_bytes()
    assert first_tex.read_bytes() == second_tex.read_bytes()


def test_preanalysis_validator_accepts_complete_synthetic_raw_bundle(
    sealed_bundle: tuple[Path, Path]
) -> None:
    root, _ = sealed_bundle
    report = validation.validate_raw_analysis_inputs(
        ROOT / "research",
        root,
        corpus_relative="design/corpus.json",
        raw_index_relative="raw/index.json",
    )
    assert report.errors == []
    assert report.checked_record_counts == {
        "setup_compatibility": 100,
        "transition": 18000,
        "transition_slot_disposition": 2000,
        "mutation": 1200,
        "oracle_repetition": 100,
    }


def test_confirmatory_analysis_rejects_resealed_scheduled_direct_oracle(
    sealed_inputs: confirm.SealedInputs,
) -> None:
    transitions = sealed_inputs.records_by_kind["transition"]
    direct = next(
        row
        for row in transitions
        if row.get("condition") == "direct"
        and row.get("condition_order") == 5
        and row.get("replicate") == 1
    )
    group_key = (
        direct["repository"]["github_repository_id"],
        direct["transition"],
        direct["replicate"],
    )
    group = [
        deepcopy(row)
        for row in transitions
        if (
            row["repository"]["github_repository_id"],
            row["transition"],
            row["replicate"],
        )
        == group_key
    ]
    direct = next(row for row in group if row["condition"] == "direct")
    selector = next(
        row
        for row in group
        if row.get("condition") in validation.SELECTOR_CONDITIONS
        and row.get("condition_order") == 4
    )
    removed_oracle_id = selector["oracle"]["run_id"]
    selector["oracle"]["run_id"] = direct["run_id"]
    selector["oracle"]["source"] = "scheduled_direct_immediate"
    direct["oracle_for_run_id"] = selector["run_id"]
    direct["started_at_utc"] = selector["completed_at_utc"]
    direct["completed_at_utc"] = "2026-02-02T00:00:02Z"
    group = [row for row in group if row["run_id"] != removed_oracle_id]
    _journal_records(group)

    run_index = {str(row["run_id"]): row for row in group}
    assert not confirm._selector_primary_oracle_is_provenance_clean(
        selector, run_index
    )
    with pytest.raises(
        confirm.AnalysisInputError,
        match="measured primary cannot serve as an oracle",
    ):
        confirm._validate_transition_oracle_provenance(
            group,
            sealed_inputs.corpus,
            confirm._repository_index(sealed_inputs.corpus),
        )


def test_secondary_condition_diagnostics_report_missingness_and_safety_events(
    sealed_inputs: confirm.SealedInputs,
) -> None:
    rows = [
        deepcopy(row)
        for row in sealed_inputs.records_by_kind["transition"]
        if row.get("condition") == "pytest-testmon" and row.get("replicate") == 1
    ]
    rows[0]["timing"].pop("execution_ns")
    rows[1]["selection"].pop("cache_bytes")
    rows[2]["oracle"]["collection_mismatch"] = True
    rows[2]["oracle"]["potential_safety_mismatch"] = True
    rows[2]["oracle"]["confirmed_safety_mismatch"] = None

    diagnostic = confirm._condition_diagnostic(
        "pytest-testmon",
        rows,
        sealed_inputs.records_by_kind["transition_slot_disposition"],
    )
    assert diagnostic["executed_node_fraction"]["requests_missing_value"] == 0
    assert diagnostic["non_execution_overhead"]["requests_missing_value"] == 1
    assert diagnostic["cache_storage"]["requests_missing_value"] == 1
    assert diagnostic["safety_events"]["collection_mismatches"] == 1
    assert diagnostic["safety_events"]["potential_safety_mismatches"] == 1
    assert diagnostic["safety_events"]["confirmed_classification_missing"] == 1


def test_h1_n_invalid_primary_oracle_is_counted_and_cannot_pass(
    sealed_inputs: confirm.SealedInputs,
) -> None:
    transitions = list(sealed_inputs.records_by_kind["transition"])
    target_index = next(
        index
        for index, row in enumerate(transitions)
        if row.get("condition") == "zerorun"
        and row.get("selection", {}).get("reused_nodes", 0) > 0
    )
    target = deepcopy(transitions[target_index])
    target["oracle"]["valid"] = False
    transitions[target_index] = target
    run_index = {
        str(row["run_id"]): row
        for row in transitions
        if isinstance(row.get("run_id"), str)
    }
    counts = confirm._component_counts(
        transitions,
        confirm._repository_index(sealed_inputs.corpus),
        natural=True,
        transition_run_index=run_index,
    )

    assert counts["required_oracle_attempts"] == 1500
    assert counts["oracle_valid_attempts"] == 1499
    assert counts["oracle_invalid_or_missing_attempts"] == 1
    assert counts["evaluable_trials"] == 1499
    assert (
        confirm._finish_h1_component(counts, coverage=True)["decision"]
        == "INCONCLUSIVE_INVALID_ORACLE"
    )


def test_h1_m_attempted_invalid_oracle_is_counted_and_cannot_pass(
    sealed_inputs: confirm.SealedInputs,
) -> None:
    mutations = list(sealed_inputs.records_by_kind["mutation"])
    mutations[0] = deepcopy(mutations[0])
    mutations[0]["oracle"]["valid"] = False
    mutations[0]["classification"]["evaluable"] = False
    for field in (
        "collection_mismatch",
        "reused_node_mismatch",
        "overall_status_mismatch",
        "false_green",
        "potential_safety_mismatch",
    ):
        mutations[0]["classification"][field] = None
    counts = confirm._component_counts(
        mutations,
        confirm._repository_index(sealed_inputs.corpus),
        natural=False,
    )

    assert counts["required_oracle_attempts"] == 1200
    assert counts["oracle_valid_attempts"] == 1199
    assert counts["oracle_invalid_or_missing_attempts"] == 1
    assert counts["evaluable_trials"] == 1199
    assert (
        confirm._finish_h1_component(counts, coverage=True)["decision"]
        == "INCONCLUSIVE_INVALID_ORACLE"
    )


def test_h2_f_rejects_observed_selector_with_invalid_primary_oracle(
    sealed_inputs: confirm.SealedInputs,
) -> None:
    records = dict(sealed_inputs.records_by_kind)
    transitions = list(records["transition"])
    target_index = next(
        index
        for index, row in enumerate(transitions)
        if row.get("condition") == "zerorun"
    )
    target = deepcopy(transitions[target_index])
    target["oracle"]["valid"] = False
    transitions[target_index] = target
    records["transition"] = tuple(transitions)
    altered = replace(sealed_inputs, records_by_kind=records)

    with pytest.raises(
        confirm.AnalysisInputError,
        match="observed zerorun slot lacks a valid provenance-clean primary oracle",
    ):
        confirm.generate_analysis(altered)


def test_owner_cluster_pairs_bootstrap_never_splits_or_size_conditions() -> None:
    rows = [
        confirm.RepositoryEstimate(1, "S1", "pair", True, 1.0, 1.0, 0.0),
        confirm.RepositoryEstimate(2, "S1", "pair", True, 1.0, 1.0, 0.0),
        *[
            confirm.RepositoryEstimate(index, "S1", f"single-{index}", True, 1.0, 1.0, 0.0)
            for index in range(3, 26)
        ],
    ]
    clusters = tuple(tuple(value) for value in confirm._owner_clusters(rows).values())
    for seed in ("a", "b", "c", "d"):
        sampled = confirm._sample_owner_clusters(confirm.HashStream(seed), clusters)
        counts = Counter(row.repository_id for row in sampled)
        assert counts[1] == counts[2]
        # Exactly one draw per owner cluster. The repository count is allowed
        # to vary because a same-owner pair contributes two repositories.
        assert counts[1] + sum(counts[index] for index in range(3, 26)) == 24


def test_bootstrap_resamples_fixed_eligible_endpoint_population(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(confirm, "BOOTSTRAP_DRAWS", 100)
    rows = [
        confirm.RepositoryEstimate(
            index * 25 + offset + 1,
            stratum,
            f"{stratum}-owner-{offset}",
            True,
            2.0 if offset == 0 else None,
            2.0,
            0.01 if offset == 0 else None,
        )
        for index, stratum in enumerate(confirm.STRATA)
        for offset in range(25)
    ]
    draws = confirm._bootstrap(rows, seed="undefined-domain-test")
    assert draws["conditional"] == [2.0] * 100
    assert draws["h3"] == [0.01] * 100
    assert all(value is not None for value in draws["failure"])
    assert all(value is not None for value in draws["h4"])
    with pytest.raises(confirm.AnalysisInputError, match="transform domain"):
        confirm._greater_inversion(2.0, [0.0, 2.0], 1.0, log_scale=True)
    lower, p_value = confirm._greater_inversion(
        0.0, [0.0, 0.0], 0.70, log_scale=False
    )
    assert lower == 0.0
    assert p_value == 1.0
    sparse_lower, sparse_p = confirm._probability_greater_inversion(
        0.01, [0.03, 0.03], 0.70
    )
    assert sparse_lower == 0.0
    assert sparse_p == 1.0


def test_confirmatory_input_rejects_duplicate_repository_ids() -> None:
    manifest = _manifest()
    manifest["repositories"][1]["github_repository_id"] = manifest["repositories"][0]["github_repository_id"]
    with pytest.raises(confirm.AnalysisInputError, match="IDs are not distinct"):
        confirm._repository_index(manifest)


def test_confirmatory_input_rejects_nonfinite_json(tmp_path: Path) -> None:
    path = tmp_path / "nonfinite.json"
    path.write_text('{"wall_ns": NaN}', encoding="utf-8")
    with pytest.raises(confirm.AnalysisInputError, match="nonfinite"):
        confirm._read_json(path, "nonfinite fixture")


def test_confirmatory_input_rejects_tampered_raw_file(
    sealed_bundle: tuple[Path, Path]
) -> None:
    root, seal_path = sealed_bundle
    transition_path = root / "raw/transition.json"
    original = transition_path.read_bytes()
    try:
        transition_path.write_bytes(original + b" ")
        with pytest.raises(confirm.AnalysisInputError, match="digest mismatch"):
            confirm.load_sealed_inputs(root, seal_path)
    finally:
        transition_path.write_bytes(original)


def _refresh_sealed_file(root: Path, seal_path: Path, relative: str) -> None:
    seal = json.loads(seal_path.read_text(encoding="utf-8"))
    path = root / relative
    digest = validation.sha256_file(path)
    for entry in seal["files"]:
        if entry["path"] == relative:
            entry["sha256"] = digest
            entry["bytes"] = path.stat().st_size
    for link in seal["links"].values():
        if link["path"] == relative:
            link["sha256"] = digest
    _write_json(seal_path, seal)


def test_confirmatory_input_rejects_forged_pass_receipt(
    sealed_bundle: tuple[Path, Path], tmp_path: Path
) -> None:
    source_root, _ = sealed_bundle
    root = tmp_path / "forged-receipt"
    shutil.copytree(source_root, root)
    seal_path = root / "analysis-input-seal.json"
    receipt_path = root / "analysis/input-validation.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    receipt["checked_record_counts"]["mutation"] -= 1
    _write_json(receipt_path, receipt)
    _refresh_sealed_file(root, seal_path, "analysis/input-validation.json")

    with pytest.raises(
        confirm.AnalysisInputError,
        match="validation rerun does not exactly reproduce",
    ):
        confirm.load_sealed_inputs(root, seal_path)


def test_confirmatory_input_rejects_old_validator_algorithm(
    sealed_bundle: tuple[Path, Path], tmp_path: Path
) -> None:
    source_root, _ = sealed_bundle
    root = tmp_path / "old-validator"
    shutil.copytree(source_root, root)
    seal_path = root / "analysis-input-seal.json"
    receipt_path = root / "analysis/input-validation.json"
    environment_path = root / "analysis/validation-environment.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    environment = json.loads(environment_path.read_text(encoding="utf-8"))
    receipt["validator"]["algorithm"] = "zerorun-raw-analysis-input-validation-v1"
    environment["algorithm"] = "zerorun-raw-analysis-input-validation-v1"
    _write_json(receipt_path, receipt)
    _write_json(environment_path, environment)
    _refresh_sealed_file(root, seal_path, "analysis/input-validation.json")
    _refresh_sealed_file(root, seal_path, "analysis/validation-environment.json")

    with pytest.raises(confirm.AnalysisInputError, match="old or invalid algorithm"):
        confirm.load_sealed_inputs(root, seal_path)


def test_confirmatory_input_rejects_validator_source_digest_substitution(
    sealed_bundle: tuple[Path, Path], tmp_path: Path
) -> None:
    source_root, _ = sealed_bundle
    root = tmp_path / "validator-substitution"
    shutil.copytree(source_root, root)
    seal_path = root / "analysis-input-seal.json"
    validator_path = root / "analysis/source/validation.py"
    validator_path.write_bytes(validator_path.read_bytes() + b"\n# substituted\n")
    _refresh_sealed_file(root, seal_path, "analysis/source/validation.py")

    with pytest.raises(
        confirm.AnalysisInputError,
        match="does not bind the sealed validator source",
    ):
        confirm.load_sealed_inputs(root, seal_path)


def test_generate_analysis_rejects_duplicate_transition_slot(
    sealed_inputs: confirm.SealedInputs,
) -> None:
    records = dict(sealed_inputs.records_by_kind)
    slots = list(records["transition_slot_disposition"])
    slots[-1] = deepcopy(slots[0])
    records["transition_slot_disposition"] = tuple(slots)
    altered = replace(sealed_inputs, records_by_kind=records)
    with pytest.raises(confirm.AnalysisInputError, match="incomplete repository"):
        confirm.generate_analysis(altered)


@pytest.mark.parametrize(
    "mutation, message",
    [
        (lambda row: row.pop("namerts"), "no namerts disposition"),
        (
            lambda row: row["namerts"].__setitem__(
                "condition_order", row["pytest-testmon"]["condition_order"]
            ),
            "exact permutation of 1..5",
        ),
    ],
)
def test_generate_analysis_rejects_incomplete_or_ambiguous_condition_slots(
    sealed_inputs: confirm.SealedInputs, mutation, message: str
) -> None:
    records = dict(sealed_inputs.records_by_kind)
    slots = list(records["transition_slot_disposition"])
    slots[0] = deepcopy(slots[0])
    mutation(slots[0])
    records["transition_slot_disposition"] = tuple(slots)
    altered = replace(sealed_inputs, records_by_kind=records)
    with pytest.raises(confirm.AnalysisInputError, match=message):
        confirm.generate_analysis(altered)
