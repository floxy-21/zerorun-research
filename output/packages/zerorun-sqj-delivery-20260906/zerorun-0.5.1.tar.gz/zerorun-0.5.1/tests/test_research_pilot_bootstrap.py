from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess

import pytest

from research.phases import bootstrap_pilot_runtime as bootstrap


IMAGE_ID = "sha256:" + "a" * 64


def _attempt(tmp_path: Path) -> Path:
    root = tmp_path / "attempt"
    (root / "input").mkdir(parents=True)
    (root / "wheels").mkdir()
    (root / "runtime").mkdir()
    for name in bootstrap.REQUIREMENTS:
        (root / "input" / name).write_text(
            "example==1.0 --hash=sha256:" + "0" * 64 + "\n",
            encoding="utf-8",
        )
    return root


def _posix_identity(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(os, "getuid", lambda: 1000, raising=False)
    monkeypatch.setattr(os, "getgid", lambda: 1000, raising=False)


def _completed(
    command: list[str], returncode: int = 0, stdout: str = "", stderr: str = ""
) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(command, returncode, stdout, stderr)


def test_success_records_exact_argv_image_and_tree_inventories(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _attempt(tmp_path)
    _posix_identity(monkeypatch)
    calls: list[list[str]] = []

    def fake_run(command: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
        calls.append(command)
        if command[:3] == ["docker", "image", "inspect"]:
            return _completed(command, stdout=IMAGE_ID + "\n")
        if command[:4] == ["docker", "container", "ls", "--all"]:
            return _completed(command)
        if command[:2] == ["docker", "run"]:
            if "download" in command:
                (root / "wheels" / "example.whl").write_bytes(b"wheel")
            if "install" in command:
                package = root / "runtime" / "example"
                package.mkdir()
                (package / "__init__.py").write_bytes(b"VALUE = 1\n")
            return _completed(command)
        raise AssertionError(command)

    monkeypatch.setattr(subprocess, "run", fake_run)

    code, record = bootstrap.run_bootstrap(root)

    assert code == 0
    assert record["status"] == "COMPLETE"
    assert record["actual_image_id"] == IMAGE_ID
    assert len(record["commands"]) == 2
    first, second = (row["argv"] for row in record["commands"])
    assert first[:3] == ["docker", "run", "--name"]
    assert "download" in first and "--network=none" not in first
    assert "install" in second and "--network=none" in second
    assert all(row["matches"] is True for row in record["input_hash_rechecks"])
    assert all(
        row["observed_sha256"] == record["requirements_sha256"]
        for row in record["input_hash_rechecks"]
    )
    assert record["wheels_tree"]["file_count"] == 1
    assert record["runtime_tree"]["files"] == [
        {
            "path": "example/__init__.py",
            "size": 10,
            "sha256": "e13df8c44af5dea1e412403910b99cc5a48f2ccbf68a66b3374d6ab9cef9fc65",
        }
    ]
    persisted = json.loads((root / "bootstrap.json").read_text(encoding="utf-8"))
    assert persisted == record
    assert calls[0][:3] == ["docker", "image", "inspect"]


def test_timeout_writes_failed_receipt_and_verifies_forced_cleanup(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _attempt(tmp_path)
    _posix_identity(monkeypatch)
    container_checks = 0
    removed: list[str] = []

    def fake_run(command: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
        nonlocal container_checks
        if command[:3] == ["docker", "image", "inspect"]:
            return _completed(command, stdout=IMAGE_ID)
        if command[:2] == ["docker", "run"]:
            raise subprocess.TimeoutExpired(command, 300)
        if command[:4] == ["docker", "container", "ls", "--all"]:
            container_checks += 1
            return _completed(command, stdout="still-running\n" if container_checks == 1 else "")
        if command[:3] == ["docker", "rm", "-f"]:
            removed.append(command[-1])
            return _completed(command, stdout=command[-1] + "\n")
        raise AssertionError(command)

    monkeypatch.setattr(subprocess, "run", fake_run)

    code, record = bootstrap.run_bootstrap(root)

    assert code == 1
    assert record["status"] == "FAILED"
    assert "timed out after 300 seconds" in record["failure"]
    assert len(record["commands"]) == 1
    assert record["commands"][0]["cleanup"]["absent_after_cleanup"] is True
    assert len(removed) == 1
    assert removed[0].startswith("zerorun-pilot-bootstrap-")
    persisted = json.loads((root / "bootstrap.json").read_text(encoding="utf-8"))
    assert persisted["status"] == "FAILED"


def test_output_reservation_failure_preserves_existing_file_and_starts_nothing(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _attempt(tmp_path)
    sentinel = root / "bootstrap-0.stderr.log"
    sentinel.write_bytes(b"keep")

    def forbidden(*args: object, **kwargs: object) -> None:
        raise AssertionError("Docker must not start when output reservation fails")

    monkeypatch.setattr(subprocess, "run", forbidden)

    with pytest.raises(FileExistsError):
        bootstrap.run_bootstrap(root)

    assert sentinel.read_bytes() == b"keep"
    assert not (root / "bootstrap.json").exists()
    assert not (root / "bootstrap-0.stdout.log").exists()


def test_requirement_hash_change_before_command_is_a_receipted_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _attempt(tmp_path)
    _posix_identity(monkeypatch)
    original_input_hashes = bootstrap._input_hashes
    calls = 0

    def changing_hashes(inputs: Path) -> dict[str, str]:
        nonlocal calls
        calls += 1
        result = original_input_hashes(inputs)
        if calls > 1:
            result[bootstrap.REQUIREMENTS[0]] = "f" * 64
        return result

    def fake_run(command: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
        if command[:3] == ["docker", "image", "inspect"]:
            return _completed(command, stdout=IMAGE_ID)
        raise AssertionError("Docker run must not start after a failed input recheck")

    monkeypatch.setattr(bootstrap, "_input_hashes", changing_hashes)
    monkeypatch.setattr(subprocess, "run", fake_run)

    code, record = bootstrap.run_bootstrap(root)

    assert code == 1
    assert record["status"] == "FAILED"
    assert record["input_hash_rechecks"][0]["stage"] == "before-command-0"
    assert record["input_hash_rechecks"][0]["matches"] is False
    assert record["input_hash_rechecks"][0]["observed_sha256"][
        bootstrap.REQUIREMENTS[0]
    ] == "f" * 64
    assert record["commands"] == []
    assert "changed before Docker execution" in record["failure"]


def test_requirement_symlink_is_refused(tmp_path: Path) -> None:
    source = tmp_path / "requirements.txt"
    source.write_text("example==1\n", encoding="utf-8")
    link = tmp_path / "requirements-link.txt"
    try:
        link.symlink_to(source)
    except OSError as exc:
        pytest.skip(f"symlink creation is unavailable: {exc}")

    with pytest.raises(bootstrap.BootstrapError, match="non-symlink"):
        bootstrap._sha256_file(link, max_bytes=1024)
