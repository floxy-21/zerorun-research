from __future__ import annotations

import hashlib

import pytest

from tools import select_commercial_corpus as corpus


def _row(name: str, stars: int = 100) -> dict[str, object]:
    return {"repository": name, "stars_at_selection": stars}


def _api_row(name: str, *, pushed_at: object) -> dict[str, object]:
    return {
        "full_name": name,
        "default_branch": "main",
        "clone_url": f"https://github.com/{name}.git",
        "stargazers_count": 100,
        "forks_count": 1,
        "size": 10,
        "created_at": "2020-01-01T00:00:00Z",
        "pushed_at": pushed_at,
        "license": {"spdx_id": "MIT"},
    }


def test_sample_rank_is_deterministic_and_stratum_bound() -> None:
    row = _row("example/project")
    first = corpus._sample_rank(row, seed="seed", stratum="low")
    assert first == corpus._sample_rank(row, seed="seed", stratum="low")
    assert first != corpus._sample_rank(row, seed="seed", stratum="high")
    assert len(first) == 64
    int(first, 16)


def test_canonical_encoding_is_order_independent_for_objects() -> None:
    left = corpus._canonical({"b": 2, "a": 1})
    right = corpus._canonical({"a": 1, "b": 2})
    assert left == right
    assert hashlib.sha256(left).hexdigest() == hashlib.sha256(right).hexdigest()


def test_queries_freeze_language_popularity_and_time_boundary() -> None:
    query = corpus._query(
        corpus.STRATA[0], cutoff="2026-09-04", maintenance_start="2024-09-04"
    )
    assert query == (
        "language:Python archived:false fork:false pytest in:readme "
        "stars:100..499 pushed:2024-09-04..2026-09-03"
    )
    assert query.count("pushed:") == 1


@pytest.mark.parametrize(
    ("maintenance_start", "cutoff", "expected"),
    (
        ("2026-09-03", "2026-09-04", "2026-09-03..2026-09-03"),
        ("2024-02-28", "2024-03-01", "2024-02-28..2024-02-29"),
        ("2025-12-31", "2026-01-01", "2025-12-31..2025-12-31"),
    ),
)
def test_pushed_range_converts_exclusive_cutoff_to_inclusive_final_date(
    maintenance_start: str,
    cutoff: str,
    expected: str,
) -> None:
    assert (
        corpus._pushed_range(
            cutoff=cutoff,
            maintenance_start=maintenance_start,
        )
        == expected
    )


@pytest.mark.parametrize(
    ("maintenance_start", "cutoff"),
    (
        ("2026-09-04", "2026-09-04"),
        ("2026-09-05", "2026-09-04"),
        ("2026-9-4", "2026-09-05"),
        ("not-a-date", "2026-09-05"),
        ("2026-02-29", "2026-03-01"),
    ),
)
def test_query_rejects_invalid_or_empty_windows(
    maintenance_start: str,
    cutoff: str,
) -> None:
    with pytest.raises(ValueError):
        corpus._query(
            corpus.STRATA[0],
            cutoff=cutoff,
            maintenance_start=maintenance_start,
        )


@pytest.mark.parametrize(
    ("pushed_at", "expected"),
    (
        ("2024-09-04T00:00:00Z", True),
        ("2026-09-03T23:59:59Z", True),
        ("2024-09-03T23:59:59Z", False),
        ("2026-09-04T00:00:00Z", False),
        ("2026-09-04T01:00:00+01:00", False),
        ("2025-01-01T00:00:00+00:00", False),
        ("2025-01-01T00:00:00", False),
        ("2025-01-01T00:00:00.000Z", False),
        ("2025-01-01T00:00:00z", False),
        ("2025-02-29T00:00:00Z", False),
        ("2025-01-01", False),
        ("not-a-timestamp", False),
        (None, False),
        (123, False),
    ),
)
def test_pushed_at_validation_is_start_inclusive_and_cutoff_exclusive(
    pushed_at: object,
    expected: bool,
) -> None:
    start_utc, cutoff_utc = corpus._utc_window(
        cutoff="2026-09-04",
        maintenance_start="2024-09-04",
    )
    assert (
        corpus._pushed_at_in_window(
            pushed_at,
            start_utc=start_utc,
            cutoff_utc=cutoff_utc,
        )
        is expected
    )


def test_frame_excludes_and_records_out_of_window_github_result(
    monkeypatch: pytest.MonkeyPatch,
) -> None:

    def request_json(url: str, *, token: str | None) -> dict[str, object]:
        del token
        if "page=2" in url:
            return {
                "items": [
                    _api_row(
                        "example/outside",
                        pushed_at="2026-09-04T00:00:00Z",
                    )
                ],
                "total_count": 2,
            }
        return {
            "items": [
                _api_row(
                    "example/inside",
                    pushed_at="2025-01-01T00:00:00Z",
                )
            ],
            "total_count": 2,
        }

    monkeypatch.setattr(
        corpus,
        "_request_json",
        request_json,
    )

    frame, total_count, rejections = corpus._frame(
        corpus.STRATA[0],
        cutoff="2026-09-04",
        maintenance_start="2024-09-04",
        token=None,
    )
    assert total_count == 2
    assert [row["repository"] for row in frame] == ["example/inside"]
    assert rejections == [
        {
            "repository": "example/outside",
            "reason": (
                "GitHub search candidate rejected because pushed_at was missing, "
                "malformed, or outside the requested maintenance window: "
                "'2026-09-04T00:00:00Z'"
            ),
        }
    ]


def test_frame_preserves_validated_pushed_at(monkeypatch: pytest.MonkeyPatch) -> None:
    pushed_at = "2025-01-01T00:00:00Z"
    row = _api_row("example/inside", pushed_at=pushed_at)
    monkeypatch.setattr(
        corpus,
        "_request_json",
        lambda url, *, token: {"items": [row], "total_count": 1},
    )

    frame, total_count, rejections = corpus._frame(
        corpus.STRATA[0],
        cutoff="2026-09-04",
        maintenance_start="2024-09-04",
        token=None,
    )

    assert total_count == 1
    assert len(frame) == 1
    assert frame[0]["pushed_at"] == pushed_at
    assert rejections == []


def test_invalid_window_fails_before_github_request(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def unexpected_request(url: str, *, token: str | None) -> dict[str, object]:
        raise AssertionError(f"unexpected GitHub request: {url}, {token}")

    monkeypatch.setattr(corpus, "_request_json", unexpected_request)

    with pytest.raises(ValueError, match="earlier than cutoff"):
        corpus._frame(
            corpus.STRATA[0],
            cutoff="2026-09-04",
            maintenance_start="2026-09-04",
            token=None,
        )


def test_strata_define_exactly_one_hundred_attempted_repositories() -> None:
    assert len(corpus.STRATA) == 4
    assert corpus.PER_STRATUM == 25
    assert len(corpus.STRATA) * corpus.PER_STRATUM == 100
    assert corpus.FRAME_PAGES * corpus.PER_PAGE == 200


def test_selection_artifact_cannot_be_confused_with_research_corpus() -> None:
    assert corpus.SCHEMA == "zerorun.commercial-compatibility-selection.v1"
    assert corpus.ARTIFACT_ROLE == "engineering_smoke_selection_only"
