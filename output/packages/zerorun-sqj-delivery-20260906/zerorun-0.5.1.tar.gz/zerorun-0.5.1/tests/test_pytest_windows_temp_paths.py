from __future__ import annotations

import os
from pathlib import Path
import tempfile
from typing import Callable

import pytest

from zerorun import path_safety


def test_stdlib_temp_directory_is_usable_without_patching_product_mkdir(
    tmp_path: Path,
    original_os_mkdir_before_temp_factory: Callable[..., None],
) -> None:
    assert os.mkdir is original_os_mkdir_before_temp_factory

    with tempfile.TemporaryDirectory(
        prefix="zerorun-stdlib-test-", dir=tmp_path
    ) as raw_temporary:
        temporary = Path(raw_temporary)
        assert os.mkdir is original_os_mkdir_before_temp_factory
        proof = temporary / "proof.txt"
        proof.write_text("writable\n", encoding="utf-8")
        assert proof.read_text(encoding="utf-8") == "writable\n"

    assert not temporary.exists()
    assert os.mkdir is original_os_mkdir_before_temp_factory


def test_pytest_temp_factory_restores_product_mkdir_behavior(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    original_os_mkdir_before_temp_factory: Callable[..., None],
) -> None:
    """The Windows test workaround must end before the test body executes."""

    assert os.mkdir is original_os_mkdir_before_temp_factory
    calls: list[tuple[tuple[object, ...], dict[str, object]]] = []

    def recording_mkdir(*args: object, **kwargs: object) -> None:
        calls.append((args, kwargs))
        original_os_mkdir_before_temp_factory(*args, **kwargs)

    monkeypatch.setattr(path_safety.os, "mkdir", recording_mkdir)
    target = tmp_path / "product-private-directory"
    assert path_safety.create_private_directory(target) == target
    assert target.is_dir()

    if os.name == "nt":
        assert calls == [((target,), {})]
    else:
        assert calls == [((target, 0o700), {})]
