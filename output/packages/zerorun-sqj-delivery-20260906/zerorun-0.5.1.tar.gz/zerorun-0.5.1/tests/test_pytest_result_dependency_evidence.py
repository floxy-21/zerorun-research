from __future__ import annotations

import pytest

from tools import hermetic_pytest_experiment as experiment
from tools import pytest_result_dependency_probe as result_probe
from tools.pytest_node_dependency_probe import _SESSION_NODE
from tools.pytest_result_dependency_probe import _result_partition_summary, node_outcome_summary


@pytest.fixture(autouse=True)
def _runtime_text_evidence():
    result_probe._RUNTIME_TEXT_ENCODING_BY_PARTITION["candidate"] = {
        "preferred_encoding": "UTF-8",
        "locale_encoding": "UTF-8",
        "filesystem_encoding": "utf-8",
        "utf8_mode": 1,
        "default_text_sample": "é",
        "default_text_bytes_hex": "c3a9",
        "default_text_write_utf8": True,
    }
    try:
        yield
    finally:
        result_probe._RUNTIME_TEXT_ENCODING_BY_PARTITION.clear()


def test_result_partition_summary_retains_exact_node_dependencies() -> None:
    partition = experiment.Partition(
        "candidate",
        ("testing/example.py",),
        frozenset({"terminal"}),
    )
    calls = {
        "testing/example.py::test_a": {
            (
                "src/_pytest/terminal.py",
                100,
                "write",
                ("self", "tw"),
                False,
                ("_pytest.terminal.TerminalReporter", "builtins.object"),
            ),
            (
                "src/_pytest/cacheprovider.py",
                200,
                "get",
                ("Path",),
                False,
            ),
        },
        "testing/example.py::test_b": {
            (
                "src/_pytest/python_api.py",
                300,
                "__eq__",
                ("math",),
                False,
            ),
        },
        _SESSION_NODE: {
            (
                "src/_pytest/terminal.py",
                50,
                "pytest_configure",
                ("TerminalReporter",),
                False,
            ),
        },
    }

    row = _result_partition_summary(
        partition,
        ["testing/example.py::test_a", "testing/example.py::test_b"],
        calls,
        5.0,
    )

    by_node = {item["nodeid"]: item for item in row["node_dependencies"]}
    assert set(by_node) == {
        "testing/example.py::test_a",
        "testing/example.py::test_b",
    }
    assert by_node["testing/example.py::test_a"]["tracked_implementation_files"] == [
        "src/_pytest/cacheprovider.py",
        "src/_pytest/terminal.py",
    ]
    assert by_node["testing/example.py::test_a"]["implementation_call_site_count"] == 2
    assert by_node["testing/example.py::test_b"]["tracked_implementation_files"] == []
    assert row["tracked_file_nodes"]["src/_pytest/terminal.py"] == [
        "testing/example.py::test_a"
    ]
    assert row["tracked_file_nodes"]["src/_pytest/cacheprovider.py"] == [
        "testing/example.py::test_a"
    ]
    assert sum(family["node_count"] for family in row["dependency_families"]) == 2
    assert all("nodeids" in family for family in row["dependency_families"])

    terminal_site = next(
        site
        for site in by_node["testing/example.py::test_a"]["project_python_call_sites"]
        if site["path"] == "src/_pytest/terminal.py"
    )
    assert terminal_site["globals"] == ["self", "tw"]
    assert terminal_site["dynamic_globals"] is False
    assert terminal_site["receiver_mro"] == [
        "_pytest.terminal.TerminalReporter",
        "builtins.object",
    ]

    assert row["session_project_python_call_site_count"] == 1
    assert row["session_project_python_call_sites"] == [
        {
            "path": "src/_pytest/terminal.py",
            "firstlineno": 50,
            "qualname": "pytest_configure",
            "globals": ["TerminalReporter"],
            "dynamic_globals": False,
        }
    ]
    assert row["runtime_text_encoding"]["default_text_write_utf8"] is True


def test_result_partition_summary_preserves_dynamic_global_uncertainty() -> None:
    partition = experiment.Partition(
        "candidate",
        ("testing/example.py",),
        frozenset(),
    )
    row = _result_partition_summary(
        partition,
        ["testing/example.py::test_dynamic"],
        {
            "testing/example.py::test_dynamic": {
                (
                    "src/_pytest/example.py",
                    12,
                    "dynamic_helper",
                    ("globals",),
                    True,
                )
            }
        },
        1.0,
    )

    site = row["node_dependencies"][0]["project_python_call_sites"][0]
    assert site["globals"] == ["globals"]
    assert site["dynamic_globals"] is True
    assert row["session_project_python_call_sites"] == []


def test_result_partition_summary_handles_nodes_without_tracked_calls() -> None:
    partition = experiment.Partition(
        "candidate",
        ("testing/example.py",),
        frozenset(),
    )
    row = _result_partition_summary(
        partition,
        ["testing/example.py::test_a"],
        {"testing/example.py::test_a": set()},
        1.0,
    )

    assert row["node_dependencies"][0]["project_python_call_sites"] == []
    assert row["node_dependencies"][0]["tracked_implementation_files"] == []
    assert row["node_dependencies"][0]["result_outcome"]["cache_candidate_success"] is False


def test_node_outcome_summary_accepts_complete_non_failing_result() -> None:
    summary = node_outcome_summary(
        [
            {"when": "setup", "outcome": "passed", "wasxfail": False},
            {"when": "call", "outcome": "passed", "wasxfail": False},
            {"when": "teardown", "outcome": "passed", "wasxfail": False},
        ]
    )

    assert summary["complete"] is True
    assert summary["failed"] is False
    assert summary["cache_candidate_success"] is True


def test_node_outcome_summary_fails_closed_for_failure_or_incomplete_reports() -> None:
    failed = node_outcome_summary(
        [
            {"when": "setup", "outcome": "passed", "wasxfail": False},
            {"when": "call", "outcome": "failed", "wasxfail": False},
            {"when": "teardown", "outcome": "passed", "wasxfail": False},
        ]
    )
    incomplete = node_outcome_summary(
        [{"when": "setup", "outcome": "passed", "wasxfail": False}]
    )

    assert failed["cache_candidate_success"] is False
    assert incomplete["complete"] is False
    assert incomplete["cache_candidate_success"] is False
