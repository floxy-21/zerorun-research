from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import pytest

from research.artifact import analyze_cpython_formative_evidence as evidence
from tools.agent_retest_trial import (
    _task_manifest_record,
    load_trial_scenario,
    trajectory_tasks,
)


ROOT = Path(__file__).resolve().parents[1]

# Exact records from the immutable v0.5.1 engine staged for the in-flight trial.
# Keeping these in the synthetic fixture avoids coupling analyzer tests to later
# working-tree edits while still exercising the canonical aggregate hash check.
ENGINE_RECORDS = (
    ("zerorun/__init__.py", 55, "5227fb2b505f9a0f36fd3cfa4482bc07d1dab373cbd36a84f3c36967ebf9a1b2"),
    ("zerorun/__main__.py", 79, "307299fda7b77d22c64cb51430ec75e5f59d78e9c948786afb3b2544fe45e4b7"),
    ("zerorun/api.py", 2482, "49e7a5a35333ed2c5ae7b695491f307ad21619cbafcd523b773a04d84518ea25"),
    ("zerorun/cli.py", 17782, "7d8a6f52bf4c97394eb9400f8dc593d7d25cc1119347e3e4898395155807730a"),
    ("zerorun/codex.py", 20519, "3041c024e632d0de82a75192d2fcd5d63aa72a364cf8718c3e03a7c636544a94"),
    ("zerorun/fingerprint.py", 14088, "82bc426784f5a8fbb898288509cba874c628c43f7e7a907a4230461939b7b083"),
    ("zerorun/hermetic.py", 16507, "4a88dd1610e33f2dbcb93bf9ab69a096643f60174b8edc4120515b307bb8db62"),
    ("zerorun/hermetic_batch.py", 2694, "b7bdce8db63ca12126f92119549c7920754544e2f2f50739e7ea725f14d3cb12"),
    ("zerorun/hermetic_batch_key.py", 8505, "5e777e7d3c1fdf6a68a89406f9244f42caa23a454dc373cfc8413c8b536dd212"),
    ("zerorun/hermetic_key.py", 23007, "6c12ba0a81b2038d821713373398b2a4c0613c65f3e4b3eebe39494aa26b0900"),
    ("zerorun/hermetic_store.py", 5817, "0d3fa26de299c077b1974623e2ed41756f054e9a55fa493debc680d35e936462"),
    ("zerorun/manifest.py", 4829, "9dbce42e523096cf99c9ee34374787abfd6d2316780fc89ba77ccbd2cb4d07f9"),
    ("zerorun/mcp.py", 46409, "581bc5af5d086159149aadf5a7535a5bf9b2a05da958c02b56cf3a3d6c4af388"),
    ("zerorun/model.py", 8275, "0ff7ac3239b3436fb78b2085a0e6bf0553f27dee33ec5dc1535858396f578695"),
    ("zerorun/normalization.py", 3217, "c7518fa7fff0287c5ff0ac6bdcc4f75759183d1f44da3d50ff368b7e7e673962"),
    ("zerorun/oci.py", 56959, "fcbd9d4110b0c4c976a03eedef1fbefab9d743ccfc6c2f4ee37a3debce926419"),
    ("zerorun/path_safety.py", 1202, "a2ed72c84936cc8c5d922d62d7a8c42ee290f5922318c1b7a00f7f5d6b12c271"),
    ("zerorun/pilot.py", 6231, "ebd3e4622891c32d55f6753a4c0bf973bd8a286c84447bf48a60a9fd336daa76"),
    ("zerorun/pytest_closure.py", 11207, "80317efaffed15ccccd467cd32e8a8cc7ce08a66edb62940db81167ef43269b8"),
    ("zerorun/pytest_node_cache.py", 10257, "dc8b790b8f6141e30c9b868f38e77666bfaf94008e3745c402f39bbe530b3676"),
    ("zerorun/pytest_node_key.py", 8002, "c0e67911dadb61777a7e53d8c44b6158d85b3d348509980c727b47779b149ebb"),
    ("zerorun/pytest_prepare_cli.py", 6748, "c656d0e5cd437ab5ba5f62f983adbdec5457abc5e5bb36d36850a19f97f5efb3"),
    ("zerorun/pytest_profile.py", 21612, "4c6c1fb46519b3a1d53c9449205acbc9798ed5d31af6db005b86f6609f0b8890"),
    ("zerorun/pytest_qualify.py", 48215, "fdc200e886c3da04e40a903f796947a3c3ca3dacac40c4deddef5c937568225c"),
    ("zerorun/pytest_review.py", 8640, "024d6ef96d8d1a68f48dbd62b928b2e7f56a218ad0266acffb3672ae1ee2e9de"),
    ("zerorun/pytest_review_cli.py", 4088, "0a83fc5a5c1349c84aa18a156989c942f1f83a0c062d168825bf3afb5b3fa2e0"),
    ("zerorun/pytest_runtime.py", 90492, "a5781720d1ab3a3bf3137b922a84d3629f65ead4011524faf7159d18d596242b"),
    ("zerorun/pytest_setup.py", 24700, "acc3109833a27b68255fd85dfa33f724a660e393407ba917a1ad437598114b92"),
    ("zerorun/runner.py", 22503, "dd7eacc098421d09f21f32e912e70fd41cd5768fa41024ed53240944bbb6abe6"),
    ("zerorun/source_uncertainty.py", 1236, "af4d4095fad81b7922f8b54a9e804ae6d2294fb1862bf07e83a60eb4084a9d6c"),
    ("zerorun/store.py", 30345, "fe1139d7c284a7a91a6d0eb494008092c1e2ef6de899b1eb34baa9719062a299"),
    ("zerorun/trust.py", 23376, "119b11d3ef1a4c013d301b143b28a17058d82c798225cca03710ecee6fb463e7"),
    ("zerorun/workspace.py", 18107, "bae82b98c1b32601bd52f1aeea71b5aedc7b226a2f352ed35cf7e0ed6fa45f96"),
)


def _key(trajectory_index: int, target: str) -> str:
    return hashlib.sha256(
        f"synthetic-{trajectory_index}-{target}".encode("utf-8")
    ).hexdigest()


def _direct_target(trajectory_index: int, target: str, *, shadow: bool = False) -> dict:
    result = {
        "target": target,
        "runtime_task": evidence._runtime_task_name(trajectory_index, target),
        "exit_code": 0,
        "wall_ms": 30.0,
        "execution_ms": 25.0,
        "stdout_sha256": evidence.EMPTY_SHA256,
        "stderr_sha256": evidence.EMPTY_SHA256,
        "fresh_container": True,
        "oracle_input_scope": ["Lib"],
    }
    if shadow:
        result.update(
            {
                "zerorun_exit_code": 0,
                "exit_code_match": True,
                "purpose": "fresh-complete-source-shadow-oracle",
            }
        )
    return result


def _direct_suite(trajectory_index: int) -> dict:
    return {
        "condition": evidence.DIRECT_CONDITION,
        "suite_wall_ms": 100.0,
        "targets": [
            _direct_target(trajectory_index, target)
            for target in evidence.TASK_NAMES
        ],
    }


def _zerorun_suite(trajectory_index: int, *, seed: bool) -> dict:
    status = evidence.FRESH_STATUS if seed else evidence.HIT_STATUS
    return {
        "condition": evidence.ZERORUN_CONDITION,
        "suite_wall_ms": 100.0 if seed else 1.0,
        "targets": [
            {
                "target": target,
                "runtime_task": evidence._runtime_task_name(
                    trajectory_index, target
                ),
                "status": status,
                "exit_code": 0,
                "wall_ms": 30.0 if seed else 0.2,
                "execution_ms": 25.0,
                "cache_key": _key(trajectory_index, target),
                "verified": False,
                "reason": (
                    "fresh hermetic result stored"
                    if seed
                    else "exact reviewed source closure and pinned runtime identity matched"
                ),
                "stdout_sha256": evidence.EMPTY_SHA256,
                "stderr_sha256": evidence.EMPTY_SHA256,
            }
            for target in evidence.TASK_NAMES
        ],
    }


def _trajectory(trajectory_index: int) -> dict:
    iterations = []
    prior = evidence.BASE_COMMIT
    for revision_index, revision in enumerate(evidence.REVISIONS):
        iterations.append(
            {
                "revision_index": revision_index + 1,
                "revision": revision,
                "prior_revision": prior,
                "condition_order": list(
                    evidence._condition_order(trajectory_index, revision_index)
                ),
                "changed_file_count": 1,
                "changed_files": [
                    f"Misc/NEWS.d/next/Tests/synthetic-{revision_index:02d}.rst"
                ],
                "expected_fresh_targets": [],
                "direct_warmup": _direct_suite(trajectory_index),
                "direct": _direct_suite(trajectory_index),
                "zerorun": _zerorun_suite(trajectory_index, seed=False),
                "shadow": {
                    "suite_wall_ms": 100.0,
                    "targets": [
                        _direct_target(trajectory_index, target, shadow=True)
                        for target in evidence.TASK_NAMES
                    ],
                    "claimed_hit_count": 3,
                    "shadow_count": 3,
                    "complete": True,
                },
                "direct_failures": [],
                "zerorun_failures": [],
                "expected_status_mismatches": [],
                "shadow_mismatches": [],
            }
        )
        prior = revision
    return {
        "trajectory_index": trajectory_index + 1,
        "cache_namespace": f"cpython-trajectory-{trajectory_index + 1:02d}",
        "cache_isolation": "disjoint task names included in v0.5 action keys",
        "base_preflight": _direct_suite(trajectory_index),
        "seed": _zerorun_suite(trajectory_index, seed=True),
        "summary": {
            "pass": True,
            "complete_trace": True,
            "measured_revision_count": 20,
            "direct_suite_wall_ms_p50": 100.0,
            "direct_suite_wall_ms_p95": 100.0,
            "zerorun_suite_wall_ms_p50": 1.0,
            "zerorun_suite_wall_ms_p95": 1.0,
            "p95_time_reduction_percent": 99.0,
            "claimed_replays": 60,
            "fresh_executions": 0,
            "fresh_shadow_executions": 60,
            "direct_failures": 0,
            "zerorun_failures": 0,
            "unexpected_target_statuses": 0,
            "shadow_exit_code_mismatches": 0,
        },
        "iterations": iterations,
    }


def _receipt() -> dict:
    image_id = "sha256:" + "1" * 64
    engine = {
        "schema": evidence.ENGINE_IDENTITY_SCHEMA,
        "sha256": evidence.ENGINE_SOURCE_SHA256,
        "file_count": len(ENGINE_RECORDS),
        "files": [
            {"path": path, "size": size, "sha256": sha256}
            for path, size, sha256 in ENGINE_RECORDS
        ],
    }
    return {
        "schema": 2,
        "kind": evidence.RECEIPT_KIND,
        "pass": True,
        "scope": {
            "classification": evidence.CLASSIFICATION,
            "primary_metrics_populated": False,
            "claim": (
                "one fixed public CPython trace; not confirmatory, customer-value, "
                "security-certification, pricing, revenue, or funding evidence"
            ),
        },
        "configuration": {
            "scenario_sha256": evidence.SCENARIO_SHA256,
            "generated_manifest_sha256": evidence.expected_manifest_sha256(),
            "zerorun_version": "0.5.1",
            "engine_source_identity": engine,
            "trial_tool_sha256": evidence.TRIAL_TOOL_SHA256,
            "manifest_version": 2,
        },
        "source": {
            "remote": evidence.PUBLIC_CPYTHON_ORIGIN,
            "base_commit": evidence.BASE_COMMIT,
            "revisions": list(evidence.REVISIONS),
            "frozen_revision_count": 20,
        },
        "runtime": {
            "oci_identity": {
                "runtime": "docker",
                "requested_image": evidence.RUNTIME_IMAGE,
                "requested_digest": evidence.RUNTIME_DIGEST,
                "platform": "linux/amd64",
                "image_id": image_id,
                "repo_digests": [evidence.RUNTIME_IMAGE],
                "rootfs": {
                    "type": "layers",
                    "layers": ["sha256:" + "2" * 64],
                },
                "config_sha256": "3" * 64,
            },
            "interpreter_attestation": {
                "implementation": "CPython",
                "version_info": [3, 12, 14],
                "version_text": "3.12.14",
                "releaselevel": "final",
                "serial": 0,
                "executable": "/usr/local/bin/python3",
                "exit_code": 0,
                "execution_ms": 5.0,
                "stdout_sha256": evidence.expected_interpreter_stdout_sha256(),
                "stderr_sha256": evidence.EMPTY_SHA256,
                "requested_image": evidence.RUNTIME_IMAGE,
                "image_id": image_id,
                "platform": "linux/amd64",
                "matches_frozen_scenario": True,
            },
        },
        "closure": {
            "basis": "author-declared",
            "independently_audited": False,
            "direct_oracle_inputs": ["Lib"],
            "targets": [
                {"name": task["name"], "inputs": list(task["inputs"])}
                for task in evidence.TASKS
            ],
        },
        "design": {
            "trajectory_count_preregistered": 2,
            "trajectory_count_executed": 2,
            "condition_order": evidence.CONDITION_ORDER_ID,
            "condition_order_counterbalanced": True,
            "cache_namespaces_disjoint": True,
            "direct_condition": (
                "fresh Docker containers over the complete checkout-visible Lib tree"
            ),
            "zerorun_condition": (
                "normal v0.5 run_hermetic_task path over author-declared closures"
            ),
            "shadow": (
                "one fresh complete-source direct container for every HIT_REUSED; "
                "exit status compared because targets are result-only"
            ),
        },
        "descriptive_measurement": {
            "observation_count_per_condition": 40,
            "direct_suite_wall_ms_p50": 100.0,
            "direct_suite_wall_ms_p95": 100.0,
            "zerorun_suite_wall_ms_p50": 1.0,
            "zerorun_suite_wall_ms_p95": 1.0,
            "shadow_cost_excluded_from_condition_timing": True,
        },
        "gates": {
            "full_preregistered_design_executed": True,
            "required_trajectories": 2,
            "minimum_iterations_per_trajectory": 20,
            "minimum_p95_reduction_percent_per_trajectory": 30.0,
            "condition_order_counterbalanced": True,
            "cache_namespaces_disjoint": True,
            "all_trajectory_gates_passed": True,
        },
        "trajectories": [_trajectory(0), _trajectory(1)],
        "limits": list(evidence.LIMITATIONS),
    }


def _analyze(receipt: dict) -> dict:
    payload = (json.dumps(receipt, indent=2, sort_keys=True) + "\n").encode("utf-8")
    return evidence.analyze_bytes(payload, payload, b"")


def _set_measured_zerorun_wall(receipt: dict, wall_ms: float) -> None:
    reduction = round((100.0 - wall_ms) / 100.0 * 100.0, 3)
    for trajectory in receipt["trajectories"]:
        for iteration in trajectory["iterations"]:
            iteration["zerorun"]["suite_wall_ms"] = wall_ms
        trajectory["summary"]["zerorun_suite_wall_ms_p50"] = wall_ms
        trajectory["summary"]["zerorun_suite_wall_ms_p95"] = wall_ms
        trajectory["summary"]["p95_time_reduction_percent"] = reduction
    receipt["descriptive_measurement"]["zerorun_suite_wall_ms_p50"] = wall_ms
    receipt["descriptive_measurement"]["zerorun_suite_wall_ms_p95"] = wall_ms


def test_synthetic_passing_receipt_recomputes_bounded_summary_and_macros() -> None:
    summary = _analyze(_receipt())

    assert summary["frozen_protocol"] == {
        "historical_preregistered_gate": True,
        "minimum_p95_reduction_percent_per_trajectory": 30.0,
        "gate_pass": True,
    }
    assert summary["confirmatory_claims_authorized"] is False
    assert summary["primary_metrics_populated"] is False
    assert summary["design"]["independent_experimental_units"] is False
    assert summary["safety"] == {
        "target_observations": 120,
        "claimed_replays": 120,
        "fresh_executions": 0,
        "shadow_oracles_required": 120,
        "fresh_shadow_executions": 120,
        "direct_failures": 0,
        "zerorun_failures": 0,
        "unexpected_target_statuses": 0,
        "shadow_exit_code_mismatches": 0,
    }
    assert summary["release_stretch_assessment"]["target_achieved"] is True
    assert summary["release_stretch_assessment"][
        "release_qualification_claimed"
    ] is False
    assert summary["analysis_disclosures"] == list(evidence.ANALYSIS_DISCLOSURES)
    rendered = evidence.render_latex(summary)
    assert "\\CPythonTrialOneP95Reduction}{99.000\\%}" in rendered
    assert "\\CPythonTrialTwoP95Reduction}{99.000\\%}" in rendered
    assert "\\CPythonTrialClaimedReplays}{120}" in rendered
    assert "\\CPythonTrialStretchMinimumSpeedup}{5.000}" in rendered
    assert "\\CPythonTrialStretchEquivalentReduction}{80.000\\%}" in rendered
    assert "\\CPythonTrialStretchTargetAchieved}{yes}" in rendered
    assert "\\CPythonTrialFrozenProtocolMinimumReduction}{30.000\\%}" in rendered
    assert "\\CPythonTrialReleaseQualified}{no}" in rendered
    assert "FORMATIVE SECONDARY" in rendered
    assert "resultsavailable" not in rendered.lower()


def test_analyzer_pins_reconstruct_the_frozen_harness_inputs() -> None:
    scenario_path = ROOT / "experiments/cpython-agent-retest/scenario.json"
    tool_path = ROOT / "tools/agent_retest_trial.py"
    assert hashlib.sha256(scenario_path.read_bytes()).hexdigest() == evidence.SCENARIO_SHA256
    assert hashlib.sha256(tool_path.read_bytes()).hexdigest() == evidence.TRIAL_TOOL_SHA256

    scenario = load_trial_scenario(scenario_path)
    all_tasks = tuple(
        task
        for trajectory_index in range(scenario.trajectory_count)
        for task in trajectory_tasks(scenario.tasks, trajectory_index)
    )
    raw_manifest = {
        "version": 2,
        "tasks": {
            task.name: _task_manifest_record(task)
            for task in all_tasks
        },
    }
    payload = (json.dumps(raw_manifest, indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )
    assert hashlib.sha256(payload).hexdigest() == evidence.expected_manifest_sha256()


def test_stretch_assessment_does_not_rewrite_historical_gate_or_overclaim() -> None:
    below = _receipt()
    _set_measured_zerorun_wall(below, 25.0)
    summary = _analyze(below)
    assert summary["frozen_protocol"]["gate_pass"] is True
    assert summary["release_stretch_assessment"] == {
        "criterion": (
            "at least 5.0x p95 end-to-end suite speedup in each trajectory "
            "and in aggregate, with zero safety mismatches"
        ),
        "threshold_basis": (
            "post-protocol user-specified stretch assessment; not preregistered"
        ),
        "measurement_basis": (
            "ratio of direct and ZeroRun p95 end-to-end suite wall times; "
            "fresh shadow-oracle cost excluded from condition timing"
        ),
        "minimum_end_to_end_p95_speedup": 5.0,
        "equivalent_minimum_p95_reduction_percent": 80.0,
        "comparison_reduction_percent": 50.0,
        "five_x_exceeds_50_percent_reduction_requirement": True,
        "aggregate_end_to_end_p95_speedup": 4.0,
        "aggregate_p95_reduction_percent": 75.0,
        "trajectory_end_to_end_p95_speedups": [4.0, 4.0],
        "all_trajectories_meet_minimum": False,
        "aggregate_meets_minimum": False,
        "zero_safety_mismatches": True,
        "target_achieved": False,
        "status": "not-achieved",
        "release_qualification_claimed": False,
    }
    assert "\\CPythonTrialStretchTargetAchieved}{no}" in evidence.render_latex(
        summary
    )

    boundary = _receipt()
    _set_measured_zerorun_wall(boundary, 20.0)
    boundary_summary = _analyze(boundary)
    assert boundary_summary["release_stretch_assessment"][
        "aggregate_end_to_end_p95_speedup"
    ] == 5.0
    assert boundary_summary["release_stretch_assessment"]["target_achieved"] is True


def test_macro_renderer_recomputes_stretch_decision_and_denominators() -> None:
    forged_decision = _analyze(_receipt())
    forged_decision["release_stretch_assessment"]["target_achieved"] = False
    with pytest.raises(evidence.EvidenceError, match="stretch target decision mismatch"):
        evidence.render_latex(forged_decision)

    forged_denominator = _analyze(_receipt())
    forged_denominator["safety"]["claimed_replays"] = 119
    with pytest.raises(evidence.EvidenceError, match="aggregate claimed-replay count"):
        evidence.render_latex(forged_denominator)

    forged_scope = _analyze(_receipt())
    forged_scope["confirmatory_claims_authorized"] = True
    with pytest.raises(evidence.EvidenceError, match="authorize confirmatory claims"):
        evidence.render_latex(forged_scope)

    forged_release = _analyze(_receipt())
    forged_release["release_stretch_assessment"][
        "release_qualification_claimed"
    ] = True
    with pytest.raises(evidence.EvidenceError, match="cannot claim release qualification"):
        evidence.render_latex(forged_release)


def test_stdout_must_be_byte_identical_and_stderr_empty() -> None:
    payload = (json.dumps(_receipt(), sort_keys=True) + "\n").encode("utf-8")
    with pytest.raises(evidence.EvidenceError, match="stdout is not byte-identical"):
        evidence.analyze_bytes(payload, payload + b" ", b"")
    with pytest.raises(evidence.EvidenceError, match="stderr is not empty"):
        evidence.analyze_bytes(payload, payload, b"warning\n")


def test_duplicate_json_keys_and_nonfinite_numbers_are_rejected() -> None:
    duplicate = b'{"schema":2,"schema":2}\n'
    with pytest.raises(evidence.EvidenceError, match="duplicate JSON key"):
        evidence.analyze_bytes(duplicate, duplicate, b"")
    nonfinite = b'{"value":NaN}\n'
    with pytest.raises(evidence.EvidenceError, match="non-finite"):
        evidence.analyze_bytes(nonfinite, nonfinite, b"")


def test_integer_schema_and_denominators_reject_numeric_spoofing() -> None:
    floating_schema = _receipt()
    floating_schema["schema"] = 2.0
    with pytest.raises(evidence.EvidenceError, match="receipt schema must be an integer"):
        _analyze(floating_schema)

    floating_count = _receipt()
    floating_count["trajectories"][0]["summary"]["claimed_replays"] = 60.0
    with pytest.raises(evidence.EvidenceError, match="replay count must be an integer"):
        _analyze(floating_count)

    boolean_serial = _receipt()
    boolean_serial["runtime"]["interpreter_attestation"]["serial"] = False
    with pytest.raises(evidence.EvidenceError, match="interpreter serial must be an integer"):
        _analyze(boolean_serial)


def test_malformed_oci_collection_is_rejected_without_type_error() -> None:
    receipt = _receipt()
    receipt["runtime"]["oci_identity"]["repo_digests"].append(7)
    with pytest.raises(evidence.EvidenceError, match="must be non-empty text"):
        _analyze(receipt)


@pytest.mark.parametrize(
    "mutation, message",
    [
        (
            lambda receipt: receipt["source"].__setitem__(
                "remote", "https://github.com/python/cpython"
            ),
            "source origin mismatch",
        ),
        (
            lambda receipt: receipt["source"]["revisions"].pop(),
            "source revision trace mismatch",
        ),
        (
            lambda receipt: receipt["configuration"].__setitem__(
                "zerorun_version", "0.5.0"
            ),
            "engine version mismatch",
        ),
        (
            lambda receipt: receipt["runtime"]["interpreter_attestation"].__setitem__(
                "version_info", [3, 11, 9]
            ),
            "interpreter version_info",
        ),
        (
            lambda receipt: receipt["closure"].__setitem__(
                "independently_audited", True
            ),
            "closure audit disclosure mismatch",
        ),
        (
            lambda receipt: receipt["limits"].pop(),
            "receipt limitations changed",
        ),
    ],
)
def test_frozen_identity_and_scope_mutations_fail_closed(mutation, message: str) -> None:
    receipt = _receipt()
    mutation(receipt)
    with pytest.raises(evidence.EvidenceError, match=message):
        _analyze(receipt)


def test_engine_file_records_are_recomputed_not_merely_labeled() -> None:
    receipt = _receipt()
    receipt["configuration"]["engine_source_identity"]["files"][0][
        "sha256"
    ] = "0" * 64
    with pytest.raises(evidence.EvidenceError, match="does not match its file records"):
        _analyze(receipt)


def test_changed_path_closure_and_status_must_reconcile() -> None:
    receipt = _receipt()
    iteration = receipt["trajectories"][0]["iterations"][0]
    iteration["changed_files"] = ["Lib/configparser.py"]
    with pytest.raises(evidence.EvidenceError, match="expected-fresh targets do not recompute"):
        _analyze(receipt)


def test_every_hit_requires_one_same_target_fresh_shadow() -> None:
    receipt = _receipt()
    shadow = receipt["trajectories"][0]["iterations"][0]["shadow"]
    shadow["targets"].pop()
    shadow["shadow_count"] = 2
    with pytest.raises(evidence.EvidenceError, match="shadow count mismatch"):
        _analyze(receipt)


def test_cache_keys_must_be_previously_published_and_cross_trajectory_disjoint() -> None:
    unpublished = _receipt()
    unpublished["trajectories"][0]["iterations"][0]["zerorun"]["targets"][0][
        "cache_key"
    ] = "f" * 64
    with pytest.raises(evidence.EvidenceError, match="not previously published"):
        _analyze(unpublished)

    overlap = _receipt()
    first = overlap["trajectories"][0]
    second = overlap["trajectories"][1]
    replacement = {
        target: first["seed"]["targets"][index]["cache_key"]
        for index, target in enumerate(evidence.TASK_NAMES)
    }
    for index, target in enumerate(evidence.TASK_NAMES):
        second["seed"]["targets"][index]["cache_key"] = replacement[target]
    for iteration in second["iterations"]:
        for index, target in enumerate(evidence.TASK_NAMES):
            iteration["zerorun"]["targets"][index]["cache_key"] = replacement[target]
    with pytest.raises(evidence.EvidenceError, match="trajectory cache keys overlap"):
        _analyze(overlap)


def test_counterbalance_and_derived_timing_cannot_be_declared_into_existence() -> None:
    order_drift = _receipt()
    order_drift["trajectories"][1]["iterations"][0]["condition_order"] = [
        evidence.DIRECT_CONDITION,
        evidence.ZERORUN_CONDITION,
    ]
    with pytest.raises(evidence.EvidenceError, match="condition order mismatch"):
        _analyze(order_drift)

    timing_drift = _receipt()
    timing_drift["trajectories"][0]["summary"][
        "p95_time_reduction_percent"
    ] = 99.9
    with pytest.raises(evidence.EvidenceError, match="p95 reduction does not recompute"):
        _analyze(timing_drift)


def test_top_level_passing_label_cannot_override_a_failed_gate() -> None:
    receipt = _receipt()
    receipt["trajectories"][0]["summary"]["pass"] = False
    with pytest.raises(evidence.EvidenceError, match="summary did not pass"):
        _analyze(receipt)


def test_cli_writes_only_namespaced_formative_outputs(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    payload = (json.dumps(_receipt(), indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )
    receipt_path = tmp_path / "raw.json"
    stdout_path = tmp_path / "trial.stdout"
    stderr_path = tmp_path / "trial.stderr"
    summary_path = tmp_path / "summary.json"
    latex_path = tmp_path / "macros.tex"
    receipt_path.write_bytes(payload)
    stdout_path.write_bytes(payload)
    stderr_path.write_bytes(b"")

    assert evidence.main(
        [
            "--receipt",
            str(receipt_path),
            "--stdout",
            str(stdout_path),
            "--stderr",
            str(stderr_path),
            "--output",
            str(summary_path),
            "--latex-output",
            str(latex_path),
        ]
    ) == 0
    captured = capsys.readouterr()
    assert captured.err == ""
    written = json.loads(summary_path.read_text(encoding="utf-8"))
    assert written["schema"] == evidence.SUMMARY_SCHEMA
    assert written["primary_metrics_populated"] is False
    assert "resultsavailable" not in latex_path.read_text(encoding="utf-8").lower()


def test_cli_rejects_output_aliases_before_writing(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    payload = (json.dumps(_receipt(), indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )
    receipt_path = tmp_path / "raw.json"
    stdout_path = tmp_path / "trial.stdout"
    stderr_path = tmp_path / "trial.stderr"
    aliased_output = tmp_path / "same-output"
    receipt_path.write_bytes(payload)
    stdout_path.write_bytes(payload)
    stderr_path.write_bytes(b"")

    assert evidence.main(
        [
            "--receipt",
            str(receipt_path),
            "--stdout",
            str(stdout_path),
            "--stderr",
            str(stderr_path),
            "--output",
            str(aliased_output),
            "--latex-output",
            str(aliased_output),
        ]
    ) == 1
    captured = capsys.readouterr()
    assert "must be different files" in captured.err
    assert not aliased_output.exists()

    assert evidence.main(
        [
            "--receipt",
            str(receipt_path),
            "--stdout",
            str(stdout_path),
            "--stderr",
            str(stderr_path),
            "--output",
            str(receipt_path),
            "--latex-output",
            str(tmp_path / "unused.tex"),
        ]
    ) == 1
    captured = capsys.readouterr()
    assert "must not overwrite an evidence input" in captured.err
    assert receipt_path.read_bytes() == payload

    hard_link = tmp_path / "raw-hard-link.json"
    os.link(receipt_path, hard_link)
    assert evidence.main(
        [
            "--receipt",
            str(receipt_path),
            "--stdout",
            str(stdout_path),
            "--stderr",
            str(stderr_path),
            "--output",
            str(hard_link),
            "--latex-output",
            str(tmp_path / "still-unused.tex"),
        ]
    ) == 1
    captured = capsys.readouterr()
    assert "must not hard-link an evidence input" in captured.err
    assert receipt_path.read_bytes() == payload
