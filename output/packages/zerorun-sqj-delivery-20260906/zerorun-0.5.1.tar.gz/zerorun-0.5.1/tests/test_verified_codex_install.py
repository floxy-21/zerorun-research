from __future__ import annotations

import base64
import gzip
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path
from unittest import mock

import pytest

from tools import install_verified_codex_cli as installer
from tools import aggregate_codex_install_evidence as evidence


@pytest.mark.parametrize(
    "relative_script",
    (
        "tools/aggregate_codex_install_evidence.py",
        "tools/codex_agent_lifecycle.py",
    ),
)
def test_repo_tools_are_directly_executable_without_pythonpath(
    relative_script: str,
) -> None:
    repository = Path(__file__).resolve().parents[1]
    environment = dict(os.environ)
    environment.pop("PYTHONPATH", None)
    completed = subprocess.run(
        [sys.executable, relative_script, "--help"],
        cwd=repository,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=15,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr.decode(
        "utf-8", errors="replace"
    )
    assert completed.stdout.startswith(b"usage:")


def _archive(path: Path, entries: list[tuple[str, bytes, str]]) -> None:
    with tarfile.open(path, "w:gz") as archive:
        for name, payload, kind in entries:
            member = tarfile.TarInfo(name)
            if kind == "file":
                member.size = len(payload)
                member.mode = 0o755 if name.endswith("/codex") else 0o644
                archive.addfile(member, io.BytesIO(payload))
            elif kind == "directory":
                member.type = tarfile.DIRTYPE
                member.mode = 0o755
                archive.addfile(member)
            elif kind == "symlink":
                member.type = tarfile.SYMTYPE
                member.linkname = payload.decode("utf-8")
                archive.addfile(member)
            elif kind == "hardlink":
                member.type = tarfile.LNKTYPE
                member.linkname = payload.decode("utf-8")
                archive.addfile(member)
            elif kind == "sparse":
                member.type = tarfile.GNUTYPE_SPARSE
                member.size = len(payload)
                archive.addfile(member, io.BytesIO(payload))
            else:  # pragma: no cover - helper misuse
                raise AssertionError(kind)


def _archive_with_declared_size(
    path: Path,
    *,
    name: str,
    size: int,
    member_type: bytes = tarfile.REGTYPE,
) -> None:
    member = tarfile.TarInfo(name)
    member.mode = 0o644
    member.size = size
    member.type = member_type
    with gzip.open(path, "wb") as handle:
        handle.write(member.tobuf(format=tarfile.GNU_FORMAT))
        handle.write(b"\0" * 1024)


def _metadata(version: str) -> bytes:
    return json.dumps({"name": "@openai/codex", "version": version}).encode()


def _sri(payload: bytes) -> str:
    return "sha512-" + base64.b64encode(hashlib.sha512(payload).digest()).decode("ascii")


def test_sri_is_exact_canonical_sha512(tmp_path: Path) -> None:
    package = tmp_path / "package.tgz"
    package.write_bytes(b"fixed package")
    expected = _sri(package.read_bytes())

    installer._verify_sri(package, expected)
    with pytest.raises(installer.InstallError, match="integrity mismatch"):
        installer._verify_sri(package, _sri(b"different"))
    with pytest.raises(installer.InstallError, match="sha512 SRI"):
        installer._verify_sri(package, "sha256-deadbeef")


def test_package_metadata_and_archive_types_are_validated(tmp_path: Path) -> None:
    valid = tmp_path / "valid.tgz"
    _archive(valid, [("package/package.json", _metadata("1.2.3"), "file")])
    assert installer._read_package_json(valid, "1.2.3")["version"] == "1.2.3"

    with pytest.raises(installer.InstallError, match="identity"):
        installer._read_package_json(valid, "1.2.4")

    linked = tmp_path / "linked.tgz"
    _archive(
        linked,
        [
            ("package/package.json", _metadata("1.2.3"), "file"),
            ("package/link", b"/etc/passwd", "symlink"),
        ],
    )
    with pytest.raises(installer.InstallError, match="link or special"):
        installer._read_package_json(linked, "1.2.3")


def test_platform_extraction_accepts_only_regular_vendor_payload(tmp_path: Path) -> None:
    package_root = tmp_path / "installed"
    package_root.mkdir()
    archive = tmp_path / "platform.tgz"
    _archive(
        archive,
        [
            ("package/vendor/x86_64-unknown-linux-musl/bin", b"", "directory"),
            ("package/vendor/x86_64-unknown-linux-musl/bin/codex", b"native", "file"),
        ],
    )

    count, size = installer._extract_verified_vendor(archive, package_root)

    installed = package_root / "vendor/x86_64-unknown-linux-musl/bin/codex"
    assert (count, size) == (1, 6)
    assert installed.read_bytes() == b"native"


def test_platform_extraction_rejects_escape_and_links(tmp_path: Path) -> None:
    for suffix, entries, match in (
        (
            "escape",
            [("package/vendor/../../outside", b"bad", "file")],
            "unsafe archive path",
        ),
        (
            "link",
            [("package/vendor/bin/codex", b"../../outside", "symlink")],
            "link or special",
        ),
        (
            "hardlink",
            [("package/vendor/bin/codex", b"package/package.json", "hardlink")],
            "link or special",
        ),
    ):
        package_root = tmp_path / f"installed-{suffix}"
        package_root.mkdir()
        archive = tmp_path / f"{suffix}.tgz"
        _archive(archive, entries)
        with pytest.raises(installer.InstallError, match=match):
            installer._extract_verified_vendor(archive, package_root)


class _Response(io.BytesIO):
    def __init__(self, payload: bytes, url: str, declared: str | None = None):
        super().__init__(payload)
        self._url = url
        self.headers = {} if declared is None else {"Content-Length": declared}

    def geturl(self) -> str:
        return self._url

    def __enter__(self):
        return self

    def __exit__(self, *_args) -> None:
        self.close()


def test_download_refuses_redirects_and_length_mismatch(tmp_path: Path) -> None:
    exact = "https://registry.npmjs.org/@openai/codex/-/codex-1.2.3.tgz"
    with mock.patch.object(
        installer.urllib.request,
        "urlopen",
        return_value=_Response(b"payload", exact + "?changed"),
    ):
        with pytest.raises(installer.InstallError, match="redirected"):
            installer._download_exact(exact, tmp_path / "redirected.tgz", maximum=100)

    with mock.patch.object(
        installer.urllib.request,
        "urlopen",
        return_value=_Response(b"payload", exact, declared="8"),
    ):
        with pytest.raises(installer.InstallError, match="differs"):
            installer._download_exact(exact, tmp_path / "short.tgz", maximum=100)


def test_install_rejects_non_exact_version_before_mutation(tmp_path: Path) -> None:
    with pytest.raises(installer.InstallError, match="exact three-component"):
        installer.install(
            version="latest",
            main_integrity=_sri(b"main"),
            platform_integrity=_sri(b"platform"),
            prefix=tmp_path / "prefix",
            receipt=tmp_path / "receipt.json",
            evidence_id="non-exact-version",
            source_commit="a" * 40,
        )
    assert not (tmp_path / "prefix").exists()
    assert not (tmp_path / "receipt.json").exists()


@pytest.mark.parametrize(
    ("evidence_id", "source_commit", "message"),
    [
        ("bad id", "a" * 40, "evidence_id"),
        ("valid-id", "0" * 40, "source_commit"),
        ("valid-id", "A" * 40, "source_commit"),
    ],
)
def test_install_requires_canonical_nonplaceholder_evidence_binding(
    tmp_path: Path,
    evidence_id: str,
    source_commit: str,
    message: str,
) -> None:
    with pytest.raises(installer.InstallError, match=message):
        installer.install(
            version="1.2.3",
            main_integrity=_sri(b"main"),
            platform_integrity=_sri(b"platform"),
            prefix=tmp_path / "prefix",
            receipt=tmp_path / "receipt.json",
            evidence_id=evidence_id,
            source_commit=source_commit,
        )
    assert not (tmp_path / "prefix").exists()


def test_direct_wrapper_extraction_matches_every_authenticated_file_and_detects_injection(
    tmp_path: Path,
) -> None:
    archive = tmp_path / "wrapper.tgz"
    _archive(
        archive,
        [
            ("package/bin/codex.js", b"#!/usr/bin/env node\n", "file"),
            ("package/package.json", _metadata("1.2.3"), "file"),
            ("package/README.md", b"authenticated readme\n", "file"),
        ],
    )
    package_root = tmp_path / "package-root"
    package_root.mkdir()

    expected, identity = installer._extract_authenticated_files(
        archive,
        package_root,
        label="wrapper",
        maximum_files=installer.MAX_MAIN_FILES,
        maximum_unpacked_bytes=installer.MAX_MAIN_UNPACKED_BYTES,
        install_member=lambda _path: True,
        allow_member=lambda path: path.parts[0] != "vendor",
    )

    observed = installer._tree_manifest(package_root)
    if os.name == "nt":
        expected = [
            {**row, "mode": next(item["mode"] for item in observed if item["path"] == row["path"])}
            for row in expected
        ]
    assert observed == expected
    assert identity["regular_files"] == 3
    (package_root / "bin/codex.js").write_bytes(b"injected launcher\n")
    assert installer._tree_manifest(package_root) != expected


def test_direct_extraction_rejects_duplicate_and_unexpected_members(tmp_path: Path) -> None:
    duplicate = tmp_path / "duplicate.tgz"
    _archive(
        duplicate,
        [
            ("package/bin/codex.js", b"first", "file"),
            ("package/bin/codex.js", b"second", "file"),
        ],
    )
    root = tmp_path / "duplicate-root"
    root.mkdir()
    with pytest.raises(installer.InstallError, match="duplicate paths"):
        installer._extract_authenticated_files(
            duplicate,
            root,
            label="wrapper",
            maximum_files=installer.MAX_MAIN_FILES,
            maximum_unpacked_bytes=installer.MAX_MAIN_UNPACKED_BYTES,
            install_member=lambda _path: True,
            allow_member=lambda path: path.parts[0] != "vendor",
        )

    unexpected = tmp_path / "unexpected.tgz"
    _archive(unexpected, [("package/vendor/injected", b"bad", "file")])
    other_root = tmp_path / "unexpected-root"
    other_root.mkdir()
    with pytest.raises(installer.InstallError, match="unexpected member"):
        installer._extract_authenticated_files(
            unexpected,
            other_root,
            label="wrapper",
            maximum_files=installer.MAX_MAIN_FILES,
            maximum_unpacked_bytes=installer.MAX_MAIN_UNPACKED_BYTES,
            install_member=lambda _path: True,
            allow_member=lambda path: path.parts[0] != "vendor",
        )


def test_archive_passes_stream_without_getmembers_materialization(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    archive = tmp_path / "streamed.tgz"
    _archive(
        archive,
        [
            ("package/package.json", _metadata("1.2.3"), "file"),
            ("package/bin/codex.js", b"launcher", "file"),
        ],
    )
    monkeypatch.setattr(
        tarfile.TarFile,
        "getmembers",
        lambda *_args, **_kwargs: pytest.fail("getmembers materialized the archive"),
    )

    assert installer._read_package_json(archive, "1.2.3")["version"] == "1.2.3"
    destination = tmp_path / "streamed-root"
    destination.mkdir()
    rows, identity = installer._extract_authenticated_files(
        archive,
        destination,
        label="wrapper",
        maximum_files=installer.MAX_MAIN_FILES,
        maximum_unpacked_bytes=installer.MAX_MAIN_UNPACKED_BYTES,
        install_member=lambda _path: True,
        allow_member=lambda path: path.parts[0] != "vendor",
    )
    assert len(rows) == 2
    assert identity["regular_files"] == 2


def test_streaming_member_count_is_enforced_as_headers_arrive(tmp_path: Path) -> None:
    archive = tmp_path / "many-members.tgz"
    entries = [
        (f"package/vendor/directory-{index}", b"", "directory")
        for index in range(5)
    ]
    _archive(archive, entries)
    destination = tmp_path / "many-root"
    destination.mkdir()

    with pytest.raises(installer.InstallError, match="member-count bound"):
        installer._extract_authenticated_files(
            archive,
            destination,
            label="platform",
            maximum_files=1,
            maximum_unpacked_bytes=1024,
            install_member=lambda _path: False,
            allow_member=lambda path: path.parts[0] == "vendor",
        )


def test_tar_extension_nesting_is_bounded_before_recursive_processing(
    tmp_path: Path,
) -> None:
    archive = tmp_path / "many-raw-headers.tgz"
    with gzip.open(archive, "wb") as handle:
        for index in range(installer.MAX_ARCHIVE_EXTENSION_DEPTH + 1):
            extension = tarfile.TarInfo(f"package/pax-{index}")
            extension.type = tarfile.XGLTYPE
            extension.size = 0
            handle.write(extension.tobuf(format=tarfile.PAX_FORMAT))
        final = tarfile.TarInfo("package/vendor/final")
        final.type = tarfile.DIRTYPE
        final.size = 0
        handle.write(final.tobuf(format=tarfile.PAX_FORMAT))
        handle.write(b"\0" * 1024)
    destination = tmp_path / "raw-header-root"
    destination.mkdir()

    with pytest.raises(installer.InstallError, match="extension-header nesting bound"):
        installer._extract_authenticated_files(
            archive,
            destination,
            label="platform",
            maximum_files=installer.MAX_PLATFORM_FILES,
            maximum_unpacked_bytes=installer.MAX_PLATFORM_UNPACKED_BYTES,
            install_member=lambda _path: False,
            allow_member=lambda path: path.parts[0] == "vendor",
        )


def test_declared_size_is_rejected_before_extractfile_or_destination_write(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    archive = tmp_path / "oversized-header.tgz"
    _archive_with_declared_size(
        archive,
        name="package/vendor/bin/codex",
        size=1025,
    )
    destination = tmp_path / "oversized-root"
    destination.mkdir()
    monkeypatch.setattr(
        tarfile.TarFile,
        "extractfile",
        lambda *_args, **_kwargs: pytest.fail("oversized member reached extractfile"),
    )

    with pytest.raises(installer.InstallError, match="extraction bounds"):
        installer._extract_authenticated_files(
            archive,
            destination,
            label="platform",
            maximum_files=1,
            maximum_unpacked_bytes=1024,
            install_member=lambda _path: True,
            allow_member=lambda path: path.parts[0] == "vendor",
        )
    assert list(destination.iterdir()) == []


def test_oversized_pax_metadata_is_rejected_before_tarfile_body_allocation(
    tmp_path: Path,
) -> None:
    archive = tmp_path / "oversized-pax.tgz"
    _archive_with_declared_size(
        archive,
        name="package/pax-header",
        size=installer.MAX_ARCHIVE_METADATA_BYTES + 1,
        member_type=tarfile.XHDTYPE,
    )

    with pytest.raises(installer.InstallError, match="metadata header exceeds"):
        installer._read_package_json(archive, "1.2.3")


def test_bounded_pax_long_path_streams_and_extracts(tmp_path: Path) -> None:
    archive = tmp_path / "bounded-pax.tgz"
    relative = Path("vendor") / ("a" * 70) / ("b" * 40) / "codex"
    _archive(archive, [(f"package/{relative.as_posix()}", b"native", "file")])
    destination = tmp_path / "bounded-pax-root"
    destination.mkdir()

    rows, identity = installer._extract_authenticated_files(
        archive,
        destination,
        label="platform",
        maximum_files=installer.MAX_PLATFORM_FILES,
        maximum_unpacked_bytes=installer.MAX_PLATFORM_UNPACKED_BYTES,
        install_member=lambda _path: True,
        allow_member=lambda path: path.parts[0] == "vendor",
    )

    assert (destination / relative).read_bytes() == b"native"
    assert [row["path"] for row in rows] == [relative.as_posix()]
    assert identity["regular_files"] == 1


def test_sparse_member_is_rejected_before_extraction(tmp_path: Path) -> None:
    archive = tmp_path / "sparse.tgz"
    _archive(
        archive,
        [("package/vendor/bin/codex", b"sparse payload", "sparse")],
    )
    destination = tmp_path / "sparse-root"
    destination.mkdir()

    with pytest.raises(installer.InstallError, match="sparse member"):
        installer._extract_authenticated_files(
            archive,
            destination,
            label="platform",
            maximum_files=1,
            maximum_unpacked_bytes=1024,
            install_member=lambda _path: True,
            allow_member=lambda path: path.parts[0] == "vendor",
        )
    assert list(destination.iterdir()) == []


def test_archive_identity_drift_after_sri_is_rejected_before_extraction(
    tmp_path: Path,
) -> None:
    archive = tmp_path / "authenticated.tgz"
    replacement = tmp_path / "replacement.tgz"
    _archive(archive, [("package/vendor/bin/codex", b"good", "file")])
    _archive(replacement, [("package/vendor/bin/codex", b"evil", "file")])
    verified = installer._verify_sri(archive, _sri(archive.read_bytes()))
    replacement.replace(archive)
    destination = tmp_path / "drift-root"
    destination.mkdir()

    with pytest.raises(installer.InstallError, match="changed since integrity"):
        installer._extract_authenticated_files(
            archive,
            destination,
            label="platform",
            maximum_files=1,
            maximum_unpacked_bytes=1024,
            install_member=lambda _path: True,
            allow_member=lambda path: path.parts[0] == "vendor",
            expected_identity=verified,
        )
    assert list(destination.iterdir()) == []


def test_archive_mutation_during_stream_is_detected_after_iteration(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    archive = tmp_path / "racing.tgz"
    _archive(archive, [("package/vendor/bin/codex", b"good", "file")])
    verified = installer._verify_sri(archive, _sri(archive.read_bytes()))
    destination = tmp_path / "racing-root"
    destination.mkdir()
    real_verify = installer._verify_open_archive_unchanged
    mutated = False

    def mutate_then_verify(handle, *, opened, lexical, label):
        nonlocal mutated
        if not mutated:
            mutated = True
            with archive.open("ab") as writer:
                writer.write(b"drift")
                writer.flush()
                os.fsync(writer.fileno())
        return real_verify(
            handle,
            opened=opened,
            lexical=lexical,
            label=label,
        )

    monkeypatch.setattr(installer, "_verify_open_archive_unchanged", mutate_then_verify)

    with pytest.raises(installer.InstallError, match="changed while being read"):
        installer._extract_authenticated_files(
            archive,
            destination,
            label="platform",
            maximum_files=1,
            maximum_unpacked_bytes=1024,
            install_member=lambda _path: True,
            allow_member=lambda path: path.parts[0] == "vendor",
            expected_identity=verified,
        )
    assert mutated is True


def test_existing_destination_is_never_clobbered(tmp_path: Path) -> None:
    archive = tmp_path / "no-clobber.tgz"
    _archive(archive, [("package/bin/codex.js", b"new", "file")])
    destination = tmp_path / "no-clobber-root"
    existing = destination / "bin" / "codex.js"
    existing.parent.mkdir(parents=True)
    existing.write_bytes(b"user-owned")

    with pytest.raises(installer.InstallError, match="appeared before extraction"):
        installer._extract_authenticated_files(
            archive,
            destination,
            label="wrapper",
            maximum_files=installer.MAX_MAIN_FILES,
            maximum_unpacked_bytes=installer.MAX_MAIN_UNPACKED_BYTES,
            install_member=lambda _path: True,
            allow_member=lambda path: path.parts[0] != "vendor",
        )
    assert existing.read_bytes() == b"user-owned"


def _install_receipt(tmp_path: Path, evidence_id: str) -> dict[str, object]:
    version = "1.2.3"
    runtime_path = str((tmp_path / "runtime").resolve())
    runtime = {
        "command": "node",
        "lexical_path": runtime_path,
        "lexical_kind": "regular_file",
        "link_target": None,
        "resolved_path": runtime_path,
        "resolved_bytes": 10,
        "resolved_sha256": "a" * 64,
        "reported_version": "v22.14.0",
    }
    main_sri = _sri(b"main")
    platform_sri = _sri(b"platform")
    payload: dict[str, object] = {
        "schema": installer.SCHEMA,
        "evidence_id": evidence_id,
        "source_commit": "a" * 40,
        "codex_version": version,
        "platform": "linux-x64",
        "main_package": {
            "url": f"{installer.REGISTRY_ORIGIN}/@openai/codex/-/codex-{version}.tgz",
            "integrity": main_sri,
            "sha256": "1" * 64,
            "bytes": 100,
            "metadata_sha256": "2" * 64,
            "regular_files": 3,
            "unpacked_bytes": 90,
            "member_manifest_sha256": "3" * 64,
        },
        "platform_package": {
            "url": f"{installer.REGISTRY_ORIGIN}/@openai/codex/-/codex-{version}-linux-x64.tgz",
            "integrity": platform_sri,
            "sha256": "4" * 64,
            "bytes": 200,
            "metadata_sha256": "5" * 64,
            "regular_files": 3,
            "unpacked_bytes": 190,
            "member_manifest_sha256": "6" * 64,
        },
        "installed": {
            "package_tree_sha256": "7" * 64,
            "package_tree_regular_files": 4,
            "package_tree_bytes": 180,
            "launcher_sha256": "8" * 64,
            "native_sha256": "9" * 64,
            "vendor_regular_files": 1,
            "vendor_unpacked_bytes": 90,
            "command_kind": "relative_symlink",
            "command_target": "../lib/node_modules/@openai/codex/bin/codex.js",
            "command_resolves_to_launcher": True,
        },
        "runtime": {
            "node": runtime,
            "runtime_identity_unchanged_after_retrieval": True,
        },
        "installer_source_sha256": installer._sha256(Path(installer.__file__).resolve()),
        "network": {
            "fixed_https_archive_downloads": 2,
            "integrity_verified_before_prefix_creation": True,
            "subprocesses_after_integrity_verification": 0,
            "network_operations_after_integrity_verification": 0,
            "package_manager_invoked": False,
        },
        "node_version": "v22.14.0",
        "network_after_integrity_verification": False,
        "installation_method": "direct-authenticated-archive-extraction",
    }
    return {**payload, "evidence_payload_sha256": installer._canonical_sha256(payload)}


def _write_canonical(path: Path, value: dict[str, object]) -> None:
    path.write_bytes(
        (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode(
            "utf-8"
        )
    )


def test_install_receipts_are_structurally_validated_and_aggregated(tmp_path: Path) -> None:
    receipts = []
    ids = [f"commercial-batch-{index}" for index in range(10)]
    for evidence_id in ids:
        path = tmp_path / f"{evidence_id}.json"
        _write_canonical(path, _install_receipt(tmp_path, evidence_id))
        receipts.append(path)

    result = evidence.aggregate(
        receipts,
        expected_ids=ids,
        expected_source_commit="a" * 40,
        version="1.2.3",
        main_integrity=_sri(b"main"),
        platform_integrity=_sri(b"platform"),
    )

    assert result["receipt_count"] == 10
    assert result["schema"] == evidence.SCHEMA
    assert result["complete_denominator"] is True
    assert result["authenticated_installation_identical_across_receipts"] is True
    assert [row["evidence_id"] for row in result["receipts"]] == ids
    assert all("node" in row and "npm" not in row for row in result["receipts"])
    assert result["evidence_payload_sha256"] == installer._canonical_sha256(
        {
            key: value
            for key, value in result.items()
            if key != "evidence_payload_sha256"
        }
    )


def test_verified_installer_never_discovers_or_executes_npm() -> None:
    source = Path(installer.__file__).read_text(encoding="utf-8")

    assert '_runtime_identity("npm")' not in source
    assert '_runtime_file_identity("npm")' not in source
    assert "npm_before" not in source
    assert '"npm_version"' not in source
    assert '"npm_install_mode"' not in source


def test_legacy_npm_bound_install_receipt_is_rejected_fail_closed(
    tmp_path: Path,
) -> None:
    path = tmp_path / "legacy-receipt.json"
    value = _install_receipt(tmp_path, "commercial-batch-0")
    value["schema"] = "zerorun.verified-codex-install.v2"
    value["npm_version"] = "10.9.2"
    value["npm_install_mode"] = "not-invoked-direct-authenticated-extraction"
    value.pop("installation_method")
    runtime = value["runtime"]
    assert isinstance(runtime, dict)
    runtime["npm_invoked_for_installation"] = False
    network = value["network"]
    assert isinstance(network, dict)
    network["npm_configuration_or_cache_used"] = False
    network.pop("package_manager_invoked")
    payload = {
        key: item for key, item in value.items() if key != "evidence_payload_sha256"
    }
    value["evidence_payload_sha256"] = installer._canonical_sha256(payload)
    _write_canonical(path, value)

    with pytest.raises(evidence.EvidenceError, match="unexpected structure"):
        evidence.validate_receipt(
            path,
            expected_id="commercial-batch-0",
            expected_source_commit="a" * 40,
            version="1.2.3",
            main_integrity=_sri(b"main"),
            platform_integrity=_sri(b"platform"),
        )


def test_receipt_cannot_claim_that_a_package_manager_was_invoked(
    tmp_path: Path,
) -> None:
    path = tmp_path / "package-manager-receipt.json"
    value = _install_receipt(tmp_path, "commercial-batch-0")
    network = value["network"]
    assert isinstance(network, dict)
    network["package_manager_invoked"] = True
    payload = {
        key: item for key, item in value.items() if key != "evidence_payload_sha256"
    }
    value["evidence_payload_sha256"] = installer._canonical_sha256(payload)
    _write_canonical(path, value)

    with pytest.raises(evidence.EvidenceError, match="offline boundary"):
        evidence.validate_receipt(
            path,
            expected_id="commercial-batch-0",
            expected_source_commit="a" * 40,
            version="1.2.3",
            main_integrity=_sri(b"main"),
            platform_integrity=_sri(b"platform"),
        )


def test_install_receipt_reader_rejects_open_time_identity_swap(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    path = tmp_path / "receipt.json"
    replacement = tmp_path / "replacement.json"
    path.write_bytes(b"{}\n")
    replacement.write_bytes(b'{"replacement":true}\n')
    real_open = evidence.os.open
    swapped = False

    def swapping_open(raw_path, flags, *args, **kwargs):
        nonlocal swapped
        if Path(raw_path) == path and not swapped:
            swapped = True
            replacement.replace(path)
        return real_open(raw_path, flags, *args, **kwargs)

    monkeypatch.setattr(evidence.os, "open", swapping_open)
    with pytest.raises(evidence.EvidenceError, match="size or identity is invalid"):
        evidence._regular_bytes(path)
    assert swapped is True


def test_install_receipt_reader_rejects_oversized_file(tmp_path: Path) -> None:
    path = tmp_path / "receipt.json"
    path.write_bytes(b"{" + (b" " * evidence.MAX_RECEIPT_BYTES) + b"}")

    with pytest.raises(evidence.EvidenceError, match="size or identity is invalid"):
        evidence._regular_bytes(path)


@pytest.mark.parametrize("mutation", ["truncate", "grow", "rewrite"])
def test_install_receipt_reader_rejects_in_place_mutation(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    mutation: str,
) -> None:
    path = tmp_path / "receipt.json"
    original_bytes = b"{}\n"
    path.write_bytes(original_bytes)
    real_read = evidence.os.read
    mutated = False

    def racing_read(descriptor: int, size: int) -> bytes:
        nonlocal mutated
        if not mutated:
            mutated = True
            before = path.stat()
            if mutation == "truncate":
                replacement = b"{"
            elif mutation == "grow":
                replacement = original_bytes + b" "
            else:
                replacement = b"[]\n"
            path.write_bytes(replacement)
            os.utime(
                path,
                ns=(before.st_atime_ns, before.st_mtime_ns + 1_000_000_000),
            )
        return real_read(descriptor, size)

    monkeypatch.setattr(evidence.os, "read", racing_read)
    with pytest.raises(evidence.EvidenceError, match="changed while being read"):
        evidence._regular_bytes(path)


@pytest.mark.parametrize(
    ("raw", "message"),
    (
        (b"[" * 33 + b"0" + b"]" * 33, "JSON depth limit"),
        (b'{"evidence_id":"a","evidence_id":"b"}\n', "duplicate JSON member"),
        (b'{"evidence_id":NaN}\n', "non-finite JSON constant"),
    ),
)
def test_install_receipt_loader_rejects_adversarial_json(
    tmp_path: Path,
    raw: bytes,
    message: str,
) -> None:
    path = tmp_path / "receipt.json"
    path.write_bytes(raw)

    with pytest.raises(evidence.EvidenceError, match=message):
        evidence._load_receipt(path)


def test_install_receipt_and_launcher_tampering_fail_closed(tmp_path: Path) -> None:
    path = tmp_path / "receipt.json"
    value = _install_receipt(tmp_path, "commercial-batch-0")
    _write_canonical(path, value)
    value["installed"]["launcher_sha256"] = "f" * 64  # type: ignore[index]
    _write_canonical(path, value)
    with pytest.raises(evidence.EvidenceError, match="payload digest mismatch"):
        evidence.validate_receipt(
            path,
            expected_id="commercial-batch-0",
            expected_source_commit="a" * 40,
            version="1.2.3",
            main_integrity=_sri(b"main"),
            platform_integrity=_sri(b"platform"),
        )

    payload = {key: item for key, item in value.items() if key != "evidence_payload_sha256"}
    value["evidence_payload_sha256"] = installer._canonical_sha256(payload)
    _write_canonical(path, value)
    accepted = evidence.validate_receipt(
        path,
        expected_id="commercial-batch-0",
        expected_source_commit="a" * 40,
        version="1.2.3",
        main_integrity=_sri(b"main"),
        platform_integrity=_sri(b"platform"),
    )
    assert accepted["launcher_sha256"] == "f" * 64

    other = tmp_path / "other.json"
    _write_canonical(other, _install_receipt(tmp_path, "commercial-batch-1"))
    with pytest.raises(evidence.EvidenceError, match="identities differ: launcher_sha256"):
        evidence.aggregate(
            [path, other],
            expected_ids=["commercial-batch-0", "commercial-batch-1"],
            expected_source_commit="a" * 40,
            version="1.2.3",
            main_integrity=_sri(b"main"),
            platform_integrity=_sri(b"platform"),
        )
