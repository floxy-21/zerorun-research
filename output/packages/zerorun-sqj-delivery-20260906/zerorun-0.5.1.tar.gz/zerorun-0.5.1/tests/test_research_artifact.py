from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil

import pytest

from research.artifact import check_draft
from research.artifact import validation


ROOT = Path(__file__).resolve().parents[1]
H64 = "a" * 64
GIT40 = "b" * 40


def _git_sha(label: str) -> str:
    return hashlib.sha1(label.encode()).hexdigest()


def _sha256(label: str) -> str:
    return hashlib.sha256(label.encode()).hexdigest()


def _manifest() -> dict[str, object]:
    seed = "synthetic-public-seed"
    repositories: list[dict[str, object]] = []
    specs = {
        "S1": 100,
        "S2": 500,
        "S3": 2_000,
        "S4": 10_000,
    }
    repository_id = 1
    for stratum, stars in specs.items():
        stratum_rows: list[dict[str, object]] = []
        for stratum_index in range(25):
            owner = f"{stratum.casefold()}-owner{stratum_index // 2:02d}"
            name = f"{owner}/repo{repository_id:03d}"
            commits = [_git_sha(f"{name}:commit:{index}") for index in range(21)]
            states = []
            for index, commit in enumerate(commits):
                states.append(
                    {
                        "index": index,
                        "commit_sha": commit,
                        "tree_sha": _git_sha(f"{name}:tree:{index}"),
                        "first_parent_sha": (
                            commits[index - 1]
                            if index
                            else _git_sha(f"{name}:prehistory")
                        ),
                        "committed_at_utc": f"2026-01-{index + 1:02d}T00:00:00Z",
                        "test_target": {
                            "argv": ["python", "-m", "pytest"],
                            "source": "tests_dir",
                            "source_sha256": _sha256(f"{name}:target"),
                        },
                        "dependency_descriptor_sha256": _sha256(
                            f"{name}:dependency:{index}"
                        ),
                        "runtime_image": f"example.invalid/python@sha256:{_sha256(f'{name}:image')}",
                        "runtime_recipe_sha256": _sha256(f"{name}:recipe"),
                    }
                )
            stratum_rows.append(
                {
                    "github_repository_id": repository_id,
                    "canonical_full_name": name,
                    "html_url": f"https://github.com/{name}",
                    "stratum": stratum,
                    "stars_at_sampling": stars,
                    "license_spdx": "MIT",
                    "size_kib": 1_000,
                    "default_branch": "main",
                    "frozen_sha": commits[-1],
                    "rank_key": validation._rank_key(seed, repository_id),
                    "rank_position": 0,
                    "selected_slot": 0,
                    "metadata_sha256": _sha256(f"{name}:metadata"),
                    "states": states,
                }
            )
            repository_id += 1
        stratum_rows.sort(key=lambda row: (row["rank_key"], row["github_repository_id"]))
        for position, row in enumerate(stratum_rows, 1):
            row["rank_position"] = position
            row["selected_slot"] = position
        repositories.extend(stratum_rows)
    return {
        "schema": "zerorun.research-corpus.v1",
        "protocol_commit": GIT40,
        "created_at_utc": "2026-02-01T00:00:00Z",
        "sampling": {
            "seed": seed,
            "seed_source": "synthetic fixture",
            "window_start_utc": "2026-01-01T00:00:00Z",
            "window_end_utc": "2026-01-02T00:00:00Z",
            "github_api_version": "2022-11-28",
            "owner_cap": 2,
            "rank_algorithm": "sha256-zerorun-corpus-v1",
            "frame_archive_sha256": "c" * 64,
            "screening_log_sha256": "d" * 64,
            "strata": [
                {"id": "S1", "min_stars": 100, "max_stars": 499, "selected_count": 25},
                {"id": "S2", "min_stars": 500, "max_stars": 1_999, "selected_count": 25},
                {"id": "S3", "min_stars": 2_000, "max_stars": 9_999, "selected_count": 25},
                {"id": "S4", "min_stars": 10_000, "max_stars": None, "selected_count": 25},
            ],
        },
        "development_contact_exclusion_sha256": "e" * 64,
        "repositories": repositories,
    }


def _selection_chain(manifest: dict[str, object]) -> tuple[dict, dict, dict]:
    candidates = []
    selection_rows = []
    screening_rows = []
    criteria = {
        "metadata": True,
        "license": True,
        "size": True,
        "identity_unique": True,
        "owner_cap": True,
        "first_parent_depth": True,
        "pytest_evidence": True,
        "test_file_count": True,
        "development_contact": True,
        "research_use_permitted": True,
    }
    for frame_position, row in enumerate(manifest["repositories"], 1):
        candidate = {
            "github_repository_id": row["github_repository_id"],
            "canonical_full_name": row["canonical_full_name"],
            "observed_aliases": [row["canonical_full_name"]],
            "html_url": row["html_url"],
            "stratum": row["stratum"],
            "stars_at_sampling": row["stars_at_sampling"],
            "primary_language": "Python",
            "is_fork": False,
            "is_archived": False,
            "is_private": False,
            "pushed_at_utc": "2026-01-01T00:00:00Z",
            "license_spdx": "MIT",
            "size_kib": row["size_kib"],
            "default_branch": row["default_branch"],
            "frozen_head_sha": row["frozen_sha"],
            "metadata_status": "complete",
            "metadata_sha256": row["metadata_sha256"],
            "frame_position": frame_position,
        }
        candidates.append(candidate)
        selection_rows.append(
            {
                "github_repository_id": row["github_repository_id"],
                "canonical_full_name": row["canonical_full_name"],
                "stratum": row["stratum"],
                "rank_key": row["rank_key"],
                "rank_position": row["rank_position"],
                "preliminary_metadata_pass": True,
                "development_contact_excluded": False,
                "proposed_for_screening": True,
                "preliminary_reason_codes": [],
            }
        )
        decisions = [
            {
                "reviewer_id": reviewer,
                "reviewed_at_utc": "2026-01-03T00:00:00Z",
                "eligible": True,
                "criteria": deepcopy(criteria),
                "reason_codes": [],
                "decision_sha256": _sha256(f"{row['canonical_full_name']}:{reviewer}"),
            }
            for reviewer in ("reviewer-a", "reviewer-b")
        ]
        screening_rows.append(
            {
                "github_repository_id": row["github_repository_id"],
                "canonical_full_name": row["canonical_full_name"],
                "stratum": row["stratum"],
                "rank_key": row["rank_key"],
                "rank_position": row["rank_position"],
                "reviewer_decisions": decisions,
                "resolved_eligible": True,
                "resolution": "agreement_include",
                "resolution_note": None,
                "selected_slot": row["selected_slot"],
            }
        )
    frame = {
        "schema": "zerorun.research-candidate-frame.v1",
        "artifact_role": "candidate_frame_only",
        "protocol_commit": GIT40,
        "retrieval_client_commit": "f" * 40,
        "created_at_utc": "2026-01-02T00:00:00Z",
        "sampling": {
            "seed": manifest["sampling"]["seed"],
            "seed_source": "synthetic fixture",
            "seed_source_payload_sha256": H64,
            "window_start_utc": "2026-01-01T00:00:00Z",
            "window_end_utc": "2026-01-02T00:00:00Z",
            "maintenance_cutoff_utc": "2024-01-01T00:00:00Z",
            "github_api_version": "2022-11-28",
            "query_cells": [
                {
                    "cell_id": stratum,
                    "stratum": stratum,
                    "query": f"synthetic {stratum}",
                    "reported_total_count": 25,
                    "pages_fetched": 1,
                    "retrieved_count": 25,
                    "first_request_at_utc": "2026-01-01T00:00:00Z",
                    "last_request_at_utc": "2026-01-01T00:00:01Z",
                    "response_index_sha256": H64,
                    "completeness_status": "complete",
                }
                for stratum in validation.STRATUM_BOUNDS
            ],
        },
        "collection": {
            "algorithm": "github-rest-two-snapshot-created-size-pushed-v1",
            "collector_source_sha256": H64,
            "created_partition_start_date": "2008-01-01",
            "created_partition_end_date": "2026-01-01",
            "terminal_cell_max_results": 900,
            "snapshot_count": 2,
            "selected_snapshot": 2,
            "snapshot_stability_max_symmetric_difference_ratio": 0.01,
            "snapshot_1_distinct_repositories": 100,
            "snapshot_2_distinct_repositories": 100,
            "overall_symmetric_difference_repositories": 0,
            "overall_symmetric_difference_ratio": 0.0,
            "snapshot_comparisons": [
                {
                    "stratum": stratum,
                    "snapshot_1_distinct_repositories": 25,
                    "snapshot_2_distinct_repositories": 25,
                    "symmetric_difference_repositories": 0,
                    "symmetric_difference_ratio": 0.0,
                }
                for stratum in validation.STRATUM_BOUNDS
            ],
            "snapshot_1_search_index_sha256": H64,
            "snapshot_2_search_index_sha256": H64,
            "stable": True,
        },
        "raw_response_index_sha256": H64,
        "raw_response_aggregate_sha256": H64,
        "development_contact_exclusion_sha256": "e" * 64,
        "candidates": candidates,
    }
    selection = {
        "schema": "zerorun.research-candidate-selection.v1",
        "artifact_role": "candidate_selection_only",
        "protocol_commit": GIT40,
        "candidate_frame_sha256": "c" * 64,
        "development_contact_exclusion_sha256": "e" * 64,
        "rank_algorithm": "sha256-zerorun-corpus-v1",
        "seed": manifest["sampling"]["seed"],
        "created_at_utc": "2026-01-03T00:00:00Z",
        "candidates": selection_rows,
    }
    screening = {
        "schema": "zerorun.research-screening-review.v1",
        "protocol_commit": GIT40,
        "candidate_frame_sha256": "c" * 64,
        "candidate_selection_sha256": "9" * 64,
        "development_contact_exclusion_sha256": "e" * 64,
        "created_at_utc": "2026-01-04T00:00:00Z",
        "reviewer_ids": ["reviewer-a", "reviewer-b"],
        "records": screening_rows,
        "agreement": {
            "double_screened_count": 100,
            "raw_agreement": 1.0,
            "cohen_kappa": 1.0,
        },
    }
    return frame, selection, screening


def _catalog() -> tuple[dict, validation.ValidationReport]:
    report = validation.ValidationReport()
    catalog = validation.load_schema_catalog(ROOT / "research" / "schemas", report)
    return catalog, report


def test_every_research_schema_passes_the_draft_2020_12_metaschema() -> None:
    catalog, report = _catalog()
    assert report.errors == []
    assert set(catalog) == set(validation.SCHEMA_TO_FILE)


def test_schema_catalog_rejects_duplicate_json_object_keys(tmp_path: Path) -> None:
    source = ROOT / "research" / "schemas"
    schema_dir = tmp_path / "schemas"
    shutil.copytree(source, schema_dir)
    target = schema_dir / "analysis-output.schema.json"
    text = target.read_text(encoding="utf-8")
    target.write_text(
        text.replace('"$defs": {', '"$defs": {"duplicate": {}, "duplicate": {},', 1),
        encoding="utf-8",
    )

    report = validation.ValidationReport()
    validation.load_schema_catalog(schema_dir, report)

    assert any("duplicate JSON object key: duplicate" in error for error in report.errors)


def test_synthetic_corpus_and_selection_chain_are_valid() -> None:
    manifest = _manifest()
    frame, selection, screening = _selection_chain(manifest)
    catalog, report = _catalog()
    for label, document, marker in (
        ("corpus", manifest, "zerorun.research-corpus.v1"),
        ("frame", frame, "zerorun.research-candidate-frame.v1"),
        ("selection", selection, "zerorun.research-candidate-selection.v1"),
        ("screening", screening, "zerorun.research-screening-review.v1"),
    ):
        validation.validate_instance(document, marker, catalog, report, label)
    assert report.errors == []
    assert validation.validate_corpus_manifest(manifest) == []
    assert validation.validate_selection_chain(
        frame,
        selection,
        screening,
        manifest,
        frame_sha256="c" * 64,
        selection_sha256="9" * 64,
        screening_sha256="d" * 64,
    ) == []


def test_corpus_validator_rejects_owner_duplicates_slots_parent_and_head() -> None:
    manifest = _manifest()
    rows = manifest["repositories"]
    rows[0]["github_repository_id"] = rows[1]["github_repository_id"]
    for index in range(3):
        rows[index]["canonical_full_name"] = f"same-owner/repo-{index}"
    rows[3]["selected_slot"] = rows[4]["selected_slot"]
    rows[5]["states"][10]["first_parent_sha"] = GIT40
    rows[6]["frozen_sha"] = GIT40
    rows[7]["rank_key"] = H64
    errors = "\n".join(validation.validate_corpus_manifest(manifest))
    assert "IDs are not distinct" in errors
    assert "owner cap exceeded" in errors
    assert "selected_slot" in errors
    assert "not adjacent" in errors
    assert "frozen_sha is not state 20" in errors
    assert "rank_key does not match" in errors


def test_corpus_validator_rejects_owner_reused_across_strata() -> None:
    manifest = _manifest()
    rows = manifest["repositories"]
    first = next(row for row in rows if row["stratum"] == "S1")
    second = next(row for row in rows if row["stratum"] == "S2")
    first["canonical_full_name"] = "cross-stratum-owner/repo-s1"
    second["canonical_full_name"] = "cross-stratum-owner/repo-s2"

    errors = "\n".join(validation.validate_corpus_manifest(manifest))
    assert "owner crosses strata" in errors


def test_selection_chain_rejects_single_reviewer_and_rank_skipping() -> None:
    manifest = _manifest()
    frame, selection, screening = _selection_chain(manifest)
    screening["records"][0]["reviewer_decisions"][1]["reviewer_id"] = "reviewer-a"
    screening["records"][1]["selected_slot"] = None
    selection["candidates"][2]["proposed_for_screening"] = False
    extra = deepcopy(frame["candidates"][0])
    extra_id = 10_000
    selected_s1_keys = [
        row["rank_key"] for row in selection["candidates"] if row["stratum"] == "S1"
    ]
    while validation._rank_key(selection["seed"], extra_id) > max(selected_s1_keys):
        extra_id += 1
    extra["github_repository_id"] = extra_id
    extra["canonical_full_name"] = f"extra-owner/repo-{extra_id}"
    extra["observed_aliases"] = [extra["canonical_full_name"]]
    extra["html_url"] = f"https://github.com/{extra['canonical_full_name']}"
    extra["frame_position"] = len(frame["candidates"]) + 1
    frame["candidates"].append(extra)
    errors = "\n".join(
        validation.validate_selection_chain(
            frame,
            selection,
            screening,
            manifest,
            frame_sha256="c" * 64,
            selection_sha256="9" * 64,
            screening_sha256="d" * 64,
        )
    )
    assert "two distinct reviewers" in errors
    assert "contiguous prefix" in errors
    assert "proposed for screening" in errors
    assert "select exactly 25" in errors
    assert "first 25 eligible" in errors
    assert "do not exactly match screened selections" in errors


def test_current_draft_passes_but_submission_requires_a_sealed_artifact() -> None:
    draft = check_draft.run_check(check_draft.parse_args(["--root", str(ROOT / "research")]))
    assert draft["status"] == "PASS"
    submission = check_draft.run_check(
        check_draft.parse_args(["--root", str(ROOT / "research"), "--submission"])
    )
    assert submission["status"] == "FAIL"
    assert "submission mode requires --artifact-root for a sealed artifact" in submission["errors"]
    assert "submission placeholders remain" in submission["errors"]


def _copy_bounded_research_fixture(destination: Path) -> Path:
    """Copy the checker's declared inputs, not unrelated local experiment caches.

    All required files are copied strictly: missing or unreadable evidence still
    fails the fixture. Keep the two inputs resolved outside research/ as well,
    including the optional simulator identity check exercised in the real tree.
    """
    copied_root = destination / "research"
    inputs = [Path("research") / relative for relative in check_draft.REQUIRED]
    inputs.extend(
        [
            Path("commercial/corpus/selection-v1.json"),
            Path("tools/research_power_simulation.py"),
        ]
    )
    for relative in inputs:
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    baseline = check_draft.run_check(
        check_draft.parse_args(["--root", str(copied_root), "--bounded-paper"])
    )
    assert baseline["status"] == "PASS", baseline["errors"]
    return copied_root


def test_draft_checker_rejects_historical_tool_snapshot_tamper(
    tmp_path: Path,
) -> None:
    copied_root = _copy_bounded_research_fixture(tmp_path)
    historical_tool = (
        copied_root
        / "artifact/historical-tools"
        / "3052655088efd69a48f1fc773279c2e0bffa7574f7d41657d772bd219007bc6a"
        / "tools/product_generalization_benchmark.py"
    )
    raw = historical_tool.read_bytes()
    historical_tool.write_bytes(bytes([raw[0] ^ 1]) + raw[1:])

    checked = check_draft.run_check(
        check_draft.parse_args(["--root", str(copied_root), "--bounded-paper"])
    )
    assert checked["status"] == "FAIL"
    assert any(
        error.startswith("invalid frozen-ceiling historical evidence:")
        and "differs from local source" in error
        for error in checked["errors"]
    )


def test_bounded_paper_passes_without_promoting_unrun_confirmatory_results(
    tmp_path: Path,
) -> None:
    bounded = check_draft.run_check(
        check_draft.parse_args(
            ["--root", str(ROOT / "research"), "--bounded-paper"]
        )
    )
    assert bounded["status"] == "PASS"
    assert bounded["mode"] == "bounded-paper"

    copied_root = _copy_bounded_research_fixture(tmp_path)
    freeze_template = copied_root / "templates" / "protocol-freeze.template.json"
    original_freeze = freeze_template.read_text(encoding="utf-8")
    freeze_template.write_text(
        original_freeze.replace(
            '  "sampling_seed": "UNSET",',
            '  "sampling_seed": "UNSET",\n  "sampling_seed": "UNSET",',
            1,
        ),
        encoding="utf-8",
    )
    duplicate_freeze = check_draft.run_check(
        check_draft.parse_args(["--root", str(copied_root), "--bounded-paper"])
    )
    assert duplicate_freeze["status"] == "FAIL"
    assert any(
        "invalid protocol freeze template" in error
        and "duplicate JSON object key: sampling_seed" in error
        for error in duplicate_freeze["errors"]
    )
    freeze_template.write_text(original_freeze, encoding="utf-8")

    main = copied_root / "paper" / "main.tex"
    main.write_text(
        main.read_text(encoding="utf-8")
        + "\n\\StudyStatus{}\nPENDING\n",
        encoding="utf-8",
    )
    tampered = check_draft.run_check(
        check_draft.parse_args(
            ["--root", str(copied_root), "--bounded-paper"]
        )
    )
    assert tampered["status"] == "FAIL"
    assert "bounded paper contains rendered placeholders" in tampered["errors"]
    assert any(
        error.startswith("bounded paper references unrun confirmatory macros:")
        and "StudyStatus" in error
        for error in tampered["errors"]
    )

    original_main = (ROOT / "research/paper/main.tex").read_text(encoding="utf-8")
    main.write_text(
        original_main.replace(
            "at least 5.0x primary",
            "at least 4.9x primary",
        ),
        encoding="utf-8",
    )
    lowered_gate = check_draft.run_check(
        check_draft.parse_args(
            ["--root", str(copied_root), "--bounded-paper"]
        )
    )
    assert lowered_gate["status"] == "FAIL"
    assert any(
        error.startswith(
            "bounded paper does not preserve the strict performance claim boundary:"
        )
        and "5.0x threshold" in error
        for error in lowered_gate["errors"]
    )


def test_placeholder_scan_finds_nested_adversarial_values() -> None:
    value = {"apparently_complete": {"estimate": "PENDING"}}
    assert list(validation._placeholder_locations(value)) == [
        "$.apparently_complete.estimate"
    ]


def test_record_self_digest_is_content_addressed() -> None:
    record = {
        "schema": "zerorun.mutation-result.v1",
        "payload": {"value": 1},
        "artifacts": {"record_sha256": ""},
    }
    record["artifacts"]["record_sha256"] = validation.canonical_json_sha256(
        {"schema": record["schema"], "payload": record["payload"], "artifacts": {}}
    )
    errors: list[str] = []
    validation._validate_record_self_digest(record, errors, "record")
    assert errors == []
    record["payload"]["value"] = 2
    validation._validate_record_self_digest(record, errors, "record")
    assert errors == ["record record self-digest mismatch"]


def test_safe_artifact_member_rejects_traversal(tmp_path: Path) -> None:
    report = validation.ValidationReport()
    assert validation._safe_member(tmp_path, "raw/rows.jsonl", report, "row") is not None
    assert validation._safe_member(tmp_path, "../escape.json", report, "row") is None
    assert validation._safe_member(tmp_path, "C:/escape.json", report, "row") is None
    assert any("unsafe artifact path" in error for error in report.errors)
    assert any("drive-qualified artifact path" in error for error in report.errors)


def _finalize_record(record: dict[str, object]) -> dict[str, object]:
    record["artifacts"]["record_sha256"] = "0" * 64
    without_digest = validation._record_without_self_digest(record)
    assert without_digest is not None
    record["artifacts"]["record_sha256"] = validation.canonical_json_sha256(
        without_digest
    )
    return record


def _journal_records(
    records: list[dict],
    *,
    starting_sequence: int = 1,
    previous_record_sha256: str | None = None,
) -> tuple[list[dict], str | None]:
    """Finalize transition records as one append-only digest chain."""

    previous = previous_record_sha256
    for offset, record in enumerate(records):
        record["journal_sequence"] = starting_sequence + offset
        record["previous_record_sha256"] = previous
        _finalize_record(record)
        previous = record["artifacts"]["record_sha256"]
    return records, previous


def _stage(status: str = "success") -> dict[str, object]:
    attempted = status != "not_attempted"
    return {
        "status": status,
        "started_at_utc": "2026-02-01T00:00:00Z" if attempted else None,
        "completed_at_utc": "2026-02-01T00:00:01Z" if attempted else None,
        "wall_ns": 1 if attempted else None,
        "exit_code": 0 if status == "success" else None,
        "log_sha256": H64 if attempted else None,
    }


def _setup_record(row: dict[str, object], corpus_sha: str) -> dict[str, object]:
    candidate = {**_stage(), "authorizing": False}
    review = {
        **_stage(),
        "reviewer_count": 2,
        "independent": True,
        "decision_sha256": H64,
    }
    return _finalize_record(
        {
            "schema": "zerorun.setup-compatibility.v1",
            "record_id": f"setup-{row['github_repository_id']}",
            "protocol_commit": GIT40,
            "engine_commit": "c" * 40,
            "corpus_sha256": corpus_sha,
            "repository": {
                "github_repository_id": row["github_repository_id"],
                "canonical_full_name": row["canonical_full_name"],
                "stratum": row["stratum"],
                "frozen_sha": row["frozen_sha"],
            },
            "started_at_utc": "2026-02-01T00:00:00Z",
            "completed_at_utc": "2026-02-01T00:00:01Z",
            "resource_limits_sha256": H64,
            "runtime": {
                "recipe_sha256": H64,
                "oci_image": f"example.invalid/python@sha256:{H64}",
                "rootfs_sha256": H64,
                "network_disabled_measured_phase": True,
            },
            "stages": {
                "environment_construction": _stage(),
                "pytest_collection": _stage(),
                "candidate_generation": candidate,
                "structured_review": review,
                "profile_activation": _stage(),
                "seed_execution": _stage(),
                "valid_product_request": _stage(),
            },
            "outcome": {
                "operator_reviewed_compatible": True,
                "manual_intervention": False,
                "failure_stage": None,
                "failure_class": "none",
            },
            "artifacts": {
                "setup_log_sha256": H64,
                "review_record_sha256": H64,
                "record_sha256": "",
            },
        }
    )


def test_setup_compatibility_reconciles_all_100_repositories() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    records = [_setup_record(row, corpus_sha) for row in manifest["repositories"]]
    assert validation.validate_setup_records(records, manifest, corpus_sha) == []
    records[0]["outcome"]["operator_reviewed_compatible"] = False
    records[0] = _finalize_record(records[0])
    errors = "\n".join(validation.validate_setup_records(records, manifest, corpus_sha))
    assert "contradicts stage outcomes" in errors


def _transition_records(manifest: dict[str, object], corpus_sha: str) -> list[dict]:
    row = manifest["repositories"][0]
    before = row["states"][0]
    after = row["states"][1]
    source = {
        "before_sha": before["commit_sha"],
        "after_sha": after["commit_sha"],
        "tree_sha": after["tree_sha"],
        "worktree_digest": H64,
    }
    environment = {
        "oci_image": f"example.invalid/python@sha256:{H64}",
        "oci_image_id": "synthetic",
        "rootfs_sha256": H64,
        "python_version": "3.14",
        "pytest_version": "9.0",
        "tool_version": "synthetic",
        "host_id": "host",
        "cpu_set": "0",
        "network_disabled": True,
    }
    repository = {
        "github_repository_id": row["github_repository_id"],
        "canonical_full_name": row["canonical_full_name"],
        "stratum": row["stratum"],
    }
    def make_record(
        condition: str,
        order: int,
        run_id: str,
        *,
        reused: int = 0,
        oracle_for_run_id: str | None = None,
        oracle: dict | None = None,
    ) -> dict:
        condition_environment = deepcopy(environment)
        condition_environment["tool_version"] = f"{condition}-synthetic"
        return {
            "schema": "zerorun.transition-result.v1",
            "run_id": run_id,
            "protocol_commit": GIT40,
            "engine_commit": "c" * 40,
            "corpus_sha256": corpus_sha,
            "repository": deepcopy(repository),
            "transition": 1,
            "condition": condition,
            "condition_order": order,
            "replicate": 1,
            "attempt_ordinal": 1,
            "run_role": (
                "fresh_oracle_primary" if condition == "oracle" else "measured_primary"
            ),
            "primary_run_id": None,
            "oracle_for_run_id": oracle_for_run_id,
            "oracle_policy_id": validation.ORACLE_POLICY_ID,
            "started_at_utc": (
                "2026-02-02T00:00:01Z"
                if condition == "oracle"
                else "2026-02-02T00:00:00Z"
            ),
            "completed_at_utc": (
                "2026-02-02T00:00:02Z"
                if condition == "oracle"
                else "2026-02-02T00:00:01Z"
            ),
            "source_identity": deepcopy(source),
            "environment_identity": condition_environment,
            "target_argv": ["python", "-m", "pytest"],
            "collection_sha256": H64,
            "timing": {
                "wall_ns": 100,
                "user_cpu_ns": 50,
                "system_cpu_ns": 10,
                "peak_rss_bytes": 1000,
            },
            "outcome": {
                "completed": True,
                "exit_code": 0,
                "status": "passed",
                "failure_class": "none",
                "timed_out": False,
                "node_outcome_sha256": H64,
            },
            "selection": {
                "total_nodes": 1,
                "executed_nodes": 1 - reused,
                "reused_nodes": reused,
                "unknown_nodes": 0,
            },
            "oracle": oracle,
            "artifacts": {
                "stdout_sha256": H64,
                "stderr_sha256": H64,
                "record_sha256": "",
            },
        }

    run_ids = {
        "direct": "direct-run",
        "pytest-testmon": "testmon-run",
        "namerts": "namerts-run",
        "babelrts": "babelrts-run",
        "zerorun": "zerorun-run",
    }
    expected_order = validation._balanced_condition_orders(
        manifest["sampling"]["seed"], row["github_repository_id"], 20
    )[0]
    records: list[dict] = []
    for order, condition in enumerate(expected_order, 1):
        if condition == "direct":
            records.append(make_record("direct", order, run_ids[condition]))
            continue
        selector_run_id = run_ids[condition]
        reused = 1 if condition == "zerorun" else 0
        oracle_run_id = f"oracle-{condition}-run"
        linked_oracle = {
            "run_id": oracle_run_id,
            "source": "fresh_oracle_record",
            "valid": True,
            "exit_code": 0,
            "collection_sha256": H64,
            "node_outcome_sha256": H64,
            "reused_node_outcomes": (
                [
                    {
                        "node_id_sha256": H64,
                        "selector_outcome": "passed",
                        "oracle_outcome": "passed",
                        "matches": True,
                    }
                ]
                if reused
                else []
            ),
            "collection_mismatch": False,
            "reused_node_mismatch": False,
            "overall_status_mismatch": False,
            "false_green": False,
            "potential_safety_mismatch": False,
            "confirmed_safety_mismatch": None,
            "repetition_set_id": None,
        }
        records.append(
            make_record(
                condition,
                order,
                selector_run_id,
                reused=reused,
                oracle=linked_oracle,
            )
        )
        records.append(
            make_record(
                "oracle",
                order,
                oracle_run_id,
                oracle_for_run_id=selector_run_id,
            )
        )
    finalized, _ = _journal_records(records)
    return finalized


def test_transition_validator_checks_corpus_adjacency_and_full_oracle_comparison() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    records = _transition_records(manifest, corpus_sha)
    assert validation.validate_transition_records(records, manifest, corpus_sha) == []
    zerorun_index = next(
        index for index, row in enumerate(records) if row["condition"] == "zerorun"
    )
    zerorun = records[zerorun_index]
    zerorun["oracle"]["reused_node_outcomes"][0]["matches"] = False
    zerorun["source_identity"]["after_sha"] = GIT40
    records[zerorun_index] = _finalize_record(zerorun)
    errors = "\n".join(
        validation.validate_transition_records(records, manifest, corpus_sha)
    )
    assert "source after_sha is not linked" in errors
    assert "condition-dependent source identity" in errors
    assert "reused_node_mismatch classification is incorrect" in errors

    drift = deepcopy(next(row for row in records if row["condition"] == "namerts"))
    drift["run_id"] = "namerts-drift-run"
    drift["replicate"] = 2
    drift["environment_identity"]["tool_version"] = "namerts-drifted"
    drift = _finalize_record(drift)
    errors = "\n".join(
        validation.validate_transition_records(
            [*_transition_records(manifest, corpus_sha), drift], manifest, corpus_sha
        )
    )
    assert "namerts tool version changes within the study" in errors


def test_transition_validator_rejects_one_oracle_shared_by_two_selectors() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    records = _transition_records(manifest, corpus_sha)
    selectors = [
        row for row in records if row["condition"] in validation.SELECTOR_CONDITIONS
    ]
    selectors[1]["oracle"]["run_id"] = selectors[0]["oracle"]["run_id"]
    _journal_records(records)

    errors = "\n".join(
        validation.validate_transition_records(records, manifest, corpus_sha)
    )
    assert "reuses an oracle already bound to another selector" in errors


def test_transition_validator_rejects_oracle_before_its_selector() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    records = _transition_records(manifest, corpus_sha)
    selector_index = next(
        index
        for index, row in enumerate(records)
        if row["condition"] in validation.SELECTOR_CONDITIONS
        and row["oracle"]["source"] == "fresh_oracle_record"
    )
    records[selector_index], records[selector_index + 1] = (
        records[selector_index + 1],
        records[selector_index],
    )
    _journal_records(records)

    errors = "\n".join(
        validation.validate_transition_records(records, manifest, corpus_sha)
    )
    assert "oracle does not immediately follow selector in the hash chain" in errors


def test_transition_validator_rejects_retry_relabelled_as_primary() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    records = _transition_records(manifest, corpus_sha)
    primary = next(row for row in records if row["condition"] == "namerts")
    favorable_retry = deepcopy(primary)
    favorable_retry["run_id"] = "namerts-favorable-retry"
    favorable_retry["attempt_ordinal"] = 2
    favorable_retry["oracle"] = None
    records.append(favorable_retry)
    _journal_records(records)

    errors = "\n".join(
        validation.validate_transition_records(records, manifest, corpus_sha)
    )
    assert "measured primary must be a measured condition attempt 1" in errors


def test_transition_validator_and_schema_reject_resealed_scheduled_direct_oracle() -> None:
    manifest = _manifest()
    repository_id = manifest["repositories"][0]["github_repository_id"]
    for seed_index in range(100):
        candidate_seed = f"synthetic-direct-last-{seed_index}"
        order = validation._balanced_condition_orders(
            candidate_seed, repository_id, 20
        )[0]
        if order[-1] == "direct":
            manifest["sampling"]["seed"] = candidate_seed
            break
    else:  # pragma: no cover - protects deterministic fixture maintenance
        raise AssertionError("could not construct a direct-last Williams fixture")

    corpus_sha = "f" * 64
    records = _transition_records(manifest, corpus_sha)
    direct = next(row for row in records if row["condition"] == "direct")
    assert direct["condition_order"] == 5
    selector = next(
        row
        for row in records
        if row["condition"] in validation.SELECTOR_CONDITIONS
        and row["condition_order"] == 4
    )
    old_oracle_id = selector["oracle"]["run_id"]
    selector["oracle"]["run_id"] = direct["run_id"]
    selector["oracle"]["source"] = "scheduled_direct_immediate"
    direct["oracle_for_run_id"] = selector["run_id"]
    direct["started_at_utc"] = selector["completed_at_utc"]
    direct["completed_at_utc"] = "2026-02-02T00:00:02Z"
    records = [row for row in records if row["run_id"] != old_oracle_id]
    _journal_records(records)

    errors = "\n".join(
        validation.validate_transition_records(records, manifest, corpus_sha)
    )
    assert "direct primary cannot serve as a selector oracle" in errors
    assert "oracle must be a separate fresh-oracle record" in errors
    assert "oracle does not immediately follow selector in the hash chain" not in errors

    catalog, schema_report = _catalog()
    validation.validate_instance(
        selector,
        "zerorun.transition-result.v1",
        catalog,
        schema_report,
        "scheduled-direct substitution",
    )
    assert any("$.oracle.source" in error for error in schema_report.errors)


def test_transition_validator_rejects_nonfrozen_order_and_collection_drift() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    records = _transition_records(manifest, corpus_sha)
    measured = [
        row for row in records if row.get("run_role") == "measured_primary"
    ]
    measured[0]["condition_order"], measured[1]["condition_order"] = (
        measured[1]["condition_order"],
        measured[0]["condition_order"],
    )
    measured[2]["collection_sha256"] = "e" * 64
    _journal_records(records)

    errors = "\n".join(
        validation.validate_transition_records(records, manifest, corpus_sha)
    )
    assert "does not match the frozen Williams schedule" in errors
    assert "condition-dependent preselection collection identity" in errors


def test_invalid_primary_oracle_forces_capped_h2_f_condition_failure() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    transitions = _transition_records(manifest, corpus_sha)
    zerorun = next(row for row in transitions if row["condition"] == "zerorun")
    oracle = next(
        row for row in transitions if row["run_id"] == zerorun["oracle"]["run_id"]
    )
    oracle["collection_sha256"] = None
    oracle["outcome"].update(
        {
            "completed": False,
            "exit_code": None,
            "status": "failure",
            "failure_class": "tool_crash",
            "timed_out": False,
            "node_outcome_sha256": None,
        }
    )
    zerorun["oracle"].update(
        {
            "valid": False,
            "exit_code": None,
            "collection_sha256": None,
            "node_outcome_sha256": None,
            "collection_mismatch": False,
            "reused_node_mismatch": False,
            "overall_status_mismatch": False,
            "false_green": False,
            "potential_safety_mismatch": False,
            "confirmed_safety_mismatch": None,
            "repetition_set_id": None,
        }
    )
    _journal_records(transitions)
    assert validation.validate_transition_records(
        transitions, manifest, corpus_sha
    ) == []

    measured = {
        row["condition"]: row
        for row in transitions
        if row.get("run_role") == "measured_primary"
    }
    repository = deepcopy(zerorun["repository"])
    source = {
        name: zerorun["source_identity"][name]
        for name in ("before_sha", "after_sha", "tree_sha")
    }
    slot = {
        "schema": "zerorun.transition-slot-disposition.v1",
        "record_id": "invalid-oracle-slot",
        "protocol_commit": GIT40,
        "engine_commit": "c" * 40,
        "corpus_sha256": corpus_sha,
        "repository": repository,
        "transition": 1,
        "source_identity": source,
        "timeout_cap_ns": 1_000,
        "artifacts": {"record_sha256": ""},
    }
    for condition in validation.MEASURED_CONDITIONS:
        row = measured[condition]
        slot[condition] = {
            "condition_order": row["condition_order"],
            "attempt_ordinal": 1,
            "run_role": "measured_primary",
            "status": "observed",
            "run_id": row["run_id"],
            "observed_wall_ns": row["timing"]["wall_ns"],
            "penalized_wall_ns": row["timing"]["wall_ns"],
            "failure_class": "none",
        }
    _finalize_record(slot)
    errors = "\n".join(
        validation.validate_transition_slot_records(
            [slot], manifest, corpus_sha, transitions, require_complete=False
        )
    )
    assert "cannot be observed without a valid provenance-clean primary oracle" in errors
    assert "must be a provenance condition_failure at the frozen cap" in errors

    slot["zerorun"].update(
        {
            "status": "condition_failure",
            "observed_wall_ns": None,
            "penalized_wall_ns": 1_000,
            "failure_class": "provenance",
        }
    )
    _finalize_record(slot)
    assert validation.validate_transition_slot_records(
        [slot], manifest, corpus_sha, transitions, require_complete=False
    ) == []


def test_failure_penalty_slot_ledger_requires_all_2000_frozen_slots() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    records: list[dict[str, object]] = []
    for row in manifest["repositories"]:
        for transition in range(1, 21):
            states = row["states"]
            records.append(
                _finalize_record(
                    {
                        "schema": "zerorun.transition-slot-disposition.v1",
                        "record_id": f"slot-{row['github_repository_id']}-{transition}",
                        "protocol_commit": GIT40,
                        "engine_commit": "c" * 40,
                        "corpus_sha256": corpus_sha,
                        "repository": {
                            "github_repository_id": row["github_repository_id"],
                            "canonical_full_name": row["canonical_full_name"],
                            "stratum": row["stratum"],
                        },
                        "transition": transition,
                        "source_identity": {
                            "before_sha": states[transition - 1]["commit_sha"],
                            "after_sha": states[transition]["commit_sha"],
                            "tree_sha": states[transition]["tree_sha"],
                        },
                        "timeout_cap_ns": 1_000,
                        "direct": {
                            "condition_order": 1,
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "condition_failure",
                            "run_id": None,
                            "observed_wall_ns": None,
                            "penalized_wall_ns": 1_000,
                            "failure_class": "setup",
                        },
                        "pytest-testmon": {
                            "condition_order": 2,
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "condition_failure",
                            "run_id": None,
                            "observed_wall_ns": None,
                            "penalized_wall_ns": 1_000,
                            "failure_class": "setup",
                        },
                        "namerts": {
                            "condition_order": 3,
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "condition_failure",
                            "run_id": None,
                            "observed_wall_ns": None,
                            "penalized_wall_ns": 1_000,
                            "failure_class": "setup",
                        },
                        "babelrts": {
                            "condition_order": 4,
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "condition_failure",
                            "run_id": None,
                            "observed_wall_ns": None,
                            "penalized_wall_ns": 1_000,
                            "failure_class": "setup",
                        },
                        "zerorun": {
                            "condition_order": 5,
                            "attempt_ordinal": 1,
                            "run_role": "measured_primary",
                            "status": "condition_failure",
                            "run_id": None,
                            "observed_wall_ns": None,
                            "penalized_wall_ns": 1_000,
                            "failure_class": "setup",
                        },
                        "artifacts": {"record_sha256": ""},
                    }
                )
            )
    assert (
        validation.validate_transition_slot_records(
            records, manifest, corpus_sha, [], require_complete=True
        )
        == []
    )
    records[0]["zerorun"]["penalized_wall_ns"] = 999
    records[0] = _finalize_record(records[0])
    errors = "\n".join(
        validation.validate_transition_slot_records(
            records[:-1], manifest, corpus_sha, [], require_complete=True
        )
    )
    assert "does not apply the frozen cap" in errors
    assert "2,000 repository/transition slots" in errors

    malformed = deepcopy(records)
    malformed[0].pop("namerts")
    malformed[0]["babelrts"]["condition_order"] = 2
    malformed[0] = _finalize_record(malformed[0])
    errors = "\n".join(
        validation.validate_transition_slot_records(
            malformed, manifest, corpus_sha, [], require_complete=True
        )
    )
    assert "namerts disposition is missing" in errors
    assert "condition orders must be an exact permutation of 1..5" in errors

    orphan = next(
        row
        for row in _transition_records(manifest, corpus_sha)
        if row["condition"] == "namerts"
    )
    errors = "\n".join(
        validation.validate_transition_slot_records(
            records, manifest, corpus_sha, [orphan], require_complete=True
        )
    )
    assert "transition runs and slot dispositions must be bijective" in errors


def test_mutation_validator_recomputes_every_reused_node_comparison() -> None:
    manifest = _manifest()
    row = manifest["repositories"][0]
    corpus_sha = "f" * 64
    reused_outcomes = [
        {
            "node_id_sha256": H64,
            "selector_outcome": "passed",
            "oracle_outcome": "passed",
            "matches": True,
        }
    ]
    reused_digest = validation.canonical_json_sha256(reused_outcomes)
    record = _finalize_record(
        {
            "schema": "zerorun.mutation-result.v1",
            "mutation_id": "mutation-1",
            "protocol_commit": GIT40,
            "engine_commit": "c" * 40,
            "corpus_sha256": corpus_sha,
            "repository": {
                "github_repository_id": row["github_repository_id"],
                "canonical_full_name": row["canonical_full_name"],
                "stratum": row["stratum"],
            },
            "category": "production_literal_operator",
            "catalog": {
                "version": "synthetic-v1",
                "sha256": H64,
                "operator_id": "literal-replace",
            },
            "selection": {
                "rank_algorithm": "sha256-zerorun-mutation-v1",
                "candidate_count": 1,
                "selected_rank": 1,
                "selected_path_sha256": H64,
            },
            "source_identity": {
                "frozen_sha": row["frozen_sha"],
                "unmutated_tree_sha": row["states"][-1]["tree_sha"],
                "mutated_tree_sha": _git_sha("synthetic-mutated-tree"),
                "runtime_rootfs_sha256": H64,
            },
            "applicability": "attempted",
            "selector": {
                "run_id": "mutation-selector-1",
                "status": "reuse",
                "exit_code": 1,
                "overall_status": "failed",
                "collection_vector_sha256": "d" * 64,
                "reused_nodes": 1,
                "reused_node_outcomes_sha256": reused_digest,
                "detected_identity_change": True,
            },
            "oracle": {
                "run_id": "mutation-oracle-1",
                "valid": True,
                "baseline_exit_code": 0,
                "mutated_exit_code": 1,
                "baseline_collection_vector_sha256": H64,
                "mutated_collection_vector_sha256": "d" * 64,
                "baseline_node_outcome_sha256": H64,
                "mutated_node_outcome_sha256": "e" * 64,
                "reused_node_outcomes": reused_outcomes,
                "reused_node_outcomes_sha256": reused_digest,
                "overall_status": "failed",
            },
            "boundary_assertion": None,
            "classification": {
                "trial_class": "semantic_mutation",
                "evaluable": True,
                "effective_semantic_mutation": True,
                "valid_boundary_assertion": None,
                "collection_mismatch": False,
                "reused_node_mismatch": False,
                "overall_status_mismatch": False,
                "false_green": False,
                "potential_safety_mismatch": False,
                "confirmed_safety_mismatch": None,
                "oracle_repetition_set_id": None,
                "failure_class": "none",
            },
            "artifacts": {
                "patch_sha256": H64,
                "selector_log_sha256": H64,
                "oracle_log_sha256": H64,
                "record_sha256": "",
            },
        }
    )
    catalog, report = _catalog()
    validation.validate_instance(
        record, "zerorun.mutation-result.v1", catalog, report, "mutation"
    )
    assert report.errors == []
    assert validation.validate_mutation_records([record], manifest, corpus_sha) == []

    invalid_oracle = deepcopy(record)
    invalid_oracle["oracle"]["valid"] = False
    invalid_oracle["classification"].update(
        {
            "evaluable": False,
            "effective_semantic_mutation": False,
            "collection_mismatch": None,
            "reused_node_mismatch": None,
            "overall_status_mismatch": None,
            "false_green": None,
            "potential_safety_mismatch": None,
            "failure_class": "oracle_invalid",
        }
    )
    _finalize_record(invalid_oracle)
    assert validation.validate_mutation_records(
        [invalid_oracle], manifest, corpus_sha
    ) == []

    mislabeled_invalid = deepcopy(invalid_oracle)
    mislabeled_invalid["classification"]["evaluable"] = True
    mislabeled_invalid["classification"]["failure_class"] = "none"
    _finalize_record(mislabeled_invalid)
    errors = "\n".join(
        validation.validate_mutation_records(
            [mislabeled_invalid], manifest, corpus_sha
        )
    )
    assert "evaluable flag contradicts" in errors
    assert "invalid oracle is not classified oracle_invalid" in errors

    record["oracle"]["reused_node_outcomes"][0]["oracle_outcome"] = "failed"
    record = _finalize_record(record)
    errors = "\n".join(
        validation.validate_mutation_records([record], manifest, corpus_sha)
    )
    assert "reused-node outcome digest is not reproducible" in errors
    assert "reused_node_mismatch classification is incorrect" in errors


def _oracle_repetition(manifest: dict[str, object], corpus_sha: str) -> dict:
    row = manifest["repositories"][0]
    record = {
        "schema": "zerorun.oracle-repetition.v1",
        "repetition_set_id": "seed-repeat",
        "protocol_commit": GIT40,
        "engine_commit": "c" * 40,
        "corpus_sha256": corpus_sha,
        "repository": {
            "github_repository_id": row["github_repository_id"],
            "canonical_full_name": row["canonical_full_name"],
            "stratum": row["stratum"],
        },
        "purpose": "seed_determinism",
        "trigger_run_id": None,
        "source_identity": {
            "commit_sha": row["frozen_sha"],
            "tree_sha": row["states"][-1]["tree_sha"],
            "worktree_digest": H64,
        },
        "environment_identity": {
            "oci_image": f"example.invalid/python@sha256:{H64}",
            "rootfs_sha256": H64,
            "network_disabled": True,
        },
        "target_argv": ["python", "-m", "pytest"],
        "repetitions": [
            {
                "repetition": index,
                "run_id": f"seed-{index}",
                "started_at_utc": "2026-02-02T00:00:00Z",
                "valid": True,
                "exit_code": 0,
                "collection_sha256": H64,
                "node_outcome_sha256": H64,
                "failure_signature_sha256": None,
                "collection_mismatch": False,
                "reused_node_mismatch": False,
                "overall_status_mismatch": False,
                "false_green": False,
                "wall_ns": 100,
                "stdout_sha256": H64,
                "stderr_sha256": H64,
            }
            for index in (1, 2, 3)
        ],
        "classification": {
            "deterministic": True,
            "majority_safety_mismatch": False,
            "compatible_mismatch_signature": None,
            "result": "deterministic_pass",
        },
        "artifacts": {"record_sha256": ""},
    }
    return _finalize_record(record)


def test_oracle_repetition_validator_rejects_hand_labeled_determinism() -> None:
    manifest = _manifest()
    corpus_sha = "f" * 64
    record = _oracle_repetition(manifest, corpus_sha)
    assert validation.validate_oracle_records([record], manifest, corpus_sha) == []
    record["repetitions"][2]["exit_code"] = 1
    record = _finalize_record(record)
    errors = "\n".join(validation.validate_oracle_records([record], manifest, corpus_sha))
    assert "deterministic classification is incorrect" in errors
    assert "result should be oracle_flaky" in errors


def _empty_h1_component() -> dict[str, object]:
    return {
        "required_oracle_attempts": 0,
        "oracle_valid_attempts": 0,
        "oracle_invalid_or_missing_attempts": 0,
        "evaluable_trials": 0,
        "evaluable_repositories": 0,
        "repositories_by_stratum": {stratum: 0 for stratum in validation.STRATUM_BOUNDS},
        "collection_mismatches": 0,
        "reused_node_mismatches": 0,
        "overall_status_mismatches": 0,
        "false_greens": 0,
        "potential_safety_mismatches": 0,
        "zero_event_bounds": {
            "method": "bonferroni_one_sided_zero_event",
            "family_alpha": 0.05,
            "repositories_with_events": 0,
            "stratum_upper": {
                stratum: None for stratum in validation.STRATUM_BOUNDS
            },
            "equal_stratum_upper": None,
            "owners_by_stratum": {
                stratum: 0 for stratum in validation.STRATUM_BOUNDS
            },
            "owner_stratum_upper": {
                stratum: None for stratum in validation.STRATUM_BOUNDS
            },
            "owner_equal_stratum_upper": None,
            "descriptive_trial_upper": None,
        },
        "coverage_gate_pass": False,
        "decision": "INCONCLUSIVE_COVERAGE_NOT_MET",
    }


def test_analysis_recomputes_h3_h4_and_full_holm_family() -> None:
    manifest = _manifest()
    corpus_sha = "1" * 64
    raw_index_sha = "2" * 64
    raw_aggregate_sha = "3" * 64
    generated_sha = "4" * 64
    setup_records = [
        _setup_record(row, corpus_sha) for row in manifest["repositories"]
    ]
    transition_records: list[dict[str, object]] = []
    transition_slot_records: list[dict[str, object]] = []
    for row in manifest["repositories"]:
        repository = {
            "github_repository_id": row["github_repository_id"],
            "canonical_full_name": row["canonical_full_name"],
            "stratum": row["stratum"],
        }
        for transition in (1, 2, 3):
            direct = {
                "repository": repository,
                "transition": transition,
                "replicate": 1,
                "condition": "direct",
                "run_role": "measured_primary",
                "attempt_ordinal": 1,
                "timing": {"wall_ns": 100},
                "outcome": {"completed": True},
                "selection": {"reused_nodes": 0},
                "oracle": None,
            }
            zerorun = {
                "repository": repository,
                "transition": transition,
                "replicate": 1,
                "condition": "zerorun",
                "run_role": "measured_primary",
                "attempt_ordinal": 1,
                "timing": {"wall_ns": 110},
                "outcome": {"completed": True},
                "selection": {"reused_nodes": 0},
                "oracle": {"valid": True},
            }
            transition_records.extend((direct, zerorun))
        for transition in range(1, 21):
            transition_slot_records.append(
                {
                    "repository": repository,
                    "direct": {"penalized_wall_ns": 100},
                    "zerorun": {"penalized_wall_ns": 100},
                }
            )

    empty_component = _empty_h1_component()
    h1_categories = [
        {
            "category": category,
            "trial_class": (
                "semantic_mutation"
                if category
                in {
                    "production_literal_operator",
                    "transitive_local_import",
                    "test_or_fixture",
                    "conftest_or_pytest_plugin",
                    "pytest_configuration_or_target",
                    "collection_identity",
                }
                else "boundary_assertion"
            ),
            "component": deepcopy(empty_component),
        }
        for category in sorted(validation.MUTATION_CATEGORIES)
    ]
    empty_secondary_population = {
        "estimand": "synthetic empty secondary estimate",
        "transition_pair_count": 0,
        "repository_count": 0,
        "repositories_by_stratum": {
            stratum: 0 for stratum in validation.STRATUM_BOUNDS
        },
        "point_weighted_median_speedup": None,
        "two_sided_95_lower": None,
        "two_sided_95_upper": None,
        "bootstrap_complete_draws": 0,
    }

    def empty_support(numerator: str, denominator: str) -> dict[str, object]:
        empty = {
            "repository_count": 0,
            "repositories_by_stratum": {
                stratum: 0 for stratum in validation.STRATUM_BOUNDS
            },
        }
        neither = {
            "repository_count": 100,
            "repositories_by_stratum": {
                stratum: 25 for stratum in validation.STRATUM_BOUNDS
            },
        }
        return {
            "definition": (
                "condition-supported repository has at least 10 completed "
                "replicate-1 requests; selector requests additionally require "
                "a valid fresh oracle"
            ),
            "minimum_valid_requests_per_repository": 10,
            "numerator_condition": numerator,
            "denominator_condition": denominator,
            "both_supported": deepcopy(empty),
            "numerator_only": deepcopy(empty),
            "denominator_only": deepcopy(empty),
            "neither_supported": neither,
        }

    def empty_condition_diagnostic(condition: str) -> dict[str, object]:
        recorded = 300 if condition in {"direct", "zerorun"} else 0
        selector = condition != "direct"
        valid_oracles = 300 if condition == "zerorun" else 0
        return {
            "condition": condition,
            "planned_requests": 2000,
            "recorded_requests": recorded,
            "completed_requests": recorded,
            "slot_status_counts": {
                "observed": 0,
                "condition_failure": 0,
                "shared_failure": 0,
            },
            "executed_node_fraction": {
                "definition": (
                    "pooled executed_nodes/total_nodes over replicate-1 records "
                    "with complete positive-total node accounting"
                ),
                "requests_with_value": 0,
                "requests_missing_value": 2000,
                "executed_nodes": None,
                "total_nodes": None,
                "pooled_fraction": None,
            },
            "non_execution_overhead": {
                "definition": (
                    "wall_ns minus execution_ns on completed replicate-1 requests"
                ),
                "requests_with_value": 0,
                "requests_missing_value": 2000,
                "total_ns": None,
                "median_ns": None,
            },
            "cache_storage": {
                "definition": (
                    "selection.cache_bytes snapshot after each replicate-1 request"
                ),
                "requests_with_value": 0,
                "requests_missing_value": 2000,
                "median_bytes": None,
                "maximum_bytes": None,
            },
            "safety_events": {
                "applicability": (
                    "SELECTOR_ORACLE" if selector else "NOT_APPLICABLE_DIRECT"
                ),
                "oracle_valid_requests": valid_oracles if selector else 0,
                "oracle_invalid_or_missing_requests": (
                    2000 - valid_oracles if selector else 2000
                ),
                "collection_mismatches": 0,
                "reused_node_mismatches": 0,
                "overall_status_mismatches": 0,
                "false_greens": 0,
                "potential_safety_mismatches": 0,
                "confirmed_safety_mismatches": 0,
                "confirmed_classification_missing": 0,
            },
        }

    secondary_selector_estimates = {
        selector: {
            "condition": selector,
            "comparisons": {
                "selector_vs_direct": {
                    "speedup_ratio": f"direct_wall_ns/{selector}_wall_ns",
                    "asymmetric_repository_support": empty_support(
                        "direct", selector
                    ),
                    "conditional_complete_case": deepcopy(
                        empty_secondary_population
                    ),
                    "failure_penalized_all_selected": deepcopy(
                        empty_secondary_population
                    ),
                },
                "zerorun_vs_selector": {
                    "speedup_ratio": f"{selector}_wall_ns/zerorun_wall_ns",
                    "asymmetric_repository_support": empty_support(
                        selector, "zerorun"
                    ),
                    "conditional_complete_case": deepcopy(
                        empty_secondary_population
                    ),
                    "failure_penalized_all_selected": deepcopy(
                        empty_secondary_population
                    ),
                },
            },
        }
        for selector in validation.MEASURED_CONDITIONS[1:-1]
    }
    analysis = {
        "schema": "zerorun.analysis-output.v1",
        "status": "COMPLETE",
        "planning_only": False,
        "provenance": {
            "protocol_commit": GIT40,
            "engine_commit": "c" * 40,
            "analysis_commit": "d" * 40,
            "analysis_environment_path": "analysis/environment.lock",
            "analysis_environment_sha256": H64,
            "generator_path": "analysis/generate.py",
            "generator_sha256": H64,
            "generator_argv": ["python", "analysis/generate.py"],
            "corpus_manifest_sha256": corpus_sha,
            "raw_bundle_index_sha256": raw_index_sha,
            "raw_bundle_aggregate_sha256": raw_aggregate_sha,
        },
        "data_validation": {
            "status": "PASS",
            "receipt_path": "derived/data-validation.json",
            "receipt_sha256": H64,
            "error_count": 0,
            "warning_count": 0,
        },
        "flow_counts": {
            "selected_repositories": 100,
            "selected_by_stratum": {stratum: 25 for stratum in validation.STRATUM_BOUNDS},
            "compatible_repositories": 100,
            "compatible_by_stratum": {stratum: 25 for stratum in validation.STRATUM_BOUNDS},
            "eligible_h2_repositories": 0,
            "eligible_h2_by_stratum": {stratum: 0 for stratum in validation.STRATUM_BOUNDS},
            "attempted_transitions": 300,
            "valid_pairs": 300,
            "reuse_bearing_requests": 0,
            "effective_mutations": 0,
            "potential_safety_mismatches": 0,
            "confirmed_safety_mismatches": 0,
        },
        "primary_estimates": {
            "H1": {
                "H1_N": deepcopy(empty_component),
                "H1_M": deepcopy(empty_component),
                "H1_M_categories": h1_categories,
                "conservative_equal_stratum_upper": None,
                "decision": "INCONCLUSIVE_COVERAGE_NOT_MET",
            },
            "H2": {
                "conditional": {
                    "estimand": "conditional compatible valid-pair speedup",
                    "repository_count": 0,
                    "repositories_by_stratum": {stratum: 0 for stratum in validation.STRATUM_BOUNDS},
                    "point_weighted_median_speedup": None,
                    "one_sided_95_lower": None,
                    "unadjusted_p_value": 1.0,
                },
                "failure_penalized": {
                    "estimand": "all-selected failure-penalized utility",
                    "repository_count": 100,
                    "repositories_by_stratum": {stratum: 25 for stratum in validation.STRATUM_BOUNDS},
                    "point_weighted_median_speedup": 1.0,
                    "one_sided_95_lower": 0.9,
                    "unadjusted_p_value": 1.0,
                },
                "bootstrap_draws": 10000,
                "conditional_bootstrap_complete_draws": 0,
                "conditional_bootstrap_undefined_draws": 10000,
                "conditional_bootstrap_domain_complete": False,
                "bootstrap_design": "endpoint_specific_stratified_owner_cluster_pairs_bootstrap",
                "coverage_gate_pass": False,
                "conditional_point_gate_pass": False,
                "conditional_interval_gate_pass": False,
                "failure_penalized_interval_gate_pass": False,
                "intersection_union_p_value": 1.0,
                "holm_adjusted_p_value": 1.0,
                "decision": "INCONCLUSIVE_COVERAGE_NOT_MET",
            },
            "H3": {
                "estimand": "equal-stratum-weighted median conditional no-reuse request overhead",
                "repository_count": 100,
                "repositories_by_stratum": {stratum: 25 for stratum in validation.STRATUM_BOUNDS},
                "request_count": 300,
                "point_weighted_median_overhead": 110 / 100 - 1,
                "one_sided_95_upper": 0.1,
                "unadjusted_p_value": 0.01,
                "holm_adjusted_p_value": 0.03,
                "bootstrap_draws": 10000,
                "bootstrap_complete_draws": 10000,
                "bootstrap_undefined_draws": 0,
                "bootstrap_domain_complete": True,
                "bootstrap_design": "endpoint_specific_stratified_owner_cluster_pairs_bootstrap",
                "coverage_gate_pass": True,
                "interval_gate_pass": True,
                "decision": "PASS",
            },
            "H4": {
                "estimand": "equal-stratum mean operator-reviewed product-path compatibility",
                "repository_count": 100,
                "successes": 100,
                "successes_by_stratum": {stratum: 25 for stratum in validation.STRATUM_BOUNDS},
                "point_equal_stratum_mean": 1.0,
                "one_sided_95_lower": 0.8,
                "unadjusted_p_value": 0.01,
                "holm_adjusted_p_value": 0.03,
                "bootstrap_draws": 10000,
                "bootstrap_design": "endpoint_specific_stratified_owner_cluster_pairs_bootstrap",
                "interval_gate_pass": True,
                "decision": "PASS",
            },
        },
        "secondary_estimates": {
            "status": "DESCRIPTIVE_NOT_IN_PRIMARY_HYPOTHESIS_GATES",
            "multiplicity_role": "excluded_from_H2_H3_H4_Holm_family",
            "bootstrap_draws": 10000,
            "bootstrap_design": "endpoint_specific_stratified_owner_cluster_pairs_bootstrap",
            "bootstrap_interval": "centered_basic_two_sided_95_log_scale",
            "condition_diagnostics": {
                condition: empty_condition_diagnostic(condition)
                for condition in validation.MEASURED_CONDITIONS
            },
            "selector_baselines": secondary_selector_estimates,
        },
        "latex_macros": {
            "CompatSuccesses": {
                "value": "100",
                "source_json_pointer": "/primary_estimates/H4/successes",
                "source_value_sha256": validation.canonical_json_sha256(100),
            }
        },
        "generated_results_sha256": generated_sha,
    }
    status = {
        "status": "COMPLETE",
        "confirmatory_claims_authorized": True,
        "protocol_commit": GIT40,
        "engine_commit": "c" * 40,
        "analysis_commit": "d" * 40,
        "corpus_manifest_sha256": corpus_sha,
        "raw_results_sha256": raw_aggregate_sha,
        "completed_repositories": 100,
    }
    generated = "\\resultsavailabletrue\n\\newcommand{\\CompatSuccesses}{100}\n"
    errors = validation.validate_analysis_links(
        analysis,
        status,
        manifest,
        setup_records,
        transition_records,
        transition_slot_records,
        [],
        corpus_sha256=corpus_sha,
        raw_index_sha256=raw_index_sha,
        raw_aggregate_sha256=raw_aggregate_sha,
        generated_results_sha256=generated_sha,
        generated_results_source=generated,
    )
    assert errors == []

    zerorun_nodes = analysis["secondary_estimates"]["condition_diagnostics"][
        "zerorun"
    ]["executed_node_fraction"]
    zerorun_nodes["requests_missing_value"] = 1999
    errors = "\n".join(
        validation.validate_analysis_links(
            analysis,
            status,
            manifest,
            setup_records,
            transition_records,
            transition_slot_records,
            [],
            corpus_sha256=corpus_sha,
            raw_index_sha256=raw_index_sha,
            raw_aggregate_sha256=raw_aggregate_sha,
            generated_results_sha256=generated_sha,
            generated_results_source=generated,
        )
    )
    assert "zerorun condition diagnostics do not recompute" in errors
    zerorun_nodes["requests_missing_value"] = 2000

    support = analysis["secondary_estimates"]["selector_baselines"][
        "namerts"
    ]["comparisons"]["zerorun_vs_selector"]["asymmetric_repository_support"]
    support["neither_supported"]["repository_count"] = 99
    errors = "\n".join(
        validation.validate_analysis_links(
            analysis,
            status,
            manifest,
            setup_records,
            transition_records,
            transition_slot_records,
            [],
            corpus_sha256=corpus_sha,
            raw_index_sha256=raw_index_sha,
            raw_aggregate_sha256=raw_aggregate_sha,
            generated_results_sha256=generated_sha,
            generated_results_source=generated,
        )
    )
    assert "namerts/zerorun_vs_selector asymmetric support does not recompute" in errors
    support["neither_supported"]["repository_count"] = 100

    testmon_conditional = analysis["secondary_estimates"]["selector_baselines"][
        "pytest-testmon"
    ]["comparisons"]["selector_vs_direct"]["conditional_complete_case"]
    testmon_conditional["point_weighted_median_speedup"] = 9.0
    errors = "\n".join(
        validation.validate_analysis_links(
            analysis,
            status,
            manifest,
            setup_records,
            transition_records,
            transition_slot_records,
            [],
            corpus_sha256=corpus_sha,
            raw_index_sha256=raw_index_sha,
            raw_aggregate_sha256=raw_aggregate_sha,
            generated_results_sha256=generated_sha,
            generated_results_source=generated,
        )
    )
    assert "pytest-testmon/selector_vs_direct conditional point must be null" in errors
    testmon_conditional["point_weighted_median_speedup"] = None

    analysis["primary_estimates"]["H3"]["repository_count"] = 99
    analysis["primary_estimates"]["H4"]["point_equal_stratum_mean"] = 0.99
    analysis["primary_estimates"]["H3"]["holm_adjusted_p_value"] = 0.01
    errors = "\n".join(
        validation.validate_analysis_links(
            analysis,
            status,
            manifest,
            setup_records,
            transition_records,
            transition_slot_records,
            [],
            corpus_sha256=corpus_sha,
            raw_index_sha256=raw_index_sha,
            raw_aggregate_sha256=raw_aggregate_sha,
            generated_results_sha256=generated_sha,
            generated_results_source=generated,
        )
    )
    assert "H3 repository_count" in errors
    assert "H4 point estimate" in errors
    assert "H3 Holm-adjusted p-value" in errors
