from __future__ import annotations

from types import SimpleNamespace
from pathlib import Path

import pytest

from zerorun.hermetic_batch_key import FingerprintSession
from zerorun.model import ConfigurationError, TaskSpec
from zerorun.pytest_node_key import (
    PYTEST_SOURCE_REVIEW_SCHEMA,
    _closure_fingerprint,
)
from zerorun.pytest_runtime import _profile_input_guard_sha256


def _closure(*absent_files: str) -> dict[str, object]:
    return {
        "selectors": [],
        "fallback_files": [],
        "absent_files": list(absent_files),
    }


def test_negative_import_candidates_are_bound_as_exact_absence(
    tmp_path: Path,
) -> None:
    digest, payload = _closure_fingerprint(
        tmp_path,
        _closure("foo.py", "foo/__init__.py"),
        session=FingerprintSession(tmp_path),
    )

    assert len(digest) == 64
    assert payload == {
        "kind": "pytest-reviewed-project-closure-v2",
        "fallback_files": [],
        "absent_files": [
            {"pattern": "foo.py", "type": "missing"},
            {"pattern": "foo/__init__.py", "type": "missing"},
        ],
        "selectors": [],
    }
    assert PYTEST_SOURCE_REVIEW_SCHEMA == "zerorun-pytest-source-review-v2"


@pytest.mark.parametrize("replacement", ["file", "directory"])
def test_negative_import_candidate_creation_invalidates_reviewed_closure(
    tmp_path: Path,
    replacement: str,
) -> None:
    row = _closure("foo.py")
    _closure_fingerprint(
        tmp_path,
        row,
        session=FingerprintSession(tmp_path),
    )
    candidate = tmp_path / "foo.py"
    if replacement == "file":
        candidate.write_text("VALUE = 'shadowed'\n", encoding="utf-8")
    else:
        candidate.mkdir()

    with pytest.raises(
        ConfigurationError,
        match="negative import candidate became available",
    ):
        _closure_fingerprint(
            tmp_path,
            row,
            session=FingerprintSession(tmp_path),
        )


@pytest.mark.parametrize("malformed", [None, "foo.py", [1], {"foo.py": True}])
def test_negative_import_candidate_shape_is_fail_closed(
    tmp_path: Path,
    malformed: object,
) -> None:
    row = _closure("foo.py")
    row["absent_files"] = malformed
    with pytest.raises(ConfigurationError, match="invalid absent_files"):
        _closure_fingerprint(
            tmp_path,
            row,
            session=FingerprintSession(tmp_path),
        )


def test_verified_action_guard_rechecks_negative_import_absence(
    tmp_path: Path,
) -> None:
    (tmp_path / "pytest.ini").write_text("[pytest]\n", encoding="utf-8")
    (tmp_path / "conftest.py").write_text("# session\n", encoding="utf-8")
    profile = SimpleNamespace(
        static_inputs=("pytest.ini",),
        session_closure={
            "selectors": [],
            "fallback_files": ["conftest.py"],
            "absent_files": ["external_dep.py", "external_dep/__init__.py"],
        },
        nodes={},
        profile_sha256="1" * 64,
    )
    task = TaskSpec(
        name="pytest",
        command=("python", "-m", "pytest"),
        inputs=("pytest.ini", "conftest.py"),
        outputs=(),
        image="python@sha256:" + "2" * 64,
        platform="linux/amd64",
        result_only=True,
        closure_reviewed=True,
    )
    guarded_paths: set[str] = set()
    before = _profile_input_guard_sha256(
        tmp_path,
        task,
        profile,
        runtime_identity={"requested_image": task.image},
        environment_fingerprint={},
        guarded_paths=guarded_paths,
    )
    assert len(before) == 64
    assert {"external_dep.py", "external_dep/__init__.py"}.issubset(
        guarded_paths
    )

    (tmp_path / "external_dep.py").write_text(
        "VALUE = 'local shadow'\n",
        encoding="utf-8",
    )
    with pytest.raises(
        ConfigurationError,
        match="negative import candidate became available",
    ):
        _profile_input_guard_sha256(
            tmp_path,
            task,
            profile,
            runtime_identity={"requested_image": task.image},
            environment_fingerprint={},
        )
