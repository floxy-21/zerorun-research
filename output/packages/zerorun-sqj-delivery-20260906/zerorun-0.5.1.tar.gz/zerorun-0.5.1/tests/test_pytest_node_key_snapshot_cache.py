from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

import zerorun.pytest_node_key as node_key_module
from zerorun.hermetic_batch_key import FingerprintSession
from zerorun.model import ConfigurationError, TaskSpec
from zerorun.pytest_node_cache import NodeCacheContext, prepare_node_cache
from zerorun.pytest_node_key import node_action_fingerprint


HEX_A = "a" * 64
HEX_B = "b" * 64
HEX_C = "c" * 64


def _task() -> TaskSpec:
    return TaskSpec(
        name="pytest",
        command=("python", "-m", "pytest"),
        inputs=(),
        outputs=(),
        env=(),
        cacheable=False,
        unsafe_effects=(),
        cache_streams=False,
        image="python@sha256:" + "d" * 64,
        platform="linux/amd64",
        result_only=True,
        closure_reviewed=True,
    )


def _item(nodeid: str, identity: str) -> dict[str, object]:
    return {
        "nodeid": nodeid,
        "identity_sha256": identity,
        "parameter_identity_supported": True,
    }


def _fingerprint(
    root: Path,
    *,
    nodeid: str,
    item: dict[str, object],
    closure: dict[str, object],
    session: FingerprintSession,
):
    return node_action_fingerprint(
        root,
        _task(),
        nodeid=nodeid,
        collection_item=item,
        collection_contract_sha256=HEX_A,
        collection_plugin_sha256=HEX_B,
        node_closure=closure,
        session_closure={
            "selectors": ["session.py::session_helper"],
            "fallback_files": [],
        },
        static_inputs=("static.txt",),
        runtime_identity={"requested_image": "python@sha256:" + "d" * 64},
        environment_fingerprint={},
        independence_review_sha256=HEX_C,
        profile_sha256="e" * 64,
        session=session,
    )


def test_shared_pytest_projection_cache_preserves_exact_keys(tmp_path: Path) -> None:
    (tmp_path / "static.txt").write_text("stable\n", encoding="utf-8")
    (tmp_path / "session.py").write_text(
        "def session_helper():\n    return 1\n",
        encoding="utf-8",
    )
    (tmp_path / "calc.py").write_text(
        "def add(a, b):\n    return a + b\n\n"
        "def sub(a, b):\n    return a - b\n",
        encoding="utf-8",
    )

    rows = [
        (
            "tests/test_calc.py::test_add",
            _item("tests/test_calc.py::test_add", "1" * 64),
            {"selectors": ["calc.py::add"], "fallback_files": []},
        ),
        (
            "tests/test_calc.py::test_sub",
            _item("tests/test_calc.py::test_sub", "2" * 64),
            {"selectors": ["calc.py::sub"], "fallback_files": []},
        ),
    ]

    shared = FingerprintSession(tmp_path)
    shared_results = [
        _fingerprint(
            tmp_path,
            nodeid=nodeid,
            item=item,
            closure=closure,
            session=shared,
        )
        for nodeid, item, closure in rows
    ]
    uncached_results = [
        _fingerprint(
            tmp_path,
            nodeid=nodeid,
            item=item,
            closure=closure,
            session=FingerprintSession(tmp_path),
        )
        for nodeid, item, closure in rows
    ]

    assert shared_results == uncached_results
    assert len(shared.pytest_static_input_records) == 1
    assert len(shared.pytest_closure_fingerprints) == 3


def test_shared_invalid_session_closure_is_failed_once_and_never_keyed(tmp_path: Path) -> None:
    (tmp_path / "static.txt").write_text("stable\n", encoding="utf-8")
    (tmp_path / "session.py").write_text("SESSION = 1\n", encoding="utf-8")
    (tmp_path / "calc.py").write_text(
        "def add(a, b):\n    return a + b\n\n"
        "def sub(a, b):\n    return a - b\n",
        encoding="utf-8",
    )
    nodeids = ["tests/test_calc.py::test_add", "tests/test_calc.py::test_sub"]
    node_rows = [
        {
            "nodeid": nodeids[0],
            "reviewable": True,
            "fresh_required": False,
            "selectors": ["calc.py::add"],
            "fallback_files": [],
        },
        {
            "nodeid": nodeids[1],
            "reviewable": True,
            "fresh_required": False,
            "selectors": ["calc.py::sub"],
            "fallback_files": [],
        },
    ]
    collection = [
        _item(nodeids[0], "1" * 64),
        _item(nodeids[1], "2" * 64),
    ]
    context = NodeCacheContext(
        runtime_identity={"requested_image": "python@sha256:" + "d" * 64},
        environment_fingerprint={},
        collection_contract_sha256=HEX_A,
        collection_plugin_sha256=HEX_B,
        independence_review_sha256=HEX_C,
        profile_sha256="e" * 64,
    )

    with patch(
        "zerorun.pytest_node_key._symbol_records_cached",
        wraps=node_key_module._symbol_records_cached,
    ) as projections, patch(
        "zerorun.pytest_node_cache._load_result_entry"
    ) as cache_lookup:
        decisions = prepare_node_cache(
            tmp_path,
            _task(),
            node_rows=node_rows,
            session_closure={
                "selectors": ["session.py::missing_helper"],
                "fallback_files": [],
            },
            static_inputs=("static.txt",),
            collection_items=collection,
            context=context,
        )

    assert projections.call_count == 1
    cache_lookup.assert_not_called()
    assert [decision.status for decision in decisions] == [
        "MISS_UNCERTAIN",
        "MISS_UNCERTAIN",
    ]
    assert all(decision.key is None and decision.cached is None for decision in decisions)
    assert all(
        decision.reason
        == "node action identity is uncertain: reviewed input symbol not found: "
        "session.py::missing_helper"
        for decision in decisions
    )


def test_cached_closure_failure_is_scoped_to_one_snapshot_session(tmp_path: Path) -> None:
    (tmp_path / "static.txt").write_text("stable\n", encoding="utf-8")
    (tmp_path / "session.py").write_text("SESSION = 1\n", encoding="utf-8")
    (tmp_path / "calc.py").write_text(
        "def add(a, b):\n    return a + b\n",
        encoding="utf-8",
    )
    closure = {"selectors": ["calc.py::add"], "fallback_files": []}
    item = _item("tests/test_calc.py::test_add", "1" * 64)
    first_session = FingerprintSession(tmp_path)

    with pytest.raises(ConfigurationError, match="missing_helper"):
        node_action_fingerprint(
            tmp_path,
            _task(),
            nodeid="tests/test_calc.py::test_add",
            collection_item=item,
            collection_contract_sha256=HEX_A,
            collection_plugin_sha256=HEX_B,
            node_closure=closure,
            session_closure={
                "selectors": ["session.py::missing_helper"],
                "fallback_files": [],
            },
            static_inputs=("static.txt",),
            runtime_identity={"requested_image": "python@sha256:" + "d" * 64},
            environment_fingerprint={},
            independence_review_sha256=HEX_C,
            profile_sha256="e" * 64,
            session=first_session,
        )

    (tmp_path / "session.py").write_text(
        "def missing_helper():\n    return 1\n",
        encoding="utf-8",
    )
    _, key, _ = node_action_fingerprint(
        tmp_path,
        _task(),
        nodeid="tests/test_calc.py::test_add",
        collection_item=item,
        collection_contract_sha256=HEX_A,
        collection_plugin_sha256=HEX_B,
        node_closure=closure,
        session_closure={
            "selectors": ["session.py::missing_helper"],
            "fallback_files": [],
        },
        static_inputs=("static.txt",),
        runtime_identity={"requested_image": "python@sha256:" + "d" * 64},
        environment_fingerprint={},
        independence_review_sha256=HEX_C,
        profile_sha256="e" * 64,
        session=FingerprintSession(tmp_path),
    )

    assert len(key) == 64
    assert len(first_session.pytest_closure_failures) == 1
