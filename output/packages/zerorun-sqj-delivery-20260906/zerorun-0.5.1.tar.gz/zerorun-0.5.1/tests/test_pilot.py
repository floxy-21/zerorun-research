from zerorun.pilot import build_pilot_report


def test_pilot_agent_policy_matches_codex_trust_boundary():
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    agents = (root / "pilot" / "AGENTS.md").read_text(encoding="utf-8")
    quickstart = (root / "pilot" / "QUICKSTART.md").read_text(encoding="utf-8")

    assert "Do not invoke the shell command `zerorun run` autonomously" in agents
    assert "task_reuse_ready" in agents
    assert "run_tests" in agents
    assert "zerorun --json init --codex --root ." in quickstart
    assert "zerorun authorize --manifest-sha256" in quickstart
    assert "manifest_authorized: true" in quickstart
    assert "https://github.com/floxy-21/zerorun-mvp" in quickstart


def test_empty_pilot_report_is_safe_and_zeroed():
    report = build_pilot_report([])

    assert report["schema"] == "zerorun-pilot-report-v1"
    assert report["events"]["total"] == 0
    assert report["events"]["ignored_non_pilot_events"] == 0
    assert report["events"]["normal_runs"] == 0
    assert report["performance"]["reuse_rate"] is None
    assert report["performance"]["fresh_compute_executed_ms"] == 0
    assert report["performance"]["reused_prior_execution_reference_ms"] == 0
    assert report["privacy"]["aggregate_only"] is True
    assert report["privacy"]["contains_source_code"] is False
    assert report["privacy"]["contains_repository_paths"] is False
    assert report["privacy"]["contains_task_names"] is False
    assert report["privacy"]["contains_commands"] is False
    assert report["privacy"]["contains_environment_values"] is False
    assert report["privacy"]["contains_cache_keys"] is False
    assert report["privacy"]["contains_reasons"] is False
    assert report["privacy"]["contains_raw_events"] is False


def test_pilot_report_aggregates_without_copying_sensitive_fields():
    events = [
        {
            "status": "MISS_EXECUTED",
            "task": "secret-payment-test",
            "wall_ms": 1000,
            "execution_ms": 950,
            "saved_ms": 0,
            "cache_key": "super-secret-cache-key",
            "command": ["pytest", "private/tests"],
            "reason": "private/path.py changed",
        },
        {
            "status": "HIT_REUSED",
            "task": "secret-payment-test",
            "wall_ms": 50,
            "execution_ms": 950,
            "saved_ms": 900,
            "cache_key": "super-secret-cache-key",
        },
        {
            "status": "VERIFY_MATCH",
            "task": "secret-payment-test",
            "wall_ms": 980,
            "execution_ms": 950,
            "saved_ms": 0,
        },
    ]

    report = build_pilot_report(events)
    rendered = repr(report)

    assert report["events"]["total"] == 3
    assert report["events"]["normal_runs"] == 2
    assert report["events"]["reuse"] == 1
    assert report["events"]["fresh_or_conservative_fallback"] == 1
    assert report["events"]["verification"] == 1
    assert report["performance"]["reuse_rate"] == 0.5
    assert report["performance"]["total_saved_ms"] == 900
    assert report["performance"]["fresh_compute_executed_ms"] == 1900
    assert report["performance"]["reused_prior_execution_reference_ms"] == 950
    assert "secret-payment-test" not in rendered
    assert "super-secret-cache-key" not in rendered
    assert "private/tests" not in rendered
    assert "private/path.py" not in rendered


def test_pilot_report_surfaces_safety_events():
    events = [
        {"status": "VERIFY_MISMATCH", "wall_ms": 500, "execution_ms": 480},
        {"status": "REJECTED_INPUT_RACE", "wall_ms": 400, "execution_ms": 350},
        {"status": "BYPASS_ACTION_BUSY", "wall_ms": 10, "execution_ms": 0},
    ]

    report = build_pilot_report(events)

    assert report["events"]["total"] == 3
    assert report["events"]["verification_mismatch_or_conflict"] == 1
    assert report["events"]["safety_stops"] == 3
    assert report["events"]["by_status"]["VERIFY_MISMATCH"] == 1
    assert report["events"]["by_status"]["REJECTED_INPUT_RACE"] == 1
    assert report["events"]["by_status"]["BYPASS_ACTION_BUSY"] == 1
    assert report["performance"]["fresh_compute_executed_ms"] == 830


def test_observe_and_unknown_events_are_excluded_from_pilot_metrics():
    events = [
        {
            "status": "OBSERVED_EXECUTED",
            "task": "<observed>",
            "wall_ms": 9999,
            "execution_ms": 9999,
            "reason": "private direct baseline command",
        },
        {"status": "SOMETHING_NEW", "wall_ms": 123, "execution_ms": 123},
        {"status": "HIT_REUSED", "wall_ms": 10, "execution_ms": 1000, "saved_ms": 990},
    ]

    report = build_pilot_report(events)
    rendered = repr(report)

    assert report["events"]["total"] == 1
    assert report["events"]["ignored_non_pilot_events"] == 2
    assert report["events"]["reuse"] == 1
    assert report["performance"]["fresh_compute_executed_ms"] == 0
    assert report["performance"]["reused_prior_execution_reference_ms"] == 1000
    assert "OBSERVED_EXECUTED" not in rendered
    assert "SOMETHING_NEW" not in rendered
    assert "private direct baseline command" not in rendered


def test_json_run_keeps_target_output_out_of_machine_readable_stdout(monkeypatch, tmp_path, capfd):
    import json
    from types import SimpleNamespace

    from zerorun import cli

    task = object()
    manifest = SimpleNamespace(root=tmp_path, tasks={"probe": task}, version=2)
    seen = {}

    class Result:
        exit_code = 0

        @staticmethod
        def as_dict():
            return {
                "task": "probe",
                "status": "MISS_EXECUTED",
                "exit_code": 0,
                "wall_ms": 1.0,
                "execution_ms": 1.0,
                "cache_key": "abc",
                "saved_ms": 0.0,
                "verified": False,
                "reason": "fresh",
                "phase_ms": {},
            }

    def fake_run_task(_manifest, _task, **kwargs):
        seen.update(kwargs)
        kwargs["stdout"].write(b"target-noise\n")
        kwargs["stdout"].flush()
        return Result()

    monkeypatch.setattr(cli, "_manifest", lambda _args: manifest)
    monkeypatch.setattr(cli, "run_task", fake_run_task)

    assert cli.main(["--json", "run", "probe"]) == 0
    captured = capfd.readouterr()
    payload = json.loads(captured.out)

    assert payload["status"] == "MISS_EXECUTED"
    assert captured.out.lstrip().startswith("{")
    assert "target-noise" not in captured.out
    assert "target-noise" in captured.err
    assert seen["stdout"] is seen["stderr"]


def test_pilot_export_publishes_default_output_atomically(monkeypatch, tmp_path):
    import json
    from types import SimpleNamespace

    from zerorun import cli

    manifest = SimpleNamespace(root=tmp_path, tasks={}, version=2)
    monkeypatch.setattr(cli, "_manifest", lambda _args: manifest)
    monkeypatch.setattr(cli, "read_events", lambda _store: [])

    assert cli.main(["pilot-export"]) == 0
    output = tmp_path / "zerorun-pilot-report.json"
    assert json.loads(output.read_text(encoding="utf-8"))["schema"] == (
        "zerorun-pilot-report-v1"
    )
    assert list(tmp_path.glob(".*.zerorun-*.tmp")) == []


def test_pilot_export_never_follows_final_output_symlink(
    monkeypatch, tmp_path, capsys
):
    from types import SimpleNamespace

    import pytest

    from zerorun import cli

    manifest = SimpleNamespace(root=tmp_path, tasks={}, version=2)
    outside = tmp_path.parent / f"{tmp_path.name}-pilot-outside.json"
    outside.write_text("do not overwrite\n", encoding="utf-8")
    output = tmp_path / "zerorun-pilot-report.json"
    try:
        output.symlink_to(outside)
    except OSError as exc:
        pytest.skip(f"symbolic links are unavailable: {exc}")
    monkeypatch.setattr(cli, "_manifest", lambda _args: manifest)
    monkeypatch.setattr(cli, "read_events", lambda _store: [])

    assert cli.main(["pilot-export"]) == 2
    assert "symbolic link or junction" in capsys.readouterr().err
    assert outside.read_text(encoding="utf-8") == "do not overwrite\n"


def test_pilot_export_never_follows_repository_parent_link(
    monkeypatch, tmp_path, capsys
):
    from types import SimpleNamespace

    import pytest

    from zerorun import cli

    manifest = SimpleNamespace(root=tmp_path, tasks={}, version=2)
    outside = tmp_path.parent / f"{tmp_path.name}-pilot-directory"
    outside.mkdir()
    linked_parent = tmp_path / "reports"
    try:
        linked_parent.symlink_to(outside, target_is_directory=True)
    except OSError as exc:
        pytest.skip(f"directory links are unavailable: {exc}")
    monkeypatch.setattr(cli, "_manifest", lambda _args: manifest)
    monkeypatch.setattr(cli, "read_events", lambda _store: [])

    assert cli.main(["pilot-export", "--output", "reports/report.json"]) == 2
    assert "symbolic link or junction" in capsys.readouterr().err
    assert not (outside / "report.json").exists()
