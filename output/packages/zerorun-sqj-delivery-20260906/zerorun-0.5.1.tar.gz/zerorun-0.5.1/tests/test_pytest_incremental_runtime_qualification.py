from __future__ import annotations

import hashlib
import json

import pytest

from tools import hermetic_pytest_distinct_proof as proof
from tools import hermetic_pytest_experiment as experiment
from tools import pytest_incremental_runtime_qualification as incremental
from tools.pytest_node_runtime_qualification import _case_row
from tools.pytest_incremental_runtime_qualification import _partition_rows, aggregate


def test_partition_rows_rejects_duplicate_or_invalid_evidence() -> None:
    proof.configure_compatible_harness()
    rows = [
        {
            "partition": partition.name,
            "candidate_source_fresh_nodes": [],
        }
        for partition in experiment.PARTITIONS
    ]
    assert set(_partition_rows({"partitions": rows})) == {
        partition.name for partition in experiment.PARTITIONS
    }

    duplicate = [*rows[:-1], dict(rows[0])]
    with pytest.raises(RuntimeError, match="current reviewed graph"):
        _partition_rows({"partitions": duplicate})

    invalid = [*rows[:-1], {"not_partition": "missing"}]
    with pytest.raises(RuntimeError, match="invalid partition row"):
        _partition_rows({"partitions": invalid})


def test_source_fresh_rejects_duplicates() -> None:
    with pytest.raises(RuntimeError, match="duplicate fresh node"):
        incremental._source_fresh(
            {
                "candidate_source_fresh_nodes": [
                    {"nodeid": "testing/test_example.py::test_one"},
                    {"nodeid": "testing/test_example.py::test_one"},
                ]
            }
        )


def test_selected_case_envelope_does_not_claim_complete_corpus() -> None:
    row = {"pr": 9624, "partitions": []}
    envelope = {
        "pass": True,
        "complete_frozen_corpus": False,
        "selected_case_only": True,
        "selected_pr": 9624,
        "cases": [row],
    }
    assert _case_row(envelope, 9624) is row

    envelope["selected_pr"] = 9628
    with pytest.raises(RuntimeError, match="incomplete"):
        _case_row(envelope, 9624)


def _zero_miss_fixture():
    proof.configure_compatible_harness()
    partition = next(
        partition
        for partition in experiment.PARTITIONS
        if partition.enabled_optional_plugins
    )
    nodeid = f"{partition.targets[0]}::test_zero_miss"
    item = {
        "nodeid": nodeid,
        "path": partition.targets[0],
        "identity_sha256": "a" * 64,
        "parameter_identity_supported": True,
    }
    baseline = {"nodeids": [nodeid], "items": [item]}
    baseline["collection_sha256"] = hashlib.sha256(
        json.dumps(
            {"items": baseline["items"], "nodeids": baseline["nodeids"]},
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    impact = {
        "partition": partition.name,
        "node_count": 1,
        "session_uncertain": False,
        "session_changed": False,
        "candidate_source_fresh_node_count": 0,
        "candidate_source_reusable_node_count": 1,
        "candidate_source_fresh_nodes": [],
        "candidate_source_reusable_nodes": [nodeid],
    }
    guard = {"guard": "same"}
    return partition, baseline, impact, guard, nodeid


def _decision(monkeypatch, *, changed_paths=None, mutate=None):
    partition, baseline, impact, guard, nodeid = _zero_miss_fixture()
    if mutate is not None:
        mutate(partition, baseline, impact, guard, nodeid)
    monkeypatch.setattr(
        incremental,
        "_partition_guard_contract",
        lambda manifest, current_partition: dict(guard),
    )
    decision = incremental._zero_miss_elision_decision(
        manifest=object(),
        partition=partition,
        impact_row=impact,
        baseline_collection=baseline,
        baseline_guard_contract=dict(guard),
        source_fresh_nodeids=[
            str(row["nodeid"]) for row in impact["candidate_source_fresh_nodes"]
        ],
        force_full_reason=None,
        changed_paths=set(changed_paths or ()),
    )
    return partition, decision


def test_zero_miss_guard_elides_only_exact_supported_partition(monkeypatch) -> None:
    _, decision = _decision(monkeypatch)
    assert decision["eligible"] is True
    assert decision["mode"] == "collection-reused-zero-miss"
    assert decision["reason"] is None


def test_zero_miss_guard_blocks_any_source_fresh_node(monkeypatch) -> None:
    def mutate(partition, baseline, impact, guard, nodeid):
        impact["candidate_source_fresh_node_count"] = 1
        impact["candidate_source_reusable_node_count"] = 0
        impact["candidate_source_fresh_nodes"] = [{"nodeid": nodeid}]
        impact["candidate_source_reusable_nodes"] = []

    _, decision = _decision(monkeypatch, mutate=mutate)
    assert decision["eligible"] is False
    assert "source-fresh" in decision["reason"]


@pytest.mark.parametrize(
    "field,value",
    [
        ("session_uncertain", True),
        ("session_changed", True),
        ("session_uncertain", None),
    ],
)
def test_zero_miss_guard_blocks_session_change_or_uncertainty(
    monkeypatch, field, value
) -> None:
    def mutate(partition, baseline, impact, guard, nodeid):
        impact[field] = value

    _, decision = _decision(monkeypatch, mutate=mutate)
    assert decision["eligible"] is False
    assert "session" in decision["reason"]


def test_zero_miss_guard_blocks_incomplete_reusable_coverage(monkeypatch) -> None:
    def mutate(partition, baseline, impact, guard, nodeid):
        impact["candidate_source_reusable_node_count"] = 0
        impact["candidate_source_reusable_nodes"] = []

    _, decision = _decision(monkeypatch, mutate=mutate)
    assert decision["eligible"] is False
    assert "source-reusable" in decision["reason"] or "source-impact counts" in decision["reason"]


def test_zero_miss_guard_blocks_unsupported_parameter_identity(monkeypatch) -> None:
    def mutate(partition, baseline, impact, guard, nodeid):
        baseline["items"][0]["parameter_identity_supported"] = False
        baseline["collection_sha256"] = incremental._collection_sha256(baseline)

    _, decision = _decision(monkeypatch, mutate=mutate)
    assert decision["eligible"] is False
    assert "unsupported parameter" in decision["reason"]


def test_zero_miss_guard_blocks_tampered_collection_digest(monkeypatch) -> None:
    def mutate(partition, baseline, impact, guard, nodeid):
        baseline["collection_sha256"] = "0" * 64

    _, decision = _decision(monkeypatch, mutate=mutate)
    assert decision["eligible"] is False
    assert "baseline structural collection" in decision["reason"]


def test_zero_miss_guard_blocks_partition_target_change(monkeypatch) -> None:
    partition, _, _, _, _ = _zero_miss_fixture()
    _, decision = _decision(monkeypatch, changed_paths={partition.targets[0]})
    assert decision["eligible"] is False
    assert "partition target source changed" in decision["reason"]


def test_zero_miss_guard_blocks_static_collection_change(monkeypatch) -> None:
    _, decision = _decision(monkeypatch, changed_paths={"testing/conftest.py"})
    assert decision["eligible"] is False
    assert "shared collection/config input changed" in decision["reason"]


def test_zero_miss_guard_blocks_unreviewed_test_support_change(monkeypatch) -> None:
    _, decision = _decision(monkeypatch, changed_paths={"testing/helpers.py"})
    assert decision["eligible"] is False
    assert "unreviewed test-support input changed" in decision["reason"]


def test_zero_miss_guard_blocks_enabled_plugin_change(monkeypatch) -> None:
    partition, _, _, _, _ = _zero_miss_fixture()
    plugin = next(iter(partition.enabled_optional_plugins))
    plugin_path = experiment.OPTIONAL_PLUGINS[plugin]
    _, decision = _decision(monkeypatch, changed_paths={plugin_path})
    assert decision["eligible"] is False
    assert "enabled pytest plugin implementation changed" in decision["reason"]


def test_zero_miss_guard_blocks_runtime_or_environment_guard_change(monkeypatch) -> None:
    partition, baseline, impact, guard, _ = _zero_miss_fixture()
    monkeypatch.setattr(
        incremental,
        "_partition_guard_contract",
        lambda manifest, current_partition: {"guard": "changed"},
    )
    decision = incremental._zero_miss_elision_decision(
        manifest=object(),
        partition=partition,
        impact_row=impact,
        baseline_collection=baseline,
        baseline_guard_contract=guard,
        source_fresh_nodeids=[],
        force_full_reason=None,
        changed_paths=set(),
    )
    assert decision["eligible"] is False
    assert "command/runtime/environment" in decision["reason"]


def _write_aggregate_cases(input_dir, *, direct_ms: float, candidate_ms: float) -> None:
    for case in experiment.PATCH_CASES:
        payload = {
            "pass": True,
            "case": {"pr": case.pr},
            "timing": {
                "direct_wall_ms": direct_ms,
                "candidate_total_wall_ms": candidate_ms,
            },
        }
        (input_dir / f"zerorun-pytest-incremental-qual-{case.pr}.json").write_text(
            json.dumps(payload),
            encoding="utf-8",
        )


def test_aggregate_pass_field_matches_failed_headroom_gate(tmp_path) -> None:
    input_dir = tmp_path / "cases"
    input_dir.mkdir()
    output = tmp_path / "aggregate.json"
    _write_aggregate_cases(input_dir, direct_ms=100.0, candidate_ms=40.0)

    assert aggregate(input_dir, output) == 2
    report = json.loads(output.read_text(encoding="utf-8"))
    assert report["measurement_valid"] is True
    assert report["pass"] is False
    assert report["preflight_gate_pass"] is False
    assert report["strict_gate_projection_pass"] is False


def test_aggregate_records_true_only_after_unchanged_headroom_gate(tmp_path) -> None:
    input_dir = tmp_path / "cases"
    input_dir.mkdir()
    output = tmp_path / "aggregate.json"
    _write_aggregate_cases(input_dir, direct_ms=100.0, candidate_ms=10.0)

    assert aggregate(input_dir, output) == 0
    report = json.loads(output.read_text(encoding="utf-8"))
    assert report["pass"] is True
    assert report["preflight_gate_pass"] is True
    assert report["strict_gate_projection_pass"] is True


@pytest.mark.parametrize("value", [0.0, -1.0, float("nan"), float("inf")])
def test_aggregate_rejects_non_positive_or_non_finite_timings(tmp_path, value) -> None:
    input_dir = tmp_path / "cases"
    input_dir.mkdir()
    output = tmp_path / "aggregate.json"
    _write_aggregate_cases(input_dir, direct_ms=100.0, candidate_ms=value)

    with pytest.raises(RuntimeError, match="non-positive or non-finite"):
        aggregate(input_dir, output)
