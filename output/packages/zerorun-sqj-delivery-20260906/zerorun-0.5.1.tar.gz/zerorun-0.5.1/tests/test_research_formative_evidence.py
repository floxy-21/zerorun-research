from __future__ import annotations

from argparse import Namespace
from copy import deepcopy
import json
from pathlib import Path

import pytest

from research.artifact import analyze_formative_evidence as formative


ROOT = Path(__file__).resolve().parents[1]
SELECTION = ROOT / "commercial/corpus/selection-v1.json"
FORMATIVE = ROOT / "research/results/formative/cd97eb5"
COMMERCIAL = FORMATIVE / "raw/commercial-100-repository-result.json"
GENERALIZATION = FORMATIVE / "raw/product-generalization-five-repo-receipt.json"


def _arguments() -> Namespace:
    return Namespace(
        commercial_selection=SELECTION,
        commercial_result=COMMERCIAL,
        generalization_result=GENERALIZATION,
        commercial_run_id=33949630904,
        commercial_artifact_id=9964423638,
        commercial_artifact_zip_sha256="06e0524b5057357e486d4c6f093c62e664fc317e79e8380512415c5f151c3d34",
        generalization_run_id=33949590961,
        generalization_artifact_id=9964520732,
        generalization_artifact_zip_sha256="adcfe35dd969981bdfd3476444b8563cc20b69c78d60dd7b9b07a2aec7faf19a",
        output=ROOT / "unused-formative-summary.json",
        latex_output=ROOT / "unused-formative-summary.tex",
        archive_directory=None,
    )


def _load(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def test_checked_formative_receipts_reproduce_tracked_summary() -> None:
    summary = formative.build_summary(_arguments())
    tracked = _load(FORMATIVE / "summary.json")
    assert summary == tracked
    assert summary["confirmatory_claims_authorized"] is False

    commercial = summary["commercial_integration"]
    assert isinstance(commercial, dict)
    assert (commercial["complete_passes"], commercial["safe_refusals"], commercial["failures"]) == (99, 1, 0)
    assert commercial["upstream_code_executed"] is False
    assert commercial["completed_observation_only"] == 99
    assert commercial["completed_with_manifest"] == 0
    assert commercial["completed_with_pytest_candidate"] == 0
    assert commercial["completed_with_pytest_profile"] == 0
    assert commercial["completed_reuse_ready"] == 0
    assert commercial["distinct_owners"] == 96
    assert commercial["multi_repository_owners"] == 3
    assert commercial["cross_stratum_owners"] == 2

    performance = summary["five_repository_performance"]
    assert isinstance(performance, dict)
    assert performance["repositories"] == 5
    assert performance["transitions"] == 100
    assert performance["aggregate_speedup"] == 0.897281
    assert performance["equal_repository_geomean_speedup"] == 0.774797
    assert performance["general_5x_claim_supported"] is False
    assert performance["five_x_or_higher_observed_transitions"] == 5
    assert performance["full_reuse_repositories"] == 2
    assert performance["valid_performance_transitions"] == 100
    assert performance["unclassified_reuse_transitions"] == 0
    assert performance["maximum_observed_transition_speedup"] == 15.362286
    assert performance["activation_evidence_kind"] == "mechanical-synthetic-formative-fixture"
    assert performance["external_hmac_authority_created"] is False
    assert performance["runtime_image"].endswith(
        "2856e6af199e8128161abd320575eb9b341f3b76f017b5d0c9cd364f60d8a050"
    )
    assert [
        (
            row["workload"],
            row["aggregate_speedup"],
            row["p95_reduction_percent"],
            row["performance_reference_pass"],
        )
        for row in performance["per_repository"]
    ] == [
        ("click", 0.755686, -53.37853, False),
        ("colorama", 0.658233, -51.142119, False),
        ("more-itertools", 0.991519, -0.196843, False),
        ("packaging", 0.659653, -152.262693, False),
        ("pycparser", 0.858224, -24.108021, False),
    ]

    archived_receipt = _load(GENERALIZATION)
    assert archived_receipt["release_gate"] == (
        "safety only; performance remains diagnostic"
    )


def test_default_cli_inputs_reproduce_bundled_evidence() -> None:
    arguments = formative.parse_args([])
    assert arguments.output == FORMATIVE / "summary.json"
    assert arguments.latex_output == ROOT / "research/paper/generated/formative_results.tex"
    assert formative.build_summary(arguments) == _load(FORMATIVE / "summary.json")


def test_formative_latex_is_explicitly_nonconfirmatory() -> None:
    summary = formative.build_summary(_arguments())
    rendered = formative._render_latex(summary)
    assert "FORMATIVE ONLY" in rendered
    assert "\\ObservedFiveXTransitions}{5}" in rendered
    assert "\\ObservedFullHitRepositories}{2}" in rendered
    assert "\\ObservedValidPerformanceTransitions}{100}" in rendered
    assert "\\ObservedAggregateSpeedup}{0.897x}" in rendered
    assert "\\ObservedZeroHitFasterTransitions}{15}" in rendered
    assert "\\ObservedFullHitOverheadFraction}{0.070121}" in rendered
    assert "\\ObservedIdealizedFiveXEliminatedWorkThreshold}{87.012\\%}" in rendered
    assert "\\ObservedReuseReadyRepositories}{0}" in rendered
    assert "\\ObservedIntegrationOwners}{96}" in rendered
    assert "\\ObservedMultiRepositoryOwners}{3}" in rendered
    assert "\\ObservedCrossStratumOwners}{2}" in rendered
    assert "\\ObservedEngineVersion}{0.5.0}" in rendered
    assert "\\ObservedPartialHitFasterTransitions}{0}" in rendered
    assert "\\ObservedDirectFailures}{0}" in rendered
    assert "\\ObservedZeroRunFailures}{0}" in rendered
    assert "\\ObservedStaleSuccesses}{0}" in rendered
    assert "\\ObservedShadowMismatches}{0}" in rendered
    assert "\\ObservedCacheConflicts}{0}" in rendered
    assert rendered.count(" & MISS \\\\") == 5
    assert "\\newcommand{\\ObservedFullHitRows}" in rendered
    assert rendered.count(" & 1 & 1409.206 & 228.427 & 1180.779 & 6.169x \\\\") == 1
    assert " & PASS \\\\" not in rendered
    assert "resultsavailabletrue" not in rendered


@pytest.mark.parametrize(
    "field, value, message",
    [
        ("commercial_run_id", 33949630905, "commercial run ID"),
        ("commercial_artifact_id", 9964423639, "commercial artifact ID"),
        (
            "commercial_artifact_zip_sha256",
            "0" * 64,
            "commercial artifact ZIP SHA-256",
        ),
        ("generalization_run_id", 33949590962, "generalization run ID"),
        ("generalization_artifact_id", 9964520733, "generalization artifact ID"),
        (
            "generalization_artifact_zip_sha256",
            "0" * 64,
            "generalization artifact ZIP SHA-256",
        ),
    ],
)
def test_formative_provenance_cannot_be_supplied_by_the_summary_under_test(
    field: str, value: object, message: str
) -> None:
    arguments = _arguments()
    setattr(arguments, field, value)
    with pytest.raises(formative.EvidenceError, match=message):
        formative.build_summary(arguments)


def test_commercial_analysis_rejects_upstream_execution() -> None:
    selection = _load(SELECTION)
    receipt = _load(COMMERCIAL)
    receipt["upstream_code_executed"] = True
    with pytest.raises(formative.EvidenceError, match="unexpectedly executed upstream code"):
        formative._commercial_summary(selection, receipt)


def test_commercial_analysis_rejects_duplicate_attempt() -> None:
    selection = _load(SELECTION)
    receipt = _load(COMMERCIAL)
    rows = receipt["rows"]
    assert isinstance(rows, list)
    rows[-1] = deepcopy(rows[0])
    with pytest.raises(formative.EvidenceError, match="attempted more than once"):
        formative._commercial_summary(selection, receipt)


def test_commercial_analysis_rejects_unproved_safe_refusal() -> None:
    selection = _load(SELECTION)
    receipt = _load(COMMERCIAL)
    rows = receipt["rows"]
    refusal = next(row for row in rows if row["status"] == "safe_refusal")
    refusal["refusal_proof"]["unchanged"] = False
    with pytest.raises(formative.EvidenceError, match="before/after proof"):
        formative._commercial_summary(selection, receipt)


def test_generalization_analysis_preserves_collection_mismatch() -> None:
    receipt = _load(GENERALIZATION)
    workloads = receipt["workloads"]
    assert isinstance(workloads, list)
    rows = workloads[0]["rows"]
    rows[0]["zerorun_collection_sha256"] = "0" * 64
    workloads[0]["shadow_mismatches"] = 1
    workloads[0]["safety_pass"] = False
    workloads[0]["performance_gate_pass"] = False
    receipt["all_safety_pass"] = False
    receipt["general_5x_claim_supported_by_this_suite"] = False
    summary = formative._generalization_summary(receipt)
    assert summary["all_safety_pass"] is False
    assert summary["event_totals"]["shadow_mismatches"] == 1
    assert summary["valid_performance_transitions"] == 99
    assert summary["general_5x_claim_supported"] is False


def test_generalization_analysis_rejects_unreconciled_failure_counter() -> None:
    receipt = _load(GENERALIZATION)
    workloads = receipt["workloads"]
    assert isinstance(workloads, list)
    rows = workloads[0]["rows"]
    rows[0]["direct_exit_code"] = 1
    with pytest.raises(formative.EvidenceError, match="direct_failures does not reconcile"):
        formative._generalization_summary(receipt)


def test_generalization_analysis_rejects_transition_as_repository_inflation() -> None:
    receipt = _load(GENERALIZATION)
    workloads = receipt["workloads"]
    assert isinstance(workloads, list)
    workloads[0]["rows"] = workloads[0]["rows"][:-1]
    with pytest.raises(formative.EvidenceError, match="20 transitions"):
        formative._generalization_summary(receipt)


def test_generalization_analysis_rejects_commit_sequence_drift() -> None:
    receipt = _load(GENERALIZATION)
    workloads = receipt["workloads"]
    rows = workloads[0]["rows"]
    rows[0]["commit"] = "0" * 40
    with pytest.raises(formative.EvidenceError, match="frozen commit sequence"):
        formative._generalization_summary(receipt)


def test_generalization_analysis_rejects_derived_p95_drift() -> None:
    receipt = _load(GENERALIZATION)
    workloads = receipt["workloads"]
    workloads[0]["p95_reduction_percent"] = 99.0
    with pytest.raises(formative.EvidenceError, match="p95 reduction mismatch"):
        formative._generalization_summary(receipt)


def test_transition_schema_includes_closest_research_baselines() -> None:
    schema = _load(ROOT / "research/schemas/transition-result.schema.json")
    assert schema["properties"]["condition"]["enum"] == [
        "direct",
        "pytest-testmon",
        "namerts",
        "babelrts",
        "zerorun",
        "oracle",
    ]
    assert schema["properties"]["condition_order"]["maximum"] == 6


def test_manuscript_has_jishan_kapoor_as_sole_author() -> None:
    source = (ROOT / "research/paper/main.tex").read_text(encoding="utf-8")
    assert source.count("\\author{") == 1
    assert "\\author{Jishan Kapoor}" in source
    assert "/Author (Jishan Kapoor)" in source
    assert "it is not an author" in source


def test_manuscript_preserves_strict_gate_and_full_hit_boundary() -> None:
    source = " ".join(
        (ROOT / "research/paper/main.tex")
        .read_text(encoding="utf-8")
        .replace("\\%", "%")
        .split()
    )
    assert "every frozen qualification workload, individually" in source
    assert "at least 5.0x primary end-to-end speedup" in source
    assert "at least 50% p95 latency reduction" in source
    assert "Neither an average across workloads nor H2 can rescue" in source
    assert "not the per-workload p95 statistic" in source
    assert "formative rather than release evidence" in source
    assert "no exact final-candidate version 0.5.1 receipt exists yet" in source


def test_manuscript_abstract_uses_generated_formative_outcome_macros() -> None:
    source = (ROOT / "research/paper/main.tex").read_text(encoding="utf-8")
    abstract = source.split("\\begin{abstract}", 1)[1].split("\\end{abstract}", 1)[0]
    for macro in (
        "ObservedIntegrationAttempts",
        "ObservedIntegrationPasses",
        "ObservedIntegrationLowerBound",
        "ObservedGeneralizationTransitions",
        "ObservedAggregateSpeedup",
        "ObservedFullHitMedianSpeedup",
        "ObservedMaximumSpeedup",
        "ObservedPartialHitFasterTransitions",
    ):
        assert f"\\{macro}" in abstract
    for stale_literal in ("94.55--99.82", "0.897x", "14.261x", "15.362x"):
        assert stale_literal not in abstract
