from __future__ import annotations

import json

import pytest

from tools import hermetic_pytest_experiment as experiment
from tools import pytest_historical_closure_bundle as bundle


def test_validated_partitions_preserves_exact_node_and_session_rows(monkeypatch: pytest.MonkeyPatch) -> None:
    partitions = (
        experiment.Partition("b", ("testing/b.py",), frozenset()),
        experiment.Partition("a", ("testing/a.py",), frozenset()),
    )
    monkeypatch.setattr(bundle.experiment, "PARTITIONS", partitions)
    rows = [
        {
            "partition": "a",
            "nodes": [{"nodeid": "testing/a.py::test_a", "selectors": ["x::a"]}],
            "session_result_closure": {"selectors": ["x::session"], "fallback_files": []},
        },
        {
            "partition": "b",
            "nodes": [{"nodeid": "testing/b.py::test_b", "selectors": ["x::b"]}],
            "session_result_closure": {"selectors": [], "fallback_files": ["src/_pytest/x.py"]},
        },
    ]

    material = bundle._validated_partitions(rows)

    assert [row["partition"] for row in material] == ["a", "b"]
    assert material[0]["node_rows"] == rows[0]["nodes"]
    assert material[0]["session_closure"] == rows[0]["session_result_closure"]


def test_validated_partitions_fails_closed_on_missing_session_or_duplicate_node(monkeypatch: pytest.MonkeyPatch) -> None:
    partition = experiment.Partition("a", ("testing/a.py",), frozenset())
    monkeypatch.setattr(bundle.experiment, "PARTITIONS", (partition,))

    with pytest.raises(RuntimeError, match="session_result_closure"):
        bundle._validated_partitions(
            [{"partition": "a", "nodes": [{"nodeid": "testing/a.py::test_a"}]}]
        )

    with pytest.raises(RuntimeError, match="duplicate historical nodeid"):
        bundle._validated_partitions(
            [
                {
                    "partition": "a",
                    "nodes": [
                        {"nodeid": "testing/a.py::test_a"},
                        {"nodeid": "testing/a.py::test_a"},
                    ],
                    "session_result_closure": {},
                }
            ]
        )


def _case_payload(case: experiment.PatchCase) -> dict[str, object]:
    core = {
        "schema": 1,
        "workload": "pytest-dev/pytest historical per-case node/session closure review candidate",
        "case": {
            "pr": case.pr,
            "merge_sha": case.merge_sha,
            "pre_merge_sha": "a" * 40,
            "source_tree_sha": "b" * 40,
            "patch_sha256": "c" * 64,
            "head_sha": "d" * 40,
        },
        "partitions": [
            {
                "partition": "terminal-core",
                "node_rows": [{"nodeid": "testing/test_terminal.py::test_x"}],
                "session_closure": {},
            }
        ],
    }
    return {
        **core,
        "candidate_only": True,
        "authorizes_reuse": False,
        "operator_reviewed": False,
        "review_required": True,
        "closure_material_sha256": bundle._canonical_sha256(core),
        "baseline_profile_wall_ms": 1.0,
    }


def test_aggregate_requires_complete_frozen_corpus_and_does_not_authorize_reuse(tmp_path) -> None:
    for case in experiment.PATCH_CASES:
        path = tmp_path / f"zerorun-pytest-closure-bundle-{case.pr}.json"
        path.write_text(json.dumps(_case_payload(case)), encoding="utf-8")

    output = tmp_path / "aggregate.json"
    assert bundle.aggregate(tmp_path, output) == 0
    report = json.loads(output.read_text(encoding="utf-8"))

    assert report["pass"] is True
    assert report["case_count"] == len(experiment.PATCH_CASES)
    assert report["complete_frozen_corpus"] is True
    assert report["operator_reviewed"] is False
    assert report["review_required"] is True
    assert report["authorizes_reuse"] is False
    assert len(report["bundle_sha256"]) == 64


def test_aggregate_rejects_incomplete_corpus(tmp_path) -> None:
    case = experiment.PATCH_CASES[0]
    path = tmp_path / f"zerorun-pytest-closure-bundle-{case.pr}.json"
    path.write_text(json.dumps(_case_payload(case)), encoding="utf-8")

    with pytest.raises(RuntimeError, match="corpus mismatch"):
        bundle.aggregate(tmp_path, tmp_path / "aggregate.json")
