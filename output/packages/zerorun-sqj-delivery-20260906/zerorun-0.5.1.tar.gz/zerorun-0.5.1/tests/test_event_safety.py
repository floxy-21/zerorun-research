from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

from zerorun import runner


def _store(path: Path):
    return SimpleNamespace(events=path, managed_file=lambda candidate: candidate)


def test_event_reader_ignores_malformed_numeric_and_oversized_rows(
    monkeypatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(runner, "MAX_EVENT_FILE_BYTES", 4096)
    monkeypatch.setattr(runner, "MAX_EVENT_LINE_BYTES", 256)
    events = tmp_path / "events.jsonl"
    valid = {
        "status": "HIT_REUSED",
        "wall_ms": 2.0,
        "execution_ms": 10.0,
        "saved_ms": 8.0,
        "reused_nodes": 1,
        "fresh_nodes": 0,
        "total_nodes": 1,
    }
    events.write_bytes(
        b"x" * 1024
        + b"\n"
        + json.dumps({**valid, "saved_ms": "not-a-number"}).encode()
        + b"\n"
        + json.dumps({**valid, "total_nodes": -1}).encode()
        + b"\n"
        + json.dumps(valid).encode()
        + b"\n"
    )

    assert runner.read_events(_store(events)) == [
        {
            "status": "HIT_REUSED",
            "wall_ms": 2.0,
            "execution_ms": 10.0,
            "saved_ms": 8.0,
            "reused_nodes": 1,
            "fresh_nodes": 0,
            "total_nodes": 1,
        }
    ]


def test_event_reader_keeps_only_bounded_recent_valid_events(
    monkeypatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(runner, "MAX_EVENTS", 3)
    events = tmp_path / "events.jsonl"
    rows = [
        {
            "status": "MISS_EXECUTED",
            "wall_ms": index,
            "execution_ms": index,
            "saved_ms": 0,
        }
        for index in range(8)
    ]
    events.write_text(
        "".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8"
    )

    result = runner.read_events(_store(events))

    assert len(result) == 3
    assert [row["wall_ms"] for row in result] == [5.0, 6.0, 7.0]


def test_event_reader_ignores_integer_and_nesting_parser_adversity(
    tmp_path: Path,
) -> None:
    events = tmp_path / "events.jsonl"
    huge_integer = b'{"status":"MISS_EXECUTED","wall_ms":' + (b"9" * 5000) + b"}\n"
    deeply_nested = (b"[" * 2000) + b"0" + (b"]" * 2000) + b"\n"
    valid = b'{"status":"HIT_REUSED","wall_ms":2,"saved_ms":1}\n'
    events.write_bytes(huge_integer + deeply_nested + valid)

    assert runner.read_events(_store(events)) == [
        {
            "status": "HIT_REUSED",
            "wall_ms": 2.0,
            "execution_ms": 0.0,
            "saved_ms": 1.0,
            "reused_nodes": 0,
            "fresh_nodes": 0,
            "total_nodes": 0,
        }
    ]
