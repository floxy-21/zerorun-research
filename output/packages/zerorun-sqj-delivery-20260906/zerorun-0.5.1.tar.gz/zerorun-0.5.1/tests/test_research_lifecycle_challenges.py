from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from research.phases.lifecycle_challenges import (
    CAMPAIGN_SCHEMA,
    CASE_SCHEMA,
    LifecycleChallengeError,
    SCENARIOS,
    _git_state,
    run_campaign,
)


def _load(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def _raw_event_digest(events: object) -> str:
    encoded = json.dumps(
        events,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(b"zerorun-pytest-raw-events-v1\0" + encoded).hexdigest()


def test_fixed_scenario_inventory_covers_requested_mechanisms() -> None:
    expected = {
        "shared-global-positive-dependency": "false_negative",
        "shared-global-negative-pollution": "false_green",
        "function-fixture-teardown": "false_negative",
        "function-fixture-pure-call": "false_negative",
        "session-fixture-finalizer": "false_negative",
        "environment-and-file-effects": "false_negative",
        "pytest-hook-observes-omitted-call": "observable_effect_only_divergence",
        "external-plugin-callback": "false_negative",
        "independent-pure-control": "independent_control_match",
    }

    assert {row.name: row.expected_classification for row in SCENARIOS} == expected
    assert {
        row.name: row.expected_call_only_classification for row in SCENARIOS
    } == {
        "shared-global-positive-dependency": "false_negative",
        "shared-global-negative-pollution": "false_green",
        "function-fixture-teardown": "observable_effect_only_divergence",
        "function-fixture-pure-call": "independent_control_match",
        "session-fixture-finalizer": "observable_effect_only_divergence",
        "environment-and-file-effects": "false_negative",
        "pytest-hook-observes-omitted-call": "independent_control_match",
        "external-plugin-callback": "independent_control_match",
        "independent-pure-control": "independent_control_match",
    }
    assert all(row.omitted_node_ids for row in SCENARIOS)
    assert all(set(row.omitted_node_ids) < set(row.node_ids) for row in SCENARIOS)


def test_campaign_falsifies_naive_omission_without_creating_authority(
    tmp_path: Path,
) -> None:
    output = tmp_path / "lifecycle-campaign"

    summary = run_campaign(output, timeout_seconds=60)

    assert summary["schema"] == CAMPAIGN_SCHEMA
    assert summary["research_owner"] == "Jishan Kapoor"
    assert summary["case_count"] == 9
    assert summary["classifications"] == {
        "false_green": 1,
        "false_negative": 6,
        "independent_control_match": 1,
        "observable_effect_only_divergence": 1,
    }
    assert summary["call_only_classifications"] == {
        "false_green": 1,
        "false_negative": 2,
        "independent_control_match": 4,
        "observable_effect_only_divergence": 2,
    }
    assert summary["all_seed_runs_reproduced_by_independent_oracles"] is True
    assert summary["all_expected_challenges_effective"] is True
    assert summary["authorizes_reuse"] is False
    assert summary["product_reuse_executed"] is False
    assert summary["profile_activated"] is False
    assert summary["authority_created_or_used"] is False
    assert summary["product_evidence_eligible"] is False
    assert summary["confirmatory_evidence_eligible"] is False
    assert summary["current_zerorun_qualification_observation"]["status"] == "NOT_RUN"
    assert summary["external_baseline_reproductions_in_this_harness"] == {
        "NameRTS_actual_repository_reproduction": "NOT_RUN",
        "pytest_testmon_actual_repository_reproduction": "NOT_RUN",
        "invented_method_comparator": False,
    }
    assert _load(output / "summary.json")["schema"] == CAMPAIGN_SCHEMA

    cases: dict[str, dict[str, object]] = {}
    for scenario in SCENARIOS:
        case_root = output / scenario.name
        case = _load(case_root / "case.json")
        cases[scenario.name] = case
        assert case["schema"] == CASE_SCHEMA
        assert case["authorizes_reuse"] is False
        assert case["product_reuse_executed"] is False
        assert case["deliberately_unsafe_omission_diagnostic"] is True
        assert case["seed_matches_independent_oracle"] is True
        assert case["challenge_effective"] is True
        assert case["classification"] == scenario.expected_classification
        assert all(
            row["claimed_outcome"] == "passed"
            for row in case["diagnostic_prior_pass_claims"]
        )
        source_locations = {
            row["location"] for row in case["fixture_manifest"]["files"]
        }
        assert "project/test_lifecycle.py" in source_locations

        for capture_name, selector, oracle_complete in (
            ("seed-full.capture.json", False, True),
            ("oracle-full.capture.json", False, True),
            ("residual-selector.capture.json", True, False),
            ("lifecycle-call-only-selector.capture.json", True, False),
        ):
            receipt = _load(case_root / capture_name)
            assert receipt["authorizes_reuse"] is False
            assert receipt["evidence_eligible"] is False
            assert receipt["study_status_mutated"] is False
            assert receipt["synthetic_validation"] is True
            assert receipt["capture_valid"] is True
            assert receipt["selector_observation"] is selector
            assert receipt["oracle_complete"] is oracle_complete
            assert receipt["canonical_outcome"]["reuse_claims"] == []
            assert receipt["raw_events"]
            assert receipt["raw_events_sha256"] == _raw_event_digest(
                receipt["raw_events"]
            )
        residual_receipt = _load(case_root / "residual-selector.capture.json")
        assert any(
            "cannot establish a full-suite oracle" in note
            for note in residual_receipt["incompleteness_notes"]
        )
        call_only = case["lifecycle_preserving_call_only_observation"]
        assert call_only["method_status"] == (
            "MANUALLY_CHOSEN_DIAGNOSTIC_CAPSULE__NOT_VALIDATED"
        )
        assert call_only["oracle_complete"] is False
        assert call_only[
            "setup_call_report_and_teardown_observed_for_suppressed_nodes"
        ] is True
        assert call_only["challenge_effective"] is True
        assert call_only["classification"] == scenario.expected_call_only_classification
        if call_only["classification"] == "independent_control_match":
            assert "does not prove semantic independence" in call_only[
                "classification_interpretation"
            ]
        assert call_only["suppression_attestation"]["call-omission.log"][
            "text"
        ].splitlines() == list(scenario.omitted_node_ids)

    false_green = cases["shared-global-negative-pollution"]
    assert false_green["independent_full_oracle"]["overall_status"] == "failed"
    assert false_green["diagnostic_combined_outcome"]["overall_status"] == "passed"
    assert false_green["independent_full_oracle"]["node_outcomes"][
        "test_lifecycle.py::test_10_victim"
    ] == "failed"
    assert false_green["diagnostic_combined_outcome"]["node_outcomes"][
        "test_lifecycle.py::test_10_victim"
    ] == "passed"
    assert false_green["diagnostic_prior_pass_basis"]["status"] == (
        "DIAGNOSTIC_PARTIAL_NODE_OBSERVATION_FROM_FAILING_FULL_SUITE"
    )
    assert false_green["diagnostic_prior_pass_basis"][
        "source_capture_overall_status"
    ] == "failed"
    assert "not evidence that ZeroRun" in false_green[
        "diagnostic_prior_pass_basis"
    ]["interpretation"]

    session = cases["session-fixture-finalizer"]
    assert "session:finalizer:set:0" in session["independent_full_oracle"][
        "effect_artifacts"
    ]["effects.log"]["text"]
    assert session["residual_selector_observation"]["effect_artifacts"][
        "effects.log"
    ]["text"].splitlines() == ["observer:seen:0"]
    assert session["lifecycle_preserving_call_only_observation"][
        "result_only_matches_oracle"
    ] is True
    assert session["lifecycle_preserving_call_only_observation"][
        "observable_effects_match_oracle"
    ] is False

    function_fixture = cases["function-fixture-teardown"]
    assert function_fixture["lifecycle_preserving_call_only_observation"][
        "result_only_matches_oracle"
    ] is True
    assert "fixture:teardown:set:1" in function_fixture[
        "lifecycle_preserving_call_only_observation"
    ]["effect_artifacts"]["effects.log"]["text"]

    fixture_pure_call = cases["function-fixture-pure-call"]
    expected_fixture_effects = [
        "fixture:setup",
        "fixture:teardown:set:1",
        "observer:seen:1",
    ]
    assert fixture_pure_call["classification"] == "false_negative"
    assert fixture_pure_call["residual_selector_observation"]["effect_artifacts"][
        "effects.log"
    ]["text"].splitlines() == ["observer:seen:0"]
    assert fixture_pure_call["independent_full_oracle"]["effect_artifacts"][
        "effects.log"
    ]["text"].splitlines() == expected_fixture_effects
    assert fixture_pure_call["lifecycle_preserving_call_only_observation"][
        "result_only_matches_oracle"
    ] is True
    assert fixture_pure_call["lifecycle_preserving_call_only_observation"][
        "observable_effects_match_oracle"
    ] is True
    assert fixture_pure_call["lifecycle_preserving_call_only_observation"][
        "effect_artifacts"
    ]["effects.log"]["text"].splitlines() == expected_fixture_effects

    hook = cases["pytest-hook-observes-omitted-call"]
    assert hook["result_only_matches_oracle"] is True
    assert hook["observable_effects_match_oracle"] is False
    assert hook["independent_full_oracle"]["effect_artifacts"]["effects.log"][
        "text"
    ].count("hook:call:") == 2
    assert hook["residual_selector_observation"]["effect_artifacts"][
        "effects.log"
    ]["text"].count("hook:call:") == 1
    assert hook["lifecycle_preserving_call_only_observation"][
        "observable_effects_match_oracle"
    ] is True

    external = cases["external-plugin-callback"]
    assert any(
        row["location"] == "external/lifecycle_external_plugin.py"
        for row in external["fixture_manifest"]["files"]
    )
    assert external["independent_full_oracle"]["effect_artifacts"][
        "external.marker"
    ]["text"] == "armed"
    assert external["residual_selector_observation"]["effect_artifacts"][
        "external.marker"
    ]["exists"] is False
    assert external["lifecycle_preserving_call_only_observation"][
        "result_only_matches_oracle"
    ] is True
    assert external["lifecycle_preserving_call_only_observation"][
        "observable_effects_match_oracle"
    ] is True

    control = cases["independent-pure-control"]
    assert control["result_only_matches_oracle"] is True
    assert control["observable_effects_match_oracle"] is True
    assert control["classification"] == "independent_control_match"

    assert not list(output.rglob(".zerorun*"))


def test_existing_output_is_refused_before_pytest_execution(tmp_path: Path) -> None:
    output = tmp_path / "existing"
    output.mkdir()

    with pytest.raises(LifecycleChallengeError, match="output already exists"):
        run_campaign(output)


def test_campaign_preserves_virtualenv_interpreter_entrypoint(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    from research.phases import lifecycle_challenges as module

    interpreter = tmp_path / "venv" / "bin" / "python"
    interpreter.parent.mkdir(parents=True)
    interpreter.write_bytes(b"interpreter fixture")
    observed = []

    def stop_after_observing(scenario, **kwargs):
        observed.append(kwargs["python_executable"])
        raise RuntimeError("entrypoint captured")

    def forbid_symlink_resolution(self, *args, **kwargs):
        if self == interpreter:
            pytest.fail("the venv interpreter entrypoint must not be dereferenced")
        return original_resolve(self, *args, **kwargs)

    original_resolve = Path.resolve
    monkeypatch.setattr(Path, "resolve", forbid_symlink_resolution)
    monkeypatch.setattr(module, "_run_scenario", stop_after_observing)
    with pytest.raises(RuntimeError, match="entrypoint captured"):
        run_campaign(tmp_path / "entrypoint-campaign", python_executable=interpreter)
    assert observed == [interpreter.absolute()]


def test_git_state_records_missing_git_without_faking_metadata(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def missing_git(*args: object, **kwargs: object) -> object:
        raise FileNotFoundError("git executable unavailable")

    monkeypatch.setattr(
        "research.phases.lifecycle_challenges.subprocess.run", missing_git
    )

    state = _git_state()

    assert state["head"] is None
    assert state["working_tree_clean_before_campaign_summary"] is None
    assert state["status_observation_available"] is False
    reasons = state["metadata_unavailable_reasons"]
    assert len(reasons) == 2
    assert all("FileNotFoundError: git executable unavailable" in row for row in reasons)
    assert reasons[0].startswith("git rev-parse HEAD:")
    assert reasons[1].startswith("git status --porcelain=v1 --untracked-files=all:")
