from __future__ import annotations

import json
from pathlib import Path
import tempfile

import tools.pytest_zero_miss_cache as zero_miss
from tools.pytest_collection_cache import (
    collection_action_fingerprint,
    save_collection_contract,
)
from tools.pytest_node_cache import (
    NodeCacheContext,
    prepare_node_cache,
    publish_verified_successes,
    verify_node_cache_snapshot,
)
from tools.pytest_zero_miss_cache import try_reuse_zero_miss_partition
from zerorun.model import TaskSpec


_HEX_A = "a" * 64
_HEX_B = "b" * 64
_HEX_C = "c" * 64
_PROFILE_SHA256 = "9" * 64


def _project() -> tuple[tempfile.TemporaryDirectory, Path]:
    temporary = tempfile.TemporaryDirectory()
    root = Path(temporary.name)
    testing = root / "testing"
    testing.mkdir(parents=True)
    (testing / "test_example.py").write_text(
        "def test_one():\n    assert True\n",
        encoding="utf-8",
    )
    (testing / "conftest.py").write_text("STATIC = 1\n", encoding="utf-8")
    package = root / "src" / "_pytest"
    package.mkdir(parents=True)
    (package / "example.py").write_text(
        "VALUE = 1\n\ndef helper():\n    return VALUE\n",
        encoding="utf-8",
    )
    (package / "session.py").write_text(
        "SESSION = 1\n\ndef session_helper():\n    return SESSION\n",
        encoding="utf-8",
    )
    _write_manifest(root)
    return temporary, root


def _task() -> TaskSpec:
    return TaskSpec(
        name="terminal-core",
        command=("bash", "-c", "python -m pytest testing/test_example.py"),
        inputs=("testing/test_example.py", "testing/conftest.py"),
        outputs=(),
        env=(),
        cacheable=True,
        unsafe_effects=(),
        cache_streams=False,
        image="example.invalid/pytest@sha256:" + "d" * 64,
        platform="linux/amd64",
        result_only=True,
        closure_reviewed=True,
    )


def _write_manifest(root: Path) -> None:
    task = _task()
    payload = {
        "version": 2,
        "tasks": {
            task.name: {
                "command": list(task.command),
                "inputs": list(task.inputs),
                "outputs": list(task.outputs),
                "env": list(task.env),
                "cacheable": task.cacheable,
                "unsafe_effects": list(task.unsafe_effects),
                "cache_streams": task.cache_streams,
                "image": task.image,
                "platform": task.platform,
                "result_only": task.result_only,
                "closure_reviewed": task.closure_reviewed,
            }
        },
    }
    (root / ".zerorun.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _contract() -> dict[str, object]:
    return {
        "contract_sha256": _HEX_A,
        "nodeids": ["testing/test_example.py::test_one"],
        "items": [
            {
                "nodeid": "testing/test_example.py::test_one",
                "identity_sha256": _HEX_B,
                "parameter_identity_supported": True,
            }
        ],
    }


def _node_rows() -> list[dict[str, object]]:
    return [
        {
            "nodeid": "testing/test_example.py::test_one",
            "reviewable": True,
            "fresh_required": False,
            "selectors": [
                "src/_pytest/example.py::@binding:VALUE",
                "src/_pytest/example.py::helper",
            ],
            "fallback_files": [],
        }
    ]


def _session_closure() -> dict[str, object]:
    return {
        "reviewable": True,
        "fresh_required": False,
        "selectors": [
            "src/_pytest/session.py::@binding:SESSION",
            "src/_pytest/session.py::session_helper",
        ],
        "fallback_files": [],
    }


def _runtime() -> dict[str, object]:
    return {"resolved_image": "sha256:" + "e" * 64}


def _seed(root: Path) -> None:
    key, fingerprint = collection_action_fingerprint(
        root,
        _task(),
        expected_contract=_contract(),
        session_closure=_session_closure(),
        runtime_identity=_runtime(),
        environment_fingerprint={},
        collection_review_sha256=_HEX_B,
    )
    save_collection_contract(root, key, fingerprint, _contract())
    context = NodeCacheContext(
        runtime_identity=_runtime(),
        environment_fingerprint={},
        collection_contract_sha256=_HEX_A,
        independence_review_sha256=_HEX_C,
        profile_sha256=_PROFILE_SHA256,
    )
    initial = prepare_node_cache(
        root,
        _task(),
        node_rows=_node_rows(),
        session_closure=_session_closure(),
        collection_items=_contract()["items"],
        context=context,
    )
    verified = verify_node_cache_snapshot(
        root,
        _task(),
        decisions=initial,
        node_rows=_node_rows(),
        session_closure=_session_closure(),
        collection_items=_contract()["items"],
        final_context=context,
    )
    assert publish_verified_successes(
        root,
        verified,
        successful_nodeids={"testing/test_example.py::test_one"},
    ) == 1


def _reuse(root: Path):
    return try_reuse_zero_miss_partition(
        root,
        _task(),
        node_rows=_node_rows(),
        session_closure=_session_closure(),
        expected_collection_contract=_contract(),
        runtime_identity=_runtime(),
        environment_fingerprint={},
        collection_review_sha256=_HEX_B,
        independence_review_sha256=_HEX_C,
        profile_sha256=_PROFILE_SHA256,
    )


def test_exact_collection_and_final_node_snapshot_authorize_zero_miss_reuse() -> None:
    temporary, root = _project()
    try:
        _seed(root)
        decision = _reuse(root)
        assert decision.reusable is True
        assert decision.status == "HIT_REUSED"
        assert [row.status for row in decision.node_decisions] == ["HIT_REUSED"]
    finally:
        temporary.cleanup()


def test_missing_collection_cache_falls_back_fresh() -> None:
    temporary, root = _project()
    try:
        decision = _reuse(root)
        assert decision.reusable is False
        assert decision.status == "MISS_COLLECTION"
    finally:
        temporary.cleanup()


def test_selected_source_change_blocks_zero_miss_even_when_collection_still_hits() -> None:
    temporary, root = _project()
    try:
        _seed(root)
        source = root / "src" / "_pytest" / "example.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace("VALUE = 1", "VALUE = 2"),
            encoding="utf-8",
        )
        decision = _reuse(root)
        assert decision.reusable is False
        assert decision.status == "MISS_NODE"
    finally:
        temporary.cleanup()


def test_test_source_change_invalidates_collection_cache_before_node_reuse() -> None:
    temporary, root = _project()
    try:
        _seed(root)
        test_source = root / "testing" / "test_example.py"
        test_source.write_text("def test_one():\n    assert 1 == 1\n", encoding="utf-8")
        decision = _reuse(root)
        assert decision.reusable is False
        assert decision.status == "MISS_COLLECTION"
    finally:
        temporary.cleanup()


def test_incomplete_reviewed_node_coverage_fails_closed() -> None:
    temporary, root = _project()
    try:
        _seed(root)
        decision = try_reuse_zero_miss_partition(
            root,
            _task(),
            node_rows=[],
            session_closure=_session_closure(),
            expected_collection_contract=_contract(),
            runtime_identity=_runtime(),
            environment_fingerprint={},
            collection_review_sha256=_HEX_B,
            independence_review_sha256=_HEX_C,
            profile_sha256=_PROFILE_SHA256,
        )
        assert decision.reusable is False
        assert decision.status == "MISS_UNCERTAIN"
    finally:
        temporary.cleanup()


def test_collection_identity_race_rejects_provisional_hits(monkeypatch) -> None:
    temporary, root = _project()
    try:
        _seed(root)
        original = zero_miss.collection_action_fingerprint
        calls = {"count": 0}

        def changing_fingerprint(*args, **kwargs):
            calls["count"] += 1
            key, payload = original(*args, **kwargs)
            if calls["count"] == 2:
                changed = dict(payload)
                changed["collection_plugin_sha256"] = "f" * 64
                return "f" * 64, changed
            return key, payload

        monkeypatch.setattr(zero_miss, "collection_action_fingerprint", changing_fingerprint)
        decision = _reuse(root)
        assert decision.reusable is False
        assert decision.status == "REJECTED_INPUT_RACE"
    finally:
        temporary.cleanup()
