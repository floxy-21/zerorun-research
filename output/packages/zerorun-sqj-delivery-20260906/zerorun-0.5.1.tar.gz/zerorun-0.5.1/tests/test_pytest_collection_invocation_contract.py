from __future__ import annotations

import pytest

from zerorun.model import ConfigurationError
from zerorun.pytest_collection_contract import (
    validate_collection_invocation_contract,
)


def _invocation(*addopts: str) -> dict[str, object]:
    return {
        "rootpath": ".",
        "args": ["tests"],
        "pyargs": False,
        "addopts": list(addopts),
    }


@pytest.mark.parametrize(
    "addopts",
    [
        ("-p", "no:logging"),
        ("-p", "no:cacheprovider"),
        ("-p", "no:vendor.plugin_v2"),
        (
            "--strict-markers",
            "-p",
            "no:logging",
            "-p",
            "no:cacheprovider",
        ),
        ("-p", "no:logging", "-p", "no:logging"),
    ],
)
def test_collection_contract_accepts_only_exact_negative_plugin_tokens(
    addopts: tuple[str, ...],
) -> None:
    invocation = _invocation(*addopts)

    assert (
        validate_collection_invocation_contract(
            invocation,
            expected_targets=("tests",),
            field="test collection invocation",
        )
        is invocation
    )


@pytest.mark.parametrize(
    "addopts",
    [
        ("-p",),
        ("-p", "logging"),
        ("-plogging",),
        ("-pno:logging",),
        ("-p=no:logging",),
        ("--plugins", "no:logging"),
        ("--plugins=no:logging",),
        ("--plugins-prefix-trick=no:logging",),
        ("-p", "no:"),
        ("-p", "no:.logging"),
        ("-p", "no:logging."),
        ("-p", "no:logging..capture"),
        ("-p", "no:pytest-cov"),
        ("-p", "no:9plugin"),
        ("-p", "no:logging:extra"),
        ("-p", "no:naïve"),
        ("-p", "no:vendor/plugin"),
        ("-p", "no: logging"),
        ("-p", "no:logging\n"),
        ("-p", "no:zerorun_qualify_plugin"),
        ("-p", "no:zerorun_collection_plugin"),
        ("-p", "no:zerorun_single_pass_plugin"),
        ("-p", "no:pytest_zerorun_qualify_plugin"),
        ("-p", "no:pytest_zerorun_collection_plugin"),
        ("-p", "no:pytest_zerorun_single_pass_plugin"),
        ("-p", "no:zerorun-qualify-plugin"),
        ("-p", "no:zerorun-collection-plugin"),
        ("-p", "no:zerorun-single-pass-plugin"),
    ],
)
def test_collection_contract_rejects_plugin_loads_ambiguity_and_evidence_disables(
    addopts: tuple[str, ...],
) -> None:
    with pytest.raises(ConfigurationError, match="unreviewed pytest plugin"):
        validate_collection_invocation_contract(
            _invocation(*addopts),
            expected_targets=("tests",),
            field="test collection invocation",
        )


def test_collection_contract_rejects_oversized_negative_plugin_name() -> None:
    with pytest.raises(ConfigurationError, match="invalid or oversized token"):
        validate_collection_invocation_contract(
            _invocation("-p", "no:" + "a" * 8192),
            expected_targets=("tests",),
            field="test collection invocation",
        )
