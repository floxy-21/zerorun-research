from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import pytest

from zerorun import trust
from zerorun.hermetic_store import _load_result_entry, _save_result_entry
from zerorun.model import ConfigurationError, TaskSpec
from zerorun.store import Store


PROFILE_DIGEST = "9" * 64


def _root(tmp_path: Path) -> Path:
    root = tmp_path / "repository"
    root.mkdir()
    (root / ".zerorun.json").write_text(
        '{"tasks":{},"version":2}\n',
        encoding="utf-8",
    )
    return root


def _task(nodeid: str) -> TaskSpec:
    suffix = hashlib.sha256(nodeid.encode("utf-8")).hexdigest()[:24]
    return TaskSpec(
        name=f"pytest::pytest-node::{suffix}",
        command=("python", "-m", "pytest"),
        inputs=(),
        outputs=(),
        env=(),
        cacheable=True,
        unsafe_effects=(),
        cache_streams=False,
        image="python@sha256:" + "d" * 64,
        platform="linux/amd64",
        result_only=True,
        closure_reviewed=True,
    )


def _fingerprint(nodeid: str, *, padding: str | None = None) -> dict:
    task = _task(nodeid)
    payload = {
        "schema": 6,
        "kind": "hermetic-result-only",
        "task": task.name,
        "nodeid": nodeid,
        "profile_sha256": PROFILE_DIGEST,
        "runtime_identity": {
            "resolved_image": "sha256:" + "a" * 64,
            "python_version": "3.12.14",
        },
        "collection": {"identity_sha256": "b" * 64},
    }
    if padding is not None:
        payload["diagnostic_padding"] = padding
    return payload


def _key(fingerprint: dict) -> str:
    return hashlib.sha256(
        json.dumps(
            fingerprint,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()


def _publish(root: Path, nodeid: str = "tests/test_one.py::test_one"):
    task = _task(nodeid)
    fingerprint = _fingerprint(nodeid)
    key = _key(fingerprint)
    metadata = _save_result_entry(
        Store(root),
        task,
        key,
        fingerprint,
        execution_ms=12.5,
    )
    return task, key, fingerprint, metadata


def _resign(root: Path, metadata: dict, *, profile: str = PROFILE_DIGEST) -> dict:
    manifest_digest = trust.manifest_sha256_for_root(root)
    session = trust.CacheTrustSession.open(
        root,
        manifest_digest=manifest_digest,
        profile_digest=profile,
    )
    unsigned = dict(metadata)
    unsigned.pop("provenance", None)
    signed = {
        **unsigned,
        "provenance": session.sign_payload(
            unsigned,
            manifest_digest=manifest_digest,
            profile_digest=profile,
        ),
    }
    session.verify_unchanged()
    return signed


def _write_metadata(store: Store, key: str, metadata: dict) -> None:
    (store.entry(key) / "metadata.json").write_text(
        json.dumps(metadata, sort_keys=True),
        encoding="utf-8",
    )


def test_schema_six_publication_is_compact_and_round_trips(tmp_path: Path) -> None:
    root = _root(tmp_path)
    task, key, fingerprint, metadata = _publish(root)
    assert metadata["storage_schema"] == 1
    assert metadata["fingerprint_sha256"] == key
    assert metadata["nodeid"] == fingerprint["nodeid"]
    assert metadata["profile_sha256"] == PROFILE_DIGEST
    assert "fingerprint" not in metadata
    assert len((Store(root).entry(key) / "metadata.json").read_bytes()) < 2_000

    loaded = _load_result_entry(Store(root), task, key, fingerprint)
    assert loaded is not None
    assert loaded["execution_ms"] == 12.5


def test_compact_metadata_rejects_tamper_and_key_path_swap(tmp_path: Path) -> None:
    root = _root(tmp_path)
    store = Store(root)
    task_a, key_a, fingerprint_a, metadata_a = _publish(
        root, "tests/test_one.py::test_a"
    )
    task_b, key_b, fingerprint_b, _ = _publish(
        root, "tests/test_one.py::test_b"
    )

    tampered = {**metadata_a, "execution_ms": 999.0}
    _write_metadata(store, key_a, tampered)
    assert _load_result_entry(store, task_a, key_a, fingerprint_a) is None
    assert (store.entry(key_a) / "QUARANTINED").is_file()

    # A valid signed record copied beneath a different key path remains bound
    # to A and cannot authorize B.
    _write_metadata(store, key_b, metadata_a)
    assert _load_result_entry(store, task_b, key_b, fingerprint_b) is None
    assert (store.entry(key_b) / "QUARANTINED").is_file()


def test_wrong_recomputed_fingerprint_cannot_quarantine_valid_entry(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    store = Store(root)
    task, key, fingerprint, _ = _publish(root)
    changed = {
        **fingerprint,
        "runtime_identity": {
            **fingerprint["runtime_identity"],
            "python_version": "3.12.15",
        },
    }
    assert _key(changed) != key
    assert _load_result_entry(store, task, key, changed) is None
    assert not (store.entry(key) / "QUARANTINED").exists()
    assert _load_result_entry(store, task, key, fingerprint) is not None


@pytest.mark.parametrize(
    "shape",
    ["downgrade", "hybrid", "unknown", "bool_storage", "bool_exit"],
)
def test_signed_noncanonical_compact_shapes_are_rejected(
    tmp_path: Path,
    shape: str,
) -> None:
    root = _root(tmp_path)
    store = Store(root)
    task, key, fingerprint, metadata = _publish(root)
    malformed = dict(metadata)
    if shape == "downgrade":
        malformed["storage_schema"] = 0
    elif shape == "hybrid":
        malformed["fingerprint"] = fingerprint
    elif shape == "bool_storage":
        malformed["storage_schema"] = True
    elif shape == "bool_exit":
        malformed["exit_code"] = False
    else:
        malformed["unrecognized"] = True
    malformed = _resign(root, malformed)
    _write_metadata(store, key, malformed)

    assert _load_result_entry(store, task, key, fingerprint) is None
    assert (store.entry(key) / "QUARANTINED").is_file()


def test_duplicate_compact_member_is_rejected_before_trust(tmp_path: Path) -> None:
    root = _root(tmp_path)
    store = Store(root)
    task, key, fingerprint, _ = _publish(root)
    path = store.entry(key) / "metadata.json"
    raw = path.read_text(encoding="utf-8")
    path.write_text(raw.replace('"schema": 6,', '"schema": 6, "schema": 6,'), encoding="utf-8")
    assert _load_result_entry(store, task, key, fingerprint) is None


def test_large_fingerprint_does_not_expand_compact_metadata(tmp_path: Path) -> None:
    root = _root(tmp_path)
    nodeid = "tests/test_one.py::test_large"
    task = _task(nodeid)
    fingerprint = _fingerprint(nodeid, padding="x" * 1_000_000)
    key = _key(fingerprint)
    _save_result_entry(
        Store(root),
        task,
        key,
        fingerprint,
        execution_ms=1.0,
    )
    assert len((Store(root).entry(key) / "metadata.json").read_bytes()) < 2_000


@pytest.mark.parametrize("execution_ms", [-1.0, math.inf, math.nan, True])
def test_compact_publication_rejects_noncanonical_execution_time(
    tmp_path: Path,
    execution_ms: object,
) -> None:
    root = _root(tmp_path)
    nodeid = "tests/test_one.py::test_time"
    task = _task(nodeid)
    fingerprint = _fingerprint(nodeid)
    with pytest.raises(ConfigurationError, match="finite and nonnegative"):
        _save_result_entry(
            Store(root),
            task,
            _key(fingerprint),
            fingerprint,
            execution_ms=execution_ms,
        )


def test_compact_publication_bounds_nodeid(tmp_path: Path) -> None:
    root = _root(tmp_path)
    nodeid = "x" * 8_193
    task = _task(nodeid)
    fingerprint = _fingerprint(nodeid)
    with pytest.raises(ConfigurationError, match="node id is malformed"):
        _save_result_entry(
            Store(root),
            task,
            _key(fingerprint),
            fingerprint,
            execution_ms=1.0,
        )


def test_legacy_full_fingerprint_entry_remains_read_only_compatible(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    store = Store(root)
    nodeid = "tests/test_one.py::test_legacy"
    task = _task(nodeid)
    fingerprint = _fingerprint(nodeid)
    key = _key(fingerprint)
    unsigned = {
        "schema": 6,
        "kind": "hermetic-result-only",
        "task": task.name,
        "key": key,
        "created_at": 1.0,
        "execution_ms": 2.0,
        "fingerprint": fingerprint,
        "exit_code": 0,
    }
    legacy = _resign(root, unsigned)
    entry = store.entry(key)
    entry.mkdir(parents=True)
    _write_metadata(store, key, legacy)

    loaded = _load_result_entry(store, task, key, fingerprint)
    assert loaded is not None
    assert loaded["fingerprint"] == fingerprint
    assert "storage_schema" not in loaded


def test_signed_legacy_boolean_exit_code_is_rejected(tmp_path: Path) -> None:
    root = _root(tmp_path)
    store = Store(root)
    nodeid = "tests/test_one.py::test_legacy_bool_exit"
    task = _task(nodeid)
    fingerprint = _fingerprint(nodeid)
    key = _key(fingerprint)
    malformed = _resign(
        root,
        {
            "schema": 6,
            "kind": "hermetic-result-only",
            "task": task.name,
            "key": key,
            "created_at": 1.0,
            "execution_ms": 2.0,
            "fingerprint": fingerprint,
            "exit_code": False,
        },
    )
    entry = store.entry(key)
    entry.mkdir(parents=True)
    _write_metadata(store, key, malformed)

    assert _load_result_entry(store, task, key, fingerprint) is None
    assert (entry / "QUARANTINED").is_file()


def test_compact_lookup_remains_provisional_until_trust_session_closes(
    tmp_path: Path,
) -> None:
    root = _root(tmp_path)
    task, key, fingerprint, _ = _publish(root)
    manifest_digest = trust.manifest_sha256_for_root(root)
    session = trust.CacheTrustSession.open(
        root,
        manifest_digest=manifest_digest,
        profile_digest=PROFILE_DIGEST,
    )
    assert _load_result_entry(
        Store(root),
        task,
        key,
        fingerprint,
        trust_session=session,
    ) is not None
    secret_path = trust._secret_path(root)
    original_secret = secret_path.read_bytes()
    replacement = bytes([original_secret[0] ^ 0xFF]) + original_secret[1:]
    secret_path.write_bytes(replacement)
    with pytest.raises(ConfigurationError, match="authority key changed"):
        session.verify_unchanged()
