from __future__ import annotations

import json
from pathlib import Path

import pytest

from tools import strict_performance_gate as gate


_pytest_gate = gate._pytest_gate


PRS = [8749, 9624, 9628, 9875, 9915, 9933, 10051, 10081, 10088, 10190]


def _incremental_report() -> dict:
    cases = []
    for pr in PRS:
        cases.append(
            {
                "pass": True,
                "case": {"pr": pr},
                "direct": [{"exit_code": 0}],
                "execution": {"pass": True},
                "safety": {
                    "post_edit_direct_control_passed": True,
                    "added_changed_unsupported_nodes_execute_fresh": True,
                    "removed_nodes_are_not_requested": True,
                    "retained_order_change_fails_closed_when_collection_executes": True,
                    "session_or_static_collection_change_runs_partition_fresh": True,
                    "enabled_plugin_or_target_change_blocks_zero_miss_elision": True,
                    "zero_miss_elision_requires_exact_source_reuse_and_supported_baseline_identity": True,
                    "zero_miss_guard_cost_is_inside_candidate_timing": True,
                    "collection_and_miss_execution_share_one_pytest_process_per_executed_partition": True,
                },
            }
        )
    return {
        "pass": True,
        "measurement_valid": True,
        "strict_gate_projection_pass": True,
        "release_gate": False,
        "cases": cases,
        "summary": {
            "case_count": 10,
            "candidate_compute_multiple": 8.830591,
            "candidate_p95_reduction_percent": 83.907,
        },
    }


def test_incremental_schema_passes_without_inventing_release_authorization():
    result = _pytest_gate(_incremental_report())

    assert result["pass"] is True
    assert result["evidence_schema"] == "pytest-incremental-qualification-v0.4"
    assert result["same_runner_compute_efficiency"] == 8.830591
    assert result["p95_reduction_percent"] == 83.907
    assert result["release_gate_authorized"] is False
    assert "cache_conflicts" not in result


def test_incremental_schema_fails_closed_when_case_safety_is_missing():
    report = _incremental_report()
    report["cases"][0]["safety"] = {}

    result = _pytest_gate(report)

    assert result["pass"] is False
    assert result["checks"]["case_evidence_complete"] is False
    assert result["checks"]["all_fail_closed_case_safety_invariants_passed"] is False


@pytest.mark.parametrize("mutation", ["one-key", "missing-key", "extra-key", "false"])
def test_incremental_schema_requires_exact_complete_true_safety_map(
    mutation: str,
) -> None:
    report = _incremental_report()
    safety = report["cases"][0]["safety"]
    if mutation == "one-key":
        report["cases"][0]["safety"] = {
            "post_edit_direct_control_passed": True
        }
    elif mutation == "missing-key":
        safety.pop("removed_nodes_are_not_requested")
    elif mutation == "extra-key":
        safety["unreviewed_invariant"] = True
    else:
        safety["removed_nodes_are_not_requested"] = False

    result = _pytest_gate(report)

    assert result["pass"] is False
    assert result["checks"]["all_fail_closed_case_safety_invariants_passed"] is False


def test_incremental_schema_rejects_boolean_direct_exit_code() -> None:
    report = _incremental_report()
    report["cases"][0]["direct"][0]["exit_code"] = False

    result = _pytest_gate(report)

    assert result["pass"] is False
    assert result["checks"]["all_post_edit_direct_controls_passed"] is False


def test_legacy_schema_is_still_supported():
    report = {
        "pass": True,
        "summary": {
            "p95_reduction_percent": 70.0,
            "same_runner_compute_cost_multiple": 6.0,
            "stale_success_events": 0,
            "shadow_mismatches": 0,
            "cache_conflicts": 0,
            "request_failures": 0,
        },
    }

    result = _pytest_gate(report)

    assert result["pass"] is True
    assert result["evidence_schema"] == "legacy-pytest-release-report"


def _legacy_report() -> dict:
    return {
        "pass": True,
        "summary": {
            "p95_reduction_percent": 70.0,
            "same_runner_compute_cost_multiple": 6.0,
            "stale_success_events": 0,
            "shadow_mismatches": 0,
            "cache_conflicts": 0,
            "request_failures": 0,
        },
    }


@pytest.mark.parametrize("kind", ["incremental", "legacy"])
@pytest.mark.parametrize(
    "invalid", [True, "100", float("nan"), float("inf"), -float("inf")]
)
@pytest.mark.parametrize("metric", ["compute", "p95"])
def test_pytest_gate_rejects_nonfinite_bool_and_string_metrics(
    kind: str,
    invalid: object,
    metric: str,
) -> None:
    report = _incremental_report() if kind == "incremental" else _legacy_report()
    if kind == "incremental":
        field = (
            "candidate_compute_multiple"
            if metric == "compute"
            else "candidate_p95_reduction_percent"
        )
    else:
        field = (
            "same_runner_compute_cost_multiple"
            if metric == "compute"
            else "p95_reduction_percent"
        )
    report["summary"][field] = invalid

    with pytest.raises(gate.GateInputError, match="finite JSON number"):
        _pytest_gate(report)


@pytest.mark.parametrize(
    ("kind", "field", "invalid"),
    [
        ("incremental", "case_count", True),
        ("incremental", "case_count", "10"),
        ("legacy", "request_failures", False),
        ("legacy", "request_failures", "0"),
    ],
)
def test_pytest_gate_rejects_bool_and_string_integer_counts(
    kind: str,
    field: str,
    invalid: object,
) -> None:
    report = _incremental_report() if kind == "incremental" else _legacy_report()
    report["summary"][field] = invalid

    with pytest.raises(gate.GateInputError, match="JSON integer"):
        _pytest_gate(report)


@pytest.mark.parametrize(
    ("raw", "message"),
    [
        (b'{"summary":{},"summary":{}}', "duplicate JSON member"),
        (b"[" * 65 + b"0" + b"]" * 65, "JSON depth limit"),
        (b'{"summary":{"p95_reduction_percent":Infinity}}', "non-finite JSON"),
    ],
)
def test_report_loader_rejects_ambiguous_or_unbounded_json(
    tmp_path: Path,
    raw: bytes,
    message: str,
) -> None:
    path = tmp_path / "report.json"
    path.write_bytes(raw)

    with pytest.raises(gate.GateInputError, match=message):
        gate._load(path)


def test_report_loader_rejects_oversized_file_before_parsing(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    path = tmp_path / "oversized.json"
    path.write_bytes(b"{" + (b" " * 64) + b"}")
    monkeypatch.setattr(gate, "MAX_REPORT_BYTES", 64)

    with pytest.raises(gate.GateInputError, match="size or identity"):
        gate._load(path)


def _sympy_report() -> dict:
    cases = []
    for pr, base_sha, head_sha, area in gate._SYMPY_CASES:
        direct = [{"exit_code": 0} for _ in gate._SYMPY_PARTITIONS]
        zerorun = [
            {"exit_code": 0, "status": "HIT_REUSED"}
            for _ in gate._SYMPY_PARTITIONS
        ]
        shadow = [{"match": True} for _ in gate._SYMPY_PARTITIONS]
        cases.append(
            {
                "pr": pr,
                "area": area,
                "base_sha": base_sha,
                "head_sha": head_sha,
                "patch_sha256": "a" * 64,
                "partitions": list(gate._SYMPY_PARTITIONS),
                "direct": direct,
                "zerorun": zerorun,
                "shadow_oracle": shadow,
                "timing": {"direct_wall_ms": 100.0, "zerorun_wall_ms": 10.0},
                "hits": len(gate._SYMPY_PARTITIONS),
                "shadow_mismatches": 0,
            }
        )
    prs = [identity[0] for identity in gate._SYMPY_CASES]
    return {
        "schema": 1,
        "experiment": gate._SYMPY_EXPERIMENT,
        "repository": gate._SYMPY_REPOSITORY,
        "image": gate._SYMPY_IMAGE,
        "platform": "linux/amd64",
        "partitions": list(gate._SYMPY_PARTITIONS),
        "source_files": ["shard.json"],
        "errors": [],
        "corpus": {
            "expected_prs": prs,
            "actual_prs": prs,
            "missing_prs": [],
            "unexpected_prs": [],
            "duplicate_prs": [],
        },
        "summary": {
            "distinct_real_patches": 20,
            "patch_loops": 20,
            "direct_p95_ms": 100.0,
            "zerorun_p95_ms": 10.0,
            "p95_reduction_percent": 90.0,
            "total_hits_after_edits": 80,
            "shadow_mismatches": 0,
            "cache_conflicts": 0,
            "direct_failures": 0,
            "zerorun_failures": 0,
        },
        "proof_gates": {},
        "cases": cases,
        "pass": True,
    }


def test_sympy_gate_replays_exact_frozen_corpus_and_raw_p95() -> None:
    result = gate._sympy_gate(_sympy_report())

    assert result["pass"] is True
    assert result["case_count"] == 20
    assert result["frozen_corpus_sha256"] == gate._SYMPY_CORPUS_SHA256
    assert result["same_runner_compute_efficiency"] == 10.0
    assert result["p95_reduction_percent"] == 90.0


@pytest.mark.parametrize("mutation", ["reduced", "duplicate", "reordered"])
def test_sympy_gate_rejects_denominator_drift(mutation: str) -> None:
    report = _sympy_report()
    if mutation == "reduced":
        report["cases"].pop()
    elif mutation == "duplicate":
        report["cases"][-1] = report["cases"][0]
    else:
        report["cases"].reverse()

    with pytest.raises(gate.GateInputError, match="20-patch|identity"):
        gate._sympy_gate(report)


def test_sympy_gate_rejects_forged_summary_p95() -> None:
    report = _sympy_report()
    report["summary"]["p95_reduction_percent"] = 99.0

    with pytest.raises(gate.GateInputError, match="does not replay"):
        gate._sympy_gate(report)


@pytest.mark.parametrize("invalid", [True, "100", float("nan"), float("inf")])
def test_sympy_gate_rejects_invalid_raw_case_timing(invalid: object) -> None:
    report = _sympy_report()
    report["cases"][0]["timing"]["direct_wall_ms"] = invalid

    with pytest.raises(gate.GateInputError, match="finite JSON number"):
        gate._sympy_gate(report)


def test_sympy_gate_rejects_boolean_result_exit_code() -> None:
    report = _sympy_report()
    report["cases"][0]["direct"][0]["exit_code"] = False

    with pytest.raises(gate.GateInputError, match="malformed exit code"):
        gate._sympy_gate(report)


def test_sympy_gate_retains_raw_failures_in_gate_result() -> None:
    report = _sympy_report()
    report["cases"][0]["direct"][0]["exit_code"] = 1
    report["summary"]["direct_failures"] = 1

    result = gate._sympy_gate(report)

    assert result["direct_total_ms"] == 2000.0
    assert result["checks"]["zero_direct_failures"] is False
    assert result["pass"] is False


def test_sympy_gate_rejects_aggregate_timing_overflow() -> None:
    report = _sympy_report()
    for case in report["cases"]:
        case["timing"]["direct_wall_ms"] = 1e308

    with pytest.raises(gate.GateInputError, match="aggregate timing is not finite"):
        gate._sympy_gate(report)


def test_sympy_gate_rejects_changed_frozen_identity() -> None:
    report = _sympy_report()
    report["cases"][0]["base_sha"] = "0" * 40

    with pytest.raises(gate.GateInputError, match="frozen identity"):
        gate._sympy_gate(report)


def test_sympy_gate_rejects_nonfinite_summary_metric() -> None:
    report = _sympy_report()
    report["summary"]["p95_reduction_percent"] = float("inf")

    with pytest.raises(gate.GateInputError, match="finite JSON number"):
        gate._sympy_gate(report)


def _legacy_sympy_shape_only() -> dict:
    return {
        "pass": True,
        "summary": {
            "p95_reduction_percent": 60.0,
            "shadow_mismatches": 0,
            "cache_conflicts": 0,
            "direct_failures": 0,
            "zerorun_failures": 0,
        },
        "cases": [
            {"timing": {"direct_wall_ms": 100.0, "zerorun_wall_ms": 1.0}}
        ],
    }


def test_sympy_gate_rejects_legacy_shape_without_frozen_denominator() -> None:
    with pytest.raises(gate.GateInputError, match="frozen 20-patch contract"):
        gate._sympy_gate(_legacy_sympy_shape_only())


def test_cli_returns_structured_failure_for_hostile_json(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    path = tmp_path / "hostile.json"
    path.write_bytes(b'{"summary":{"p95_reduction_percent":Infinity}}')

    result = gate.main(["--workload", "pytest", "--input", str(path)])
    output = json.loads(capsys.readouterr().out)

    assert result == 1
    assert output["schema"] == "zerorun.strict-performance-gate-error.v1"
    assert output["pass"] is False
    assert "non-finite JSON" in output["error"]
