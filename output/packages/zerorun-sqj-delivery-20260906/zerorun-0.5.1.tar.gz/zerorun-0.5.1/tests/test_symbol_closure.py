from __future__ import annotations

import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from zerorun.api import run_task
from zerorun.hermetic_key import task_fingerprint_v2
from zerorun.manifest import load_manifest
from zerorun.model import ConfigurationError
from zerorun.oci import hermetic_environment


IMAGE = "example.invalid/python@sha256:" + "a" * 64
RUNTIME = {
    "runtime": "docker",
    "requested_image": IMAGE,
    "requested_digest": "sha256:" + "a" * 64,
    "platform": "linux/amd64",
    "image_id": "sha256:" + "b" * 64,
    "repo_digests": [IMAGE],
    "rootfs": {"type": "layers", "layers": ["sha256:" + "c" * 64]},
    "config_sha256": "d" * 64,
}


class SymbolClosureTests(unittest.TestCase):
    def setUp(self):
        host = patch("zerorun.hermetic.validate_host")
        host.start()
        self.addCleanup(host.stop)

    def make_project(self, selectors: list[str]):
        temporary = tempfile.TemporaryDirectory()
        root = Path(temporary.name)
        (root / "bootstrap.txt").write_text("stable\n", encoding="utf-8")
        (root / "module.py").write_text(
            "FLAG = 1\n\n"
            "def selected(value=FLAG):\n"
            "    return value + 1\n\n"
            "def unrelated():\n"
            "    return 10\n\n"
            "class Box:\n"
            "    TOKEN = 5\n\n"
            "    def chosen(self):\n"
            "        return 20\n\n"
            "    def other(self):\n"
            "        return 30\n",
            encoding="utf-8",
        )
        manifest = {
            "version": 2,
            "tasks": {
                "work": {
                    "command": ["python", "-c", "pass"],
                    "inputs": ["bootstrap.txt"],
                    "input_symbols": selectors,
                    "outputs": [],
                    "cacheable": True,
                    "unsafe_effects": [],
                    "env": [],
                    "cache_streams": False,
                    "result_only": True,
                    "closure_reviewed": True,
                    "image": IMAGE,
                    "platform": "linux/amd64",
                }
            },
        }
        path = root / ".zerorun.json"
        path.write_text(json.dumps(manifest), encoding="utf-8")
        return temporary, path

    def fingerprint(self, path: Path):
        manifest = load_manifest(path)
        task = manifest.tasks["work"]
        _, env_fp = hermetic_environment(task)
        return task_fingerprint_v2(
            manifest,
            task,
            RUNTIME,
            environment_fingerprint=env_fp,
        )

    def test_unselected_function_body_does_not_invalidate_selected_symbol(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        key1, fingerprint1 = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace("return 10", "return 999"),
            encoding="utf-8",
        )
        key2, fingerprint2 = self.fingerprint(path)
        self.assertEqual(key1, key2)
        self.assertEqual(fingerprint1, fingerprint2)
        self.assertEqual(fingerprint1["schema"], 8)

    def test_unselected_function_definition_time_state_invalidates(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        key1, _ = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace(
                "def unrelated():", "def unrelated(value=FLAG):"
            ),
            encoding="utf-8",
        )
        key2, _ = self.fingerprint(path)
        self.assertNotEqual(key1, key2)

    def test_unselected_class_definition_time_state_invalidates(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        key1, _ = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace("TOKEN = 5", "TOKEN = 6"),
            encoding="utf-8",
        )
        key2, _ = self.fingerprint(path)
        self.assertNotEqual(key1, key2)

    def test_selected_function_body_invalidates(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        key1, _ = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace("return value + 1", "return value + 2"),
            encoding="utf-8",
        )
        key2, _ = self.fingerprint(path)
        self.assertNotEqual(key1, key2)

    def test_module_level_assignment_invalidates_projection(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        key1, _ = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace("FLAG = 1", "FLAG = 2"),
            encoding="utf-8",
        )
        key2, _ = self.fingerprint(path)
        self.assertNotEqual(key1, key2)

    def test_nested_class_method_selector_is_exact(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::Box.chosen"])
        self.addCleanup(temporary.cleanup)
        key1, _ = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace("return 30", "return 31"),
            encoding="utf-8",
        )
        key2, _ = self.fingerprint(path)
        self.assertEqual(key1, key2)
        source.write_text(
            source.read_text(encoding="utf-8").replace("return 20", "return 21"),
            encoding="utf-8",
        )
        key3, _ = self.fingerprint(path)
        self.assertNotEqual(key2, key3)

    def test_class_projection_tracks_class_state_without_all_method_bodies(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::Box.@class"])
        self.addCleanup(temporary.cleanup)
        key1, _ = self.fingerprint(path)
        source = path.parent / "module.py"
        source.write_text(
            source.read_text(encoding="utf-8").replace("return 30", "return 31"),
            encoding="utf-8",
        )
        key2, _ = self.fingerprint(path)
        self.assertEqual(key1, key2)
        source.write_text(
            source.read_text(encoding="utf-8").replace("TOKEN = 5", "TOKEN = 6"),
            encoding="utf-8",
        )
        key3, _ = self.fingerprint(path)
        self.assertNotEqual(key2, key3)

    def test_symbol_closure_cache_hit_survives_unselected_body_edit(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        manifest = load_manifest(path)
        task = manifest.tasks["work"]
        with patch("zerorun.hermetic.inspect_runtime", return_value=RUNTIME), patch(
            "zerorun.hermetic._docker_execute", return_value=(0, 100.0, b"", b"")
        ) as execute:
            first = run_task(manifest, task, stdout=io.BytesIO(), stderr=io.BytesIO())
            source = path.parent / "module.py"
            source.write_text(
                source.read_text(encoding="utf-8").replace("return 10", "return 999"),
                encoding="utf-8",
            )
            second = run_task(manifest, task, stdout=io.BytesIO(), stderr=io.BytesIO())
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "HIT_REUSED")
        self.assertEqual(execute.call_count, 1)
        metadata = json.loads(
            (manifest.root / ".zerorun" / "cache" / first.cache_key / "metadata.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertEqual(metadata["schema"], 8)

    def test_symbol_closure_cache_miss_when_selected_body_changes(self):
        temporary, path = self.make_project(["module.py::@module", "module.py::selected"])
        self.addCleanup(temporary.cleanup)
        manifest = load_manifest(path)
        task = manifest.tasks["work"]
        with patch("zerorun.hermetic.inspect_runtime", return_value=RUNTIME), patch(
            "zerorun.hermetic._docker_execute", return_value=(0, 100.0, b"", b"")
        ) as execute:
            first = run_task(manifest, task, stdout=io.BytesIO(), stderr=io.BytesIO())
            source = path.parent / "module.py"
            source.write_text(
                source.read_text(encoding="utf-8").replace("return value + 1", "return value + 2"),
                encoding="utf-8",
            )
            second = run_task(manifest, task, stdout=io.BytesIO(), stderr=io.BytesIO())
        self.assertEqual(first.status, "MISS_EXECUTED")
        self.assertEqual(second.status, "MISS_EXECUTED")
        self.assertNotEqual(first.cache_key, second.cache_key)
        self.assertEqual(execute.call_count, 2)

    def test_missing_reviewed_symbol_rejects(self):
        temporary, path = self.make_project(["module.py::does_not_exist"])
        self.addCleanup(temporary.cleanup)
        with self.assertRaisesRegex(ConfigurationError, "reviewed input symbol not found"):
            self.fingerprint(path)

    def test_missing_reviewed_class_rejects(self):
        temporary, path = self.make_project(["module.py::Missing.@class"])
        self.addCleanup(temporary.cleanup)
        with self.assertRaisesRegex(ConfigurationError, "reviewed input class is ambiguous or not found"):
            self.fingerprint(path)

    def test_invalid_symbol_selector_shape_rejects_manifest(self):
        temporary, path = self.make_project(["module.py::selected"])
        self.addCleanup(temporary.cleanup)
        raw = json.loads(path.read_text(encoding="utf-8"))
        raw["tasks"]["work"]["input_symbols"] = ["module.py"]
        path.write_text(json.dumps(raw), encoding="utf-8")
        with self.assertRaisesRegex(ConfigurationError, "input_symbols"):
            load_manifest(path)


if __name__ == "__main__":
    unittest.main()
