from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from zerorun import pytest_qualify


def _run_profiled_nodes(
    root: Path,
    source: str,
    nodeids: tuple[str, ...],
    *,
    force_legacy_profile: bool = False,
    instrument_monitor_fast_path: bool = False,
    ephemeral_root: Path | None = None,
    target_relative: str = "test_profiler_adversarial.py",
    extra_files: dict[str, str] | None = None,
) -> dict[str, object]:
    support = root / "support"
    support.mkdir()
    (support / pytest_qualify._CONTEXT_FILE).write_text(
        pytest_qualify._CONTEXT_SOURCE,
        encoding="utf-8",
    )
    (support / pytest_qualify._PLUGIN_FILE).write_text(
        pytest_qualify._PLUGIN_SOURCE,
        encoding="utf-8",
    )
    site = pytest_qualify._SITE_SOURCE.replace(
        '_ROOT = "/workspace"',
        f"_ROOT = {root.as_posix()!r}",
    ).replace(
        '_OUT_DIR = "/zerorun-pytest-qualify-output"',
        f"_OUT_DIR = {support.as_posix()!r}",
    )
    if ephemeral_root is not None:
        node_ephemeral_root = ephemeral_root / "node"
        node_ephemeral_root.mkdir(parents=True, exist_ok=True)
        site = site.replace(
            '_EPHEMERAL_ROOT = "/tmp"',
            f"_EPHEMERAL_ROOT = {node_ephemeral_root.as_posix()!r}",
        )
    if force_legacy_profile:
        site = site.replace(
            '_MONITORING = getattr(sys, "monitoring", None)',
            "_MONITORING = None",
        )
    if instrument_monitor_fast_path:
        counter_anchor = '_MONITORING_NAME = "zerorun-pytest-qualify"\n'
        classification_anchor = (
            '            filename = getattr(code, "co_filename", None)\n'
        )
        frame_anchor = (
            "    try:\n"
            "        frame = sys._getframe(1)\n"
            "        if frame.f_code is not code:\n"
            '            _mark_uncertainty("monitoring-frame-attribution-failed", owner)\n'
        )
        assert site.count(counter_anchor) == 1
        assert site.count(classification_anchor) == 1
        assert site.count(frame_anchor) == 1
        site = site.replace(
            counter_anchor,
            counter_anchor
            + "_MONITOR_PROJECT_CLASSIFICATIONS = 0\n"
            + "_MONITOR_FRAME_LOOKUPS = 0\n",
        )
        site = site.replace(
            classification_anchor,
            "            global _MONITOR_PROJECT_CLASSIFICATIONS\n"
            "            _MONITOR_PROJECT_CLASSIFICATIONS += 1\n"
            + classification_anchor,
        )
        site = site.replace(
            frame_anchor,
            "    try:\n"
            "        global _MONITOR_FRAME_LOOKUPS\n"
            "        _MONITOR_FRAME_LOOKUPS += 1\n"
            "        frame = sys._getframe(1)\n"
            "        if frame.f_code is not code:\n"
            '            _mark_uncertainty("monitoring-frame-attribution-failed", owner)\n',
        )
    (support / pytest_qualify._SITE_FILE).write_text(site, encoding="utf-8")
    for relative, contents in (extra_files or {}).items():
        extra = root / relative
        extra.parent.mkdir(parents=True, exist_ok=True)
        extra.write_text(contents, encoding="utf-8")
    target = root / target_relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(source, encoding="utf-8")
    environment = dict(os.environ)
    environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    environment["PYTHONPATH"] = str(support)
    if ephemeral_root is not None:
        ephemeral_root.mkdir(exist_ok=True)
        node_ephemeral_root = ephemeral_root / "node"
        node_ephemeral_root.mkdir(exist_ok=True)
        environment["TMPDIR"] = str(ephemeral_root)
        environment["TEMP"] = str(ephemeral_root)
        environment["TMP"] = str(ephemeral_root)
        environment["ZERORUN_TEST_NODE_TMP"] = str(node_ephemeral_root)
    completed = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-q",
            "-p",
            "zerorun_qualify_plugin",
            *nodeids,
        ],
        cwd=root,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=30,
    )
    assert completed.returncode == 0, completed.stdout + completed.stderr
    payloads = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in support.glob("profile-*.json")
    ]
    plugin_payloads = [
        payload for payload in payloads if payload.get("pytest_plugin_loaded") is True
    ]
    assert len(plugin_payloads) == 1, payloads
    return plugin_payloads[0]


def _run_profiled_test(root: Path, source: str) -> tuple[str, dict[str, object]]:
    nodeid = "test_profiler_adversarial.py::test_raw_thread"
    return nodeid, _run_profiled_nodes(root, source, (nodeid,))


def _profile_bucket_closure(
    root: Path,
    payload: dict[str, object],
    bucket: str,
) -> dict[str, object]:
    observations = payload["import_observations"]
    external_modules = tuple(
        row[0]
        for row in (
            *observations["external_modules"],
            *observations["stable_external_toplevels"],
        )
    )
    decoded_imports = pytest_qualify._validate_executed_imports(
        payload["executed_imports"],
        label="captured profiler edges",
    )
    return pytest_qualify._closure_row(
        root,
        pytest_qualify._decode_sites(payload.get("buckets", {}).get(bucket, [])),
        external_modules=external_modules,
        import_search_roots=tuple(
            sorted({".", "src", *observations["project_search_roots"]})
        ),
        executed_imports=decoded_imports.get(bucket, ()),
    )


def test_normal_import_edges_include_cached_node_imports(tmp_path: Path) -> None:
    nodeid = "test_profiler_adversarial.py::test_cached_import"
    payload = _run_profiled_nodes(
        tmp_path,
        """import cached_helper


def test_cached_import():
    import cached_helper
    assert cached_helper.VALUE == 7
""",
        (nodeid,),
        extra_files={"cached_helper.py": "VALUE = 7\n"},
    )

    session_modules = {
        row[8]
        for row in payload.get("executed_imports", {}).get("__session__", [])
    }
    node_rows = payload.get("executed_imports", {}).get(nodeid, [])
    assert "cached_helper" in session_modules
    assert any(
        row[8] == "cached_helper" and row[9] == [] and row[10] == 0
        for row in node_rows
    )
    assert not payload.get("uncertainties", {}).get(nodeid)

    decoded_imports = pytest_qualify._validate_executed_imports(
        payload["executed_imports"],
        label="captured import edges",
    )
    closure = pytest_qualify._closure_row(
        tmp_path,
        pytest_qualify._decode_sites(payload["buckets"][nodeid]),
        executed_imports=decoded_imports[nodeid],
    )
    assert closure["unresolved_imports"] == []
    assert "cached_helper.py" not in closure["fallback_files"]
    assert "cached_helper.py::@module-state" in closure["selectors"]


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 10), (3, 11), (3, 12), (3, 13), (3, 14)},
    reason="assertion-rewrite provenance is version-gated",
)
def test_assertion_rewrite_pair_after_future_import_is_proven_and_ignored(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_future_import"
    payload = _run_profiled_nodes(
        tmp_path,
        """from __future__ import annotations

import cached_helper


def test_future_import():
    assert cached_helper.VALUE == 7
""",
        (nodeid,),
        extra_files={"cached_helper.py": "VALUE = 7\n"},
    )

    session_rows = payload.get("executed_imports", {}).get("__session__", [])
    session_modules = {row[8] for row in session_rows}
    assert "builtins" not in session_modules
    assert "_pytest.assertion.rewrite" not in session_modules
    assert not payload.get("uncertainties", {}).get("__session__")
    assert _profile_bucket_closure(
        tmp_path, payload, "__session__"
    )["unresolved_imports"] == []


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 10), (3, 11), (3, 12), (3, 13), (3, 14)},
    reason="assertion-rewrite provenance is version-gated",
)
def test_assertion_rewrite_pair_after_docstring_future_and_decorator_is_ignored(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_decorated_header"
    payload = _run_profiled_nodes(
        tmp_path,
        '''"""Module documentation."""
from __future__ import annotations

@(lambda function: function)
def decorated_helper():
    return cached_helper.VALUE


import cached_helper


def test_decorated_header():
    assert decorated_helper() == 7
''',
        (nodeid,),
        extra_files={"cached_helper.py": "VALUE = 7\n"},
    )

    session_rows = payload.get("executed_imports", {}).get("__session__", [])
    session_modules = {row[8] for row in session_rows}
    assert "builtins" not in session_modules
    assert "_pytest.assertion.rewrite" not in session_modules
    assert not payload.get("uncertainties", {}).get("__session__")
    assert _profile_bucket_closure(
        tmp_path, payload, "__session__"
    )["unresolved_imports"] == []


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 10), (3, 11), (3, 12), (3, 13), (3, 14)},
    reason="assertion-rewrite provenance is version-gated",
)
def test_explicit_assertion_runtime_imports_are_never_ignored(tmp_path: Path) -> None:
    nodeid = "test_profiler_adversarial.py::test_explicit_imports"
    payload = _run_profiled_nodes(
        tmp_path,
        """from __future__ import annotations

import builtins
import _pytest.assertion.rewrite


def test_explicit_imports():
    assert builtins.len(()) == 0
    assert _pytest.assertion.rewrite.AssertionRewritingHook
""",
        (nodeid,),
    )

    session_rows = payload.get("executed_imports", {}).get("__session__", [])
    for module in ("builtins", "_pytest.assertion.rewrite"):
        matching = [row for row in session_rows if row[8] == module]
        assert len(matching) == 1
        assert matching[0][7] > matching[0][6]
    assert _profile_bucket_closure(
        tmp_path, payload, "__session__"
    )["unresolved_imports"] == []


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 10), (3, 11), (3, 12), (3, 13), (3, 14)},
    reason="assertion-rewrite provenance is version-gated",
)
def test_dynamic_builtins_import_remains_fresh_required(tmp_path: Path) -> None:
    nodeid = "test_profiler_adversarial.py::test_dynamic_import"
    payload = _run_profiled_nodes(
        tmp_path,
        """loaded = __import__("builtins")


def test_dynamic_import():
    assert loaded.len(()) == 0
""",
        (nodeid,),
    )

    assert "dynamic-or-unattributed-import-call" in set(
        payload.get("uncertainties", {}).get("__session__", [])
    )


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 10), (3, 11), (3, 12), (3, 13), (3, 14)},
    reason="assertion-rewrite provenance is version-gated",
)
@pytest.mark.parametrize(
    "variant",
    (
        "exact-exec",
        "exact-function",
        "partial",
        "wrong-store",
        "changed-span",
        "duplicate",
    ),
)
def test_forged_assertion_rewrite_bytecode_cannot_gain_authority(
    tmp_path: Path,
    variant: str,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_forged_pair"
    payload = _run_profiled_nodes(
        tmp_path,
        f'''import ast
import types

VARIANT = {variant!r}


def synthetic_import(module, target, line=1, end_line=1):
    alias = ast.alias(
        name=module,
        asname=target,
        lineno=line,
        col_offset=0,
        end_lineno=end_line,
        end_col_offset=0,
    )
    return ast.Import(
        names=[alias],
        lineno=line,
        col_offset=0,
        end_lineno=end_line,
        end_col_offset=0,
    )


def forged_code():
    target = "@py_builtins" if VARIANT != "wrong-store" else "@py_builtin_spoof"
    first = synthetic_import("builtins", target)
    second_line = 2 if VARIANT == "changed-span" else 1
    second = synthetic_import(
        "_pytest.assertion.rewrite",
        "@pytest_ar",
        line=second_line,
        end_line=second_line,
    )
    body = [first] if VARIANT == "partial" else [first, second]
    if VARIANT == "duplicate":
        body.extend(
            [
                synthetic_import("builtins", "@py_builtins"),
                synthetic_import("_pytest.assertion.rewrite", "@pytest_ar"),
            ]
        )
    tree = ast.Module(body=body, type_ignores=[])
    return compile(tree, __file__, "exec")


def test_forged_pair():
    code = forged_code()
    if VARIANT == "exact-function":
        types.FunctionType(code, globals())()
    else:
        exec(code, globals(), globals())
''',
        (nodeid,),
    )

    node_rows = payload.get("executed_imports", {}).get(nodeid, [])
    if sys.version_info[:2] == (3, 10):
        # Python 3.10 has no bytecode column positions.  A forged pair lacks
        # the authenticated pytest loader caller, so it is refused before an
        # edge with guessed coordinates can be emitted.
        assert not any(row[8] == "builtins" for row in node_rows)
        assert "incomplete-import-edge-attribution:position" in set(
            payload.get("uncertainties", {}).get(nodeid, [])
        )
    else:
        assert any(row[8] == "builtins" for row in node_rows)
        closure = _profile_bucket_closure(tmp_path, payload, nodeid)
        assert any(
            "selected import projection" in reason
            and "dynamic/custom import or evaluation" in reason
            for reason in closure["unresolved_imports"]
        )


def test_relative_fromlist_import_edge_is_exactly_attributed(tmp_path: Path) -> None:
    nodeid = "pkg/test_relative.py::test_relative_import"
    payload = _run_profiled_nodes(
        tmp_path,
        """def test_relative_import():
    from .helper import VALUE
    assert VALUE == 11
""",
        (nodeid,),
        target_relative="pkg/test_relative.py",
        extra_files={
            "pkg/__init__.py": "",
            "pkg/helper.py": "VALUE = 11\n",
        },
    )

    rows = payload.get("executed_imports", {}).get(nodeid, [])
    assert any(
        row[8] == "helper" and row[9] == ["VALUE"] and row[10] == 1
        for row in rows
    )
    assert not payload.get("uncertainties", {}).get(nodeid)


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 12), (3, 14)},
    reason="the guarded CPython _typing callback is version-specific",
)
def test_cpython_typing_non_import_callbacks_remain_uncertain_and_unrecorded(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_box"
    payload = _run_profiled_nodes(
        tmp_path,
        """import typing as t

T = t.TypeVar("T")


class Box(t.Generic[T]):
    pass


def test_box():
    assert Box[int]
""",
        (nodeid,),
    )

    assert "dynamic-or-unattributed-import-call" in set(
        payload.get("uncertainties", {}).get("__session__", [])
    )
    session_rows = payload.get("executed_imports", {}).get("__session__", [])
    typing_rows = [row for row in session_rows if row[8] == "typing"]
    assert typing_rows
    assert all(row[5] == 1 for row in typing_rows)


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 12), (3, 14)},
    reason="the guarded CPython _typing callback is version-specific",
)
def test_counterfeit_typing_call_with_internal_signature_remains_unresolved(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_counterfeit"
    payload = _run_profiled_nodes(
        tmp_path,
        """counterfeit = __import__("typing", globals(), locals(), [], 0)


def test_counterfeit():
    assert counterfeit.__name__ == "typing"
""",
        (nodeid,),
    )

    assert "dynamic-or-unattributed-import-call" in set(
        payload.get("uncertainties", {}).get("__session__", [])
    )
    assert not any(
        row[8] == "typing"
        for row in payload.get("executed_imports", {}).get("__session__", [])
    )


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 12), (3, 14)},
    reason="the guarded CPython _typing callback is version-specific",
)
def test_duplicate_counterfeit_typing_calls_fail_closed_without_guessed_edges(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_counterfeit"
    payload = _run_profiled_nodes(
        tmp_path,
        """counterfeits = (__import__("typing", globals(), locals(), [], 0), __import__("typing", globals(), locals(), [], 0))


def test_counterfeit():
    assert all(module.__name__ == "typing" for module in counterfeits)
""",
        (nodeid,),
    )

    assert "dynamic-or-unattributed-import-call" in set(
        payload.get("uncertainties", {}).get("__session__", [])
    )
    assert not any(
        row[8] == "typing"
        for row in payload.get("executed_imports", {}).get("__session__", [])
    )


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 12), (3, 14)},
    reason="the guarded CPython _typing callback is version-specific",
)
def test_runtime_aliased_typing_constructor_cannot_impersonate_private_callback(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_counterfeit"
    payload = _run_profiled_nodes(
        tmp_path,
        """import builtins
import sys
import typing as t

namespace = vars(sys.modules[__name__])
t.TypeVar = getattr(builtins, "__" + "import" + "__")
counterfeit = t.TypeVar("typing", namespace, namespace, [], 0)


def test_counterfeit():
    assert counterfeit.__name__ == "typing"
""",
        (nodeid,),
    )

    assert "dynamic-or-unattributed-import-call" in set(
        payload.get("uncertainties", {}).get("__session__", [])
    )
    typing_rows = [
        row
        for row in payload.get("executed_imports", {}).get("__session__", [])
        if row[8] == "typing"
    ]
    assert any(row[5] == 3 for row in typing_rows)
    assert not any(row[5] == 7 for row in typing_rows)


@pytest.mark.skipif(
    sys.version_info[:2] not in {(3, 12), (3, 14)},
    reason="the guarded CPython _typing callback is version-specific",
)
def test_c_level_subscript_cannot_impersonate_private_typing_callback(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_counterfeit"
    payload = _run_profiled_nodes(
        tmp_path,
        """import builtins
import sys
import typing as t
from collections import defaultdict
from functools import partial

namespace = vars(sys.modules[__name__])
loader = getattr(builtins, "__" + "import" + "__")
t.List = defaultdict(partial(loader, "typing", namespace, namespace, [], 0))
counterfeit = t.List["missing"]


def test_counterfeit():
    assert counterfeit.__name__ == "typing"
""",
        (nodeid,),
    )

    assert "dynamic-or-unattributed-import-call" in set(
        payload.get("uncertainties", {}).get("__session__", [])
    )
    typing_rows = [
        row
        for row in payload.get("executed_imports", {}).get("__session__", [])
        if row[8] == "typing"
    ]
    assert any(row[5] == 3 for row in typing_rows)
    assert not any(row[5] == 10 for row in typing_rows)


def test_counterfeit_class_getitem_typing_import_remains_fresh(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_counterfeit"
    payload = _run_profiled_nodes(
        tmp_path,
        """class Counterfeit:
    @classmethod
    def __class_getitem__(cls, item):
        return __import__("typing", globals(), locals(), [], 0)


def test_counterfeit():
    assert Counterfeit[int].__name__ == "typing"
""",
        (nodeid,),
    )

    assert "dynamic-or-unattributed-import-call" in set(
        payload.get("uncertainties", {}).get(nodeid, [])
    )


def test_direct_dynamic_import_call_is_not_certified(tmp_path: Path) -> None:
    nodeid = "test_profiler_adversarial.py::test_dynamic_import"
    payload = _run_profiled_nodes(
        tmp_path,
        """def test_dynamic_import():
    module = __import__("dynamic_helper")
    assert module.VALUE == 13
""",
        (nodeid,),
        extra_files={"dynamic_helper.py": "VALUE = 13\n"},
    )

    assert "dynamic-or-unattributed-import-call" in set(
        payload.get("uncertainties", {}).get(nodeid, [])
    )
    assert not any(
        row[8] == "dynamic_helper"
        for row in payload.get("executed_imports", {}).get(nodeid, [])
    )


def test_import_wrapper_tamper_is_reported_by_integrity_boundary(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_import_tamper"
    payload = _run_profiled_nodes(
        tmp_path,
        """import builtins

saved_import = builtins.__import__


def forwarding_import(*args, **kwargs):
    return saved_import(*args, **kwargs)


def test_import_tamper():
    builtins.__import__ = forwarding_import
""",
        (nodeid,),
    )

    assert any(
        "builtins.__import__ guard was replaced" in reason
        for reason in payload.get("integrity_violations", [])
    )


def test_public_managed_start_attribute_cannot_suppress_raw_thread_uncertainty(
    tmp_path: Path,
) -> None:
    nodeid, payload = _run_profiled_test(
        tmp_path,
        """import _thread
import threading


def child_work():
    return 7


def test_raw_thread():
    current = threading.current_thread()
    missing = object()
    previous = getattr(current, "_zerorun_managed_start", missing)
    current._zerorun_managed_start = True
    try:
        if hasattr(_thread, "start_joinable_thread"):
            handle = _thread.start_joinable_thread(child_work)
            handle.join()
        else:
            done = threading.Event()

            def run():
                try:
                    child_work()
                finally:
                    done.set()

            _thread.start_new(run, ())
            assert done.wait(5)
    finally:
        if previous is missing:
            del current._zerorun_managed_start
        else:
            current._zerorun_managed_start = previous
""",
    )
    uncertainties = payload.get("uncertainties", {})
    observed = {
        reason
        for bucket in (nodeid, "__session__")
        for reason in uncertainties.get(bucket, [])
    }
    assert "unmanaged-thread-start" in observed


def test_legacy_start_new_alias_is_always_fail_closed(tmp_path: Path) -> None:
    nodeid, payload = _run_profiled_test(
        tmp_path,
        """import _thread
import threading


def test_raw_thread():
    done = threading.Event()

    def run():
        done.set()

    _thread.start_new(run, ())
    assert done.wait(5)
""",
    )
    uncertainties = payload.get("uncertainties", {})
    observed = {
        reason
        for bucket in (nodeid, "__session__")
        for reason in uncertainties.get(bucket, [])
    }
    assert "unmanaged-thread-start" in observed


def test_legacy_start_new_alias_tamper_is_reported(tmp_path: Path) -> None:
    nodeid = "test_profiler_adversarial.py::test_alias_tamper"
    payload = _run_profiled_nodes(
        tmp_path,
        """import _thread


saved_start_new = _thread.start_new


def forwarding_start_new(*args, **kwargs):
    return saved_start_new(*args, **kwargs)


def test_alias_tamper():
    _thread.start_new = forwarding_start_new
""",
        (nodeid,),
    )
    assert any(
        "_thread.start_new hook was replaced" in reason
        for reason in payload.get("integrity_violations", [])
    )


def test_mutable_current_thread_api_cannot_reassign_child_to_prior_node(
    tmp_path: Path,
) -> None:
    seed_nodeid = "test_profiler_adversarial.py::test_seed_thread_record"
    victim_nodeid = "test_profiler_adversarial.py::test_spoof_current_thread"
    payload = _run_profiled_nodes(
        tmp_path,
        """import threading


seed_thread = None


def child_observation():
    return 11


def test_seed_thread_record():
    global seed_thread
    seed_thread = threading.Thread(target=lambda: None)
    seed_thread.start()
    seed_thread.join()


def test_spoof_current_thread():
    original_current_thread = threading.current_thread
    victim = threading.Thread(target=child_observation)
    threading.current_thread = lambda: seed_thread
    try:
        victim.start()
        victim.join()
    finally:
        threading.current_thread = original_current_thread
""",
        (seed_nodeid, victim_nodeid),
    )
    buckets = payload.get("buckets", {})
    victim_sites = {
        (site[0], site[2]) for site in buckets.get(victim_nodeid, [])
    }
    seed_sites = {(site[0], site[2]) for site in buckets.get(seed_nodeid, [])}
    assert ("test_profiler_adversarial.py", "child_observation") in victim_sites
    assert ("test_profiler_adversarial.py", "child_observation") not in seed_sites


def test_mutable_thread_ident_cannot_reassign_child_to_prior_node(
    tmp_path: Path,
) -> None:
    seed_nodeid = "test_profiler_adversarial.py::test_seed_thread_record"
    victim_nodeid = "test_profiler_adversarial.py::test_spoof_thread_ident"
    payload = _run_profiled_nodes(
        tmp_path,
        """import threading


seed_thread = None


def child_observation():
    return 13


def test_seed_thread_record():
    global seed_thread
    seed_thread = threading.Thread(target=lambda: None)
    seed_thread.start()
    seed_thread.join()


def spoofing_worker():
    current = threading.current_thread()
    raw_ident = threading.get_ident()
    seed_ident = seed_thread._ident
    current_ident = current._ident
    seed_thread._ident = raw_ident
    current._ident = -1
    try:
        assert child_observation() == 13
    finally:
        current._ident = current_ident
        seed_thread._ident = seed_ident


def test_spoof_thread_ident():
    victim = threading.Thread(target=spoofing_worker)
    victim.start()
    victim.join()
""",
        (seed_nodeid, victim_nodeid),
    )
    buckets = payload.get("buckets", {})
    victim_sites = {
        (site[0], site[2]) for site in buckets.get(victim_nodeid, [])
    }
    seed_sites = {(site[0], site[2]) for site in buckets.get(seed_nodeid, [])}
    assert ("test_profiler_adversarial.py", "child_observation") in victim_sites
    assert ("test_profiler_adversarial.py", "child_observation") not in seed_sites


@pytest.mark.skipif(
    not hasattr(sys, "monitoring"),
    reason="requires the PEP 669 sys.monitoring API",
)
def test_transient_monitoring_disable_cannot_hide_project_calls(tmp_path: Path) -> None:
    (tmp_path / "hidden_module.py").write_text(
        "def hidden_call():\n    return 17\n",
        encoding="utf-8",
    )
    nodeid = "test_profiler_adversarial.py::test_transient_disable"
    payload = _run_profiled_nodes(
        tmp_path,
        """import sys
from hidden_module import hidden_call


def test_transient_disable():
    monitoring = sys.monitoring
    tool_id = monitoring.PROFILER_ID
    events = monitoring.events.PY_START | monitoring.events.PY_RESUME
    monitoring.set_events(tool_id, 0)
    try:
        assert hidden_call() == 17
    finally:
        monitoring.set_events(tool_id, events)
""",
        (nodeid,),
    )
    assert payload.get("integrity_violations") == []
    node_sites = {
        (site[0], site[2])
        for site in payload.get("buckets", {}).get(nodeid, [])
    }
    hidden_call_recorded = ("hidden_module.py", "hidden_call") in node_sites
    uncertainties = payload.get("uncertainties", {})
    reason = "monitoring-configuration-changed:set_events"
    assert hidden_call_recorded or (
        reason in uncertainties.get(nodeid, [])
        and reason in uncertainties.get("__session__", [])
    )


def test_monitoring_keeps_project_code_enabled_across_nodes_and_finds_late_code(
    tmp_path: Path,
) -> None:
    first = "test_profiler_adversarial.py::test_first"
    second = "test_profiler_adversarial.py::test_second"
    payload = _run_profiled_nodes(
        tmp_path,
        """def shared_project_call():
    return 3


def late_project_call():
    return 5


def test_first():
    assert shared_project_call() == 3


def test_second():
    assert shared_project_call() == 3
    assert late_project_call() == 5
""",
        (first, second),
    )
    buckets = payload.get("buckets", {})
    first_sites = {(row[0], row[2]) for row in buckets.get(first, [])}
    second_sites = {(row[0], row[2]) for row in buckets.get(second, [])}
    shared = ("test_profiler_adversarial.py", "shared_project_call")
    late = ("test_profiler_adversarial.py", "late_project_call")
    assert shared in first_sites
    assert shared in second_sites
    assert late not in first_sites
    assert late in second_sites


def test_monitoring_py_resume_attributes_generator_across_node_boundary(
    tmp_path: Path,
) -> None:
    first = "test_profiler_adversarial.py::test_first_resume"
    second = "test_profiler_adversarial.py::test_second_resume"
    payload = _run_profiled_nodes(
        tmp_path,
        """def shared_generator():
    yield 7
    yield 11


stream = shared_generator()


def test_first_resume():
    assert next(stream) == 7


def test_second_resume():
    assert next(stream) == 11
""",
        (first, second),
    )
    buckets = payload.get("buckets", {})
    expected = ("test_profiler_adversarial.py", "shared_generator")
    assert expected in {(row[0], row[2]) for row in buckets.get(first, [])}
    assert expected in {(row[0], row[2]) for row in buckets.get(second, [])}


@pytest.mark.skipif(
    not hasattr(sys, "monitoring"),
    reason="requires the PEP 669 sys.monitoring API",
)
def test_monitoring_seen_code_fast_path_skips_repeat_callback_work(
    tmp_path: Path,
) -> None:
    first = "test_profiler_adversarial.py::test_first_repeated_resume"
    second = "test_profiler_adversarial.py::test_second_repeated_resume"
    payload = _run_profiled_nodes(
        tmp_path,
        """import sitecustomize


def hot_generator():
    while True:
        yield 17


stream = hot_generator()


def test_first_repeated_resume():
    before_first = (
        sitecustomize._MONITOR_PROJECT_CLASSIFICATIONS,
        sitecustomize._MONITOR_FRAME_LOOKUPS,
    )
    assert next(stream) == 17
    after_first = (
        sitecustomize._MONITOR_PROJECT_CLASSIFICATIONS,
        sitecustomize._MONITOR_FRAME_LOOKUPS,
    )
    assert after_first == (before_first[0] + 1, before_first[1] + 1)
    for _ in range(100):
        assert next(stream) == 17
    after_repeats = (
        sitecustomize._MONITOR_PROJECT_CLASSIFICATIONS,
        sitecustomize._MONITOR_FRAME_LOOKUPS,
    )
    assert after_repeats == after_first


def test_second_repeated_resume():
    before_first = (
        sitecustomize._MONITOR_PROJECT_CLASSIFICATIONS,
        sitecustomize._MONITOR_FRAME_LOOKUPS,
    )
    assert next(stream) == 17
    after_first = (
        sitecustomize._MONITOR_PROJECT_CLASSIFICATIONS,
        sitecustomize._MONITOR_FRAME_LOOKUPS,
    )
    # The code-object classification is request-global and immutable, while
    # frame recovery/recording remains bucket-local for correct attribution.
    assert after_first == (before_first[0], before_first[1] + 1)
    for _ in range(100):
        assert next(stream) == 17
    after_repeats = (
        sitecustomize._MONITOR_PROJECT_CLASSIFICATIONS,
        sitecustomize._MONITOR_FRAME_LOOKUPS,
    )
    assert after_repeats == after_first
""",
        (first, second),
        instrument_monitor_fast_path=True,
    )

    expected = ("test_profiler_adversarial.py", "hot_generator")
    buckets = payload.get("buckets", {})
    assert expected in {(row[0], row[2]) for row in buckets.get(first, [])}
    assert expected in {(row[0], row[2]) for row in buckets.get(second, [])}
    assert payload.get("integrity_violations") == []


@pytest.mark.skipif(
    not hasattr(sys, "monitoring"),
    reason="requires the PEP 669 sys.monitoring API",
)
def test_monitoring_disables_each_external_start_location_once_overall(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_external_disable"
    payload = _run_profiled_nodes(
        tmp_path,
        """import sitecustomize
import sys


def test_external_disable():
    monitoring = sys.monitoring
    tool_id = monitoring.PROFILER_ID
    event = monitoring.events.PY_START
    original_register = sitecustomize._ORIGINAL_MONITORING_REGISTER_CALLBACK
    original_callback = original_register(tool_id, event, None)
    assert original_callback is not None
    observed = []
    namespace = {}
    exec(compile('def external_call():\\n    return 13\\n', '/opt/zr_external_probe.py', 'exec'), namespace)
    external_call = namespace['external_call']

    def counted_callback(code, offset):
        if code is external_call.__code__:
            observed.append(offset)
        return original_callback(code, offset)

    original_register(tool_id, event, counted_callback)
    try:
        assert external_call() == 13
        assert external_call() == 13
    finally:
        previous = original_register(tool_id, event, original_callback)
        assert previous is counted_callback
    assert len(observed) == 1
""",
        (nodeid,),
    )
    assert payload.get("integrity_violations") == []


@pytest.mark.skipif(
    not hasattr(sys, "monitoring"),
    reason="requires the PEP 669 sys.monitoring API",
)
def test_monitoring_detects_transient_py_resume_callback_replacement(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_resume_tamper"
    payload = _run_profiled_nodes(
        tmp_path,
        """import sitecustomize
import sys


def forged_resume(code, offset):
    return None


def test_resume_tamper():
    sitecustomize._ORIGINAL_MONITORING_REGISTER_CALLBACK(
        sys.monitoring.PROFILER_ID,
        sys.monitoring.events.PY_RESUME,
        forged_resume,
    )
""",
        (nodeid,),
    )
    violations = payload.get("integrity_violations", [])
    assert any("sys.monitoring profiler was replaced" in row for row in violations)


def test_monitoring_and_legacy_profiler_emit_equivalent_project_closures(
    tmp_path: Path,
) -> None:
    source = """import threading


def shared_generator():
    yield 2
    yield 3


stream = shared_generator()


def child_call():
    return 5


def test_first():
    assert next(stream) == 2
    worker = threading.Thread(target=child_call)
    worker.start()
    worker.join()


def test_second():
    assert next(stream) == 3
    assert child_call() == 5
"""
    nodeids = (
        "test_profiler_adversarial.py::test_first",
        "test_profiler_adversarial.py::test_second",
    )
    monitoring_root = tmp_path / "monitoring"
    legacy_root = tmp_path / "legacy"
    monitoring_root.mkdir()
    legacy_root.mkdir()
    monitoring = _run_profiled_nodes(monitoring_root, source, nodeids)
    legacy = _run_profiled_nodes(
        legacy_root,
        source,
        nodeids,
        force_legacy_profile=True,
    )

    def project_rows(payload: dict[str, object]) -> dict[str, set[tuple]]:
        return {
            bucket: {
                tuple(row[:3]) + (tuple(row[3]), row[4])
                for row in rows
                if row[0] == "test_profiler_adversarial.py"
            }
            for bucket, rows in payload.get("buckets", {}).items()
        }

    assert project_rows(monitoring) == project_rows(legacy)


@pytest.mark.parametrize("force_legacy_profile", (False, True))
@pytest.mark.parametrize("managed_thread", (False, True))
def test_equal_code_objects_from_distinct_files_retain_identity_and_paths(
    tmp_path: Path,
    force_legacy_profile: bool,
    managed_thread: bool,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_both_modules"
    invocation = (
        "    thread = threading.Thread(target=worker)\n"
        "    thread.start()\n"
        "    thread.join()\n"
        if managed_thread
        else "    worker()\n"
    )
    payload = _run_profiled_nodes(
        tmp_path,
        """import threading

import alpha
import beta


def worker():
    for _ in range(20):
        assert alpha.value() == 1
        assert beta.value() == 1


def test_both_modules():
"""
        + invocation,
        (nodeid,),
        force_legacy_profile=force_legacy_profile,
        extra_files={
            "alpha.py": "def value():\n    return 1\n",
            "beta.py": "def value():\n    return 1\n",
        },
    )

    buckets = payload.get("buckets", {})
    session_sites = {(row[0], row[2]) for row in buckets.get("__session__", [])}
    node_sites = {(row[0], row[2]) for row in buckets.get(nodeid, [])}
    assert {("alpha.py", "<module>"), ("beta.py", "<module>")} <= session_sites
    assert {("alpha.py", "value"), ("beta.py", "value")} <= node_sites
    assert not payload.get("uncertainties", {}).get(nodeid)
    assert payload.get("integrity_violations") == []
    closure = _profile_bucket_closure(tmp_path, payload, nodeid)
    assert {"alpha.py::value", "beta.py::value"} <= set(closure["selectors"])
    assert closure["unresolved_imports"] == []


def test_forged_module_origin_and_path_hook_mutation_fail_closed(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_forged_import_environment"
    payload = _run_profiled_nodes(
        tmp_path,
        """import sitecustomize
import sys
import types


def test_forged_import_environment():
    forged = types.ModuleType("forged_external")
    forged.__spec__ = types.SimpleNamespace(
        origin=sys.prefix + "/lib/forged_external.py",
        loader=None,
        submodule_search_locations=None,
    )
    sys.modules["forged_external"] = forged
    sitecustomize._IMPORT_MODULES.add("forged_external")
    sys.path_hooks.append(lambda path: None)
""",
        (nodeid,),
    )

    session_uncertainties = set(
        payload.get("uncertainties", {}).get("__session__", [])
    )
    assert any("path-hooks-changed" in reason for reason in session_uncertainties)
    assert any(
        "unsupported-module-origin:forged_external" in reason
        for reason in session_uncertainties
    )
    external_names = {
        row[0]
        for row in payload.get("import_observations", {}).get(
            "external_modules", []
        )
    }
    assert "forged_external" not in external_names


def test_net_zero_ephemeral_mutations_are_evidenced_without_fresh_requirement(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_isolated_filesystem"
    ephemeral = tmp_path.parent / f"{tmp_path.name}-external-tmp"
    payload = _run_profiled_nodes(
        tmp_path,
        """import os
import tempfile


def test_isolated_filesystem():
    original = os.getcwd()
    node_tmp = os.environ["ZERORUN_TEST_NODE_TMP"]
    os.environ["TMPDIR"] = node_tmp
    os.environ["TEMP"] = node_tmp
    os.environ["TMP"] = node_tmp
    tempfile.tempdir = node_tmp
    isolated = os.path.join(node_tmp, "zerorun-isolated")
    os.mkdir(isolated, 0o777)
    os.chdir(isolated)
    try:
        with open("before.txt", "w", encoding="utf-8") as handle:
            handle.write("bound")
        os.chmod("before.txt", 0o600)
        os.rename("before.txt", "after.txt")
        os.remove("after.txt")
    finally:
        os.chdir(original)
        os.rmdir(isolated)
""",
        (nodeid,),
        ephemeral_root=ephemeral,
    )

    reasons = set(payload.get("uncertainties", {}).get(nodeid, []))
    assert not any("filesystem-mutation" in reason for reason in reasons), "\n".join(
        sorted(reasons)
    )
    rows = payload.get("filesystem_mutations", {}).get(nodeid, [])
    assert rows
    assert {row[1] for row in rows} == {"ephemeral"}
    assert {row[0] for row in rows}.issuperset(
        {"open", "os.mkdir", "os.chmod", "os.rename", "os.remove", "os.rmdir"}
    )


def test_project_bytes_path_and_cross_scope_rename_remain_fresh(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_project_mutations"
    ephemeral = tmp_path.parent / f"{tmp_path.name}-external-tmp"
    (tmp_path / "project-data.txt").write_text("data", encoding="utf-8")
    payload = _run_profiled_nodes(
        tmp_path,
        """import os
import tempfile


def test_project_mutations():
    node_tmp = os.environ["ZERORUN_TEST_NODE_TMP"]
    os.environ["TMPDIR"] = node_tmp
    os.environ["TEMP"] = node_tmp
    os.environ["TMP"] = node_tmp
    tempfile.tempdir = node_tmp
    source = os.fsencode("project-data.txt")
    destination = os.path.join(tempfile.gettempdir(), "moved-data.txt")
    os.rename(source, os.fsencode(destination))
    os.rename(os.fsencode(destination), source)
""",
        (nodeid,),
        ephemeral_root=ephemeral,
    )

    reasons = set(payload.get("uncertainties", {}).get(nodeid, []))
    assert "project-filesystem-mutation:os.rename" in reasons
    rows = payload.get("filesystem_mutations", {}).get(nodeid, [])
    assert {row[1] for row in rows}.issuperset({"project", "ephemeral"})


def test_symlink_escape_from_project_is_still_a_project_mutation(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_symlink_escape"
    external = tmp_path.parent / f"{tmp_path.name}-symlink-target"
    external.mkdir()
    try:
        os.symlink(external, tmp_path / "escape", target_is_directory=True)
    except (NotImplementedError, OSError) as exc:
        pytest.skip(f"directory symlink is unavailable: {exc}")

    payload = _run_profiled_nodes(
        tmp_path,
        """import os


def test_symlink_escape():
    with open(os.path.join("escape", "outside.txt"), "w", encoding="utf-8") as handle:
        handle.write("bounded")
    os.remove(os.path.join("escape", "outside.txt"))
""",
        (nodeid,),
    )

    reasons = set(payload.get("uncertainties", {}).get(nodeid, []))
    assert "project-filesystem-mutation:open" in reasons
    assert "project-filesystem-mutation:os.remove" in reasons


def test_integer_fd_write_requires_stable_linux_procfs_identity(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_integer_fd_write"
    ephemeral = tmp_path.parent / f"{tmp_path.name}-external-tmp"
    payload = _run_profiled_nodes(
        tmp_path,
        """import os
import tempfile


def test_integer_fd_write():
    node_tmp = os.environ["ZERORUN_TEST_NODE_TMP"]
    os.environ["TMPDIR"] = node_tmp
    os.environ["TEMP"] = node_tmp
    os.environ["TMP"] = node_tmp
    tempfile.tempdir = node_tmp
    path = os.path.join(node_tmp, "descriptor.txt")
    descriptor = os.open(path, os.O_CREAT | os.O_WRONLY, 0o600)
    try:
        with open(descriptor, "w", closefd=False) as handle:
            handle.write("descriptor")
    finally:
        os.close(descriptor)
        os.remove(path)
""",
        (nodeid,),
        ephemeral_root=ephemeral,
    )

    reasons = set(payload.get("uncertainties", {}).get(nodeid, []))
    rows = payload.get("filesystem_mutations", {}).get(nodeid, [])
    if sys.platform == "linux":
        assert "unscoped-filesystem-mutation:open" not in reasons
        assert any(
            row[0] == "open"
            and row[1] == "ephemeral"
            and "#" in row[2]
            for row in rows
        )
    else:
        assert "unscoped-filesystem-mutation:open" in reasons


@pytest.mark.skipif(sys.platform != "linux", reason="requires Linux procfs")
@pytest.mark.parametrize("close_before_wrap", [False, True])
def test_deleted_or_closed_fd_cannot_borrow_ephemeral_path_authority(
    tmp_path: Path,
    close_before_wrap: bool,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_unstable_fd"
    ephemeral = tmp_path.parent / f"{tmp_path.name}-external-tmp"
    payload = _run_profiled_nodes(
        tmp_path,
        f"""import os
import tempfile


def test_unstable_fd():
    node_tmp = os.environ["ZERORUN_TEST_NODE_TMP"]
    os.environ["TMPDIR"] = node_tmp
    os.environ["TEMP"] = node_tmp
    os.environ["TMP"] = node_tmp
    tempfile.tempdir = node_tmp
    path = os.path.join(node_tmp, "unstable-descriptor.txt")
    descriptor = os.open(path, os.O_CREAT | os.O_WRONLY, 0o600)
    os.remove(path)
    if {close_before_wrap!r}:
        os.close(descriptor)
    try:
        with open(descriptor, "w", closefd=False) as handle:
            handle.write("must not gain authority")
    except OSError:
        pass
    finally:
        if not {close_before_wrap!r}:
            os.close(descriptor)
""",
        (nodeid,),
        ephemeral_root=ephemeral,
    )

    reasons = set(payload.get("uncertainties", {}).get(nodeid, []))
    assert "unscoped-filesystem-mutation:open" in reasons


@pytest.mark.skipif(sys.platform != "linux", reason="requires Linux procfs")
def test_reused_fd_resolving_to_project_cannot_borrow_old_temp_identity(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_reused_fd"
    ephemeral = tmp_path.parent / f"{tmp_path.name}-external-tmp"
    (tmp_path / "project-descriptor.txt").write_text("project", encoding="utf-8")
    payload = _run_profiled_nodes(
        tmp_path,
        """import os
import tempfile


def test_reused_fd():
    node_tmp = os.environ["ZERORUN_TEST_NODE_TMP"]
    os.environ["TMPDIR"] = node_tmp
    os.environ["TEMP"] = node_tmp
    os.environ["TMP"] = node_tmp
    tempfile.tempdir = node_tmp
    temp_path = os.path.join(node_tmp, "old-descriptor.txt")
    old_descriptor = os.open(temp_path, os.O_CREAT | os.O_WRONLY, 0o600)
    os.close(old_descriptor)
    os.remove(temp_path)
    project_descriptor = os.open("project-descriptor.txt", os.O_WRONLY)
    if project_descriptor != old_descriptor:
        os.dup2(project_descriptor, old_descriptor)
        os.close(project_descriptor)
        project_descriptor = old_descriptor
    try:
        with open(project_descriptor, "w", closefd=False) as handle:
            handle.write("changed")
    finally:
        os.close(project_descriptor)
""",
        (nodeid,),
        ephemeral_root=ephemeral,
    )

    reasons = set(payload.get("uncertainties", {}).get(nodeid, []))
    assert "project-filesystem-mutation:open" in reasons


def test_dir_fd_mutation_is_unclassifiable_and_remains_fresh(
    tmp_path: Path,
) -> None:
    if os.name == "nt":
        pytest.skip("dir_fd mutation APIs are not available on Windows")
    nodeid = "test_profiler_adversarial.py::test_dir_fd"
    payload = _run_profiled_nodes(
        tmp_path,
        """import os


def test_dir_fd():
    descriptor = os.open(".", os.O_RDONLY)
    try:
        os.mkdir("dirfd-created", dir_fd=descriptor)
        os.rmdir("dirfd-created", dir_fd=descriptor)
    finally:
        os.close(descriptor)
""",
        (nodeid,),
    )
    reasons = set(payload.get("uncertainties", {}).get(nodeid, []))
    assert "unscoped-filesystem-mutation:os.mkdir" in reasons
    assert "unscoped-filesystem-mutation:os.rmdir" in reasons


def test_unrestored_external_chdir_and_managed_thread_fail_closed(
    tmp_path: Path,
) -> None:
    nodeid = "test_profiler_adversarial.py::test_unrestored_cwd"
    ephemeral = tmp_path.parent / f"{tmp_path.name}-external-tmp"
    payload = _run_profiled_nodes(
        tmp_path,
        """import os
import tempfile
import threading


def test_unrestored_cwd():
    node_tmp = os.environ["ZERORUN_TEST_NODE_TMP"]
    os.environ["TMPDIR"] = node_tmp
    os.environ["TEMP"] = node_tmp
    os.environ["TMP"] = node_tmp
    tempfile.tempdir = node_tmp
    isolated = os.path.join(node_tmp, "zerorun-cwd")
    os.mkdir(isolated, 0o777)
    worker = threading.Thread(target=lambda: open(os.path.join(isolated, "x"), "w").close())
    worker.start()
    worker.join()
    os.chdir(isolated)
""",
        (nodeid,),
        ephemeral_root=ephemeral,
    )
    reasons = set(payload.get("uncertainties", {}).get(nodeid, []))
    assert "cwd-not-restored-at-node-completion" in reasons
