# ZeroRun v0.5.1

## Current delivery: start here

The current two-part handoff is [HANDOFF.md](HANDOFF.md). The journal article is
**ZeroRun: Validated Test-Result Reuse for AI Coding Workflows**, prepared for
Software Quality Journal; its [manuscript and reproducible evidence](research/sqj/README.md)
supersede the earlier research-direction proposals below. The reviewer archive
is [Online Resource 1](output/submission/ESM_1.zip). Jishan Kapoor is the sole
human author, with substantive AI assistance disclosed in the manuscript.

The optimized runtime core is commit `86f4228`. It completed the five-version
Linux regression matrix, fresh Windows regression, 200 revision comparisons,
10 adverse checks, and the 100-repository Codex interface smoke (99 integrations,
one safe refusal, zero failures). The paper separately measures whole-task
reuse with fresh controls. These are distinct evidence sets, not 100 upstream
test suites or AI coding episodes. The unchanged commercial 5x/50% performance
gate remains unmet; this is an MIT-licensed engineering/research distribution,
not a promoted performance-qualified commercial release.

The delivery distributions include this updated documentation and the unchanged
tested runtime sources. All research results, package identities, and current
entry points are reconciled in the handoff. The baseline/remediation and
pre-release passages below are preserved historical snapshots, not the latest
measurement or the active paper plan. Operating-mode and installation sections
remain the implementation guide.

## Preserved baseline description and release history

ZeroRun is a fail-closed deterministic test-result reuse layer for coding agents and CI. It can expose repository-bound test operations to Codex through a project skill and a local stdio MCP server.

This repository has two deliberately separate evidence tracks:

1. **Research:** a bounded empirical report and artifact package under [`research/`](research/), with Jishan Kapoor as sole author. The adopted next-paper route is an automated, no-user safety/applicability/cost study; see the [direction decision](research/DIRECTION_DECISION_2026-09-06.md). The original larger protocol is preserved as an unrun prospective extension. Its frame/ranking, dispatcher, analysis, and validation software is synthetically tested, but real corpus/baseline/oracle execution and independent reproduction remain incomplete.
2. **Code and commercial engineering:** the runtime, Codex integration, release controls, and a separate 100-repository non-executing compatibility smoke under [`commercial/`](commercial/).

## Evaluated baseline and current remediation

The exact `21cecc7` v0.5.1 baseline completed its [100-repository Codex smoke](https://github.com/floxy-21/zerorun-mvp/actions/runs/34010011313): 99 completed integrations, one proved safe refusal, and zero failures. This did not execute those repositories' upstream tests. Its separate [full-product run](https://github.com/floxy-21/zerorun-mvp/actions/runs/34010011323) failed: all five workloads missed the unchanged performance gate, and Packaging exposed a negative-plugin compatibility error. The exact raw performance receipt and complete adverse outcomes are archived in [`docs/evidence/21cecc7/`](docs/evidence/21cecc7/).

Subsequent source changes address that compatibility error, an import-attribution safety defect, and qualification overhead. They do not inherit the baseline's measurements. This is still a release candidate, not a qualified 5x product or a submission-ready top-journal study; only new exact-source receipts can establish the changed implementation's results.

## Pre-release truth and evidence cutoff

The release-status statements below are a 2026-09-05 pre-qualification snapshot.
They do not pre-claim the final workflow outcome; after promotion, the immutable
exact-commit release receipts govern release status while the historical evidence
boundaries below remain unchanged.

- The source tree is versioned **`0.5.1`**. It remains an engineering-MVP release candidate until the exact final `main` commit passes every mandatory gate; repository and package benchmarks do not constitute customer-demand or revenue proof.
- v0.5 adds a managed Codex skill, a repository-bound seven-tool MCP server, explicit setup approval, externally authenticated review authority, reviewed pytest-node profiles, and conservative observation-only onboarding.
- The frozen v0.4 internal qualification remains historical evidence for the exact v0.4 implementation. It is not automatically inherited by v0.5.
- The unchanged v0.5.1 release gate requires **at least 5.0x end-to-end speedup and at least 50% p95 reduction independently on every frozen workload**, with all safety checks passing. At this evidence cutoff, no exact-final-commit v0.5.1 receipt has demonstrated that gate; a miss blocks release and may not be hidden by averaging workloads, lowering thresholds, or changing the denominator after measurement.
- At frozen v0.5.0 commit `cd97eb55727a41e20354c9a8c9747c28dae525a6`, the five-repository campaign was 0.897281x direct in aggregate (11.448% slower) with 7.381% node reuse. Five of 100 transitions were full hits and all five exceeded 5x (14.261x median, 15.362x maximum); all 13 partial-hit transitions were slower. These are bounded, mechanically activated formative results and do not transfer to 0.5.1; see [`commercial/TESTING_AND_100_REPOS.md`](commercial/TESTING_AND_100_REPOS.md).
- ZeroRun has no external-user, retention, willingness-to-pay, or pricing evidence. Engineering readiness is not commercial validation.
- A deterministic compatibility selection containing 100 distinct repositories from 96 GitHub owners is frozen at digest `c3ecd05a6a5432c55bac1ba3eff3f448e10b778572b1b11ab2760709d0509061`. For exact v0.5.0, run `33949630904` attempted all 100 identities: 99 integrations completed, one was safely refused with proof, and zero failed. This smoke checked installation/layout, Codex CLI registration, and direct MCP protocol behavior; it did not execute upstream code, run a Codex agent episode, measure correctness/speed, or validate users or demand. Version 0.5.1 requires its own rerun.
- Real Codex-agent lifecycle testing is a separate deterministic synthetic-fixture harness. It cannot turn the 100-repository layout smoke into arbitrary-repository, agent-effectiveness, or commercial evidence, and the exact final candidate still needs its own bound receipt.
- Exact v0.5.0 passed complete Windows and Ubuntu 26.04/WSL suites and immutable main/package/Codex registration-protocol gates. The 0.5.1 candidate must pass the same gates before its release evidence is published; historical results are not silently inherited.

## Operating modes

| Mode | Configuration | Behavior |
| --- | --- | --- |
| Codex observation only | No externally authorized manifest/profile | MCP exposes diagnosis and readiness only. Run approved direct tests with Codex's normal test tooling, outside ZeroRun MCP. |
| Codex/MCP task reuse | Exact `.zerorun.json` v2 bytes reviewed and authorized outside the checkout | Reuses only an HMAC-provenanced successful result whose declared inputs and pinned Linux/amd64 OCI runtime identity are unchanged. |
| Codex/MCP pytest-node reuse | Exact manifest and activated `.zerorun-pytest.json` bytes externally authorized | Reuses only exact reviewed nodes with authenticated snapshot/cache provenance; unknown, changed, unsupported, or racing nodes execute fresh. |
| Legacy manifest v1 | A cacheable v1 task invoked directly from the CLI | Still accepted for CLI compatibility; executes a staged workspace on the host and may replay streams/regular-file outputs. MCP `run_tests` refuses v1. It is deprecated and outside the commercial v2 isolation claim. |

A cacheable legacy-v1 task must keep declared outputs outside every declared input path, directory, or glob. ZeroRun rejects such overlap because it would make the cache key self-referential and prevent a race-safe output commit.

A generated `.zerorun-pytest.candidate.json` never authorizes reuse. Codex/MCP activation requires an exact, completed operator review of closure completeness and node independence, followed by external per-user authorization of the exact manifest/profile bytes. Authority receipts and their HMAC key live outside the repository; every reusable cache/snapshot payload needs matching external HMAC provenance, and Git-tracked `.zerorun` runtime state is refused. Direct CLI execution remains an explicitly invoked trusted-operator path.

The legacy direct CLI `zerorun observe -- COMMAND...` is a trusted-operator-only compatibility helper: it runs the supplied command on the host without reuse or MCP approval enforcement. It is not an MCP tool and must not be exposed as a general agent interface. Legacy `observe_test` MCP calls hard-error.

Codex/MCP execution requires manifest v2, an empty task `env`, and an already-present digest-pinned image; normal MCP execution never pulls. It refuses legacy v1. Direct CLI v1 execution remains a trusted-repository-only compatibility path; do not treat it as Docker-isolated v2.

## Install from source

Python 3.10 or newer is required. Hermetic reuse and managed pytest setup require Docker Engine on Linux/amd64.

```bash
python -m pip install .
zerorun --version
```

Validate an existing reviewed task:

```bash
zerorun doctor
zerorun explain TASK
zerorun run TASK
zerorun run TASK --verify
```

`--verify` executes fresh and quarantines conflicting cached evidence. Do not weaken a closure, runtime pin, or safety setting to obtain a hit.

## Connect Codex

Run this from a Git repository with both `zerorun` and the Codex CLI on `PATH`:

```bash
zerorun --json init --codex --root .
codex mcp get zerorun --json
```

Initialization installs the managed project skill at `.agents/skills/zerorun/SKILL.md` and registers the local stdio MCP server. It refuses to overwrite a user-authored skill, write through a symbolic-link path, replace a different `zerorun` MCP registration, initialize outside a Git repository, or execute a ZeroRun/Codex launcher resolved inside the target repository. Restart or refresh the local Codex client after registration, then open a new session so it reloads the MCP and skill catalogs.

Before reuse, review the exact configuration digest reported by MCP `doctor` and store authority outside the checkout:

```bash
zerorun authorize --manifest-sha256 MANIFEST_SHA256
```

For pytest-node reuse, also pass `--pytest-profile-sha256 PROFILE_SHA256` after activating and reviewing the exact profile. Any byte change invalidates the matching authority.

The seven MCP tools are `prepare_pytest`, `run_pytest`, `run_tests`, `stats`, `explain`, `doctor`, and `list_tasks`. Only `prepare_pytest` may acquire a runtime or create setup files, and it requires explicit approval. Normal MCP execution never pulls and only executes environment-free v2 tasks in digest-pinned Linux/amd64 Docker. The server binds to its startup repository and rejects access to another repository.

See [`commercial/INSTALLATION_AND_CODEX.md`](commercial/INSTALLATION_AND_CODEX.md) for onboarding and the [official Codex MCP documentation](https://learn.chatgpt.com/docs/extend/mcp) for Codex configuration behavior.

## Supported safety boundary

Reusable v2 work remains intentionally narrow:

- Linux/amd64 and an immutable OCI image reference pinned by digest;
- verified Docker image identity included in the action key;
- no network during test execution;
- read-only checkout, with `.git` and `.zerorun` hidden;
- dropped Linux capabilities, `no-new-privileges`, 2 CPU/2 GiB/no-swap/512-PID limits, a 900-second execution timeout, and bounded temporary writable `/tmp`;
- deterministic, result-only targets with no artifact or stream replay;
- explicit operator-reviewed source closure;
- external per-user authority plus HMAC provenance bound to the canonical checkout and exact manifest/profile bytes;
- local per-project state, publication locking, integrity checks, tracked-state refusal, and quarantine on conflict;
- bounded descriptors, JSON-RPC input, output tails, evidence, node/count/depth structures, and execution time;
- normal checkouts and linked worktrees with regular `.git` directories/files; link, special, or dangling markers fail closed;
- fresh execution or safe refusal whenever evidence is incomplete or unsupported.

ZeroRun does not automatically prove source-closure completeness. Docker, the host, the operator review, the per-user account boundary, and the selected dependency supply chain remain trust boundaries. Same-user code executed on the host can access or replace that user's authority material and is outside this threat model. The full model is in [`commercial/SECURITY.md`](commercial/SECURITY.md).

## Evidence and documentation

- [`CHANGELOG.md`](CHANGELOG.md) — versioned product, security, and evidence-boundary changes.
- [`commercial/README.md`](commercial/README.md) — current v0.5 engineering and claim status.
- [`commercial/ARCHITECTURE.md`](commercial/ARCHITECTURE.md) — components, decisions, and data flow.
- [`commercial/MANIFEST_V2.md`](commercial/MANIFEST_V2.md) — reviewed task configuration reference.
- [`commercial/INSTALLATION_AND_CODEX.md`](commercial/INSTALLATION_AND_CODEX.md) — installation and Codex onboarding.
- [`commercial/TESTING_AND_100_REPOS.md`](commercial/TESTING_AND_100_REPOS.md) — layered gates and the exact meaning of the 100-repository smoke.
- [`commercial/RELEASE_RUNBOOK.md`](commercial/RELEASE_RUNBOOK.md) — finalization, release, rollback, and evidence rules.
- [`commercial/OPERATIONS.md`](commercial/OPERATIONS.md) — controlled-release support, data handling, rollback, uninstall, and incident response.
- [`commercial/COMMERCIAL_READINESS.md`](commercial/COMMERCIAL_READINESS.md) — allowed claims and the no-user-demand boundary.
- [`research/README.md`](research/README.md) — research-paper package and pending confirmatory study.
- [`evidence/v0.4.0/README.md`](evidence/v0.4.0/README.md) — immutable historical v0.4 evidence index.
- [`docs/ACCEPTANCE_EVIDENCE_V0.4.0.md`](docs/ACCEPTANCE_EVIDENCE_V0.4.0.md) — authoritative detailed v0.4 receipt.

## License

ZeroRun-owned code is available under the MIT license. See [`LICENSE.txt`](LICENSE.txt)
and [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md). Third-party dependencies,
upstream benchmark repositories, publisher templates, and historical artifacts
retain their own notices and terms. Open-source availability does not establish
release qualification or commercial demand.
