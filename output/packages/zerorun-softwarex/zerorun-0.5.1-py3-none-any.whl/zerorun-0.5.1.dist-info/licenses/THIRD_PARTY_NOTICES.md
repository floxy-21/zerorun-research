# License boundaries

ZeroRun-owned source and research code use the MIT license in LICENSE.txt. Licence.txt contains identical bytes for the journal template's alternate spelling.

The public trajectory evidence is from Nebius, SWE-rebench-OpenHands-Trajectories, https://huggingface.co/datasets/nebius/SWE-rebench-openhands-trajectories, observed revision 35455389ab51bf5e2306bfd436ef72d0f98bf882, retrieved 6 September 2026. It remains CC-BY-4.0, not MIT. Each collection preserves its source-notices/README.md and complete source-notices/LICENSE. Raw responses are unchanged; analyses are derived annotations. No endorsement is implied.

Upstream test workload source and dependencies retain their own licenses. Their project URLs, commits and dependency pins are recorded in research/sqj/run_frozen_campaign.py and evidence. Raw logs may contain short third-party source excerpts and retain that provenance; this release does not claim ownership of those excerpts. Dependencies and upstream repositories are not relicensed.

The standalone package declares no third-party runtime Python dependency. Building uses setuptools (MIT); running the research unit tests uses pytest (MIT) and its separately licensed dependencies. Docker, Git, Python, benchmark dependencies and optional Codex clients are separately installed tools.
