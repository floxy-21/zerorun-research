# Cover letter for author approval

Prepared for SoftwareX, Original Software Publication. This text has not been sent. Before submission, the author must approve the exact manuscript, verify the public code/evidence links in its metadata, and complete the declarations listed in `SUBMISSION_CHECKLIST.md`.

---

Dear Editors of SoftwareX,

Please consider "ZeroRun: Reproducible test-result reuse for AI coding tools" as an Original Software Publication.

ZeroRun is a Python execution component and evaluation kit for deterministic test-result reuse in AI coding-tool integrations. It gives researchers and tool developers a concrete way to distinguish a previous successful test status from fresh execution, test the declared input boundary, and measure whether avoided execution outweighs checking and miss costs. Command-line and repository-bound MCP interfaces expose this contract alongside isolated fresh execution.

The contribution combines an explicit result-origin interface, a whole-file hit path that avoids unnecessary execution staging, and source-bound validation tools. It is distinct in operating contract from feature/TTL-guided tool caching and trajectory-prefix caching in agent post-training: ZeroRun revalidates declared local test inputs and returns status metadata, without reconstructing arbitrary tool effects or transcripts. The article does not claim a new caching algorithm or language-model inference acceleration.

The evaluation separates controlled execution measurements from observations of public AI-agent trajectories. Independent input-inventory checks and fresh-oracle comparisons exercise changes, failures, repetitions, and restoration. Full-sequence costs are distinguished from favorable individual-hit timings. A fixed sample of 128 public episodes, including 122 with valid action/observation pairing, demonstrates why repeated command text cannot establish reuse eligibility: all 120 repeat pairs have intervening state uncertainty. These are not reported as agent cache hits. Raw measurements, exclusions, interrupted attempts, recovery records, and source-binding checks accompany the article.

The intended research application is reproducible evaluation of test-reuse decisions in coding-tool infrastructure. An integrator can configure a bounded target, inspect eligibility, consume a provenance-bearing result, request fresh diagnostics when needed, and compare total cost before enabling reuse. The article explains this workflow and provides runnable examples. This emphasis on reusable research software and its application is appropriate for SoftwareX; established adoption, commercial demand, and end-to-end AI task improvements are not asserted.

The submission now includes a complete operator guide and manifest reference, a checked client decision example, and a descriptive operating-region calculation using every completed replication block. Client evidence separates scripted response checks, the recorded Codex attempt, and a five-call non-model configuration diagnostic with a missing-authority control. The original failed client attempt is retained; the successful configuration diagnostic is not substituted for autonomous-agent validation. This makes both practical setup requirements and limits of the result-only interface inspectable.

The clean public research repository is https://github.com/floxy-21/zerorun-research. Its metadata identify the exact code version, installation requirements, and applicable licenses. Please assess this work as a bounded software contribution with reproducible operating examples and explicit limitations.

Thank you for considering the manuscript.

Jishan Kapoor  
Independent researcher  
Toronto, Canada  
kapoorjishan2@gmail.com

---

Author confirmation required before sending: final manuscript approval; originality and no concurrent consideration elsewhere; accurate funding and competing-interest disclosures; public artifact access and distribution rights; and the complete generative-AI disclosure. This prepared letter does not assert that those confirmations or journal submission have already occurred.
